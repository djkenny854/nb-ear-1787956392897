# Home feed polish: image flipping, video rail scroll, footer spacing, rail arrows 

## 1. Home product cards flip to images that aren't loaded yet

Current behaviour in `src/components/cards/HomeProductCard.tsx`: a preload effect fetches image 1, then the rest, and sets `allImagesReady`. Two things break it:

- An 8s failsafe force-sets `allImagesReady = true` even if the other images never finished — so rotation starts onto blank frames.
- The preload effect keys off the `images` array prop (new reference each render), so it restarts and can mark ready while later URLs are still in flight. Rotation is also all-or-nothing rather than per-image.

Fix:
- Track a `loadedIndexes` set: each preloaded URL marks its own index ready (using `img.decode()` where available, so the bitmap is truly paintable, not just downloaded).
- Paint the first image as soon as index 0 is decoded (unchanged UX: spinner → first image).
- Preload the remaining images in the background only after index 0 resolves, and only for cards that entered the viewport (existing `hasEnteredViewport` gate stays).
- Rotation only cycles through indexes present in `loadedIndexes`; if only index 0 is ready, the card simply never flips. Remove the blanket 8s failsafe (keep a failsafe only for the *first* image so the spinner can't hang).
- Failed images (error) are excluded from the rotation set entirely instead of being flipped to.
- Dot indicators reflect the rotatable set.

## 2. Short videos rail keeps auto-scrolling while the user scrolls

`src/components/sections/WatchAndBuy.tsx` runs a 3s round-robin that calls `rail.scrollTo(...)` to keep the active clip in view — this fights manual scrolling.

Fix:
- Add a `userInteracted` flag set on `pointerdown` / `touchstart` / `wheel` / manual `scroll` on the rail; while set, skip the auto `scrollTo` and pause the auto-advance interval.
- Resume auto-advance after a short idle window (about 6s with no interaction), or leave it stopped for the rest of the session on touch devices — resume-after-idle is the default.
- Also skip auto-advance when the rail is off-screen (IntersectionObserver), so it doesn't scroll while the user is elsewhere on the page.

## 3. Footer / bottom spacing

`src/components/Layout.tsx` applies an inline `paddingBottom: 5rem` to `<main>` on every breakpoint (the `md:pb-0` class is overridden by the inline style). That is the empty band below the footer on desktop.

Fix:
- Move the bottom padding to a CSS-variable/class driven value so it applies on mobile only (bottom nav height + safe-area inset) and is `0` from `md:` up. Desktop footer then sits flush at the extreme bottom.
- On mobile the reserved space stays, so `MinimalFooter` ends exactly where the bottom navigation begins with no overlap.
- Home page: drop the trailing `mt-6` wrapper gap around the footer so no extra scroll area is generated below it.

## 4. Arrow buttons for horizontal rails on pointer devices

All home sections use `overflow-x-auto` rails with no controls, so mouse users can't scroll them.

Fix:
- Add a small reusable `RailScroller` wrapper (`src/components/common/RailScroller.tsx`): renders its children rail plus left/right circular buttons, shown only on `(hover: hover) and (pointer: fine)` devices, auto-hidden when the rail is at its start/end, scrolling by ~85% of the visible width with smooth behaviour.
- Apply it to the home rails: `DealsSection`, `PopularNearYou`, `TrendingNow`, `WatchAndBuy`, `ContinueViewing`, `VerifiedSellers`, `ContentCarousel`, `CategoryQuickAccess`, `PersonalizedFeedSections`.
- Apply the same pattern to the horizontal rails in the social feed.

## Technical notes

- No database or edge-function changes; this is presentation and client logic only.
- Files touched: `HomeProductCard.tsx`, `WatchAndBuy.tsx`, `Layout.tsx`, `Home.tsx`, the section components listed above, plus one new `RailScroller` component.
- Data-saver mode keeps its current behaviour (single image, no rotation, no video autoplay).
