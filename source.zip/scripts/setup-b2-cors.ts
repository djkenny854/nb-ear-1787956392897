/**
 * One-shot script: enable CORS on the EarlyMarket B2 bucket so browsers can
 * PUT videos directly to Backblaze (no more shipping bytes through the edge
 * function).
 *
 * Run once with B2 credentials in env:
 *
 *   B2_APPLICATION_KEY_ID=... \
 *   B2_APPLICATION_KEY=... \
 *   B2_BUCKET_ID=... \
 *   bun run scripts/setup-b2-cors.ts
 *
 * Re-run any time you add a new origin (e.g. a new custom domain).
 */

const keyId = process.env.B2_APPLICATION_KEY_ID;
const appKey = process.env.B2_APPLICATION_KEY;
const bucketId = process.env.B2_BUCKET_ID;

if (!keyId || !appKey || !bucketId) {
  console.error("Missing B2_APPLICATION_KEY_ID / B2_APPLICATION_KEY / B2_BUCKET_ID");
  process.exit(1);
}

// B2 only accepts fully-qualified origins ("https://example.com") or "*".
// Subdomain wildcards and bare schemes are rejected. Use "*" so any
// Lovable preview / published / custom-domain host can upload — uploads
// are protected by short-lived per-file tokens issued by the upload-video
// edge function, so this is safe.
const allowedOrigins = ["*"];

async function main() {
  const authRes = await fetch("https://api.backblazeb2.com/b2api/v2/b2_authorize_account", {
    headers: { Authorization: "Basic " + Buffer.from(`${keyId}:${appKey}`).toString("base64") },
  });
  if (!authRes.ok) throw new Error("auth failed: " + (await authRes.text()));
  const auth = await authRes.json();

  const body = {
    accountId: auth.accountId,
    bucketId,
    corsRules: [
      {
        corsRuleName: "earlymarketBrowserUploads",
        allowedOrigins,
        allowedOperations: [
          "b2_upload_file",
          "b2_upload_part",
          "b2_download_file_by_name",
          "b2_download_file_by_id",
        ],
        allowedHeaders: [
          "authorization",
          "content-type",
          "x-bz-file-name",
          "x-bz-content-sha1",
          "x-bz-info-*",
          "x-bz-server-side-encryption",
        ],
        exposeHeaders: ["x-bz-file-id", "x-bz-content-sha1"],
        maxAgeSeconds: 3600,
      },
    ],
  };

  const updRes = await fetch(`${auth.apiUrl}/b2api/v2/b2_update_bucket`, {
    method: "POST",
    headers: { Authorization: auth.authorizationToken, "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const text = await updRes.text();
  if (!updRes.ok) throw new Error("update_bucket failed: " + text);
  console.log("CORS rule installed:");
  console.log(text);
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
