# Cloudflare CDN in front of Backblaze B2 — setup guide

This guide wires Cloudflare's free CDN in front of your Backblaze B2 bucket so
that videos and images on EarlyMarket are served from Cloudflare's edge
(faster) and B2 egress bandwidth becomes free (Bandwidth Alliance).

**You will need:**
- A domain on Cloudflare (free plan is enough). We assume `earlymarketug.com`.
- Your B2 bucket name (e.g. `earlymarket-videos`) and endpoint
  (`f005.backblazeb2.com`).
- About 20 minutes.

---

## 1. Add a CNAME for the CDN host

Cloudflare → DNS → Add record:

| Field | Value |
|---|---|
| Type | CNAME |
| Name | `cdn` |
| Target | `f005.backblazeb2.com` |
| Proxy status | **Proxied** (orange cloud ON) |
| TTL | Auto |

Resulting host: `cdn.earlymarketug.com` →  proxied → B2.

## 2. Rewrite the Host header so B2 accepts the request

B2 routes requests by `Host` header. When Cloudflare proxies, the incoming
host is `cdn.earlymarketug.com` and B2 returns 404. We rewrite it.

Cloudflare → Rules → **Origin Rules** → Create rule:

- Name: `B2 host rewrite`
- When incoming requests match: `Hostname equals cdn.earlymarketug.com`
- Then: `Set Host header` → `f005.backblazeb2.com`

## 3. Cache aggressively

Cloudflare → Rules → **Cache Rules** → Create rule:

- Name: `Cache B2 assets`
- When incoming requests match: `Hostname equals cdn.earlymarketug.com`
- Then:
  - Cache eligibility: **Eligible for cache**
  - Edge TTL: **Override origin** → `30 days`
  - Browser TTL: `7 days`
  - Cache key: include URL path only (ignore query string for cache hits, OR
    include if you plan to use signed query params later — see step 6).

## 4. Test

1. Old direct URL (still works, no CDN):
   `https://f005.backblazeb2.com/file/earlymarket-videos/videos/.../sample.mp4`
2. New CDN URL (same path, new host):
   `https://cdn.earlymarketug.com/file/earlymarket-videos/videos/.../sample.mp4`

Open the CDN URL in a browser. Inspect the response header `cf-cache-status`.
First hit will be `MISS` or `EXPIRED`; refresh and you should see `HIT`.

## 5. Tell EarlyMarket to use the CDN host

Add an environment variable in **Supabase → Project Settings → Edge
Functions → Secrets**:

```
CDN_BASE_URL = https://cdn.earlymarketug.com/file/earlymarket-videos
```

And in your Lovable project's frontend env (`.env`):

```
VITE_CDN_BASE_URL=https://cdn.earlymarketug.com/file/earlymarket-videos
```

After this, every new video upload returns a CDN URL, and existing videos are
rewritten on the fly by the `cdnUrl()` helper in `src/utils/cdnUrl.ts`.

## 6. (Optional) Hotlink protection

Cloudflare → Security → WAF → **Custom rules** → Create rule:

- Name: `Block external hotlinking of media`
- Expression:
  ```
  (http.host eq "cdn.earlymarketug.com")
  and (not http.referer contains "earlymarketug.com")
  and (not http.referer contains "lovable.app")
  and (http.request.uri.path matches ".*\\.(mp4|webm|mov|jpg|jpeg|png|webp)$")
  ```
- Action: **Block**

This stops other sites from `<video src="cdn.earlymarketug.com/...">`. It does
**not** stop a determined user from copying the URL — see the next doc for
signed URLs.

## What this does NOT solve

- **Adaptive bitrate / low-bandwidth playback.** B2 stores a single MP4. To
  serve multiple resolutions you need a transcoder. The recommended path is
  Cloudflare Stream (different product, $5/1000 min stored + $1/1000 min
  delivered). See `docs/CLOUDFLARE_STREAM_MIGRATION.md` (TBD) for when to
  switch.
- **Truly undownloadable video.** Browsers must be able to fetch the bytes to
  play the video, so anyone can capture them. The best you can do on the open
  web is signed short-lived URLs (next doc) plus segmented HLS (Cloudflare
  Stream). Even X / TikTok cannot prevent screen recording.

## Where else to put a CDN?

| Asset | Where it lives now | Action |
|---|---|---|
| App JS/CSS bundles | Vercel | Already on Vercel CDN, do nothing |
| Logos/badges in `src/assets/*` | Bundled by Vite, hashed | Already cached, do nothing |
| Files in `public/*` | Vercel | Already on Vercel CDN, do nothing |
| User avatars | Supabase Storage | Already CDN-fronted by Supabase, do nothing |
| **Listing photos in B2** | B2 direct | **Move to `cdn.earlymarketug.com`** |
| **Listing videos in B2** | B2 direct | **Move to `cdn.earlymarketug.com`** |

Only the last two need work. The rest are fine.
---

## Browser → B2 direct uploads (CORS)

Wizards now PUT video files directly from the browser to B2 (the edge function
only hands out a short-lived upload URL). For this to work the bucket must
allow CORS from our origins. Run the one-shot script once per environment:

```sh
B2_APPLICATION_KEY_ID=... \
B2_APPLICATION_KEY=... \
B2_BUCKET_ID=... \
bun run scripts/setup-b2-cors.ts
```

Re-run it whenever a new origin (custom domain, native shell scheme) is added.

---

## Progressive video streaming (separate worker)

The signed-URL worker above serves images and one-off downloads. **For video
playback** the app uses a second worker on `videos.earlymarketug.com` that
forwards HTTP `Range` requests to B2 and adds long-lived edge caching, so
playback starts after the first ~2MB instead of waiting for the full file.

See `docs/CLOUDFLARE_VIDEO_WORKER.md` and `cloudflare/video-worker/` for the
code and deploy steps.
