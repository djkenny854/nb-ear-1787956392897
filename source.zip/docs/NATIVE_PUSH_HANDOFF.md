# EarlyMarket — Native Push & Safe-Area Handoff Prompt (for Antigravity)

Give this whole file to Antigravity in your local Android project. Lovable has already done:

- Created `device_tokens` table + trigger that fires `send-push` after every `notifications` insert.
- Deployed `send-push` edge function (FCM HTTP v1) with secrets `FCM_PROJECT_ID`, `FCM_CLIENT_EMAIL`, `FCM_PRIVATE_KEY` already set.
- Wired `useCapacitorPushNotifications` to register + store tokens + route taps by `data.path`.
- Generated `src/assets/ic_notification.png` (monochrome white silhouette).
- Added a safe-area nudge loop that forces window insets to settle at cold start.

---

## What Antigravity must do locally

### 1. Firebase setup
1. In Firebase Console → Project settings → Your apps → add Android app with package `com.earlymarketug.app`.
2. Download `google-services.json` and place it at `android/app/google-services.json`.
3. In Firebase Console → Project settings → Service accounts → Generate new private key. That JSON gives you `client_email` and `private_key`. (Already saved in Lovable secrets — no action needed unless you rotate.)

### 2. Gradle changes

**`android/build.gradle`** — add classpath in the `dependencies` block of `buildscript`:
```gradle
classpath 'com.google.gms:google-services:4.4.2'
```

**`android/app/build.gradle`** — at the bottom of the file add:
```gradle
apply plugin: 'com.google.gms.google-services'
```
And in `dependencies`:
```gradle
implementation platform('com.google.firebase:firebase-bom:33.5.1')
implementation 'com.google.firebase:firebase-messaging'
```

### 3. Notification icon
Convert `src/assets/ic_notification.png` into the standard Android drawable sizes and drop into:
```
android/app/src/main/res/drawable-mdpi/ic_notification.png       (24x24)
android/app/src/main/res/drawable-hdpi/ic_notification.png       (36x36)
android/app/src/main/res/drawable-xhdpi/ic_notification.png      (48x48)
android/app/src/main/res/drawable-xxhdpi/ic_notification.png     (72x72)
android/app/src/main/res/drawable-xxxhdpi/ic_notification.png    (96x96)
```
(Use Android Studio → Image Asset → Notification Icons, or ImageMagick.)

### 4. AndroidManifest.xml
Inside `<application>`:
```xml
<meta-data
    android:name="com.google.firebase.messaging.default_notification_icon"
    android:resource="@drawable/ic_notification" />
<meta-data
    android:name="com.google.firebase.messaging.default_notification_color"
    android:resource="@color/notification_color" />
<meta-data
    android:name="com.google.firebase.messaging.default_notification_channel_id"
    android:value="default" />
```

Add `android/app/src/main/res/values/colors.xml`:
```xml
<color name="notification_color">#F97316</color>
```

### 5. Default notification channel
In `MainActivity.java`'s `onCreate`, before `super.onCreate`:
```java
if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
    android.app.NotificationChannel channel = new android.app.NotificationChannel(
        "default", "General", android.app.NotificationManager.IMPORTANCE_HIGH);
    channel.setDescription("EarlyMarket notifications");
    channel.enableVibration(true);
    android.app.NotificationManager nm = getSystemService(android.app.NotificationManager.class);
    if (nm != null) nm.createNotificationChannel(channel);
}
```

### 6. Safe-area / edge-to-edge fix
In `MainActivity.java` `onCreate` (after `super.onCreate`):
```java
androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(
    getWindow().getDecorView(),
    (v, insets) -> {
        // Dispatch to WebView so env(safe-area-inset-*) becomes non-zero
        // BEFORE the first frame paints. This kills the cold-start bug where
        // content sat under the status/nav bar until Google Sign-In triggered
        // a relayout.
        return insets;
    });
```

### 7. Sync & build
```bash
git pull
npm install
npx cap sync android
npx cap open android
# Build & Run
```

---

## Testing checklist
- Sign in → app requests notification permission.
- Kill the app. From another account, send a message / like a product.
- Notification appears in the tray with white bag icon on orange background.
- Swipe/expand → "Reply" and "Mark read" buttons visible on message pushes.
- Tap → app opens at `/messages/<thread_id>` (or the correct deep-link path).
- Open app fresh → status bar and gesture nav bar do NOT overlap content.

## Quick actions currently supported
- **message** → Reply, Mark read
- **follow** → View profile
- **like / bookmark** → View
- **job_application** → View
- **default** → Open

Reply-with-inline-text is not wired yet (needs `RemoteInput` in a custom `FirebaseMessagingService`). Ask if you want that added.

---

## 8. Gap audit — what is still missing for native Android (Feb 2026)

Everything below lives in the **local Android project**; it cannot be done from Lovable.

### 8.1 Plugins to install
```bash
npm i @capacitor/push-notifications @capacitor/local-notifications @capacitor/microphone
npx cap sync android
```
`@capacitor/microphone` is optional but recommended — the app calls it (dynamic
import, safely skipped when absent) to request the OS mic permission *before*
`getUserMedia`, which is why voice notes currently fail in the APK.

### 8.2 AndroidManifest permissions (root `<manifest>` level)
```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />   <!-- Android 13+ -->
<uses-permission android:name="android.permission.RECORD_AUDIO" />          <!-- voice notes -->
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
<uses-permission android:name="android.permission.VIBRATE" />
<uses-feature android:name="android.hardware.microphone" android:required="false" />
```
Without `RECORD_AUDIO` the WebView rejects `navigator.mediaDevices.getUserMedia`
with `NotAllowedError` even when the in-app permission dialog says granted —
this is the root cause of "voice notes don't work in the app".

### 8.3 WebView must grant the media capture request
Capacitor's `BridgeWebChromeClient` forwards `onPermissionRequest`, but only for
permissions the app itself already holds. Confirm in `MainActivity.java`:
```java
@Override
public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  if (android.os.Build.VERSION.SDK_INT >= 23 &&
      checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
        != android.content.pm.PackageManager.PERMISSION_GRANTED) {
    requestPermissions(new String[]{ android.Manifest.permission.RECORD_AUDIO }, 9001);
  }
}
```

### 8.4 Notification coverage
Every row inserted into `public.notifications` fires the `fire_push_on_notification`
trigger → `send-push` edge function, so **all** in-app notification types already
map to an Android tray notification: new message, new follower, new ad from a
followed seller, ad boosted/approved/rejected, application received/updated,
review received, post liked, post commented, bookmark, voice note, shared post,
payment completed, verification approved/rejected, new order.
Nothing extra is needed per-type; the payload carries `data.path`, and
`useCapacitorPushNotifications` navigates to it on tap (so tapping a message
notification opens that exact chat).

### 8.5 Runtime permission prompt (Android 13+)
`PushNotifications.requestPermissions()` is already called after sign-in and in
the onboarding "Grant notification access" step. If the user declines, Android
never re-prompts — the app must deep-link to system settings instead.

### 8.6 Verification steps
1. `adb shell dumpsys package com.earlymarketug.app | grep -A5 "runtime permissions"` → RECORD_AUDIO and POST_NOTIFICATIONS granted.
2. Record a voice note in a chat → uploads to `voice-recordings` bucket.
3. Kill app, receive a message from another account → tray notification → tap opens the thread.
