# Cloudflare video worker (progressive playback for B2 videos)

This is the production setup that makes videos in the app start playing in
~1 second on a normal mobile connection instead of waiting for the full file
to download. See `cloudflare/video-worker/` for the worker source and
`README.md` for deploy steps.

## Why we need it

The B2 origin URL works for downloads but is slow for streaming:

- Cloudflare doesn't cache it (cross-origin), so every play hits B2 in the US.
- B2 honors `Range` requests, but without a long edge cache every viewer pays
  the full round-trip on the first byte.
- The browser falls back to "download the whole file before playing" if any
  of the response headers (Accept-Ranges, Content-Type) are missing.

The worker sits on `videos.earlymarketug.com`, forwards Range requests
verbatim to B2, normalises the response headers, and asks Cloudflare to
`cacheEverything` with a 1-year TTL. After the first viewer in Uganda fetches
a video, every subsequent viewer in the region gets it from the nearest
Cloudflare edge with zero B2 round-trip.

## End-to-end request flow

```text
browser  ──Range: bytes=0-2097152──▶  videos.earlymarketug.com (worker)
                                         │
                                         ├─ cache HIT  ──▶ 206 Partial Content from edge
                                         │
                                         └─ cache MISS ──▶ B2 origin ──▶ 206 + cached at edge
browser  ◀── 206 + Content-Range ────────┘
```

## App integration

1. Deploy the worker (see `cloudflare/video-worker/README.md`).
2. Add `VITE_VIDEO_CDN_BASE_URL=https://videos.earlymarketug.com` to `.env`.
3. The app uses `videoCdnUrl()` from `src/utils/cdnUrl.ts` everywhere a video
   `src` is rendered (`SmartVideo`, `VideoFeedCard`, `XStyleVideoCard`,
   `ReelVideoPlayer`, `AdaptiveMedia`, `ServiceUpdateCard`,
   `ServicePortfolioGallery`, `SellerMediaTab`, `VideoPlayer`, etc.).
4. New uploads land in B2 via `uploadVideoToB2`; the returned URL is rewritten
   to the worker URL before being stored in the DB. No migration needed for
   existing rows — `videoCdnUrl()` rewrites legacy
   `cdn.earlymarketug.com/file/<bucket>/...` and raw B2 URLs on the fly.

## Player guarantees (`src/components/media/SmartVideo.tsx`)

- Container is always solid black to prevent white flashes.
- `poster` (or `blurThumbnail`) shows until the first real frame is ready.
- `<video>` starts at `opacity: 0`, fades to `1` over 300ms on `canplay`.
- `preload="metadata"` until the card is ≥60% visible; flipped to `auto` and
  `load()` is called only then.
- `play()` runs inside `canplaythrough` so the buffer is large enough to play
  without stalling.
- Leaving the viewport pauses and drops back to `preload="none"`.
- The browser's default grey play UI is never visible (no missing poster, no
  control surface in feed mode).

## Upload pipeline (already in place)

`src/utils/videoCompression.ts` already passes `-movflags +faststart` to
ffmpeg.wasm so the `moov` atom is at the start of every encoded MP4 — that's
what lets the browser start playing after the first few KB.

## Out of scope

The existing signed-URL worker on `cdn.earlymarketug.com` (see
`CLOUDFLARE_WORKER_SIGNED_URLS.md`) is untouched. Public videos go through the
new `videos.` subdomain; signed/private content keeps using the existing path.