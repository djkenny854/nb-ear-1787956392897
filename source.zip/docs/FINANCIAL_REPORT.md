# EarlyMarket â Financial Accountability Report

> Last updated: April 2026

---

## 1. Currently Active Platforms & Monthly Costs

| Platform | Purpose | Tier | Monthly Cost (USD) | Notes |
|----------|---------|------|-------------------|-------|
| **Supabase** | Database, Auth, Storage, Edge Functions, Realtime | Free â Pro | **$0 â $25** | Free tier: 500MB DB, 1GB storage, 500K edge invocations. Pro tier recommended for production. |
| **OpenAI API** (via Lovable AI Gateway) | Embeddings (`text-embedding-3-small`), AI product analyzer | Usage-based | **~$1 â $5** | ~$0.02 per 1M tokens. At ~1000 ads/month with analysis: ~$2-3. |
| **Resend** | Transactional emails (verification, notifications) | Free â Pro | **$0 â $20** | Free: 100 emails/day, 3000/month. Pro: $20/mo for 50K emails. |
| **Backblaze B2** | Video file storage (`b2_video_url`) | Usage-based | **~$1 â $6** | $6/TB/month storage + $10/TB egress. Minimal at current scale. |

### Current Monthly Total: **$2 â $156/month**

- **Minimum (all free tiers):** ~$2/month (just OpenAI token costs)
- **Production recommended:** ~$50-70/month (Supabase Pro + Lovable Builder + low usage costs)
- **At scale:** ~$150+/month

---

## 2. Secrets & API Keys Currently Configured

| Secret Name | Platform | Status |
|-------------|----------|--------|
| `SUPABASE_URL` | Supabase | â Auto-configured |
| `SUPABASE_ANON_KEY` | Supabase | â Auto-configured |
| `SUPABASE_SERVICE_ROLE_KEY` | Supabase | â Configured |
| `RESEND_API_KEY` | Resend | â Configured |
| `B2_KEY_ID` / `B2_APP_KEY` | Backblaze B2 | â ï¸ Referenced in code, verify configuration |

---

## 3. Future Integrations Needed

### High Priority (Required for Launch)

| Platform | Purpose | Monthly Cost | Integration Effort |
|----------|---------|-------------|-------------------|
| **Flutterwave** | Payment processing (cards, mobile money) | 1.4% per transaction (no monthly fee) | Medium â SDK integration, webhook handling |
| **MTN MoMo API** | Mobile money payments (Uganda primary) | Per-transaction fees (~1-2%) | Medium â API integration, approval process required |
| **Airtel Money API** | Mobile money payments (Uganda) | Per-transaction fees (~1-2%) | Medium â Similar to MTN MoMo |
| **Custom Domain** | earlymarket.com or .ug | **$10 â $15/year** | Easy â DNS configuration |
| **SSL Certificate** | HTTPS (included with most hosting) | **$0** | Included with Supabase/Lovable |

### Medium Priority (Post-Launch)

| Platform | Purpose | Monthly Cost | Notes |
|----------|---------|-------------|-------|
| **Africa's Talking** | SMS verification, notifications | **$0 + $0.02/SMS** | Great African coverage, pay-per-use |
| **Twilio** (alternative) | SMS worldwide | **$0 + $0.05/SMS** | More expensive but global reach |
| **Firebase Cloud Messaging (FCM)** | Push notifications (Android) | **$0** | Free, already using Capacitor |
| **Apple Push Notification Service (APNs)** | Push notifications (iOS) | **$99/year** (Apple Developer) | Required for iOS app |
| **Cloudflare** | CDN for images/media delivery | **$0 â $20** | Free tier is generous, speeds up media loading |
| **Google Maps API** | Location services, store locator | **$0 â $200** | $200 free credit/month, then $7/1000 requests |

### Low Priority (Growth Phase)

| Platform | Purpose | Monthly Cost | Notes |
|----------|---------|-------------|-------|
| **Mixpanel / PostHog** | Advanced analytics | **$0 â $25** | Free tier available, useful for growth tracking |
| **Sentry** | Error monitoring | **$0 â $26** | Free tier: 5K errors/month |
| **Intercom / Crisp** | Customer support chat | **$0 â $25** | Crisp has free tier; Intercom starts at $74/mo |
| **SendGrid** (alternative to Resend) | High-volume email | **$0 â $20** | If email volume exceeds Resend limits |
| **AWS S3** (alternative to B2) | Media storage at scale | **$23/TB** | More expensive but more ecosystem tools |

---

## 4. Cost Projections by Scale

### Early Stage (0 â 1,000 users)
| Item | Cost/Month |
|------|-----------|
| Supabase Free | $0 |
| Lovable | $0 â $20 |
| OpenAI embeddings | ~$1 |
| Resend Free | $0 |
| **Total** | **~$1 â $21/month** |

### Growth Stage (1,000 â 10,000 users)
| Item | Cost/Month |
|------|-----------|
| Supabase Pro | $25 |
| OpenAI | ~$5 |
| Resend Pro | $20 |
| SMS (Africa's Talking) | ~$10 |
| CDN (Cloudflare Free) | $0 |
| **Total** | **~$80 â $110/month** |

### Scale Stage (10,000+ users)
| Item | Cost/Month |
|------|-----------|
| Supabase Pro + addons | $50 â $100 |
| OpenAI | ~$15 |
| Resend Business | $40 |
| SMS | ~$50 |
| CDN | $20 |
| Error monitoring | $26 |
| Analytics | $25 |
| **Total** | **~$326 â $376/month** |

---

## 5. Revenue Opportunities to Offset Costs

| Feature | Model | Potential Revenue |
|---------|-------|------------------|
| **Boost/Promote Listings** | Pay-per-boost ($1-5/day) | Primary revenue stream |
| **Verification Badge** | One-time or subscription fee | $5-10/month per verified seller |
| **Featured Seller** | Monthly subscription | $10-20/month |
| **Transaction Fees** | % of each sale (if payment integrated) | 2-5% per transaction |
| **Premium Analytics** | Seller dashboard upgrade | $5-15/month |

---

## 6. Edge Functions Currently Deployed

| Function | Purpose | External API Used |
|----------|---------|------------------|
| `semantic-search` | AI-powered search with embeddings | Lovable AI Gateway (OpenAI) |
| `generate-embedding` | Generate embeddings for new ads | Lovable AI Gateway (OpenAI) |
| `backfill-embeddings` | Bulk embedding generation | Lovable AI Gateway (OpenAI) |
| `ai-analyze-product` | AI product analysis/suggestions | Lovable AI Gateway (OpenAI) |
| `send-email` | Transactional emails | Resend API |
| `send-notification` | Push notifications | FCM (future) |

---

*This report should be updated quarterly or whenever new integrations are added.*
