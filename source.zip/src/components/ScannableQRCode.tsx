// Backward-compatible wrapper around StyledQRCode
import React from 'react';
import StyledQRCode from '@/components/StyledQRCode';

interface ScannableQRCodeProps {
  value: string;
  size?: number;
  title?: string;
  subtitle?: string;
  showDownload?: boolean;
}

const ScannableQRCode: React.FC<ScannableQRCodeProps> = ({
  value,
  size = 240,
  title,
  subtitle,
  showDownload = true,
}) => {
  return (
    <StyledQRCode
      value={value}
      size={size}
      title={title}
      subtitle={subtitle}
      showDownload={showDownload}
    />
  );
};

export default ScannableQRCode;
