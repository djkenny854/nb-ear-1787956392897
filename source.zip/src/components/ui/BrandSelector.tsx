import React, { useState, useMemo } from 'react';
import { Check, ChevronsUpDown, Search, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { useBrands } from '@/hooks/useBrands';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';

interface BrandSelectorProps {
  value: string;
  onChange: (value: string) => void;
  category?: string;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}

const BrandSelector: React.FC<BrandSelectorProps> = ({
  value,
  onChange,
  category,
  placeholder = 'Select brand...',
  className,
  disabled,
}) => {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isCustom, setIsCustom] = useState(false);
  const [customBrand, setCustomBrand] = useState('');

  const { brands, loading } = useBrands({ category });

  const filteredBrands = useMemo(() => {
    if (!searchQuery) return brands;
    const query = searchQuery.toLowerCase();
    return brands.filter((brand) =>
      brand.name.toLowerCase().includes(query)
    );
  }, [brands, searchQuery]);

  const selectedBrand = useMemo(() => {
    return brands.find((b) => b.name === value);
  }, [brands, value]);

  const handleSelect = (brandName: string) => {
    onChange(brandName);
    setOpen(false);
    setSearchQuery('');
    setIsCustom(false);
  };

  const handleCustomBrand = () => {
    if (customBrand.trim()) {
      onChange(customBrand.trim());
      setIsCustom(false);
      setCustomBrand('');
      setOpen(false);
    }
  };

  if (isCustom) {
    return (
      <div className={cn('flex gap-2', className)}>
        <Input
          value={customBrand}
          onChange={(e) => setCustomBrand(e.target.value)}
          placeholder="Enter brand name..."
          className="flex-1"
          onKeyDown={(e) => {
            if (e.key === 'Enter') {
              e.preventDefault();
              handleCustomBrand();
            }
          }}
        />
        <Button
          type="button"
          size="sm"
          onClick={handleCustomBrand}
          disabled={!customBrand.trim()}
        >
          Add
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          onClick={() => setIsCustom(false)}
        >
          Cancel
        </Button>
      </div>
    );
  }

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className={cn('justify-between font-normal', className)}
          disabled={disabled || loading}
        >
          {value ? (
            <div className="flex items-center gap-2">
              {selectedBrand?.logo_url && (
                <Avatar className="h-5 w-5">
                  <AvatarImage src={selectedBrand.logo_url} alt={value} />
                  <AvatarFallback className="text-[10px]">
                    {value.charAt(0)}
                  </AvatarFallback>
                </Avatar>
              )}
              <span className="truncate">{value}</span>
            </div>
          ) : (
            <span className="text-muted-foreground">{placeholder}</span>
          )}
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[300px] p-0" align="start">
        <Command shouldFilter={false}>
          <div className="flex items-center border-b px-3">
            <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
            <input
              className="flex h-10 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
              placeholder="Search brands..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <CommandList>
            <CommandEmpty>
              <div className="py-4 text-center text-sm">
                <p className="text-muted-foreground mb-2">No brand found</p>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setIsCustom(true);
                    setCustomBrand(searchQuery);
                    setOpen(false);
                  }}
                  className="gap-1"
                >
                  <Plus className="h-3 w-3" />
                  Add "{searchQuery || 'custom brand'}"
                </Button>
              </div>
            </CommandEmpty>
            <CommandGroup>
              {filteredBrands.map((brand) => (
                <CommandItem
                  key={brand.id}
                  value={brand.name}
                  onSelect={() => handleSelect(brand.name)}
                  className="cursor-pointer"
                >
                  <div className="flex items-center gap-2 flex-1">
                    <Avatar className="h-6 w-6">
                      {brand.logo_url ? (
                        <AvatarImage src={brand.logo_url} alt={brand.name} />
                      ) : null}
                      <AvatarFallback className="text-[10px] bg-muted">
                        {brand.name.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <span>{brand.name}</span>
                    {brand.is_popular && (
                      <span className="text-[10px] text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
                        Popular
                      </span>
                    )}
                  </div>
                  <Check
                    className={cn(
                      'h-4 w-4',
                      value === brand.name ? 'opacity-100' : 'opacity-0'
                    )}
                  />
                </CommandItem>
              ))}
            </CommandGroup>
            <div className="border-t p-2">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="w-full justify-start gap-2"
                onClick={() => {
                  setIsCustom(true);
                  setOpen(false);
                }}
              >
                <Plus className="h-4 w-4" />
                Add custom brand
              </Button>
            </div>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};

export default BrandSelector;
