import React from 'react';
import { cn } from '@/lib/utils';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';

interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  /** Show the full branded spinner with logo (X.com style) */
  branded?: boolean;
}

/**
 * X.com-inspired spinner with logo center and stretching arc animation.
 * - Thin ring rotates around logo
 * - Ring stretches/contracts like X.com loading indicator
 */
const Spinner: React.FC<SpinnerProps> = ({ size = 'md', className, branded = false }) => {
  const sizeMap = {
    sm: { container: 'w-8 h-8', logo: 'w-4 h-4', ring: 16, stroke: 2 },
    md: { container: 'w-12 h-12', logo: 'w-6 h-6', ring: 24, stroke: 2 },
    lg: { container: 'w-16 h-16', logo: 'w-8 h-8', ring: 32, stroke: 2.5 },
    xl: { container: 'w-24 h-24', logo: 'w-12 h-12', ring: 48, stroke: 3 },
  };

  const s = sizeMap[size];

  if (!branded) {
    // Simple thin spinner without logo
    return (
      <div className={cn('inline-flex items-center justify-center', className)}>
        <svg
          className={cn(s.container, 'animate-spin')}
          viewBox="0 0 50 50"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <circle
            cx="25" cy="25" r="21"
            stroke="currentColor"
            strokeWidth={s.stroke}
            className="opacity-10"
          />
          <circle
            cx="25" cy="25" r="21"
            stroke="currentColor"
            strokeWidth={s.stroke}
            strokeLinecap="round"
            strokeDasharray="33 99"
            className="text-primary spinner-stretch"
          />
        </svg>
      </div>
    );
  }

  // Branded X.com-style spinner with logo center
  return (
    <div className={cn('inline-flex items-center justify-center relative', s.container, className)}>
      {/* Logo in center */}
      <img
        src={earlymarketLogo}
        alt=""
        className={cn(s.logo, 'absolute z-10 object-contain')}
      />
      {/* Rotating thin ring that stretches */}
      <svg
        className={cn('absolute inset-0', s.container, 'spinner-rotate')}
        viewBox="0 0 50 50"
        fill="none"
      >
        <circle
          cx="25" cy="25" r="22"
          stroke="hsl(var(--primary))"
          strokeWidth={s.stroke}
          strokeLinecap="round"
          className="spinner-stretch"
          style={{ fill: 'none' }}
        />
      </svg>
      
      {/* Inline styles for the stretch + rotate animation */}
      <style>{`
        .spinner-rotate {
          animation: spinnerRotate 1.4s linear infinite;
        }
        .spinner-stretch {
          stroke-dasharray: 1 138;
          animation: spinnerStretch 1.4s ease-in-out infinite;
          transform-origin: center;
        }
        @keyframes spinnerRotate {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        @keyframes spinnerStretch {
          0% {
            stroke-dasharray: 1 138;
            stroke-dashoffset: 0;
          }
          50% {
            stroke-dasharray: 70 138;
            stroke-dashoffset: -30;
          }
          100% {
            stroke-dasharray: 1 138;
            stroke-dashoffset: -124;
          }
        }
      `}</style>
    </div>
  );
};

export { Spinner };
