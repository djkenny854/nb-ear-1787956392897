import * as React from "react"
import { Drawer as DrawerPrimitive } from "vaul"
import { X } from "lucide-react"

import { cn } from "@/lib/utils"
import { isCapacitorNative } from "@/hooks/useCapacitor"

/**
 * Sets a body flag while any overlay is open so global CSS can pause
 * background skeleton animations during the slide-in (prevents jank).
 * Reference-counted to support nested/overlapping overlays.
 */
let overlayOpenCount = 0
export function useOverlayOpenFlag(open: boolean | undefined) {
  React.useEffect(() => {
    if (!open) return
    overlayOpenCount += 1
    document.body.dataset.overlayOpen = "true"
    return () => {
      overlayOpenCount = Math.max(0, overlayOpenCount - 1)
      if (overlayOpenCount === 0) delete document.body.dataset.overlayOpen
    }
  }, [open])
}

const Drawer = ({
  shouldScaleBackground,
  open,
  ...props
}: React.ComponentProps<typeof DrawerPrimitive.Root>) => {
  useOverlayOpenFlag(open)
  // Always disable page-scale — it forces a repaint of every element on
  // the page during the slide, which causes visible lag (especially on
  // pages full of skeletons or media).
  const scale = shouldScaleBackground ?? false
  return (
    <DrawerPrimitive.Root
      shouldScaleBackground={scale}
      open={open}
      {...props}
    />
  )
}
Drawer.displayName = "Drawer"


const DrawerTrigger = DrawerPrimitive.Trigger

const DrawerPortal = DrawerPrimitive.Portal

const DrawerClose = DrawerPrimitive.Close

const DrawerOverlay = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Overlay>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Overlay>
>(({ className, ...props }, ref) => (
  <DrawerPrimitive.Overlay
    ref={ref}
    className={cn("fixed inset-0 z-[200] bg-black/80", className)}
    {...props}
  />
))
DrawerOverlay.displayName = DrawerPrimitive.Overlay.displayName

const DrawerContent = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Content>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Content>
>(({ className, children, ...props }, ref) => (
  <DrawerPortal>
    <DrawerOverlay />
    <DrawerPrimitive.Content
      ref={ref}
      className={cn(
        "fixed inset-x-0 bottom-0 z-[200] mt-24 flex max-h-[85vh] flex-col rounded-t-3xl border bg-background",
        className
      )}
      {...props}
    >
      {/* Drag handle */}
      <div className="mx-auto mt-3 h-1.5 w-12 rounded-full bg-muted shrink-0" />
      {/* Close button */}
      <DrawerPrimitive.Close className="absolute right-3 top-3 rounded-full p-1.5 bg-muted/60 hover:bg-muted transition-colors z-10">
        <X className="h-4 w-4 text-muted-foreground" />
        <span className="sr-only">Close</span>
      </DrawerPrimitive.Close>
      {/* Scrollable content area */}
      <div className="flex-1 overflow-y-auto overscroll-contain">
        {children}
      </div>
    </DrawerPrimitive.Content>
  </DrawerPortal>
))
DrawerContent.displayName = "DrawerContent"

const DrawerHeader = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("grid gap-1.5 p-4 text-center sm:text-left", className)}
    {...props}
  />
)
DrawerHeader.displayName = "DrawerHeader"

const DrawerFooter = ({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) => (
  <div
    className={cn("mt-auto flex flex-col gap-2 p-4", className)}
    {...props}
  />
)
DrawerFooter.displayName = "DrawerFooter"

const DrawerTitle = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Title>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Title>
>(({ className, ...props }, ref) => (
  <DrawerPrimitive.Title
    ref={ref}
    className={cn(
      "text-lg font-semibold leading-none tracking-tight",
      className
    )}
    {...props}
  />
))
DrawerTitle.displayName = DrawerPrimitive.Title.displayName

const DrawerDescription = React.forwardRef<
  React.ElementRef<typeof DrawerPrimitive.Description>,
  React.ComponentPropsWithoutRef<typeof DrawerPrimitive.Description>
>(({ className, ...props }, ref) => (
  <DrawerPrimitive.Description
    ref={ref}
    className={cn("text-sm text-muted-foreground", className)}
    {...props}
  />
))
DrawerDescription.displayName = DrawerPrimitive.Description.displayName

export {
  Drawer,
  DrawerPortal,
  DrawerOverlay,
  DrawerTrigger,
  DrawerClose,
  DrawerContent,
  DrawerHeader,
  DrawerFooter,
  DrawerTitle,
  DrawerDescription,
}
