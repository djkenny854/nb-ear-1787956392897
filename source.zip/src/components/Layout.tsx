import React, { useState, useEffect, useMemo } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import TopNavigation from '@/components/TopNavigation';
import BottomNavigation from '@/components/BottomNavigation';
import LeftSidebar from '@/components/LeftSidebar';
import AppTour from '@/components/AppTour';
import { isCapacitorNative, isEdgeToEdgeSpacerEnabled } from '@/hooks/useCapacitor';
import EarlyMarketAIIntroDialog from '@/components/ai/EarlyMarketAIIntroDialog';
import { KEEP_ALIVE_PATHS, KeepAliveHost } from '@/components/routing/KeepAlive';
import Discover from '@/pages/Discover';
import Search from '@/pages/ImprovedSearch';

interface LayoutProps {
  children?: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const [isNavVisible, setIsNavVisible] = useState(true);
  const isNative = isCapacitorNative();
  const prefersReducedMotion = typeof window !== 'undefined' &&
    (document.documentElement.classList.contains('reduce-motion') ||
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches);

  const hideLayoutPaths = ['/auth'];
  const hideBottomNavPaths = ['/ai', '/create-business-account', '/onboarding'];
  // Marketplace uses normal window scrolling (its top bar is position:fixed),
  // so it must NOT be locked into single-scroll / overflow-hidden.
  const singleScrollPaths = ['/discover', '/messages', '/ai'];
  const shouldShowLayout = !hideLayoutPaths.includes(location.pathname);
  // Hide bottom nav on chat-open state within /messages (chat pane visible)
  const isChatOpenOnMessages =
    location.pathname === '/messages' && location.hash === '#chat';
  const shouldHideBottomNav =
    hideBottomNavPaths.includes(location.pathname) || isChatOpenOnMessages;
  const isSingleScroll = singleScrollPaths.includes(location.pathname);
  // Top navigation bar only visible on home page
  const shouldHideNavBar = location.pathname !== '/';
  // Collapse the desktop sidebar (icons only) on Messages page
  const forceCollapsedSidebar = location.pathname === '/messages';
  const keepAliveEntries = useMemo(
    () => ({
      '/discover': <Discover />,
      '/marketplace': <Search />,
    }),
    [],
  );


  // Auto-hide navigation on scroll (both window and custom containers)
  // Uses cooldown to prevent oscillation (shaky nav bar)
  useEffect(() => {
    let lastScroll = 0;
    let ticking = false;
    let accumulatedUp = 0;
    let accumulatedDown = 0;
    let cooldownUntil = 0; // Timestamp: ignore scroll events until this time
    
    const handleScroll = (scrollY: number) => {
      if (ticking) return;
      ticking = true;
      
      requestAnimationFrame(() => {
        const now = Date.now();
        
        // Skip scroll events during cooldown period
        if (now < cooldownUntil) {
          lastScroll = scrollY;
          ticking = false;
          return;
        }
        
        const delta = scrollY - lastScroll;
        
        // Ignore tiny movements (increased threshold)
        if (Math.abs(delta) < 5) {
          ticking = false;
          return;
        }

        if (delta > 0) {
          // Scrolling down
          accumulatedDown += delta;
          accumulatedUp = 0;
          if (accumulatedDown > 60) {
            setIsNavVisible(prev => {
              if (prev) {
                cooldownUntil = now + 300; // 300ms cooldown after hiding
              }
              return false;
            });
          }
        } else {
          // Scrolling up
          accumulatedUp += Math.abs(delta);
          accumulatedDown = 0;
          if (accumulatedUp > 80) {
            setIsNavVisible(prev => {
              if (!prev) {
                cooldownUntil = now + 300; // 300ms cooldown after showing
              }
              return true;
            });
          }
        }

        lastScroll = scrollY;
        ticking = false;
      });
    };

    // Window scroll listener
    const handleWindowScroll = () => {
      handleScroll(window.scrollY);
    };

    // Custom container scroll listener
    const handleContainerScroll = (e: Event) => {
      const target = e.target as HTMLElement;
      handleScroll(target.scrollTop);
    };

    window.addEventListener('scroll', handleWindowScroll, { passive: true });
    
    // Use MutationObserver to detect when social-feed-scroll-container appears
    let feedContainer: HTMLElement | null = null;
    
    const attachToContainer = () => {
      const el = document.getElementById('social-feed-scroll-container');
      if (el && el !== feedContainer) {
        feedContainer?.removeEventListener('scroll', handleContainerScroll);
        feedContainer = el;
        feedContainer.addEventListener('scroll', handleContainerScroll, { passive: true });
      }
    };
    
    attachToContainer();
    
    const observer = new MutationObserver(() => {
      attachToContainer();
    });
    observer.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      window.removeEventListener('scroll', handleWindowScroll);
      feedContainer?.removeEventListener('scroll', handleContainerScroll);
    };
  }, [location.pathname]);

  // Reset nav visibility when route changes
  useEffect(() => {
    setIsNavVisible(true);
  }, [location.pathname]);

  // Add viewport meta tag to prevent zooming
  React.useEffect(() => {
    const viewport = document.querySelector('meta[name="viewport"]');
    if (viewport) {
      viewport.setAttribute('content', 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no');
    } else {
      const meta = document.createElement('meta');
      meta.name = 'viewport';
      meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
      document.head.appendChild(meta);
    }
  }, []);

  if (!shouldShowLayout) {
    return <Outlet />;
  }

  return (
    <div className={`bg-background w-full overflow-x-hidden ${isSingleScroll ? 'h-dvh overflow-hidden' : 'min-h-screen'}`}>
      {/* Edge-to-edge notch spacer — toggled via EDGE_TO_EDGE_SPACER_ENABLED
          in useCapacitor.ts. Height matches the device's status-bar/notch
          via env(safe-area-inset-top). Inherits bg-background so it follows
          light/dark mode. Pushes all subsequent page content (including the
          fixed top nav) below the system status bar when edge-to-edge is on
          in a local Android APK build. */}
      {isEdgeToEdgeSpacerEnabled() && (
        <div
          aria-hidden
          className="w-full bg-background"
          style={{ height: 'env(safe-area-inset-top, 0px)' }}
        />
      )}
      {/* Mobile only: Top Navigation - hidden on tablet and above since sidebar shows */}
      {!shouldHideNavBar && (
        <div
          className={`md:hidden fixed left-0 right-0 z-[100] bg-background will-change-transform`}
          style={{
            top: 0,
            paddingTop: isNative ? 'env(safe-area-inset-top, 0px)' : '0px',
            transform: isNavVisible ? 'translate3d(0,0,0)' : 'translate3d(0,-100%,0)',
            transition: 'transform 280ms cubic-bezier(0.22, 1, 0.36, 1)',
            backfaceVisibility: 'hidden',
            WebkitBackfaceVisibility: 'hidden' as any,
          }}
        >
          <TopNavigation />
        </div>
      )}

      {/* Mobile spacer for fixed navbar - accounts for safe area + navbar height */}
      {!shouldHideNavBar && (
        <div 
          className="md:hidden"
          style={{
            height: isNative
              ? 'calc(env(safe-area-inset-top, 0px) + 48px)'
              : '48px',
          }}
        />
      )}

      {/* Native-only: top safe area spacer when nav bar is hidden (non-home pages) */}
      {shouldHideNavBar && isNative && (
        <div className="md:hidden safe-area-top" />
      )}

      {/* Desktop: Full-width layout with sidebar */}
      <div className={`w-full flex ${isSingleScroll ? 'h-full min-h-0' : ''}`}>
        {/* Left sidebar - fixed position, collapsed on tablet (md-lg), expanded on desktop (lg+) */}
        {/* Tablet: collapsed (icons only) — X-style left inset */}
        <aside className="hidden md:block lg:hidden w-[88px] shrink-0">
            <div className="fixed top-0 left-0 w-[88px] h-screen bg-background overflow-hidden">
              <div className="h-full pl-4 pr-2 py-4">
                <LeftSidebar collapsed={true} />
              </div>
            </div>
        </aside>

        {/* Desktop: expanded — X.com proportions (rail ~275px, generous left inset) */}
        {/* On /messages, collapse to icons-only while keeping outer padding/margins */}
        <aside className={`hidden lg:block ${forceCollapsedSidebar ? 'w-[88px]' : 'w-[288px] xl:w-[320px]'} shrink-0`}>
          <div className={`fixed top-0 left-0 ${forceCollapsedSidebar ? 'w-[88px]' : 'w-[288px] xl:w-[320px]'} h-screen bg-background overflow-y-auto overflow-x-hidden scrollbar-thin`}>
            <div className={`h-full ${forceCollapsedSidebar ? 'pl-4 pr-2' : 'pl-6 xl:pl-10 pr-2'} py-3 flex flex-col`}>
              <LeftSidebar collapsed={forceCollapsedSidebar} />
            </div>
          </div>
        </aside>

        {/* Main content - fills remaining space */}
        {/* On mobile native: add bottom padding for safe area + bottom nav */}
        <main
          className={`min-w-0 flex-1 app-main-bottom-gap ${isSingleScroll ? 'h-full min-h-0 overflow-hidden' : ''}`}
          style={{
            // Mobile reserves room for the bottom navigation so the footer
            // ends exactly where the nav begins. Desktop/tablet have no
            // bottom nav, so the footer sits flush at the extreme bottom.
            ['--app-bottom-gap' as any]:
              (shouldHideBottomNav || (KEEP_ALIVE_PATHS as readonly string[]).includes(location.pathname))
                ? '0px'
                : isNative
                  ? 'calc(env(safe-area-inset-bottom, 0px) + 5rem)'
                  : '5rem',
          }}
        >
          {/*
            Keep-Alive host: /discover and /marketplace are mounted exactly
            once per session and never unmounted on in-app navigation.
            Browser-native scroll position is preserved automatically.
            The matching <Route> in App.tsx renders a <KeepAliveSlot/>
            placeholder so React Router still matches the path.
          */}
          <KeepAliveHost
            entries={keepAliveEntries}
          />

          {/* Non-keep-alive routes render here, with the original transition. */}
          {(() => {
            const isKeepAlivePath = (KEEP_ALIVE_PATHS as readonly string[]).includes(
              location.pathname
            );
            if (isKeepAlivePath) return null;
            if (children) return children;
            return (
              <AnimatePresence mode="wait" initial={false}>
                <motion.div
                  key={location.pathname}
                  initial={prefersReducedMotion ? false : { opacity: 0, x: 16 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={prefersReducedMotion ? { opacity: 0 } : { opacity: 0, x: -16 }}
                  transition={{
                    duration: 0.22,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                  style={{ willChange: 'transform, opacity' }}
                >
                  <Outlet />
                </motion.div>
              </AnimatePresence>
            );
          })()}
        </main>
      </div>

      {/* Mobile: Bottom Navigation */}
      {!shouldHideBottomNav && <BottomNavigation hidden={!isNavVisible} />}
      <AppTour />
      {/* Global EarlyMarket AI intro modal — opened via openEarlyMarketAI() */}
      <EarlyMarketAIIntroDialog />
    </div>
  );
};

export default Layout;