import React, { useState, useRef, useEffect } from 'react';
import { Search, Check, ChevronDown } from 'lucide-react';
import { cn } from '@/lib/utils';

const BUSINESS_CATEGORIES = [
  'Agriculture & Farming', 'Automotive & Car Wash', 'Bakery & Pastry', 'Barber Shop',
  'Beauty & Personal Care', 'Boutique & Fashion', 'Building & Construction Materials',
  'Car Dealership', 'Carpentry & Woodwork', 'Catering Services', 'Cleaning Services',
  'Computer & Phone Repair', 'Consulting', 'Daycare & Childcare', 'Delivery & Courier Services',
  'Education & Training', 'Electrical Services', 'Electronics & Gadgets',
  'Event Planning & Decoration', 'Fashion & Clothing', 'Financial Services', 'Fitness & Gym',
  'Food & Beverages', 'Furniture & Interior Design', 'Gaming Lounge & Entertainment',
  'General Merchandise', 'Graphics & Printing', 'Grocery & Supermarket', 'Hardware Store',
  'Health & Wellness', 'Home & Garden', 'Hotel & Accommodation', 'IT Services & Software',
  'Jewelry & Accessories', 'Landscaping & Gardening', 'Laundry & Dry Cleaning', 'Legal Services',
  'Livestock & Poultry', 'Mechanic & Auto Repair', 'Media & Advertising', 'Mobile Money Agent',
  'Music & DJ Services', 'Internet Cafe & Cyber', 'Painting & Art', 'Pest Control',
  'Pet Shop & Veterinary', 'Pharmacy & Medical Supplies', 'Photography & Videography',
  'Plumbing Services', 'Professional Services', 'Real Estate & Property', 'Repair & Maintenance',
  'Restaurant & Fast Food', 'Retail & Trading', 'Salon & Spa', 'Security Services',
  'Solar & Energy', 'Stationery & Office Supplies', 'Tailoring & Fashion Design', 'Technology',
  'Telecom & Airtime', 'Tours & Travel', 'Transportation & Logistics',
  'Welding & Metal Fabrication', 'Wholesale & Distribution', 'Other'
];

interface SearchableCategoryDropdownProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
}

const SearchableCategoryDropdown: React.FC<SearchableCategoryDropdownProps> = ({
  value,
  onChange,
  placeholder = 'Search category...',
  className,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [search, setSearch] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const filtered = search
    ? BUSINESS_CATEGORIES.filter(c => c.toLowerCase().includes(search.toLowerCase()))
    : BUSINESS_CATEGORIES;

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setSearch('');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  return (
    <div ref={containerRef} className={cn('relative', className)}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex h-10 w-full items-center justify-between rounded-md border border-input bg-secondary px-3 py-2 text-sm ring-offset-background focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
      >
        <div className="flex items-center gap-2 min-w-0">
          <Search className="w-4 h-4 text-muted-foreground shrink-0" />
          <span className={cn('truncate', !value && 'text-muted-foreground')}>
            {value || placeholder}
          </span>
        </div>
        <ChevronDown className="h-4 w-4 opacity-50 shrink-0" />
      </button>

      {isOpen && (
        <div className="absolute z-[100] mt-1 w-full rounded-md border border-border bg-popover shadow-lg">
          <div className="p-2 border-b border-border">
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <input
                ref={inputRef}
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search categories..."
                className="w-full pl-8 pr-3 py-2 text-sm bg-secondary rounded-md border border-border/50 focus:outline-none focus:ring-1 focus:ring-ring"
              />
            </div>
          </div>
          <div className="max-h-48 overflow-y-auto p-1">
            {filtered.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-3">No categories found</p>
            ) : (
              filtered.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => {
                    onChange(category);
                    setIsOpen(false);
                    setSearch('');
                  }}
                  className={cn(
                    'flex w-full items-center gap-2 rounded-sm px-2 py-2 text-sm hover:bg-accent hover:text-accent-foreground transition-colors',
                    value === category && 'bg-accent/50'
                  )}
                >
                  <Check className={cn('w-4 h-4 shrink-0', value === category ? 'opacity-100' : 'opacity-0')} />
                  {category}
                </button>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export { SearchableCategoryDropdown, BUSINESS_CATEGORIES };
export default SearchableCategoryDropdown;
