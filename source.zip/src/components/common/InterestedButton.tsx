import React from 'react';
import { Button } from '@/components/ui/button';
import { ThumbsUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useInterested } from '@/hooks/useEngagement';
import { useAuth } from '@/components/auth/AuthContext';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

interface InterestedButtonProps {
  contentId: string;
  contentType: 'ad' | 'post' | 'event' | 'service';
  variant?: 'default' | 'compact';
  className?: string;
}

const InterestedButton: React.FC<InterestedButtonProps> = ({
  contentId,
  contentType,
  variant = 'default',
  className,
}) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { isInterested, count, toggleInterested, isLoading } = useInterested(contentId, contentType);

  const handleClick = async () => {
    if (!user) {
      toast.error('Please sign in to show interest');
      navigate('/auth');
      return;
    }
    await toggleInterested();
  };

  if (variant === 'compact') {
    return (
      <Button
        variant="ghost"
        size="sm"
        onClick={handleClick}
        disabled={isLoading}
        className={cn(
          "flex-col gap-1 h-auto py-3",
          isInterested && "text-primary",
          className
        )}
      >
        <ThumbsUp className={cn("w-6 h-6", isInterested && "fill-current")} />
        <span className="text-xs">
          {count > 0 ? count : ''} {isInterested ? 'Interested' : 'Interested?'}
        </span>
      </Button>
    );
  }

  return (
    <Button
      onClick={handleClick}
      disabled={isLoading}
      variant="outline"
      className={cn(
        "flex-1 rounded-full h-12",
        isInterested && "bg-primary/10 border-primary/30 text-primary",
        className
      )}
    >
      <ThumbsUp className={cn("w-5 h-5 mr-2", isInterested && "fill-current")} />
      {count > 0 && <span className="mr-1">{count}</span>}
      {isInterested ? 'Interested' : 'Interested?'}
    </Button>
  );
};

export default InterestedButton;
