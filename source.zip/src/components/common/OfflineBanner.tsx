import React from 'react';
import { WifiOff, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';

interface OfflineBannerProps {
  onRetry?: () => void;
  isRetrying?: boolean;
  variant?: 'inline' | 'fullpage';
}

const OfflineBanner: React.FC<OfflineBannerProps> = ({ onRetry, isRetrying = false, variant = 'inline' }) => {
  const { isOnline } = useNetworkStatus();

  if (isOnline) return null;

  if (variant === 'fullpage') {
    return (
      <div className="flex flex-col items-center justify-center py-20 px-6 text-center">
        <div className="p-4 rounded-full bg-muted mb-4">
          <WifiOff className="w-8 h-8 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-1">You're offline</h3>
        <p className="text-sm text-muted-foreground mb-4 max-w-xs">
          Check your internet connection and try again
        </p>
        {onRetry && (
          <Button
            variant="outline"
            size="sm"
            onClick={onRetry}
            disabled={isRetrying}
            className="gap-2 rounded-full"
          >
            <RefreshCw className={`w-4 h-4 ${isRetrying ? 'animate-spin' : ''}`} />
            {isRetrying ? 'Retrying...' : 'Try Again'}
          </Button>
        )}
      </div>
    );
  }

  return (
    <div className="text-center py-6 px-4">
      <div className="inline-flex items-center gap-2 bg-muted/60 rounded-full px-4 py-2.5 text-sm text-muted-foreground border border-border/50">
        <WifiOff className="w-4 h-4 flex-shrink-0" />
        <span>You're offline</span>
        {onRetry && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onRetry}
            disabled={isRetrying}
            className="h-6 px-2 text-xs ml-1 text-primary hover:text-primary"
          >
            <RefreshCw className={`w-3 h-3 mr-1 ${isRetrying ? 'animate-spin' : ''}`} />
            Retry
          </Button>
        )}
      </div>
    </div>
  );
};

export default OfflineBanner;
