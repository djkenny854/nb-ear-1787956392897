
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import {
  Star,
  Users,
  Calendar,
  User,
  Video,
  CheckCircle2,
  Clock,
  AlertCircle,
  Shield,
  FileText,
  Package,
  Wrench
} from 'lucide-react';
import { cn } from '@/lib/utils';
import VerificationProgressSkeleton from './VerificationProgressSkeleton';
import { useVerificationEligibility, MIN_PRODUCTS_FOR_VERIFICATION } from '@/hooks/useVerificationEligibility';

interface VerificationCriteria {
  reviews_count: number;
  avg_rating: number;
  transactions_count: number;
  account_age_days: number;
  profile_complete: boolean;
  has_video: boolean;
  verification_score: number;
  is_verified: boolean;
}

const VerificationProgress = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const eligibility = useVerificationEligibility();

  const { data: verificationData, isLoading } = useQuery({
    queryKey: ['verification-progress', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('verification_criteria')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      return data as VerificationCriteria | null;
    },
    enabled: !!user?.id
  });

  const { data: sellerProfile } = useQuery({
    queryKey: ['seller-profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      
      const { data, error } = await supabase
        .from('seller_profiles')
        .select('*')
        .eq('user_id', user.id)
        .single();
      
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!user?.id
  });

  if (isLoading) {
    return <VerificationProgressSkeleton />;
  }

  if (!sellerProfile) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <AlertCircle className="w-12 h-12 text-orange-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold mb-2">Create Business Profile First</h3>
          <p className="text-gray-600 mb-4">
            You need to create a business profile before you can get verified.
          </p>
          <Button onClick={() => navigate('/create-business-account')}>
            Create Business Profile
          </Button>
        </CardContent>
      </Card>
    );
  }

  const criteria = verificationData || {
    reviews_count: 0,
    avg_rating: 0,
    transactions_count: 0,
    account_age_days: 0,
    profile_complete: false,
    has_video: false,
    verification_score: 0,
    is_verified: false
  };

  const verificationItems = [
    {
      icon: Star,
      title: '10+ Reviews with 4.5+ Rating',
      current: `${criteria.reviews_count} reviews (${criteria.avg_rating.toFixed(1)} avg)`,
      completed: criteria.reviews_count >= 10 && criteria.avg_rating >= 4.5,
      action: () => navigate('/my-ads'),
      actionText: 'View My Listings'
    },
    {
      icon: Users,
      title: '15+ Successful Transactions',
      current: `${criteria.transactions_count} transactions`,
      completed: criteria.transactions_count >= 15,
      action: () => navigate('/post-ad'),
      actionText: 'Post New Ad'
    },
    {
      icon: Package,
      title: `${MIN_PRODUCTS_FOR_VERIFICATION}+ active products OR 1 service workspace`,
      current: `${eligibility.productsCount} products · ${eligibility.serviceWorkspacesCount} workspace${eligibility.serviceWorkspacesCount === 1 ? '' : 's'}`,
      completed: eligibility.eligible,
      action: () => navigate('/post-ad'),
      actionText: 'Add inventory'
    },
    {
      icon: User,
      title: 'Complete Profile',
      current: `${sellerProfile?.profile_completion_percentage || 0}% complete`,
      completed: criteria.profile_complete,
      action: () => navigate('/profile/edit'),
      actionText: 'Complete Profile'
    },
    {
      icon: Video,
      title: 'Embed Product Video',
      current: criteria.has_video ? 'Video added' : 'No video',
      completed: criteria.has_video,
      action: () => navigate('/post-ad'),
      actionText: 'Add Video'
    }
  ];

  const completedCount = verificationItems.filter(item => item.completed).length;
  const progressPercentage = Math.round((completedCount / verificationItems.length) * 100);

  // Hide verification progress for already verified users
  if (criteria.is_verified) {
    return (
      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-6 text-center">
          <CheckCircle2 className="w-12 h-12 text-green-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-green-900 mb-2">You're Verified!</h3>
          <p className="text-green-700 mb-4">
            Congratulations! You have successfully earned your verification badge and can now access all premium features including video embedding.
          </p>
          <div className="bg-green-100 border border-green-200 rounded-lg p-4">
            <h4 className="font-medium text-green-900 mb-2">Your Verified Benefits:</h4>
            <ul className="text-sm text-green-800 space-y-1">
              <li>• Embed videos in your listings</li>
              <li>• Higher visibility in search results</li>
              <li>• Access to premium features</li>
              <li>• Enhanced buyer trust</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Inventory / Workspace Eligibility — replaces account-age requirement */}
      <Card className={cn(
        "p-6 transition-all",
        eligibility.eligible
          ? "bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/20 dark:to-emerald-950/20 border-green-200"
          : "bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-950/20 dark:to-orange-950/20 border-amber-200"
      )}>
        <div className="flex items-start gap-4">
          <div className={cn(
            "p-3 rounded-full",
            eligibility.eligible ? "bg-green-500 text-white" : "bg-amber-500 text-white"
          )}>
            <Package className="w-6 h-6" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold mb-2">Inventory Requirement</h3>
            <p className="text-sm text-muted-foreground mb-4">
              You need at least <strong>{MIN_PRODUCTS_FOR_VERIFICATION} active products</strong> on the marketplace,
              <strong> or at least 1 service workspace</strong>, before you can apply for verification.
            </p>

            <div className="grid sm:grid-cols-2 gap-3 mb-3">
              <div className={cn(
                "rounded-xl p-3 border bg-background/60",
                eligibility.productsCount >= MIN_PRODUCTS_FOR_VERIFICATION ? "border-green-300" : "border-amber-200"
              )}>
                <div className="flex items-center gap-2 mb-1">
                  <Package className="w-4 h-4 text-primary" />
                  <span className="text-xs font-medium text-muted-foreground">Active products</span>
                </div>
                <div className="text-2xl font-bold">
                  {eligibility.productsCount}
                  <span className="text-sm font-normal text-muted-foreground"> / {MIN_PRODUCTS_FOR_VERIFICATION}</span>
                </div>
                <Progress
                  className="h-1.5 mt-2"
                  value={Math.min((eligibility.productsCount / MIN_PRODUCTS_FOR_VERIFICATION) * 100, 100)}
                />
              </div>
              <div className={cn(
                "rounded-xl p-3 border bg-background/60",
                eligibility.serviceWorkspacesCount >= 1 ? "border-green-300" : "border-amber-200"
              )}>
                <div className="flex items-center gap-2 mb-1">
                  <Wrench className="w-4 h-4 text-primary" />
                  <span className="text-xs font-medium text-muted-foreground">Service workspaces</span>
                </div>
                <div className="text-2xl font-bold">
                  {eligibility.serviceWorkspacesCount}
                  <span className="text-sm font-normal text-muted-foreground"> / 1</span>
                </div>
                <Progress
                  className="h-1.5 mt-2"
                  value={Math.min(eligibility.serviceWorkspacesCount * 100, 100)}
                />
              </div>
            </div>

            {eligibility.eligible ? (
              <div className="flex items-center gap-2 text-green-600 font-medium">
                <CheckCircle2 className="w-5 h-5" />
                <span>You're eligible to apply for verification!</span>
              </div>
            ) : (
              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-2 text-amber-600 font-medium">
                  <Clock className="w-5 h-5" />
                  <span>
                    Add {Math.max(MIN_PRODUCTS_FOR_VERIFICATION - eligibility.productsCount, 0)} more product{eligibility.productsCount === MIN_PRODUCTS_FOR_VERIFICATION - 1 ? '' : 's'} or create a service workspace.
                  </span>
                </div>
                <div className="flex gap-2 ml-auto">
                  <Button size="sm" variant="outline" onClick={() => navigate('/post-ad')}>Add product</Button>
                  <Button size="sm" onClick={() => navigate('/publish/service')}>Create workspace</Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Verification Instructions */}
      <Card className="p-6">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <Shield className="w-6 h-6 text-primary" />
          How to Get Verified
        </h3>

        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
              1
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1">Meet the Inventory Requirement</h4>
              <p className="text-sm text-muted-foreground">
                Have at least {MIN_PRODUCTS_FOR_VERIFICATION} active products or 1 service workspace. {eligibility.eligible ? "✓ Complete" : "Not yet met"}
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
              2
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1">Complete the Verification Application</h4>
              <p className="text-sm text-muted-foreground">
                Submit your identity documents and business information through our secure application form. All fields marked as required must be filled.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
              3
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1">Upload Clear Documents</h4>
              <p className="text-sm text-muted-foreground">
                AI verification checks your documents in real-time. Make sure images are clear, well-lit, and all document corners are visible.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-sm">
              4
            </div>
            <div className="flex-1">
              <h4 className="font-semibold mb-1">Await Review</h4>
              <p className="text-sm text-muted-foreground">
                Our team reviews your application within 2-3 business days. You'll be notified once your verification is approved.
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Required Documents */}
      <Card className="p-6 bg-blue-50/50 dark:bg-blue-950/20 border-blue-200">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <FileText className="w-6 h-6 text-blue-600" />
          Required Documents
        </h3>
        
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="flex gap-3">
            <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-sm">Government-Issued ID</div>
              <div className="text-xs text-muted-foreground mt-1">
                National ID, Passport, or Driver's License (both sides)
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-sm">Selfie Photo</div>
              <div className="text-xs text-muted-foreground mt-1">
                Clear photo of your face for identity matching
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-sm">Business Information</div>
              <div className="text-xs text-muted-foreground mt-1">
                Business details and contact information (optional for individuals)
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold text-sm">Supporting Documents</div>
              <div className="text-xs text-muted-foreground mt-1">
                Business registration, tax certificates (optional)
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Benefits of Verification */}
      <Card className="p-6 bg-gradient-to-br from-primary/5 to-primary/10">
        <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
          <Star className="w-6 h-6 text-primary" />
          Benefits of Being Verified
        </h3>
        
        <div className="grid sm:grid-cols-2 gap-4">
          {[
            { icon: Video, title: "Video Embedding", desc: "Showcase products with embedded videos" },
            { icon: Star, title: "Higher Visibility", desc: "Priority placement in search results" },
            { icon: Shield, title: "Trust Badge", desc: "Display verified badge on your profile" },
            { icon: Users, title: "Buyer Confidence", desc: "Increase trust with verified status" }
          ].map((benefit, idx) => (
            <div key={idx} className="flex gap-3 bg-background rounded-xl p-4">
              <div className="p-2 rounded-lg bg-primary/10 h-fit">
                <benefit.icon className="w-5 h-5 text-primary" />
              </div>
              <div>
                <div className="font-semibold text-sm">{benefit.title}</div>
                <div className="text-xs text-muted-foreground mt-1">{benefit.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
};

export default VerificationProgress;
