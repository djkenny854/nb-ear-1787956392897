// Native-only auth screen — X.com style. Used in Capacitor native mode.
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Loader2, Mail, Eye, EyeOff, CheckCircle, KeyRound } from 'lucide-react';
import { toast } from 'sonner';
import { supabase, flushAuthStorage } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useNativeAuth } from '@/hooks/useNativeAuth';
import OtpVerificationCard from '@/components/auth/OtpVerificationCard';
import { canRequestOtp, recordOtpRequest, minutesUntilReset } from '@/lib/otpRateLimit';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';

type Mode = 'initial' | 'email-signin' | 'email-signup' | 'signup-otp' | 'forgot-email' | 'forgot-otp' | 'forgot-password' | 'forgot-success';

const GoogleGlyph = () => (
  <svg viewBox="0 0 24 24" className="w-6 h-6">
    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
  </svg>
);

const XGlyph = () => (
  <svg viewBox="0 0 24 24" className="w-5 h-5" fill="currentColor">
    <path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"/>
  </svg>
);

interface FloatingInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'prefix'> {
  label: string;
  prefixNode?: React.ReactNode;
  rightAdornment?: React.ReactNode;
}

const FloatingInput = React.forwardRef<HTMLInputElement, FloatingInputProps>(
  ({ label, prefixNode, rightAdornment, id, className, ...props }, ref) => {
    const inputId = id || `fi-${label.replace(/\s+/g, '-').toLowerCase()}`;
    return (
      <div className="relative flex items-stretch h-14 rounded-2xl bg-muted/40 border border-border focus-within:border-primary transition-colors overflow-hidden">
        {prefixNode && (
          <span className="flex items-center px-4 text-muted-foreground text-base border-r border-border shrink-0">
            {prefixNode}
          </span>
        )}
        <div className="relative flex-1">
          <input
            ref={ref}
            id={inputId}
            placeholder=" "
            className={`peer w-full h-full bg-transparent px-4 pt-4 pb-1 text-base text-foreground focus:outline-none ${className || ''}`}
            {...props}
          />
          <label
            htmlFor={inputId}
            className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground text-base transition-all duration-200
              peer-focus:top-2.5 peer-focus:-translate-y-0 peer-focus:text-[11px] peer-focus:text-muted-foreground
              peer-[:not(:placeholder-shown)]:top-2.5 peer-[:not(:placeholder-shown)]:-translate-y-0 peer-[:not(:placeholder-shown)]:text-[11px] peer-[:not(:placeholder-shown)]:text-muted-foreground"
          >
            {label}
          </label>
        </div>
        {rightAdornment && <div className="flex items-center pr-2">{rightAdornment}</div>}
      </div>
    );
  }
);
FloatingInput.displayName = 'FloatingInput';


const NativeAuthScreen: React.FC = () => {
  const navigate = useNavigate();
  const { signIn, signUp } = useAuth();
  const { signInWithGoogle, signInWithX } = useNativeAuth();

  const [mode, setMode] = useState<Mode>('initial');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [pendingEmail, setPendingEmail] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [resendTimer, setResendTimer] = useState(0);
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  React.useEffect(() => {
    if (resendTimer <= 0) return;
    const timer = window.setTimeout(() => setResendTimer((value) => Math.max(value - 1, 0)), 1000);
    return () => window.clearTimeout(timer);
  }, [resendTimer]);

  const resetOtpState = () => {
    setOtpCode('');
    setResendTimer(0);
  };

  const resetPasswordState = () => {
    setNewPassword('');
    setConfirmNewPassword('');
    setShowNewPassword(false);
  };

  const goBack = () => {
    if (mode === 'signup-otp') {
      resetOtpState();
      setMode('email-signup');
      return;
    }
    if (mode === 'forgot-otp') {
      resetOtpState();
      setMode('forgot-email');
      return;
    }
    if (mode === 'forgot-password') {
      resetPasswordState();
      setMode('forgot-otp');
      return;
    }
    if (mode === 'forgot-email' || mode === 'forgot-success') {
      resetOtpState();
      resetPasswordState();
      setMode('email-signin');
      return;
    }
    setMode('initial');
  };

  const handleGoogle = async () => {
    setGoogleLoading(true);
    const res = await signInWithGoogle();
    if (res.success) {
      navigate('/');
      return;
    }
    setGoogleLoading(false);
  };

  const handleX = async () => {
    await signInWithX();
  };

  const handleEmailSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    const { error } = await signIn(email, password);
    if (error) toast.error(error.message || 'Failed to sign in');
    else {
      toast.success('Welcome back!');
      navigate('/');
    }
    setLoading(false);
  };

  const handleEmailSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPassword) return toast.error('Passwords do not match');
    if (password.length < 6) return toast.error('Password must be at least 6 characters');
    if (!phone || phone.length < 9) return toast.error('Please enter a valid phone number');

    setLoading(true);
    const fullPhone = `+256${phone.replace(/^0/, '')}`;

    if (!canRequestOtp(email)) {
      toast.error(`Too many code requests. Try again in ${minutesUntilReset(email)} minutes.`);
      setLoading(false);
      return;
    }

    const { error } = await signUp(email, password, {
      phone: fullPhone,
      full_name: fullName || undefined,
    });
    if (error) {
      toast.error(error.message || 'Failed to sign up');
      setLoading(false);
      return;
    }
    recordOtpRequest(email);
    setPendingEmail(email);
    setOtpCode('');
    setResendTimer(60);
    setMode('signup-otp');
    toast.success('Verification code sent to your email');
    setLoading(false);
  };

  const handleVerifySignupOtp = async () => {
    if (otpCode.length !== 6) return toast.error('Please enter the 6-digit code');
    setLoading(true);
    const { error } = await supabase.auth.verifyOtp({
      email: pendingEmail,
      token: otpCode,
      type: 'signup',
    });
    if (error) {
      toast.error(error.message || 'Invalid verification code');
    } else {
      await flushAuthStorage();
      toast.success('Email verified! Welcome to EarlyMarket');
      navigate('/');
    }
    setLoading(false);
  };

  const handleResendSignupOtp = async () => {
    if (resendTimer > 0 || !pendingEmail) return;
    if (!canRequestOtp(pendingEmail)) {
      toast.error(`Too many code requests. Try again in ${minutesUntilReset(pendingEmail)} minutes.`);
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.resend({ type: 'signup', email: pendingEmail });
    if (error) {
      toast.error(error.message || 'Failed to resend code');
    } else {
      recordOtpRequest(pendingEmail);
      setOtpCode('');
      setResendTimer(60);
      toast.success('New verification code sent');
    }
    setLoading(false);
  };

  const handleSendRecoveryOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return toast.error('Enter your email first');
    if (!canRequestOtp(email)) {
      toast.error(`Too many code requests. Try again in ${minutesUntilReset(email)} minutes.`);
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) {
      toast.error(error.message || 'Failed to send reset code');
    } else {
      recordOtpRequest(email);
      setPendingEmail(email);
      setOtpCode('');
      setResendTimer(60);
      setMode('forgot-otp');
      toast.success('Verification code sent to your email');
    }
    setLoading(false);
  };

  const handleVerifyRecoveryOtp = async () => {
    if (otpCode.length !== 6) return toast.error('Please enter the 6-digit code');
    setLoading(true);
    const { data, error } = await supabase.auth.verifyOtp({
      email: pendingEmail,
      token: otpCode,
      type: 'recovery',
    });
    if (error) {
      toast.error(error.message || 'Invalid verification code');
    } else if (data.session) {
      await flushAuthStorage();
      setMode('forgot-password');
      toast.success('Code verified. Set your new password.');
    } else {
      toast.error('Verification failed. Please try again.');
    }
    setLoading(false);
  };

  const handleResendRecoveryOtp = async () => {
    if (resendTimer > 0 || !pendingEmail) return;
    if (!canRequestOtp(pendingEmail)) {
      toast.error(`Too many code requests. Try again in ${minutesUntilReset(pendingEmail)} minutes.`);
      return;
    }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(pendingEmail, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) {
      toast.error(error.message || 'Failed to resend code');
    } else {
      recordOtpRequest(pendingEmail);
      setOtpCode('');
      setResendTimer(60);
      toast.success('New verification code sent');
    }
    setLoading(false);
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword.length < 6) return toast.error('Password must be at least 6 characters');
    if (newPassword !== confirmNewPassword) return toast.error('Passwords do not match');

    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      toast.error(error.message || 'Failed to update password');
    } else {
      await flushAuthStorage();
      resetPasswordState();
      setMode('forgot-success');
    }
    setLoading(false);
  };

  return (
    <div
      className="fixed inset-0 z-[100] bg-background text-foreground flex flex-col overflow-hidden"
      style={{
        paddingTop: 'env(safe-area-inset-top)',
        paddingBottom: 'env(safe-area-inset-bottom)',
      }}
    >
      {/* Header back button */}
      <div className="h-12 flex items-center px-3 shrink-0">
        {mode !== 'initial' && (
          <button
            onClick={goBack}
            className="p-2 -ml-2 text-foreground/80 hover:text-foreground"
            aria-label="Back"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        )}
      </div>

      <AnimatePresence mode="wait">
        {mode === 'initial' && (
          <motion.div
            key="initial"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="flex-1 flex flex-col px-6 min-h-0"
          >
            {/* Logo + tagline centered upper area */}
            <div className="flex-1 flex flex-col items-center justify-center">
              <motion.img
                src={earlymarketLogo}
                alt="EarlyMarket"
                className="w-20 h-20 object-contain mb-6"
                initial={{ opacity: 0, scale: 0.85 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, ease: 'easeOut' }}
              />
              <motion.h1
                className="text-[28px] sm:text-4xl font-extrabold tracking-tight text-center leading-tight whitespace-nowrap"
                initial={{ opacity: 0, y: 14 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.15 }}
              >
                Social Business Marketplace
              </motion.h1>
            </div>

            {/* Bottom auth actions */}
            <div className="pb-6 space-y-5">
              {/* Provider circles */}
              <div className="flex items-center justify-center gap-5">
                <button
                  onClick={handleGoogle}
                  disabled={googleLoading || loading}
                  className="w-14 h-14 rounded-full bg-card border border-border flex items-center justify-center active:scale-95 transition-transform disabled:opacity-60"
                  aria-label="Continue with Google"
                >
                  {googleLoading ? (
                    <Loader2 className="w-5 h-5 animate-spin text-foreground" />
                  ) : (
                    <GoogleGlyph />
                  )}
                </button>
                <button
                  onClick={handleX}
                  disabled={loading}
                  className="w-14 h-14 rounded-full bg-black text-white border border-border flex items-center justify-center active:scale-95 transition-transform"
                  aria-label="Continue with X"
                >
                  <XGlyph />
                </button>
              </div>

              {/* or divider */}
              <div className="flex items-center gap-3">
                <div className="flex-1 h-px bg-border" />
                <span className="text-muted-foreground text-sm">or</span>
                <div className="flex-1 h-px bg-border" />
              </div>

              {/* Continue with email pill */}
              <button
                onClick={() => setMode('email-signin')}
                className="w-full h-14 rounded-full bg-foreground text-background font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.99] transition-transform"
              >
                <Mail className="w-5 h-5" />
                Continue with Email
              </button>

              {/* Create account link */}
              <p className="text-center text-sm text-muted-foreground">
                New here?{' '}
                <button
                  onClick={() => setMode('email-signup')}
                  className="text-foreground font-semibold underline-offset-2 hover:underline"
                >
                  Create an account
                </button>
              </p>

              {/* Terms */}
              <p className="text-center text-[11px] text-muted-foreground leading-relaxed px-4">
                By continuing, you agree to our{' '}
                <a href="/terms" className="text-foreground/80">Terms</a>,{' '}
                <a href="/privacy" className="text-foreground/80">Privacy Policy</a> and{' '}
                <a href="/cookie-policy" className="text-foreground/80">Cookie Use</a>.
              </p>
            </div>
          </motion.div>
        )}

        {mode === 'signup-otp' && (
          <motion.div
            key="signup-otp"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="flex-1 flex flex-col justify-center px-6 min-h-0"
          >
            <OtpVerificationCard
              email={pendingEmail}
              value={otpCode}
              onChange={setOtpCode}
              onSubmit={handleVerifySignupOtp}
              onResend={handleResendSignupOtp}
              onBack={goBack}
              resendTimer={resendTimer}
              loading={loading}
            />
          </motion.div>
        )}

        {mode === 'forgot-email' && (
          <motion.div
            key="forgot-email"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="flex-1 flex flex-col justify-center px-6 min-h-0"
          >
            <h2 className="text-3xl font-extrabold mb-1">Reset password</h2>
            <p className="text-sm text-muted-foreground mb-6">Enter your email to receive a security code.</p>
            <form onSubmit={handleSendRecoveryOtp} className="space-y-3">
              <FloatingInput
                label="Email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
              />
              <button
                type="submit"
                disabled={loading}
                className="w-full h-14 mt-2 rounded-full bg-foreground text-background font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.99] transition-transform disabled:opacity-60"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Send code
              </button>
            </form>
          </motion.div>
        )}

        {mode === 'forgot-otp' && (
          <motion.div
            key="forgot-otp"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="flex-1 flex flex-col justify-center px-6 min-h-0"
          >
            <OtpVerificationCard
              email={pendingEmail}
              value={otpCode}
              onChange={setOtpCode}
              onSubmit={handleVerifyRecoveryOtp}
              onResend={handleResendRecoveryOtp}
              onBack={goBack}
              resendTimer={resendTimer}
              loading={loading}
              title="Enter your reset code"
              subtitle="The password reset code was sent to your email"
            />
          </motion.div>
        )}

        {mode === 'forgot-password' && (
          <motion.div
            key="forgot-password"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="flex-1 flex flex-col justify-center px-6 min-h-0"
          >
            <div className="flex justify-center mb-6">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <KeyRound className="w-6 h-6 text-primary" />
              </div>
            </div>
            <h2 className="text-3xl font-extrabold mb-1">Create new password</h2>
            <p className="text-sm text-muted-foreground mb-6">Choose a strong password for your account.</p>
            <form onSubmit={handleUpdatePassword} className="space-y-3">
              <FloatingInput
                label="New password"
                type={showNewPassword ? 'text' : 'password'}
                required
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                autoComplete="new-password"
                rightAdornment={
                  <button
                    type="button"
                    onClick={() => setShowNewPassword((s) => !s)}
                    className="p-2 text-muted-foreground"
                    aria-label="Toggle password"
                  >
                    {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                }
              />
              <FloatingInput
                label="Confirm password"
                type={showNewPassword ? 'text' : 'password'}
                required
                value={confirmNewPassword}
                onChange={(e) => setConfirmNewPassword(e.target.value)}
                autoComplete="new-password"
              />
              <button
                type="submit"
                disabled={loading}
                className="w-full h-14 mt-2 rounded-full bg-foreground text-background font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.99] transition-transform disabled:opacity-60"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                Update password
              </button>
            </form>
          </motion.div>
        )}

        {mode === 'forgot-success' && (
          <motion.div
            key="forgot-success"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="flex-1 flex flex-col justify-center px-6 min-h-0 text-center"
          >
            <div className="w-16 h-16 mx-auto mb-5 rounded-full bg-green-500/15 flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
            <h2 className="text-3xl font-extrabold mb-2">Password updated</h2>
            <p className="text-sm text-muted-foreground mb-6">Your account is ready to use.</p>
            <button
              type="button"
              onClick={() => navigate('/')}
              className="w-full h-14 rounded-full bg-foreground text-background font-semibold text-base flex items-center justify-center active:scale-[0.99] transition-transform"
            >
              Continue
            </button>
          </motion.div>
        )}

        {(mode === 'email-signin' || mode === 'email-signup') && (
          <motion.div
            key={mode}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="flex-1 flex flex-col px-6 min-h-0 overflow-y-auto"
          >
            <h2 className="text-3xl font-extrabold mb-1">
              {mode === 'email-signin' ? 'Sign in' : 'Create your account'}
            </h2>
            <p className="text-sm text-muted-foreground mb-6">
              {mode === 'email-signin' ? 'Welcome back to Earlymarket' : 'Join the social business marketplace'}
            </p>

            <form
              onSubmit={mode === 'email-signin' ? handleEmailSignIn : handleEmailSignUp}
              className="space-y-3"
            >
              {mode === 'email-signup' && (
                <FloatingInput
                  label="Full name"
                  type="text"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                />
              )}
              <FloatingInput
                label="Email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
              />
              {mode === 'email-signup' && (
                <FloatingInput
                  label="Phone number"
                  type="tel"
                  prefixNode="+256"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 9))}
                />
              )}
              <FloatingInput
                label="Password"
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete={mode === 'email-signin' ? 'current-password' : 'new-password'}
                rightAdornment={
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    className="p-2 text-muted-foreground"
                    aria-label="Toggle password"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                }
              />
              {mode === 'email-signup' && (
                <FloatingInput
                  label="Confirm password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  autoComplete="new-password"
                />
              )}


              <button
                type="submit"
                disabled={loading}
                className="w-full h-14 mt-2 rounded-full bg-foreground text-background font-semibold text-base flex items-center justify-center gap-2 active:scale-[0.99] transition-transform disabled:opacity-60"
              >
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                {mode === 'email-signin' ? 'Sign in' : 'Create account'}
              </button>

              {mode === 'email-signin' && (
                <button
                  type="button"
                  onClick={() => {
                    setPendingEmail(email);
                    resetOtpState();
                    resetPasswordState();
                    setMode('forgot-email');
                  }}
                  className="w-full text-sm text-muted-foreground mt-2"
                >
                  Forgot your password?
                </button>
              )}
            </form>

            <p className="text-center text-sm text-muted-foreground mt-6">
              {mode === 'email-signin' ? (
                <>
                  Don't have an account?{' '}
                  <button onClick={() => setMode('email-signup')} className="text-foreground font-semibold">
                    Sign up
                  </button>
                </>
              ) : (
                <>
                  Already have an account?{' '}
                  <button onClick={() => setMode('email-signin')} className="text-foreground font-semibold">
                    Sign in
                  </button>
                </>
              )}
            </p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default NativeAuthScreen;
