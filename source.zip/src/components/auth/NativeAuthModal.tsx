// Native Auth Modal - OTP-based authentication for Capacitor apps
import React, { useState, useEffect } from 'react';
import { useAuth } from '@/components/auth/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { ShoppingBag, Mail, User, Phone, MapPin, ArrowLeft, Loader2 } from 'lucide-react';
import { supabase, flushAuthStorage } from '@/integrations/supabase/client';
import { isCapacitorNative } from '@/hooks/useCapacitor';
import { useNativeAuth } from '@/hooks/useNativeAuth';
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp';

interface NativeAuthModalProps {
  children: React.ReactNode;
}

const NativeAuthModal: React.FC<NativeAuthModalProps> = ({ children }) => {
  const { user } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [accountType, setAccountType] = useState('');
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  
  // OTP verification states
  const [showOtpVerification, setShowOtpVerification] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [isSignUpFlow, setIsSignUpFlow] = useState(false);
  const [resendTimer, setResendTimer] = useState(0);

  const isNative = isCapacitorNative();
  const { signInWithGoogle } = useNativeAuth();

  // Resend timer countdown
  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    }
  }, [resendTimer]);

  if (user) return <>{children}</>;

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });
    
    if (error) {
      toast.error(error.message || 'Failed to sign in');
    } else {
      toast.success('Welcome back!');
      setOpen(false);
    }
    
    setLoading(false);
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!fullName || !phone || !location || !accountType) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    setLoading(true);
    setIsSignUpFlow(true);

    // For native apps, use OTP verification instead of email links
    if (isNative) {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            phone,
            full_name: fullName,
            location,
            account_type: accountType
          }
        }
      });

      if (error) {
        toast.error(error.message || 'Failed to sign up');
        setLoading(false);
        return;
      }

      toast.success('Verification code sent to your email!');
      setShowOtpVerification(true);
      setResendTimer(60);
    } else {
      // For web, use the standard email redirect flow
      const redirectUrl = `${window.location.origin}/`;
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            phone,
            full_name: fullName,
            location,
            account_type: accountType
          }
        }
      });

      if (error) {
        toast.error(error.message || 'Failed to sign up');
      } else {
        toast.success('Account created! Please check your email to verify.');
        setOpen(false);
      }
    }
    
    setLoading(false);
  };

  const handleVerifyOtp = async () => {
    if (otpCode.length !== 6) {
      toast.error('Please enter the 6-digit code');
      return;
    }

    setLoading(true);

    const { error } = await supabase.auth.verifyOtp({
      email,
      token: otpCode,
      type: 'signup'
    });

    if (error) {
      toast.error(error.message || 'Invalid verification code');
    } else {
      await flushAuthStorage();
      toast.success('Email verified successfully! Welcome to EarlyMarket!');
      setOpen(false);
      setShowOtpVerification(false);
    }

    setLoading(false);
  };

  const handleResendOtp = async () => {
    if (resendTimer > 0) return;

    setLoading(true);

    const { error } = await supabase.auth.resend({ type: 'signup', email });

    if (error) {
      toast.error('Failed to resend code. Please try again.');
    } else {
      toast.success('New verification code sent!');
      setResendTimer(60);
    }

    setLoading(false);
  };

  const handleNativeGoogleSignIn = async () => {
    setLoading(true);
    const result = await signInWithGoogle();
    if (result.success) {
      setOpen(false);
    }
    setLoading(false);
  };

  const handleBackFromOtp = () => {
    setShowOtpVerification(false);
    setOtpCode('');
  };

  // OTP Verification Screen
  if (showOtpVerification) {
    return (
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogTrigger asChild>
          {children}
        </DialogTrigger>
        <DialogContent className="max-w-md mx-auto bg-background border shadow-2xl p-6">
          <div className="text-center">
            <button 
              onClick={handleBackFromOtp}
              className="absolute left-4 top-4 text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>

            <div className="w-16 h-16 mx-auto mb-4 bg-primary/10 rounded-full flex items-center justify-center">
              <Mail className="w-8 h-8 text-primary" />
            </div>

            <h2 className="text-xl font-bold mb-2">Verify Your Email</h2>
            <p className="text-muted-foreground text-sm mb-6">
              We've sent a 6-digit code to<br />
              <span className="font-medium text-foreground">{email}</span>
            </p>

            <div className="flex justify-center mb-6">
              <InputOTP 
                maxLength={6} 
                value={otpCode} 
                onChange={setOtpCode}
              >
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>

            <Button
              onClick={handleVerifyOtp}
              className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold"
              disabled={loading || otpCode.length !== 6}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Verifying...
                </>
              ) : (
                'Verify Email'
              )}
            </Button>

            <div className="mt-4">
              <button
                onClick={handleResendOtp}
                disabled={resendTimer > 0 || loading}
                className="text-sm text-primary hover:underline disabled:text-muted-foreground disabled:no-underline"
              >
                {resendTimer > 0 
                  ? `Resend code in ${resendTimer}s` 
                  : "Didn't receive the code? Resend"
                }
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="max-w-5xl mx-auto bg-card border-0 shadow-2xl p-0 overflow-hidden">
        <div className="flex min-h-[600px]">
          {/* Left side - Illustration */}
          <div className="hidden md:flex md:w-1/2 bg-gradient-to-br from-primary via-primary/90 to-destructive p-8 items-center justify-center relative overflow-hidden">
            <div className="absolute inset-0 bg-black/10"></div>
            <div className="relative z-10 text-center text-primary-foreground">
              <div className="mb-8">
                <div className="w-32 h-32 mx-auto mb-6 bg-primary-foreground/20 rounded-full flex items-center justify-center backdrop-blur-sm">
                  <ShoppingBag className="w-16 h-16 text-primary-foreground" />
                </div>
                <h2 className="text-3xl font-bold mb-4">Uganda's Premier</h2>
                <h3 className="text-2xl font-semibold mb-2">Business Marketplace</h3>
                <h3 className="text-2xl font-semibold">Platform</h3>
              </div>
              <div className="text-primary-foreground/90 text-lg">
                Join thousands of businesses across East Africa
              </div>
            </div>
            <div className="absolute top-20 left-10 w-24 h-24 bg-yellow-400 rounded-full opacity-30"></div>
            <div className="absolute bottom-20 right-10 w-16 h-16 bg-primary-foreground/20 rounded-lg rotate-45"></div>
          </div>
          
          {/* Right side - Form */}
          <div className="w-full md:w-1/2 p-8 bg-card">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold text-foreground">Sign in or create account</h2>
            </div>

            <div className="space-y-4">
              {/* Social Sign-In Buttons */}
              <div className="space-y-3">
                <Button
                  onClick={handleNativeGoogleSignIn}
                  variant="outline"
                  className="w-full h-12 bg-card hover:bg-muted border border-border text-foreground font-medium justify-start px-4"
                  disabled={loading}
                >
                  <svg className="w-5 h-5 mr-3" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                  </svg>
                  Continue with Google
                </Button>

                <Button
                  onClick={async () => {
                    const { triggerXSignIn } = await import('@/hooks/useNativeAuth');
                    await triggerXSignIn();
                  }}
                  variant="outline"
                  className="w-full h-12 bg-black hover:bg-black/90 text-white border-0 font-medium justify-start px-4"
                  disabled={loading}
                >
                  <svg className="w-5 h-5 mr-3" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"/>
                  </svg>
                  Continue with X
                </Button>
              </div>

              <div className="relative my-6">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-sm">
                  <span className="px-4 bg-card text-muted-foreground font-medium">OR</span>
                </div>
              </div>

              <Tabs defaultValue="signin" className="w-full">
                <TabsList className="grid w-full grid-cols-2 bg-muted">
                  <TabsTrigger value="signin" className="font-medium">Sign In</TabsTrigger>
                  <TabsTrigger value="signup" className="font-medium">Create Account</TabsTrigger>
                </TabsList>
                
                <TabsContent value="signin" className="mt-6">
                  <form onSubmit={handleSignIn} className="space-y-4">
                    <Input
                      type="email"
                      placeholder="Enter your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="h-12 border-border text-base"
                      required
                    />
                    <Input
                      type="password"
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="h-12 border-border text-base"
                      required
                    />
                    <Button
                      type="submit"
                      className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-base rounded-lg"
                      disabled={loading}
                    >
                      {loading ? 'Signing in...' : 'Continue'}
                    </Button>
                  </form>
                </TabsContent>
                
                <TabsContent value="signup" className="mt-6">
                  <form onSubmit={handleSignUp} className="space-y-4">
                    <Input
                      type="email"
                      placeholder="Enter your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="h-12 border-border text-base"
                      required
                    />
                    <Input
                      type="password"
                      placeholder="Create a password (min. 6 characters)"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="h-12 border-border text-base"
                      required
                      minLength={6}
                    />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                        <Input
                          type="text"
                          placeholder="Full Name"
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          className="pl-10 h-12 border-border text-base"
                          required
                        />
                      </div>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                        <Input
                          type="tel"
                          placeholder="Phone Number"
                          value={phone}
                          onChange={(e) => setPhone(e.target.value)}
                          className="pl-10 h-12 border-border text-base"
                          required
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="relative">
                        <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4 z-10" />
                        <Input
                          type="text"
                          placeholder="Location/City"
                          value={location}
                          onChange={(e) => setLocation(e.target.value)}
                          className="pl-10 h-12 border-border text-base"
                          required
                        />
                      </div>
                      <Select value={accountType} onValueChange={setAccountType} required>
                        <SelectTrigger className="h-12 border-border text-base">
                          <SelectValue placeholder="Account Type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="buyer">Buyer</SelectItem>
                          <SelectItem value="seller">Seller</SelectItem>
                          <SelectItem value="both">Both Buyer & Seller</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      type="submit"
                      className="w-full h-12 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold text-base rounded-lg"
                      disabled={loading}
                    >
                      {loading ? 'Creating account...' : 'Continue'}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default NativeAuthModal;
