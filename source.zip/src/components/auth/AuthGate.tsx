// AuthGate - Requires user authentication before showing content
import React, { useState, useCallback, useEffect } from 'react';
import { useAuth } from '@/components/auth/AuthContext';
import { Loader2 } from 'lucide-react';
import NativeSplashScreen from '@/components/NativeSplashScreen';
import NativeAuthScreen from '@/components/auth/NativeAuthScreen';
import Auth from '@/pages/Auth';
import { isCapacitorNative } from '@/hooks/useCapacitor';
import PostAuthOnboarding from '@/components/onboarding/PostAuthOnboarding';
import { ONBOARDING_VERSION } from '@/constants/appVersion';
import { supabase } from '@/integrations/supabase/client';

interface AuthGateProps {
  children: React.ReactNode;
}

const AuthGate: React.FC<AuthGateProps> = ({ children }) => {
  const { user, loading: authLoading, recovering } = useAuth();
  const [splashDone, setSplashDone] = useState(false);
  const [onboardingNeeded, setOnboardingNeeded] = useState<boolean | null>(null);

  // Check onboarding version against the current user's profile once authed.
  useEffect(() => {
    let cancelled = false;
    if (!user) { setOnboardingNeeded(null); return; }
    const localVer = localStorage.getItem('earlymarket_onboarding_v2_completed');
    if (localVer === ONBOARDING_VERSION) {
      setOnboardingNeeded(false);
      return;
    }
    (async () => {
      const { data } = await supabase
        .from('profiles')
        .select('onboarding_completed_version')
        .eq('id', user.id)
        .maybeSingle();
      if (cancelled) return;
      const done = data?.onboarding_completed_version === ONBOARDING_VERSION;
      if (done) localStorage.setItem('earlymarket_onboarding_v2_completed', ONBOARDING_VERSION);
      setOnboardingNeeded(!done);
    })();
    return () => { cancelled = true; };
  }, [user]);

  // Log auth state transitions for debugging native sign-in
  useEffect(() => {
    console.log('[AuthGate] Auth state changed — user:', user?.email ?? 'null', 'loading:', authLoading, 'recovering:', recovering);
  }, [user, authLoading, recovering]);

  const handleSplashFinish = useCallback(() => setSplashDone(true), []);
  const handleOnboardingFinish = useCallback(() => setOnboardingNeeded(false), []);

  // 1. Splash screen first
  if (!splashDone) {
    return <NativeSplashScreen onFinish={handleSplashFinish} />;
  }

  // 2. Auth loading
  if (authLoading || recovering) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Reconnecting...</p>
        </div>
      </div>
    );
  }

  // 3. Authenticated — show onboarding first if needed for this version
  if (user) {
    if (onboardingNeeded === null) {
      return (
        <div className="min-h-screen bg-background flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      );
    }
    if (onboardingNeeded) {
      return <PostAuthOnboarding onFinish={handleOnboardingFinish} />;
    }
    console.log('[AuthGate] Rendering children — user authenticated:', user.email);
    return <>{children}</>;
  }

  // 4. Not authenticated — native gets X-style screen, web keeps current Auth page
  console.log('[AuthGate] Rendering Auth page — no user');
  return isCapacitorNative() ? <NativeAuthScreen /> : <Auth isNativeGate />;
};

export default AuthGate;
