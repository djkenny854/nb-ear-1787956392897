import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldX, UserX, Clock, ArrowLeft, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface ListingUnavailableProps {
  reason: 'banned' | 'subscription' | 'not_found';
  onBack?: () => void;
}

const reasonContent = {
  banned: {
    icon: UserX,
    title: 'Content Unavailable',
    description: 'This listing has been removed for violating our community guidelines.',
    showExplore: true,
  },
  subscription: {
    icon: Clock,
    title: 'Listing Currently Hidden',
    description: "The owner's subscription has expired. This listing may become available again once they renew.",
    showExplore: true,
  },
  not_found: {
    icon: ShieldX,
    title: 'Listing Not Found',
    description: 'This listing may have been removed or the link is incorrect.',
    showExplore: true,
  },
};

export const ListingUnavailable: React.FC<ListingUnavailableProps> = ({ reason, onBack }) => {
  const navigate = useNavigate();
  const content = reasonContent[reason] || reasonContent.not_found;
  const Icon = content.icon;

  return (
    <div className="min-h-[60vh] flex items-center justify-center p-4">
      <Card className="max-w-md w-full border-0 shadow-lg">
        <CardContent className="p-8 text-center">
          {/* Icon */}
          <div className="mx-auto w-20 h-20 rounded-full bg-muted flex items-center justify-center mb-6">
            <Icon className="h-10 w-10 text-muted-foreground" />
          </div>

          {/* Title */}
          <h1 className="text-2xl font-bold text-foreground mb-3">
            {content.title}
          </h1>

          {/* Description */}
          <p className="text-muted-foreground mb-8">
            {content.description}
          </p>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              variant="outline"
              onClick={onBack || (() => navigate(-1))}
              className="gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Go Back
            </Button>
            
            {content.showExplore && (
              <Button
                onClick={() => navigate('/search')}
                className="gap-2"
              >
                <Search className="h-4 w-4" />
                Explore Listings
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
