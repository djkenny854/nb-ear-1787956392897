import React, { useEffect } from 'react';
import { Helmet } from 'react-helmet-async';

interface SellerJsonLdProps {
  seller: {
    id: string;
    business_name: string;
    description?: string;
    logo_url?: string;
    cover_image?: string;
    location?: string;
    district?: string;
    phone?: string;
    email?: string;
    website?: string;
    is_verified?: boolean;
    verification_badge_color?: string;
    rating?: number;
    review_count?: number;
    store_slug?: string;
    created_at?: string;
    working_hours?: Record<string, { open: string; close: string; closed?: boolean }>;
    social_links?: {
      facebook?: string;
      instagram?: string;
      twitter?: string;
      tiktok?: string;
      whatsapp?: string;
    };
    follower_count?: number;
    business_category?: string;
  };
  products?: Array<{
    id: string;
    title: string;
    price?: number;
    currency?: string;
    images?: string[];
    description?: string;
  }>;
}

const SellerJsonLd: React.FC<SellerJsonLdProps> = ({ seller, products }) => {
  const siteUrl = 'https://earlymarketug.com';
  
  // Generate SEO-friendly slug from business name if no store_slug
  const generateSlug = (name: string) => 
    name?.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
  
  const sellerSlug = seller.store_slug || generateSlug(seller.business_name);
  const sellerUrl = sellerSlug 
    ? `${siteUrl}/business/${sellerSlug}`
    : `${siteUrl}/seller/${seller.id}`;

  // Build meta description with key info
  const verifiedText = seller.is_verified ? '✓ Verified Seller' : '';
  const locationText = seller.location || seller.district || 'Uganda';
  const categoryText = seller.business_category || '';
  const productCount = products?.length || 0;
  const productText = productCount > 0 ? `${productCount}+ products available` : '';
  const ratingText = seller.rating && seller.rating > 0 ? `★ ${seller.rating.toFixed(1)} rating` : '';
  
  const metaDescription = [
    seller.description?.slice(0, 100) || `${seller.business_name} on EarlyMarket Uganda`,
    verifiedText,
    categoryText,
    locationText,
    ratingText,
    productText
  ].filter(Boolean).join(' • ').slice(0, 160);

  // Build page title
  const pageTitle = `${seller.business_name}${seller.is_verified ? ' ✓' : ''} | EarlyMarket Uganda`;

  // OG Image - prefer cover image, then logo
  const ogImage = seller.cover_image || seller.logo_url || `${siteUrl}/og-default.png`;

  // Build LocalBusiness schema with enhanced data
  const localBusinessSchema: Record<string, any> = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "@id": sellerUrl,
    "name": seller.business_name,
    "url": sellerUrl,
    "description": seller.description || `${seller.business_name} - Shop products and services on EarlyMarket, Uganda's trusted marketplace.`,
  };

  // Add logo and images
  if (seller.logo_url) {
    localBusinessSchema.logo = seller.logo_url;
    localBusinessSchema.image = [seller.logo_url];
    if (seller.cover_image) {
      localBusinessSchema.image.push(seller.cover_image);
    }
  } else if (seller.cover_image) {
    localBusinessSchema.image = seller.cover_image;
  }

  // Add address
  if (seller.location || seller.district) {
    localBusinessSchema.address = {
      "@type": "PostalAddress",
      "addressLocality": seller.location || seller.district,
      "addressRegion": seller.district,
      "addressCountry": "UG"
    };
  }

  // Add contact info
  if (seller.phone) {
    localBusinessSchema.telephone = seller.phone;
  }
  if (seller.email) {
    localBusinessSchema.email = seller.email;
  }

  // Add social links
  const socialLinks: string[] = [];
  if (seller.website) socialLinks.push(seller.website);
  if (seller.social_links?.facebook) socialLinks.push(seller.social_links.facebook);
  if (seller.social_links?.instagram) socialLinks.push(seller.social_links.instagram);
  if (seller.social_links?.twitter) socialLinks.push(seller.social_links.twitter);
  if (seller.social_links?.tiktok) socialLinks.push(seller.social_links.tiktok);
  if (socialLinks.length > 0) {
    localBusinessSchema.sameAs = socialLinks;
  }

  // Add aggregate rating if available
  if (seller.rating && seller.rating > 0 && seller.review_count && seller.review_count > 0) {
    localBusinessSchema.aggregateRating = {
      "@type": "AggregateRating",
      "ratingValue": seller.rating.toFixed(1),
      "reviewCount": seller.review_count,
      "bestRating": 5,
      "worstRating": 1
    };
  }

  // Add opening hours if available
  if (seller.working_hours && Object.keys(seller.working_hours).length > 0) {
    const openingHoursSpec: any[] = [];
    const dayMap: Record<string, string> = {
      'monday': 'Monday', 'tuesday': 'Tuesday', 'wednesday': 'Wednesday',
      'thursday': 'Thursday', 'friday': 'Friday', 'saturday': 'Saturday', 'sunday': 'Sunday'
    };

    for (const [day, hours] of Object.entries(seller.working_hours)) {
      if (!hours.closed && hours.open && hours.close) {
        const dayOfWeek = dayMap[day.toLowerCase()];
        if (dayOfWeek) {
          openingHoursSpec.push({
            "@type": "OpeningHoursSpecification",
            "dayOfWeek": dayOfWeek,
            "opens": hours.open,
            "closes": hours.close
          });
        }
      }
    }

    if (openingHoursSpec.length > 0) {
      localBusinessSchema.openingHoursSpecification = openingHoursSpec;
    }
  }

  // Add founding date
  if (seller.created_at) {
    localBusinessSchema.foundingDate = seller.created_at.split('T')[0];
  }

  // Add verification as award/certification
  if (seller.is_verified) {
    localBusinessSchema.award = "EarlyMarket Verified Seller";
    localBusinessSchema.additionalProperty = [
      {
        "@type": "PropertyValue",
        "name": "Verification Status",
        "value": "Verified"
      },
      {
        "@type": "PropertyValue",
        "name": "Trust Badge",
        "value": "EarlyMarket Verified"
      }
    ];
  }

  // Add business category
  if (seller.business_category) {
    localBusinessSchema.category = seller.business_category;
  }

  // Add follower count as interaction statistic
  if (seller.follower_count && seller.follower_count > 0) {
    localBusinessSchema.interactionStatistic = {
      "@type": "InteractionCounter",
      "interactionType": "https://schema.org/FollowAction",
      "userInteractionCount": seller.follower_count
    };
  }

  // Add parent organization
  localBusinessSchema.parentOrganization = {
    "@type": "Organization",
    "name": "EarlyMarket Uganda",
    "url": siteUrl,
    "logo": `${siteUrl}/favicon.png`
  };

  // Build products schema if available - as OfferCatalog
  const productsSchema = products && products.length > 0 ? {
    "@context": "https://schema.org",
    "@type": "OfferCatalog",
    "name": `Products by ${seller.business_name}`,
    "numberOfItems": products.length,
    "itemListElement": products.slice(0, 10).map((product, index) => ({
      "@type": "Offer",
      "position": index + 1,
      "itemOffered": {
        "@type": "Product",
        "@id": `${siteUrl}/ad/${product.id}`,
        "name": product.title,
        "description": product.description?.slice(0, 150),
        "url": `${siteUrl}/ad/${product.id}`,
        "image": product.images?.[0],
        "offers": product.price ? {
          "@type": "Offer",
          "price": product.price,
          "priceCurrency": product.currency || "UGX",
          "availability": "https://schema.org/InStock",
          "seller": {
            "@type": "Organization",
            "name": seller.business_name,
            "url": sellerUrl
          }
        } : undefined
      }
    }))
  } : null;

  // BreadcrumbList schema
  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Home",
        "item": siteUrl
      },
      ...(seller.business_category ? [{
        "@type": "ListItem",
        "position": 2,
        "name": seller.business_category,
        "item": `${siteUrl}/search?category=${encodeURIComponent(seller.business_category)}`
      }] : []),
      {
        "@type": "ListItem",
        "position": seller.business_category ? 3 : 2,
        "name": seller.business_name,
        "item": sellerUrl
      }
    ]
  };

  return (
    <>
      <Helmet>
        {/* Primary Meta Tags */}
        <title>{pageTitle}</title>
        <meta name="title" content={pageTitle} />
        <meta name="description" content={metaDescription} />
        <link rel="canonical" href={sellerUrl} />

        {/* Open Graph / Facebook */}
        <meta property="og:type" content="business.business" />
        <meta property="og:url" content={sellerUrl} />
        <meta property="og:title" content={pageTitle} />
        <meta property="og:description" content={metaDescription} />
        <meta property="og:image" content={ogImage} />
        <meta property="og:site_name" content="EarlyMarket Uganda" />
        {seller.location && <meta property="business:contact_data:locality" content={seller.location} />}
        {seller.phone && <meta property="business:contact_data:phone_number" content={seller.phone} />}
        {seller.email && <meta property="business:contact_data:email" content={seller.email} />}

        {/* Twitter */}
        <meta property="twitter:card" content="summary_large_image" />
        <meta property="twitter:url" content={sellerUrl} />
        <meta property="twitter:title" content={pageTitle} />
        <meta property="twitter:description" content={metaDescription} />
        <meta property="twitter:image" content={ogImage} />

        {/* Additional SEO */}
        <meta name="robots" content="index, follow" />
        <meta name="author" content={seller.business_name} />
        {seller.business_category && <meta name="keywords" content={`${seller.business_name}, ${seller.business_category}, Uganda, EarlyMarket, buy, sell, ${seller.location || ''}`} />}
      </Helmet>

      {/* JSON-LD Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
      />
      {productsSchema && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(productsSchema) }}
        />
      )}
    </>
  );
};

export default SellerJsonLd;
