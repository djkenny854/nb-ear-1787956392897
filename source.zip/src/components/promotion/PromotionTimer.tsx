import React, { useEffect, useState } from 'react';
import { cn } from '@/lib/utils';

interface PromotionTimerProps {
  validUntil?: string | null;
  startAt?: string | null;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  /** Called once when the timer reaches 0 (past validUntil) */
  onExpire?: () => void;
}

interface Parts {
  d: number;
  h: number;
  m: number;
  s: number;
  expired: boolean;
  starting: boolean;
  urgent: boolean; // <= 1 day left
  total: number;
}

function parseDate(input?: string | null): number | null {
  if (!input) return null;
  let t = new Date(input).getTime();
  if (isNaN(t)) t = new Date(`${input}T23:59:59`).getTime();
  return isNaN(t) ? null : t;
}

function computeParts(validUntil?: string | null, startAt?: string | null): Parts {
  const now = Date.now();
  const end = parseDate(validUntil);
  const start = parseDate(startAt);
  let target: number | null = null;
  let starting = false;
  if (start && start > now) {
    target = start;
    starting = true;
  } else if (end) {
    target = end;
  }
  if (!target) return { d: 0, h: 0, m: 0, s: 0, expired: false, starting: false, urgent: false, total: 0 };
  const diff = target - now;
  if (diff <= 0) return { d: 0, h: 0, m: 0, s: 0, expired: !starting, starting: false, urgent: false, total: 0 };
  const d = Math.floor(diff / 86400000);
  const h = Math.floor((diff % 86400000) / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  const s = Math.floor((diff % 60000) / 1000);
  const urgent = !starting && diff <= 86400000; // <= 1 day
  return { d, h, m, s, expired: false, starting, urgent, total: diff };
}

const sizeMap = {
  sm: { box: 'min-w-[28px] h-8 text-[11px] px-1', num: 'text-xs font-semibold', lbl: 'text-[8px]' },
  md: { box: 'min-w-[36px] h-10 text-sm px-1.5', num: 'text-sm font-bold', lbl: 'text-[9px]' },
  lg: { box: 'min-w-[52px] h-14 px-2', num: 'text-xl font-bold', lbl: 'text-[10px]' },
};

export const PromotionTimer: React.FC<PromotionTimerProps> = ({
  validUntil,
  startAt,
  size = 'sm',
  className,
  onExpire,
}) => {
  const [parts, setParts] = useState<Parts>(() => computeParts(validUntil, startAt));

  useEffect(() => {
    setParts(computeParts(validUntil, startAt));
    const id = setInterval(() => {
      const next = computeParts(validUntil, startAt);
      setParts(next);
      if (next.expired) {
        clearInterval(id);
        onExpire?.();
      }
    }, 1000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [validUntil, startAt]);

  if (parts.expired) {
    return (
      <span className={cn('inline-flex items-center gap-1 rounded-md border border-destructive/40 bg-transparent px-2 py-0.5 text-[10px] font-semibold text-destructive', className)}>
        Expired
      </span>
    );
  }

  const s = sizeMap[size];
  const urgent = parts.urgent;
  const showDays = parts.d > 0;
  const items: [string, number][] = showDays
    ? [['D', parts.d], ['H', parts.h], ['M', parts.m], ['S', parts.s]]
    : [['H', parts.h], ['M', parts.m], ['S', parts.s]];

  return (
    <div
      className={cn(
        'inline-flex items-center gap-1 leading-none tabular-nums',
        urgent ? 'text-destructive' : 'text-foreground',
        className,
      )}
      aria-label={parts.starting ? 'Starts in' : 'Ends in'}
      role="timer"
    >
      {parts.starting && (
        <span className={cn('mr-0.5 font-medium', s.lbl, urgent ? 'text-destructive' : 'text-muted-foreground')}>
          Starts
        </span>
      )}
      {items.map(([label, value], i) => (
        <React.Fragment key={label}>
          <div
            className={cn(
              'inline-flex flex-col items-center justify-center rounded-md border bg-transparent',
              s.box,
              urgent ? 'border-destructive/50' : 'border-border/60',
            )}
          >
            <span className={s.num}>{String(value).padStart(2, '0')}</span>
            <span className={cn('font-medium opacity-70', s.lbl)}>{label}</span>
          </div>
          {i < items.length - 1 && (
            <span className={cn('opacity-40', s.num)}>:</span>
          )}
        </React.Fragment>
      ))}
    </div>
  );
};

export default PromotionTimer;