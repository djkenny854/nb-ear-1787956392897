// Video loading skeleton component
import React from 'react';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

interface VideoSkeletonProps {
  className?: string;
  aspectRatio?: 'video' | 'square' | 'portrait';
}

const VideoSkeleton: React.FC<VideoSkeletonProps> = ({
  className,
  aspectRatio = 'video',
}) => {
  const aspectClass = {
    video: 'aspect-video',
    square: 'aspect-square',
    portrait: 'aspect-[9/16]',
  }[aspectRatio];

  return (
    <div
      className={cn(
        'relative overflow-hidden bg-muted rounded-xl',
        aspectClass,
        className
      )}
    >
      {/* Shimmer animation */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-foreground/5 to-transparent animate-shimmer" 
        style={{ backgroundSize: '200% 100%' }} 
      />
      
      {/* Center play icon skeleton */}
      <div className="absolute inset-0 flex items-center justify-center">
        <Skeleton className="w-16 h-16 rounded-full" />
      </div>
      
      {/* Bottom controls skeleton */}
      <div className="absolute bottom-0 left-0 right-0 p-3">
        <Skeleton className="h-1 w-full rounded-full mb-2" />
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Skeleton className="w-8 h-8 rounded-full" />
            <Skeleton className="w-8 h-8 rounded-full" />
            <Skeleton className="w-16 h-4 rounded" />
          </div>
          <div className="flex items-center gap-2">
            <Skeleton className="w-8 h-8 rounded-full" />
            <Skeleton className="w-8 h-8 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default VideoSkeleton;
