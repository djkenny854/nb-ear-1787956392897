import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { SearchIcon, Clock, TrendingUp, X } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { ScrollArea } from '@/components/ui/scroll-area';

interface SearchAutocompleteProps {
  value: string;
  onChange: (value: string) => void;
  onSearch: (query?: string) => void;
  className?: string;
  placeholders?: string[];
}

const DEFAULT_PLACEHOLDERS = [
  "Verified sellers. Safer deals.",
  "Escrow-ready payments. Shop with confidence.",
  "Fast delivery options. Trusted local stores.",
  "Find jobs & promotions near you.",
  "Search by brand, color, model…",
];

// Temporarily disabled: the focus dropdown/modal and its background data fetch
// are turned off. Flip to true to re-enable suggestions + recent searches.
const DROPDOWN_ENABLED = false;

const SearchAutocomplete: React.FC<SearchAutocompleteProps> = ({
  value,
  onChange,
  onSearch,
  className = '',
  placeholders: placeholdersProp,
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [displayedText, setDisplayedText] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  
  // Use refs to track animation state without causing re-renders
  const animationRef = useRef({
    currentIndex: 0,
    isDeleting: false,
    placeholderIdx: 0
  });

  const placeholders = placeholdersProp && placeholdersProp.length > 0
    ? placeholdersProp
    : DEFAULT_PLACEHOLDERS;

  // Typing animation effect
  useEffect(() => {
    if (value) {
      setDisplayedText('');
      return;
    }

    const interval = setInterval(() => {
      const anim = animationRef.current;
      const idx = anim.placeholderIdx % placeholders.length;
      const currentPlaceholder = placeholders[idx] || '';
      
      
      if (!anim.isDeleting) {
        if (anim.currentIndex < currentPlaceholder.length) {
          setDisplayedText(currentPlaceholder.slice(0, anim.currentIndex + 1));
          anim.currentIndex++;
        } else {
          anim.isDeleting = true;
        }
      } else {
        if (anim.currentIndex > 0) {
          setDisplayedText(currentPlaceholder.slice(0, anim.currentIndex - 1));
          anim.currentIndex--;
        } else {
          anim.isDeleting = false;
          anim.placeholderIdx = (anim.placeholderIdx + 1) % placeholders.length;
        }
      }
    }, 100);

    return () => clearInterval(interval);
  }, [value]);

  // Load recent searches
  useEffect(() => {
    const stored = localStorage.getItem('recentSearches');
    if (stored) {
      setRecentSearches(JSON.parse(stored));
    }
  }, []);

  // Fetch search suggestions
  const { data: suggestions = [], isLoading } = useQuery({
    queryKey: ['search-suggestions', value],
    queryFn: async () => {
      if (!value || value.length < 2) return [];
      
      const { data, error } = await supabase
        .from('ads')
        .select('title, category')
        .or(`title.ilike.%${value}%,description.ilike.%${value}%,category.ilike.%${value}%`)
        .eq('status', 'active')
        .limit(8);
      
      if (error) throw error;
      
      // Extract unique suggestions
      const uniqueSuggestions = new Set<string>();
      data.forEach(ad => {
        if (ad.title.toLowerCase().includes(value.toLowerCase())) {
          uniqueSuggestions.add(ad.title);
        }
        if (ad.category.toLowerCase().includes(value.toLowerCase())) {
          uniqueSuggestions.add(ad.category);
        }
      });
      
      return Array.from(uniqueSuggestions).slice(0, 6);
    },
    enabled: DROPDOWN_ENABLED && value.length >= 2,
  });

  const saveRecentSearch = (query: string) => {
    const updated = [query, ...recentSearches.filter(s => s !== query)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('recentSearches', JSON.stringify(updated));
  };

  const handleSuggestionClick = (suggestion: string) => {
    onChange(suggestion);
    saveRecentSearch(suggestion);
    setIsFocused(false);
    onSearch(suggestion);
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem('recentSearches');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if (value) {
        saveRecentSearch(value);
        onSearch(value);
        setIsFocused(false);
      }
    }
  };

  const showDropdown = DROPDOWN_ENABLED && isFocused && (value.length >= 2 || recentSearches.length > 0);

  return (
    <div className={`relative ${className}`}>
      <div className="relative h-14 bg-muted/30 rounded-lg border border-border/50 flex items-center px-4 overflow-hidden group hover:border-border transition-colors focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/20">
        {/* Shimmer animation overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/60 to-transparent bg-[length:200%_100%] animate-shimmer pointer-events-none" />
        
        <SearchIcon className="w-4 h-4 text-muted-foreground mr-3 shrink-0 relative z-10" />
        <input
          ref={inputRef}
          type="text"
          placeholder={value ? '' : displayedText}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setTimeout(() => setIsFocused(false), 200)}
          onKeyPress={handleKeyPress}
          className="flex-1 bg-transparent border-none outline-none text-base text-foreground placeholder:text-muted-foreground relative z-10"
        />
        <kbd className="hidden sm:inline-flex h-5 select-none items-center gap-1 rounded border border-border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-100 relative z-10">
          /
        </kbd>
      </div>

      {/* Suggestions Dropdown */}
      {showDropdown && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-popover text-popover-foreground border border-border rounded-lg shadow-xl z-[500] max-h-[400px] overflow-hidden">
          <ScrollArea className="max-h-[400px]">
            {value.length >= 2 ? (
              // Search suggestions
              <div className="p-2">
                {isLoading ? (
                  <div className="space-y-2">
                    {Array.from({ length: 4 }).map((_, i) => (
                      <div key={i} className="flex items-center gap-3 p-3 rounded-lg">
                        <Skeleton className="w-4 h-4 rounded" />
                        <div className="flex-1 space-y-2">
                          <Skeleton className="h-4 w-full animate-pulse" />
                          <Skeleton className="h-3 w-2/3 animate-pulse" />
                        </div>
                      </div>
                    ))}
                  </div>
                ) : suggestions.length > 0 ? (
                  <div className="space-y-1">
                    <div className="px-3 py-2 text-xs font-medium text-muted-foreground flex items-center gap-2">
                      <TrendingUp className="w-3 h-3" />
                      Suggestions
                    </div>
                    {suggestions.map((suggestion, index) => (
                      <button
                        key={index}
                        onClick={() => handleSuggestionClick(suggestion)}
                        className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-muted/50 transition-colors group flex items-center gap-3"
                      >
                        <SearchIcon className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                        <span className="text-sm text-foreground group-hover:text-primary transition-colors">
                          {suggestion}
                        </span>
                      </button>
                    ))}
                  </div>
                ) : (
                  <div className="px-3 py-8 text-center text-sm text-muted-foreground">
                    No suggestions found
                  </div>
                )}
              </div>
            ) : recentSearches.length > 0 ? (
              // Recent searches
              <div className="p-2">
                <div className="px-3 py-2 text-xs font-medium text-muted-foreground flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-3 h-3" />
                    Recent Searches
                  </div>
                  <button
                    onClick={clearRecentSearches}
                    className="text-xs text-muted-foreground hover:text-foreground transition-colors"
                  >
                    Clear
                  </button>
                </div>
                <div className="space-y-1">
                  {recentSearches.map((search, index) => (
                    <button
                      key={index}
                      onClick={() => handleSuggestionClick(search)}
                      className="w-full text-left px-3 py-2.5 rounded-lg hover:bg-muted/50 transition-colors group flex items-center gap-3"
                    >
                      <Clock className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
                      <span className="text-sm text-foreground group-hover:text-primary transition-colors flex-1">
                        {search}
                      </span>
                      <X className="w-3 h-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
          </ScrollArea>
        </div>
      )}
    </div>
  );
};

export default SearchAutocomplete;
