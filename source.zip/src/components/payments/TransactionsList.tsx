import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle2, Clock, XCircle, Megaphone, Crown, Gift, 
  DollarSign, RefreshCw, Receipt, ShoppingBag 
} from 'lucide-react';
import { format, formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';
import type { PaymentTransaction } from '@/hooks/usePaymentData';

interface TransactionsListProps {
  transactions: PaymentTransaction[];
  variant?: 'compact' | 'full';
  limit?: number;
}

export const TransactionsList = ({ transactions, variant = 'full', limit }: TransactionsListProps) => {
  const displayTransactions = limit ? transactions.slice(0, limit) : transactions;

  const formatCurrency = (amount: number, currency: string = 'UGX') => {
    return new Intl.NumberFormat('en-UG', { 
      style: 'currency', 
      currency, 
      minimumFractionDigits: 0 
    }).format(amount);
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'completed': return { icon: CheckCircle2, color: 'text-green-600', bg: 'bg-green-500/10', label: 'Completed' };
      case 'pending': return { icon: Clock, color: 'text-amber-600', bg: 'bg-amber-500/10', label: 'Pending' };
      case 'failed': return { icon: XCircle, color: 'text-red-600', bg: 'bg-red-500/10', label: 'Failed' };
      case 'expired': return { icon: Clock, color: 'text-muted-foreground', bg: 'bg-muted', label: 'Expired' };
      default: return { icon: Clock, color: 'text-muted-foreground', bg: 'bg-muted', label: status };
    }
  };

  const getTransactionTypeConfig = (type: string) => {
    switch (type) {
      case 'boost': return { icon: Megaphone, color: 'text-primary', label: 'Ad Boost' };
      case 'subscription': return { icon: Crown, color: 'text-amber-500', label: 'Subscription' };
      case 'promotion': return { icon: Gift, color: 'text-purple-500', label: 'Promotion' };
      case 'topup': return { icon: DollarSign, color: 'text-green-500', label: 'Top Up' };
      case 'refund': return { icon: RefreshCw, color: 'text-blue-500', label: 'Refund' };
      case 'ad_purchase': return { icon: ShoppingBag, color: 'text-indigo-500', label: 'Ad Purchase' };
      default: return { icon: Receipt, color: 'text-muted-foreground', label: type };
    }
  };

  const getDescription = (transaction: PaymentTransaction) => {
    const metadata = transaction.metadata;
    if (metadata?.description) return metadata.description;
    
    const typeConfig = getTransactionTypeConfig(transaction.payment_type);
    return typeConfig.label;
  };

  if (displayTransactions.length === 0) {
    return (
      <div className="text-center py-8">
        <Receipt className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
        <p className="text-muted-foreground">No transactions yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {displayTransactions.map((transaction) => {
        const statusConfig = getStatusConfig(transaction.status);
        const typeConfig = getTransactionTypeConfig(transaction.payment_type);
        const StatusIcon = statusConfig.icon;
        const TypeIcon = typeConfig.icon;

        return (
          <div 
            key={transaction.id} 
            className={cn(
              "flex items-center gap-3 p-3 rounded-lg transition-colors",
              variant === 'compact' ? "bg-muted/30 hover:bg-muted/50" : "bg-card border",
              transaction.status === 'pending' && "border-amber-500/20",
              transaction.status === 'completed' && "border-green-500/20",
              transaction.status === 'failed' && "border-red-500/20"
            )}
          >
            <div className={cn("p-2 rounded-full", statusConfig.bg)}>
              <TypeIcon className={cn("w-4 h-4", typeConfig.color)} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm truncate">{getDescription(transaction)}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="capitalize">{transaction.payment_provider.replace('_', ' ')}</span>
                <span>•</span>
                <span>
                  {variant === 'compact' 
                    ? formatDistanceToNow(new Date(transaction.created_at), { addSuffix: true })
                    : format(new Date(transaction.created_at), 'MMM d, yyyy h:mm a')
                  }
                </span>
              </div>
              {transaction.error_message && (
                <p className="text-xs text-red-500 mt-1 truncate">{transaction.error_message}</p>
              )}
            </div>
            <div className="text-right flex-shrink-0">
              <p className="font-semibold text-sm">{formatCurrency(transaction.amount, transaction.currency)}</p>
              <Badge 
                variant="outline" 
                className={cn("text-[10px] gap-1 mt-1", statusConfig.color, statusConfig.bg)}
              >
                <StatusIcon className="w-3 h-3" />
                {statusConfig.label}
              </Badge>
            </div>
          </div>
        );
      })}
    </div>
  );
};

interface GroupedTransactionsProps {
  pendingTransactions: PaymentTransaction[];
  completedTransactions: PaymentTransaction[];
  failedTransactions: PaymentTransaction[];
}

export const GroupedTransactions = ({
  pendingTransactions,
  completedTransactions,
  failedTransactions,
}: GroupedTransactionsProps) => {
  return (
    <div className="space-y-6">
      {/* Pending Transactions */}
      {pendingTransactions.length > 0 && (
        <Card className="border-amber-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-600" />
              Pending ({pendingTransactions.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <TransactionsList transactions={pendingTransactions} variant="full" />
          </CardContent>
        </Card>
      )}

      {/* Completed Transactions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
            Completed ({completedTransactions.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <TransactionsList transactions={completedTransactions} variant="full" />
        </CardContent>
      </Card>

      {/* Failed Transactions */}
      {failedTransactions.length > 0 && (
        <Card className="border-red-500/30">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <XCircle className="w-4 h-4 text-red-600" />
              Failed ({failedTransactions.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <TransactionsList transactions={failedTransactions} variant="full" />
          </CardContent>
        </Card>
      )}
    </div>
  );
};
