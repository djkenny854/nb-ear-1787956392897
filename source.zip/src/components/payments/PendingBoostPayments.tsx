import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Megaphone, Clock, CreditCard, Smartphone, AlertCircle } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import type { BoostRequest } from '@/hooks/usePaymentData';

interface PendingBoostPaymentsProps {
  pendingBoostPayments: BoostRequest[];
  pendingBoostReview: BoostRequest[];
  mobileMoneyEnabled: boolean;
  stripeEnabled: boolean;
  onPayment: (boost: BoostRequest) => void;
}

export const PendingBoostPayments = ({
  pendingBoostPayments,
  pendingBoostReview,
  mobileMoneyEnabled,
  stripeEnabled,
  onPayment,
}: PendingBoostPaymentsProps) => {
  const navigate = useNavigate();
  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-UG', { style: 'currency', currency: 'UGX', minimumFractionDigits: 0 }).format(amount);
  };

  if (pendingBoostPayments.length === 0 && pendingBoostReview.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      {/* Approved - Ready for Payment */}
      {pendingBoostPayments.length > 0 && (
        <Card className="border-green-500/30 bg-gradient-to-r from-green-500/5 to-transparent">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-green-600" />
              Ready for Payment ({pendingBoostPayments.length})
            </CardTitle>
            <CardDescription>
              These boost requests have been approved. Complete payment to activate.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingBoostPayments.map((boost) => (
              <div key={boost.id} className="flex items-center gap-3 p-4 rounded-lg bg-card border border-green-500/20">
                <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  {boost.ad?.images?.[0] ? (
                    <img 
                      src={boost.ad.images[0]} 
                      alt={boost.ad?.title || 'Ad'} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Megaphone className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{boost.ad?.title || 'Unknown Ad'}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-[10px] capitalize">
                      {boost.boost_type}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {boost.duration_days} days
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Approved {format(new Date(boost.updated_at), 'MMM d, yyyy')}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="font-bold text-lg text-primary">{formatCurrency(boost.amount_paid)}</p>
                  <Button 
                    size="sm" 
                    className="mt-2"
                    onClick={() => onPayment(boost)}
                    disabled={!mobileMoneyEnabled && !stripeEnabled}
                  >
                    <CreditCard className="w-3 h-3 mr-1" />
                    Pay Now
                  </Button>
                </div>
              </div>
            ))}

            {!mobileMoneyEnabled && !stripeEnabled && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
                <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <p className="text-xs text-amber-700 dark:text-amber-400">
                  Payment methods are currently being set up. You'll be able to complete payment soon.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Pending Review */}
      {pendingBoostReview.length > 0 && (
        <Card className="border-amber-500/30 bg-gradient-to-r from-amber-500/5 to-transparent">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Clock className="w-4 h-4 text-amber-600" />
              Awaiting Review ({pendingBoostReview.length})
            </CardTitle>
            <CardDescription>
              These boost requests are being reviewed by our team.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingBoostReview.map((boost) => (
              <div key={boost.id} className="flex items-center gap-3 p-4 rounded-lg bg-card border border-amber-500/20 opacity-80">
                <div className="w-12 h-12 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                  {boost.ad?.images?.[0] ? (
                    <img 
                      src={boost.ad.images[0]} 
                      alt={boost.ad?.title || 'Ad'} 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Megaphone className="w-5 h-5 text-muted-foreground" />
                    </div>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{boost.ad?.title || 'Unknown Ad'}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className="text-[10px] capitalize border-amber-500/50 text-amber-600">
                      {boost.boost_type}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {boost.duration_days} days
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Submitted {format(new Date(boost.created_at), 'MMM d, yyyy')}
                  </p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="font-bold text-lg">{formatCurrency(boost.amount_paid)}</p>
                  <Badge variant="outline" className="mt-2 text-[10px] border-amber-500/50 text-amber-600 bg-amber-500/10">
                    <Clock className="w-3 h-3 mr-1" />
                    Under Review
                  </Badge>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
};
