import React from 'react';
import { Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { addWatermarkToImage } from '@/utils/watermark';
import { toast } from 'sonner';

interface ImageDownloadButtonProps {
  imageUrl: string;
  fileName?: string;
  className?: string;
}

export const ImageDownloadButton: React.FC<ImageDownloadButtonProps> = ({ 
  imageUrl, 
  fileName = 'image.jpg',
  className 
}) => {
  const handleDownload = async () => {
    try {
      // Fetch the image
      const response = await fetch(imageUrl);
      const blob = await response.blob();
      
      // Create a File object from blob
      const file = new File([blob], fileName, { type: blob.type });
      
      // Add watermark
      const watermarkedFile = await addWatermarkToImage(file);
      
      // Create download link
      const url = URL.createObjectURL(watermarkedFile);
      const link = document.createElement('a');
      link.href = url;
      link.download = `watermarked-${fileName}`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast.success('Image downloaded with watermark');
    } catch (error) {
      console.error('Error downloading image:', error);
      toast.error('Failed to download image');
    }
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={handleDownload}
      className={className}
      title="Download with watermark"
    >
      <Download className="w-4 h-4" />
    </Button>
  );
};
