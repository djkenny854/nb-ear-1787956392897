import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import HomeProductCard from './cards/HomeProductCard';
import ProductSkeleton from './LoadingSkeleton';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ChevronRight, PackageX } from 'lucide-react';

interface SimilarItemsProps {
  currentAdId: string;
  category: string;
  subcategory?: string | null;
  location: string;
  condition?: string | null;
  brand?: string | null;
  color?: string | null;
  onLike?: (id: string) => void;
  onSave?: (id: string) => void;
  onCall?: (id: string) => void;
  likedAds?: Set<string>;
  savedAds?: Set<string>;
  maxItems?: number;
}

const SimilarItems: React.FC<SimilarItemsProps> = ({
  currentAdId,
  category,
  subcategory,
  location,
  condition,
  brand,
  color,
  maxItems = 6,
}) => {
  const navigate = useNavigate();

  const { data: similarAds = [], isLoading } = useQuery({
    queryKey: ['similar-items', currentAdId, category, subcategory, condition, brand],
    queryFn: async () => {
      const selectFields = `
        id, title, price, original_price, location, images, is_boosted, has_discount,
        created_at, seller_id, category, subcategory, inventory_count, view_count, condition, brand
      `;

      const baseQuery = () => supabase
        .from('ads')
        .select(selectFields)
        .eq('status', 'active')
        .neq('id', currentAdId);

      // Only match by subcategory if available
      if (!subcategory) {
        return [];
      }

      // Tier 0: Same subcategory + condition + brand
      let tier0Data: any[] = [];
      if (condition && brand) {
        const { data } = await baseQuery()
          .eq('subcategory', subcategory)
          .eq('condition', condition)
          .ilike('brand', brand)
          .order('is_boosted', { ascending: false })
          .order('created_at', { ascending: false })
          .limit(12);
        tier0Data = data || [];
      }

      // Tier 1: Same subcategory + condition
      let tier1Data: any[] = [];
      if (condition && tier0Data.length < 12) {
        const existingIds = new Set(tier0Data.map(d => d.id));
        const { data } = await baseQuery()
          .eq('subcategory', subcategory)
          .eq('condition', condition)
          .order('is_boosted', { ascending: false })
          .order('created_at', { ascending: false })
          .limit(12 - tier0Data.length);
        tier1Data = (data || []).filter(d => !existingIds.has(d.id));
      }

      // Tier 2: Same subcategory only
      let tier2Data: any[] = [];
      const allPrev = [...tier0Data, ...tier1Data];
      if (allPrev.length < 12) {
        const existingIds = new Set(allPrev.map(d => d.id));
        const { data } = await baseQuery()
          .eq('subcategory', subcategory)
          .order('is_boosted', { ascending: false })
          .order('created_at', { ascending: false })
          .limit(12 - allPrev.length);
        tier2Data = (data || []).filter(d => !existingIds.has(d.id));
      }

      const adsData = [...tier0Data, ...tier1Data, ...tier2Data];

      if (adsData.length === 0) return [];

      // Get seller data
      const sellerIds = adsData.map(ad => ad.seller_id).filter(Boolean);
      let sellersData: any[] = [];
      if (sellerIds.length > 0) {
        const { data: sellers } = await supabase
          .from('seller_profiles')
          .select('id, business_name, business_logo_url, is_verified, district, sub_county')
          .in('id', [...new Set(sellerIds)]);
        sellersData = sellers || [];
      }

      return adsData.map(ad => ({
        id: ad.id,
        title: ad.title,
        price: ad.price || 0,
        original_price: ad.original_price,
        location: ad.location || 'Uganda',
        images: ad.images || [],
        is_boosted: ad.is_boosted,
        has_discount: ad.has_discount,
        created_at: ad.created_at,
        inventory_count: ad.inventory_count,
        view_count: ad.view_count,
        seller: sellersData.find(seller => seller.id === ad.seller_id) || null
      }));
    },
  });

  const handleAdClick = (id: string) => {
    navigate(`/ad/${id}`);
  };

  if (isLoading) {
    return (
      <div>
        <h3 className="text-lg font-semibold mb-4">Similar Items</h3>
        <ProductSkeleton count={maxItems} layout="grid" />
      </div>
    );
  }

  if (similarAds.length === 0) {
    return (
      <div>
        <h3 className="text-lg font-semibold mb-4">Similar Items</h3>
        <div className="flex flex-col items-center justify-center py-8 text-center">
          <PackageX className="w-10 h-10 text-muted-foreground mb-2" />
          <p className="text-muted-foreground text-sm">No similar products found</p>
        </div>
      </div>
    );
  }

  // Hard cap at 15 similar items regardless of the caller-provided value.
  const cap = Math.min(maxItems, 15);
  const displayedAds = similarAds.slice(0, cap);
  const hasMore = similarAds.length > cap;

  return (
    <div>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          Similar Items
          <span className="text-sm text-muted-foreground font-normal">({displayedAds.length} items)</span>
        </h3>
        {hasMore && (
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => navigate(`/search?category=${encodeURIComponent(subcategory || category)}`)}
            className="text-primary hover:text-primary/80 gap-1"
          >
            Show more
            <ChevronRight className="w-4 h-4" />
          </Button>
        )}
      </div>
      
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2 sm:gap-3">
        {displayedAds.map((ad) => (
          <div key={ad.id} className="w-full">
            <HomeProductCard
              id={ad.id}
              title={ad.title}
              price={ad.price}
              originalPrice={ad.original_price}
              images={ad.images}
              location={ad.location}
              viewCount={ad.view_count}
              isBoosted={ad.is_boosted}
              hasDiscount={ad.has_discount}
              createdAt={ad.created_at}
              inventoryCount={ad.inventory_count}
              seller={ad.seller ? {
                business_name: ad.seller.business_name,
                business_logo_url: ad.seller.business_logo_url,
                is_verified: ad.seller.is_verified,
                district: ad.seller.district,
                sub_county: ad.seller.sub_county
              } : null}
              onClick={() => handleAdClick(ad.id)}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default SimilarItems;
