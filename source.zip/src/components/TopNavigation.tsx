import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronDown, User, Globe, Menu, X, Store, Users, Shield, BookOpen, TrendingUp, Zap, Award, HeadphonesIcon, MessageSquare, Phone, Search } from 'lucide-react';
import { useAuth } from '@/components/auth/AuthContext';
import AnimatedSearchBar from '@/components/search/AnimatedSearchBar';
import { useLanguage } from '@/contexts/LanguageContext';
import { useCurrency } from '@/contexts/CurrencyContext';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuList,
  NavigationMenuTrigger,
} from '@/components/ui/navigation-menu';

const TopNavigation = () => {
  const navigate = useNavigate();
  const { user, signOut } = useAuth();
  const { theme } = useTheme();
  const { language } = useLanguage();
  const { currency, getCurrencySymbol } = useCurrency();
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [searchExpanded, setSearchExpanded] = useState(false);

  // Get display text for language - now reactive to context changes
  const languageDisplay = language === 'sw' ? 'SW' : 'EN';
  // Get currency symbol - reactive to context changes
  const currencyDisplay = getCurrencySymbol();

  const megaMenuItems = {
    'Get Started': {
      icon: Zap,
      columns: [{
        title: 'Quick Start',
        links: [{
          label: 'How It Works',
          icon: BookOpen,
          path: '/how-it-works',
          description: 'Learn the basics of EarlyMarket'
        }, {
          label: 'Create Account',
          icon: User,
          path: '/auth',
          description: 'Join our community today'
        }, {
          label: 'Post Your First Ad',
          icon: Store,
          path: '/post-ad',
          description: 'List your first product'
        }, {
          label: 'Verification Guide',
          icon: Shield,
          path: '/verification',
          description: 'Get verified for trust'
        }]
      }, {
        title: 'New User Guide',
        links: [{
          label: 'Account Setup',
          icon: User,
          path: '/setup',
          description: 'Complete your profile'
        }, {
          label: 'Safety Tips',
          icon: Shield,
          path: '/safety',
          description: 'Trade safely online'
        }, {
          label: 'Payment Methods',
          icon: TrendingUp,
          path: '/payments',
          description: 'Secure payment options'
        }]
      }, {
        title: 'Get the App',
        links: [{
          label: 'Download iOS',
          icon: Phone,
          path: '#',
          description: 'Get it on the App Store',
          image: 'https://developer.apple.com/app-store/marketing/guidelines/images/badge-example-preferred_2x.png'
        }, {
          label: 'Download Android',
          icon: Phone,
          path: '#',
          description: 'Get it on Google Play',
          image: 'https://upload.wikimedia.org/wikipedia/commons/7/78/Google_Play_Store_badge_EN.svg'
        }, {
          label: 'Scan QR Code',
          icon: HeadphonesIcon,
          path: '#',
          description: 'Scan to download instantly',
          qrCode: true
        }]
      }]
    },
    'Marketplace': {
      icon: Store,
      columns: [{
        title: 'Browse Categories',
        links: [{
          label: 'All Categories',
          icon: Store,
          path: '/search',
          description: 'Explore all products'
        }, {
          label: 'Featured Items',
          icon: Award,
          path: '/search?featured=true',
          description: 'Top rated products'
        }, {
          label: 'New Arrivals',
          icon: Zap,
          path: '/search?sort=newest',
          description: 'Latest listings'
        }, {
          label: 'Best Sellers',
          icon: TrendingUp,
          path: '/search?sort=popular',
          description: 'Most popular items'
        }]
      }, {
        title: 'Seller Tools',
        links: [{
          label: 'Seller Dashboard',
          icon: Store,
          path: '/seller-dashboard',
          description: 'Manage your listings'
        }, {
          label: 'Post an Ad',
          icon: Store,
          path: '/post-ad',
          description: 'List your product'
        }, {
          label: 'Analytics',
          icon: TrendingUp,
          path: '/analytics',
          description: 'Track performance'
        }, {
          label: 'Business Profile',
          icon: Award,
          path: '/create-business-account',
          description: 'Create your business account'
        }]
      }, {
        title: 'Support',
        links: [{
          label: 'Help Center',
          icon: HeadphonesIcon,
          path: '/help',
          description: 'Get support'
        }, {
          label: 'Contact Us',
          icon: Phone,
          path: '/contact',
          description: 'Reach our team'
        }, {
          label: 'Trading Tips',
          icon: BookOpen,
          path: '/trading-tips',
          description: 'Expert advice'
        }]
      }]
    }
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (showUserMenu && !(event.target as Element).closest('.user-menu-container')) {
        setShowUserMenu(false);
      }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [showUserMenu]);

  return (
    <nav className="bg-background sticky top-0 z-50 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between h-12 md:h-14">
          {/* Logo - Always visible */}
          <div onClick={() => navigate('/')} className="flex items-center gap-2 flex-shrink-0 cursor-pointer">
            <img
              src={earlymarketLogo}
              alt="EarlyMarket"
              className="h-8 md:h-10 w-auto object-contain"
            />
            <span
              className="text-foreground font-medium tracking-tight text-[20px] md:text-[22px] leading-relaxed"
            >
              Earlymarket
            </span>
          </div>

          {/* Desktop - Only show search and essential actions */}
          <div className="hidden lg:flex items-center gap-4 flex-1 justify-end">
            {/* Global Search Icon */}
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/search')}
              className="flex items-center gap-2 text-foreground hover:text-primary"
            >
              <Search className="w-5 h-5" />
              <span className="text-sm">Search</span>
            </Button>

            {/* Language/Currency */}
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={() => navigate('/account-settings?tab=my-account')}
              className="flex items-center gap-2 text-sm"
            >
              <Globe className="w-5 h-5" />
              <span>{languageDisplay}/{currencyDisplay}</span>
            </Button>

            {/* User Menu */}
            <div className="relative user-menu-container">
              <Button variant="ghost" size="sm" onClick={() => setShowUserMenu(!showUserMenu)} className="flex items-center gap-2 text-sm">
                <User className="w-5 h-5" />
                <span>{user ? 'Account' : 'Sign In'}</span>
                <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${showUserMenu ? 'rotate-180' : ''}`} />
              </Button>

              {showUserMenu && (
                <div className="absolute right-0 top-full mt-2 w-48 bg-card rounded-lg shadow-xl border border-border py-2 animate-fade-in z-[60]">
                  {user ? (
                    <>
                      <button onClick={() => navigate('/profile')} className="w-full text-left px-4 py-2 hover:bg-accent transition-colors text-sm text-foreground">
                        My Profile
                      </button>
                      <button onClick={() => navigate('/dashboard')} className="w-full text-left px-4 py-2 hover:bg-accent transition-colors text-sm text-foreground">
                        Dashboard
                      </button>
                      <hr className="my-2" />
                      <button onClick={() => {
                        signOut();
                        setShowUserMenu(false);
                      }} className="w-full text-left px-4 py-2 hover:bg-accent text-destructive transition-colors text-sm">
                        Sign Out
                      </button>
                    </>
                  ) : (
                    <>
                      <button onClick={() => navigate('/auth')} className="w-full text-left px-4 py-2 hover:bg-accent transition-colors text-sm text-foreground">
                        Sign In
                      </button>
                      <button onClick={() => navigate('/auth')} className="w-full text-left px-4 py-2 hover:bg-accent transition-colors text-sm text-foreground">
                        Create Account
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Mobile - Search bar and language/currency */}
          <div className="flex lg:hidden items-center gap-2">
            <AnimatedSearchBar 
              isExpanded={searchExpanded} 
              onExpandChange={setSearchExpanded} 
            />
            
            {/* Language/Currency - Mobile */}
            {!searchExpanded && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => navigate('/account-settings?tab=my-account')}
                className="flex items-center gap-1 text-xs px-2"
              >
                <Globe className="w-4 h-4" />
                <span>{languageDisplay}/{currencyDisplay}</span>
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default TopNavigation;
