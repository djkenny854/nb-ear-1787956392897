
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, AlertTriangle, MapPin, Tag, Calendar } from 'lucide-react';

interface ReviewData {
  productData: any;
  locationData: any;
  images: any[];
}

interface Step3Props {
  data: ReviewData;
}

export const Step3ReviewPublish: React.FC<Step3Props> = ({ data }) => {
  const { productData, locationData, images } = data;
  
  const getQualityStats = () => {
    const highQualityImages = images.filter(img => img.isHighQuality).length;
    const lowQualityImages = images.length - highQualityImages;
    return { highQualityImages, lowQualityImages };
  };

  const qualityStats = getQualityStats();
  const isReadyToPublish = images.length > 0 && productData.title && productData.description && productData.price && locationData.location;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            Review Your Listing
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground mb-4">
            Please review all the information below before publishing your ad. Make sure everything is correct.
          </p>
        </CardContent>
      </Card>

      {/* Product Information */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Tag className="w-4 h-4" />
            Product Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium text-lg">{productData.title || 'No title provided'}</h3>
            <p className="text-muted-foreground mt-1">{productData.description || 'No description provided'}</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="font-medium">Price:</span>
              <p className="text-muted-foreground">{productData.currency || 'UGX'} {productData.price || 'Not set'}</p>
            </div>
            <div>
              <span className="font-medium">Condition:</span>
              <p className="text-muted-foreground">{productData.condition || 'Not specified'}</p>
            </div>
            <div>
              <span className="font-medium">Brand:</span>
              <p className="text-muted-foreground">{productData.brand || 'Not specified'}</p>
            </div>
            <div>
              <span className="font-medium">Model:</span>
              <p className="text-muted-foreground">{productData.model || 'Not specified'}</p>
            </div>
          </div>

          {(productData.color || productData.size || productData.weight) && (
            <div className="grid grid-cols-3 gap-4 text-sm">
              {productData.color && (
                <div>
                  <span className="font-medium">Color:</span>
                  <p className="text-muted-foreground">{productData.color}</p>
                </div>
              )}
              {productData.size && (
                <div>
                  <span className="font-medium">Size:</span>
                  <p className="text-muted-foreground">{productData.size}</p>
                </div>
              )}
              {productData.weight && (
                <div>
                  <span className="font-medium">Weight:</span>
                  <p className="text-muted-foreground">{productData.weight}</p>
                </div>
              )}
            </div>
          )}

          {productData.features && (
            <div>
              <span className="font-medium">Key Features:</span>
              <p className="text-muted-foreground whitespace-pre-line">{productData.features}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Images Review */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Images ({images.length}/25)</CardTitle>
        </CardHeader>
        <CardContent>
          {images.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <AlertTriangle className="w-12 h-12 mx-auto mb-2" />
              <p>No images uploaded. At least one image is required.</p>
            </div>
          ) : (
            <>
              <div className="flex gap-2 mb-4">
                <Badge variant="secondary" className="bg-green-500 text-white">
                  {qualityStats.highQualityImages} High Quality
                </Badge>
                {qualityStats.lowQualityImages > 0 && (
                  <Badge variant="secondary" className="bg-orange-500 text-white">
                    {qualityStats.lowQualityImages} Need Enhancement
                  </Badge>
                )}
              </div>
              
              <div className="grid grid-cols-4 md:grid-cols-6 gap-2">
                {images.map((image, index) => (
                  <div key={image.id} className="relative aspect-square">
                    <img
                      src={image.url}
                      alt={`Product ${index + 1}`}
                      className="w-full h-full object-cover rounded border"
                    />
                    {index === 0 && (
                      <Badge className="absolute -top-2 -left-2 bg-primary text-xs">
                        Main
                      </Badge>
                    )}
                    {!image.isHighQuality && (
                      <div className="absolute -top-1 -right-1">
                        <AlertTriangle className="w-4 h-4 text-orange-500" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {/* Location */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Location
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            {locationData.location || 'No location selected'}
          </p>
        </CardContent>
      </Card>

      {/* Publishing Status */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Publishing Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isReadyToPublish ? (
            <div className="flex items-center gap-2 text-green-600">
              <CheckCircle className="w-5 h-5" />
              <span>Your listing is ready to publish!</span>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-orange-600">
              <AlertTriangle className="w-5 h-5" />
              <span>Please complete all required fields before publishing.</span>
            </div>
          )}
          
          {qualityStats.lowQualityImages > 0 && (
            <p className="text-sm text-muted-foreground mt-2">
              Consider enhancing {qualityStats.lowQualityImages} image(s) for better visibility.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
