
import React, { useState, useRef } from 'react';
import { cn } from '@/lib/utils';

interface FloatingLabelTextareaProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  rows?: number;
  className?: string;
}

export const FloatingLabelTextarea: React.FC<FloatingLabelTextareaProps> = ({
  label,
  value,
  onChange,
  placeholder = '',
  required = false,
  rows = 4,
  className
}) => {
  const [isFocused, setIsFocused] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const hasValue = value && value.length > 0;
  const isLabelFloating = isFocused || hasValue;

  return (
    <div className={cn("relative group", className)}>
      <textarea
        ref={textareaRef}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onFocus={() => setIsFocused(true)}
        onBlur={() => setIsFocused(false)}
        placeholder={isLabelFloating ? placeholder : ''}
        required={required}
        rows={rows}
        className={cn(
          "w-full px-4 pt-7 pb-3 bg-white border-2 rounded-xl transition-all duration-300 outline-none resize-none",
          "shadow-sm hover:shadow-md",
          isFocused 
            ? "border-blue-500 shadow-lg shadow-blue-500/20 ring-4 ring-blue-500/10" 
            : hasValue 
              ? "border-gray-300" 
              : "border-gray-200",
          "hover:border-blue-300"
        )}
      />
      <label
        className={cn(
          "absolute left-4 pointer-events-none transition-all duration-300 ease-out cursor-text",
          isLabelFloating
            ? "top-2 text-xs font-semibold text-blue-600"
            : "top-6 text-base text-gray-500 group-hover:text-gray-700"
        )}
        onClick={() => textareaRef.current?.focus()}
      >
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      
      {/* Bottom border animation */}
      <div 
        className={cn(
          "absolute bottom-0 left-0 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-300",
          isFocused ? "w-full" : "w-0"
        )}
      />
    </div>
  );
};
