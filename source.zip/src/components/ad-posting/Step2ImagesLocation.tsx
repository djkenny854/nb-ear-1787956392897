
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { MapPin } from 'lucide-react';
import { ImageUploadWithEditor } from './ImageUploadWithEditor';
import SearchableLocationSelector from '@/components/seller/SearchableLocationSelector';

interface LocationFormData {
  location: string;
}

interface ImageData {
  id: string;
  file: File;
  url: string;
  isHighQuality: boolean;
  qualityScore: number;
  edited?: boolean;
}

interface SellerProfile {
  district?: string;
  sub_county?: string;
  parish?: string;
  village?: string;
}

interface Step2Props {
  locationData: LocationFormData;
  onLocationChange: (field: keyof LocationFormData, value: string) => void;
  images: ImageData[];
  onImagesChange: (images: ImageData[]) => void;
  locations: any[];
  sellerProfile?: SellerProfile;
}

export const Step2ImagesLocation: React.FC<Step2Props> = ({
  locationData,
  onLocationChange,
  images,
  onImagesChange,
  locations,
  sellerProfile
}) => {
  const [useBusinessLocation, setUseBusinessLocation] = React.useState(false);
  const [customLocation, setCustomLocation] = React.useState({
    district: '',
    subCounty: '',
    parish: '',
    village: ''
  });

  const handleLocationSelect = (location: any) => {
    setCustomLocation({
      district: location.district || '',
      subCounty: location.subcounty || '',
      parish: location.parish || '',
      village: location.village || ''
    });
    
    // Format the location string
    const locationParts = [
      location.district,
      location.subcounty,
      location.parish,
      location.village
    ].filter(Boolean);
    
    onLocationChange('location', locationParts.join(', '));
  };

  const handleLocationFieldChange = (field: string, value: string) => {
    setCustomLocation(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleUseBusinessLocation = () => {
    if (sellerProfile) {
      const businessLocationParts = [
        sellerProfile.district,
        sellerProfile.sub_county,
        sellerProfile.parish,
        sellerProfile.village
      ].filter(Boolean);
      
      onLocationChange('location', businessLocationParts.join(', '));
      setUseBusinessLocation(true);
    }
  };

  return (
    <div className="space-y-6">
      <ImageUploadWithEditor
        images={images}
        onImagesChange={onImagesChange}
        maxImages={25}
      />

      <Card className="backdrop-blur-sm bg-white/50 border-white/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Location & Delivery
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Business Location Option */}
          {sellerProfile && (
            <div className="p-4 rounded-lg bg-blue-50/50 border border-blue-200/50">
              <div className="flex items-center justify-between mb-2">
                <div>
                  <h4 className="font-medium text-blue-900">Use Business Location</h4>
                  <p className="text-sm text-blue-700">
                    {[sellerProfile.district, sellerProfile.sub_county, sellerProfile.parish, sellerProfile.village]
                      .filter(Boolean)
                      .join(', ')}
                  </p>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleUseBusinessLocation}
                  className="bg-blue-100 border-blue-300 text-blue-700 hover:bg-blue-200"
                >
                  Use This Location
                </Button>
              </div>
            </div>
          )}

          {/* Custom Location Selector */}
          <div>
            <Label className="text-base font-medium mb-4 block">
              {sellerProfile ? 'Or Choose Different Location *' : 'Product Location *'}
            </Label>
            <SearchableLocationSelector
              onLocationSelect={handleLocationSelect}
              district={customLocation.district}
              subCounty={customLocation.subCounty}
              parish={customLocation.parish}
              village={customLocation.village}
              onLocationChange={handleLocationFieldChange}
              required={true}
            />
          </div>

          {/* Current Selected Location Display */}
          {locationData.location && (
            <div className="p-3 bg-green-50/50 border border-green-200/50 rounded-lg">
              <h4 className="font-medium text-green-900 mb-1">Selected Location:</h4>
              <p className="text-sm text-green-700">{locationData.location}</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};
