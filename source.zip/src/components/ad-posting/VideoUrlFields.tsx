
import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Lock, Check, AlertCircle, Link2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import YouTubeEmbed from '@/components/YouTubeEmbed';

interface VideoUrlFieldsProps {
  formData: Record<string, any>;
  onFormChange: (field: string, value: any) => void;
  isVerified: boolean;
}

const VideoUrlFields: React.FC<VideoUrlFieldsProps> = ({
  formData,
  onFormChange,
  isVerified
}) => {
  const navigate = useNavigate();

  const validateYouTubeUrl = (url: string) => {
    const pattern = /^(https?:\/\/)?(www\.)?(youtube\.com\/watch\?v=|youtu\.be\/)[\w-]+/;
    return pattern.test(url);
  };

  const validateTikTokUrl = (url: string) => {
    const pattern = /^(https?:\/\/)?(www\.)?tiktok\.com\/@[\w.-]+\/video\/\d+/;
    return pattern.test(url);
  };

  if (!isVerified) {
    return (
      <div className="rounded-2xl bg-muted/40 border border-border p-5 flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-muted rounded-full">
            <Lock className="w-5 h-5 text-muted-foreground" />
          </div>
          <div>
            <h4 className="font-semibold text-sm">Video links locked</h4>
            <p className="text-xs text-muted-foreground">
              Verified sellers can embed YouTube and TikTok videos.
            </p>
          </div>
        </div>
        <Button onClick={() => navigate('/verify')} size="sm" className="rounded-full">
          Verify now
        </Button>
      </div>
    );
  }

  const yt = formData.youtube_url || '';
  const tt = formData.tiktok_url || '';
  const ytValid = yt ? validateYouTubeUrl(yt) : null;
  const ttValid = tt ? validateTikTokUrl(tt) : null;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="p-1.5 rounded-lg bg-primary/10">
          <Link2 className="w-4 h-4 text-primary" />
        </div>
        <h3 className="text-base font-semibold">Link a video from YouTube or TikTok</h3>
      </div>
      <p className="text-sm text-muted-foreground">
        Already have your video online? Paste the link and we'll embed it on your listing.
      </p>

      <div className="grid gap-3 md:grid-cols-2">
        {/* YouTube */}
        <div className="space-y-1.5">
          <Label htmlFor="youtube_url" className="text-xs font-medium text-muted-foreground">
            YouTube
          </Label>
          <div className="relative">
            <span className="absolute left-2 top-1/2 -translate-y-1/2 inline-flex items-center justify-center w-7 h-7 rounded-md bg-[#FF0000] text-white">
              {/* YouTube glyph */}
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="currentColor" aria-hidden="true">
                <path d="M21.6 7.2a2.5 2.5 0 0 0-1.8-1.8C18.3 5 12 5 12 5s-6.3 0-7.8.4A2.5 2.5 0 0 0 2.4 7.2 26 26 0 0 0 2 12a26 26 0 0 0 .4 4.8 2.5 2.5 0 0 0 1.8 1.8C5.7 19 12 19 12 19s6.3 0 7.8-.4a2.5 2.5 0 0 0 1.8-1.8A26 26 0 0 0 22 12a26 26 0 0 0-.4-4.8zM10 15V9l5.2 3L10 15z" />
              </svg>
            </span>
            <Input
              id="youtube_url"
              type="url"
              placeholder="https://youtube.com/watch?v=..."
              value={yt}
              onChange={(e) => onFormChange('youtube_url', e.target.value)}
              className="pl-12 h-11 rounded-xl"
            />
          </div>
          {ytValid === false && (
            <p className="text-[11px] text-destructive flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Doesn't look like a YouTube URL
            </p>
          )}
          {ytValid === true && (
            <p className="text-[11px] text-emerald-600 flex items-center gap-1">
              <Check className="w-3 h-3" /> Will embed on your listing
            </p>
          )}
        </div>

        {/* TikTok */}
        <div className="space-y-1.5">
          <Label htmlFor="tiktok_url" className="text-xs font-medium text-muted-foreground">
            TikTok
          </Label>
          <div className="relative">
            <span className="absolute left-2 top-1/2 -translate-y-1/2 inline-flex items-center justify-center w-7 h-7 rounded-md bg-black text-white">
              {/* TikTok glyph */}
              <svg viewBox="0 0 24 24" className="w-4 h-4" fill="currentColor" aria-hidden="true">
                <path d="M16.5 3a5.5 5.5 0 0 0 4 4v3a8.5 8.5 0 0 1-4-1v6.5a6 6 0 1 1-6-6h.5v3.2a3 3 0 1 0 2.5 3V3h3z" />
              </svg>
            </span>
            <Input
              id="tiktok_url"
              type="url"
              placeholder="https://tiktok.com/@user/video/..."
              value={tt}
              onChange={(e) => onFormChange('tiktok_url', e.target.value)}
              className="pl-12 h-11 rounded-xl"
            />
          </div>
          {ttValid === false && (
            <p className="text-[11px] text-destructive flex items-center gap-1">
              <AlertCircle className="w-3 h-3" /> Doesn't look like a TikTok video URL
            </p>
          )}
          {ttValid === true && (
            <p className="text-[11px] text-emerald-600 flex items-center gap-1">
              <Check className="w-3 h-3" /> Will embed on your listing
            </p>
          )}
        </div>
      </div>

      {/* YouTube preview */}
      {ytValid && (
        <div className="rounded-2xl overflow-hidden border border-border">
          <YouTubeEmbed url={yt} height="220" title="YouTube preview" />
        </div>
      )}

      <p className="text-[11px] text-muted-foreground">
        Tip: short clips (under 60 seconds) get the most views. Use good lighting and steady framing.
      </p>
    </div>
  );
};

export default VideoUrlFields;
