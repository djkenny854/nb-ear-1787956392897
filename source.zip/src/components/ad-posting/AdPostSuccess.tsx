
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Share2, Eye, Edit } from 'lucide-react';
import { getShareableUrl } from '@/utils/getAppUrl';

interface AdPostSuccessProps {
  adId: string;
  onContinue: () => void;
}

export const AdPostSuccess: React.FC<AdPostSuccessProps> = ({ adId, onContinue }) => {
  const handleShare = async () => {
    const url = getShareableUrl(`/ad/${adId}`);
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Check out my ad!',
          text: 'I just posted a new ad on EarlyMarket',
          url: url
        });
      } catch (err) {
        console.log('Share cancelled');
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(url);
      alert('Ad link copied to clipboard!');
    }
  };

  const handleViewAd = () => {
    window.open(`/ad/${adId}`, '_blank');
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-green-50 to-blue-50 p-4">
      <Card className="max-w-md w-full backdrop-blur-md bg-white/90 border-white/20 shadow-2xl">
        <CardContent className="p-8 text-center">
          {/* Success Icon */}
          <div className="mb-6">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </div>

          {/* Success Message */}
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            🎉 Ad Posted Successfully!
          </h2>
          <p className="text-gray-600 mb-6">
            Your ad is now live and visible to thousands of potential buyers. 
            Start getting inquiries from interested customers!
          </p>

          {/* Action Buttons */}
          <div className="space-y-3">
            <Button
              onClick={handleViewAd}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
            >
              <Eye className="w-4 h-4 mr-2" />
              View Your Ad
            </Button>

            <Button
              onClick={handleShare}
              variant="outline"
              className="w-full bg-white/50 backdrop-blur-sm"
            >
              <Share2 className="w-4 h-4 mr-2" />
              Share Ad
            </Button>

            <Button
              onClick={onContinue}
              variant="ghost"
              className="w-full text-gray-600 hover:text-gray-900"
            >
              Go to Profile
            </Button>
          </div>

          {/* Additional Info */}
          <div className="mt-6 p-4 bg-blue-50 rounded-lg">
            <h3 className="font-semibold text-blue-900 mb-2">What's Next?</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Respond quickly to buyer inquiries</li>
              <li>• Keep your ad updated with accurate info</li>
              <li>• Consider boosting for more visibility</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
