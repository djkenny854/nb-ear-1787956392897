import React, { useState, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Upload, X, Edit, AlertTriangle, CheckCircle, Video, Play, FileImage, FileVideo, VideoOff, Sparkles, Scissors, Image as ImageLucide } from 'lucide-react';
import { toast } from 'sonner';
import { ImageEditor } from './ImageEditor';
import { useVideoUploadsEnabled } from '@/hooks/useVideoUploadsEnabled';
import { useAIFeatureFlags } from '@/hooks/useAIFeatureFlags';
import EMIIcon from '@/components/icons/EMIIcon';
import { supabase } from '@/integrations/supabase/client';
import { StackedFramesIllustration } from './MediaIllustrations';
import { MAX_VIDEO_UPLOAD_MB } from '@/utils/uploadVideoToB2';

interface MediaData {
  id: string;
  file: File;
  url: string;
  isHighQuality: boolean;
  qualityScore: number;
  edited?: boolean;
  type: 'image' | 'video';
  enhanced?: boolean;
}

// Keep backward compatibility with ImageData
interface ImageData {
  id: string;
  file: File;
  url: string;
  isHighQuality: boolean;
  qualityScore: number;
  edited?: boolean;
  type?: 'image' | 'video';
  enhanced?: boolean;
}

interface ImageUploadWithEditorProps {
  images: ImageData[];
  onImagesChange: (images: ImageData[]) => void;
  maxImages?: number;
  allowVideo?: boolean;
  maxVideoSizeMB?: number;
}

const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      resolve(result.split(',')[1] || '');
    };
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });

export const ImageUploadWithEditor: React.FC<ImageUploadWithEditorProps> = ({
  images,
  onImagesChange,
  maxImages = 10,
  allowVideo = true,
  maxVideoSizeMB = MAX_VIDEO_UPLOAD_MB
}) => {
  const { videoEnabled, loading: videoFlagLoading } = useVideoUploadsEnabled();
  const { enhanceImageEnabled } = useAIFeatureFlags();
  const effectiveAllowVideo = allowVideo && videoEnabled;
  const [dragActive, setDragActive] = useState(false);
  const [editingImageId, setEditingImageId] = useState<string | null>(null);
  const [enhancingIds, setEnhancingIds] = useState<Set<string>>(new Set());
  const [enhancingAll, setEnhancingAll] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const imageItems = images.filter(img => img.type !== 'video');
  const videoItem = images.find(img => img.type === 'video');
  const canEnhanceAll = imageItems.length > 0 && imageItems.length <= 5 && !enhancingAll;

  const enhanceImage = async (imageId: string) => {
    const image = images.find(i => i.id === imageId);
    if (!image || image.type === 'video' || image.enhanced || image.isHighQuality) return;

    setEnhancingIds(prev => new Set(prev).add(imageId));

    try {
      const base64 = await fileToBase64(image.file);
      const { data, error } = await supabase.functions.invoke('enhance-image', {
        body: { imageBase64: base64, mimeType: image.file.type },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      if (data?.enhancedImageBase64 && data.enhanced) {
        const byteString = atob(data.enhancedImageBase64);
        const ab = new ArrayBuffer(byteString.length);
        const ia = new Uint8Array(ab);
        for (let i = 0; i < byteString.length; i++) {
          ia[i] = byteString.charCodeAt(i);
        }
        const blob = new Blob([ab], { type: image.file.type || 'image/jpeg' });
        const enhancedFile = new File([blob], `enhanced-${image.file.name}`, { type: image.file.type || 'image/jpeg' });

        const newUrl = URL.createObjectURL(enhancedFile);
        URL.revokeObjectURL(image.url);

        const updated = images.map(img =>
          img.id === imageId
            ? { ...img, file: enhancedFile, url: newUrl, enhanced: true, isHighQuality: true, qualityScore: 95 }
            : img
        );
        onImagesChange(updated);
        toast.success('Image enhanced with EMI!');
      } else {
        toast.info(data?.message || 'Enhancement not available for this image');
      }
    } catch (err: any) {
      console.error('Enhancement error:', err);
      const message = err?.context?.error || err?.message || '';
      if (message.includes('non-2xx') || message.includes('non-2XX')) {
        toast.error('AI enhancement service failed. Please try again in a few seconds.');
      } else {
        toast.error(message || 'Failed to enhance image');
      }
    } finally {
      setEnhancingIds(prev => {
        const next = new Set(prev);
        next.delete(imageId);
        return next;
      });
    }
  };

  const enhanceAllImages = async () => {
    const eligibleImages = imageItems.filter(img => !img.enhanced && !img.isHighQuality);
    if (eligibleImages.length === 0) {
      toast.info('No low-quality images need enhancement');
      return;
    }

    setEnhancingAll(true);
    const allIds = new Set(eligibleImages.map(i => i.id));
    setEnhancingIds(allIds);

    for (const img of eligibleImages) {
      await enhanceImage(img.id);
    }

    setEnhancingAll(false);
    setEnhancingIds(new Set());
  };

  const checkImageQuality = (file: File): Promise<{ isHighQuality: boolean; score: number }> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const minWidth = 800;
        const minHeight = 600;
        const minFileSize = 100 * 1024;
        const maxFileSize = 10 * 1024 * 1024;

        let score = 0;
        if (img.width >= minWidth && img.height >= minHeight) score += 30;
        if (file.size >= minFileSize && file.size <= maxFileSize) score += 20;
        const aspectRatio = img.width / img.height;
        if (aspectRatio >= 0.5 && aspectRatio <= 2.0) score += 20;
        if (file.type === 'image/jpeg' || file.type === 'image/png') score += 15;
        score += 15;

        resolve({ isHighQuality: score >= 60, score });
      };
      img.onerror = () => resolve({ isHighQuality: false, score: 0 });
      img.src = URL.createObjectURL(file);
    });
  };

  const handleFiles = useCallback(async (files: FileList) => {
    const fileArray = Array.from(files);
    const imageFiles = fileArray.filter(f => f.type.startsWith('image/'));
    const videoFiles = fileArray.filter(f => f.type.startsWith('video/'));

    if (videoFiles.length > 0 && !effectiveAllowVideo) {
      toast.error('Video uploads are currently disabled');
      if (imageFiles.length === 0) return;
    }

    const existingVideo = images.find(img => img.type === 'video');
    const totalImagesCount = images.filter(img => img.type !== 'video').length;

    if (totalImagesCount + imageFiles.length > maxImages) {
      toast.error(`You can only upload up to ${maxImages} images`);
      return;
    }

    if (videoFiles.length > 1 || (existingVideo && videoFiles.length > 0)) {
      toast.error('Only one video is allowed per listing');
      return;
    }

    const newMedia: ImageData[] = [];
    
    for (let i = 0; i < imageFiles.length; i++) {
      const file = imageFiles[i];
      if (file.size > 10 * 1024 * 1024) {
        toast.error(`${file.name} is too large. Maximum size is 10MB for images`);
        continue;
      }
      try {
        const quality = await checkImageQuality(file);
        newMedia.push({
          id: `${Date.now()}-${i}`,
          file,
          url: URL.createObjectURL(file),
          isHighQuality: quality.isHighQuality,
          qualityScore: quality.score,
          type: 'image'
        });
      } catch (error) {
        console.error('Error processing image:', error);
        toast.error(`Failed to process ${file.name}`);
      }
    }

    if (effectiveAllowVideo && videoFiles.length > 0) {
      const videoFile = videoFiles[0];
      const fileSizeMB = videoFile.size / (1024 * 1024);
      if (!videoFile.type.startsWith('video/')) {
        toast.error('Please choose a video file');
      } else if (fileSizeMB > maxVideoSizeMB) {
        toast.error(`Video must be under ${maxVideoSizeMB}MB`);
      } else {
        newMedia.push({
          id: `video-${Date.now()}`,
          file: videoFile,
          url: URL.createObjectURL(videoFile),
          isHighQuality: true,
          qualityScore: 100,
          type: 'video'
        });
        toast.success('Video added - will be uploaded when you publish');
      }
    }

    if (newMedia.length > 0) {
      onImagesChange([...images, ...newMedia]);
      const addedImages = newMedia.filter(m => m.type === 'image');
      if (addedImages.length > 0) {
        toast.success(`${addedImages.length} image(s) uploaded successfully`);
        const lowQualityImages = addedImages.filter(img => !img.isHighQuality);
        if (lowQualityImages.length > 0) {
          toast.info(`${lowQualityImages.length} image(s) could benefit from editing for better quality`);
        }
      }
    }
  }, [images, onImagesChange, maxImages, effectiveAllowVideo, maxVideoSizeMB]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    else if (e.type === 'dragleave') setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) handleFiles(e.dataTransfer.files);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) handleFiles(e.target.files);
    e.target.value = '';
  };

  const removeMedia = (id: string) => {
    const mediaToRemove = images.find(img => img.id === id);
    if (mediaToRemove) URL.revokeObjectURL(mediaToRemove.url);
    onImagesChange(images.filter(img => img.id !== id));
    toast.success(mediaToRemove?.type === 'video' ? 'Video removed' : 'Image removed');
  };

  const openImageEditor = (imageId: string) => setEditingImageId(imageId);

  const handleImageEditorSave = (editedImageBlob: Blob) => {
    if (!editingImageId) return;
    const editedFile = new File([editedImageBlob], 'edited-image.jpg', { type: 'image/jpeg' });
    const updatedImages = images.map(img => {
      if (img.id === editingImageId) {
        URL.revokeObjectURL(img.url);
        return { ...img, file: editedFile, url: URL.createObjectURL(editedFile), edited: true, isHighQuality: true, qualityScore: 90 };
      }
      return img;
    });
    onImagesChange(updatedImages);
    setEditingImageId(null);
    toast.success('Image enhanced successfully!');
  };

  const editingImage = editingImageId ? images.find(img => img.id === editingImageId) : null;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-primary/10">
            <ImageLucide className="w-4 h-4 text-primary" />
          </div>
          <h3 className="text-base font-semibold">Photos & clips</h3>
        </div>
        <div className="flex gap-1.5">
          <Badge variant="outline" className="text-[10px] rounded-full">
            {imageItems.length}/{maxImages} photos
          </Badge>
          {effectiveAllowVideo && (
            <Badge variant={videoItem ? 'default' : 'outline'} className="text-[10px] rounded-full">
              {videoItem ? '1 clip' : '0/1 clip'}
            </Badge>
          )}
        </div>
      </div>

      <p className="text-sm text-muted-foreground">
        Add up to {maxImages} photos and a short clip. The first photo is your cover.
        Drag to reorder. Tap any photo to crop or enhance with AI.
      </p>

      {!videoItem && imageItems.length < 2 && (
        <div className="p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg text-xs text-amber-700 dark:text-amber-400 flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          At least 2 photos recommended (optional if you add a featured video).
        </div>
      )}

      {/* Upload Area */}
      {imageItems.length === 0 && !videoItem ? (
        // Empty state — soft surface, illustration, big pill button (matches mockup)
        <div
          onClick={() => fileInputRef.current?.click()}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
          className={`rounded-3xl bg-muted/40 border border-border transition-all p-8 text-center cursor-pointer ${
            dragActive ? 'border-primary/60 bg-primary/5 ring-2 ring-primary/20' : 'hover:border-primary/40 hover:bg-muted/60'
          }`}
        >
          <div className="max-w-sm mx-auto">
            <StackedFramesIllustration className="w-44 h-32 mx-auto mb-2 text-primary" />
            <h4 className="text-lg font-semibold text-foreground">No media yet…</h4>
            <p className="text-sm text-muted-foreground mt-1 mb-5">
              Share photos or short clips of your product. Bright, clear shots get more views.
            </p>
            <Button
              type="button"
              size="lg"
              className="rounded-full px-6 gap-2"
              onClick={(e) => {
                e.stopPropagation();
                fileInputRef.current?.click();
              }}
            >
              <Upload className="w-4 h-4" />
              Upload media
            </Button>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept={effectiveAllowVideo ? "image/*,video/mp4,video/quicktime,video/webm" : "image/*"}
            onChange={handleFileSelect}
            className="hidden"
          />
        </div>
      ) : (
        // Compact "add more" row when there's already media
        <Card
          className={`border-2 border-dashed transition-all cursor-pointer ${
            dragActive ? 'border-primary bg-primary/5' : 'border-muted-foreground/25 hover:bg-muted/40'
          }`}
          onClick={() => fileInputRef.current?.click()}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <CardContent className="p-5 flex items-center justify-center gap-3 text-sm">
            <Upload className="w-4 h-4 text-muted-foreground" />
            <span className="font-medium">
              {dragActive ? 'Drop to add' : imageItems.length >= maxImages ? 'Maximum reached' : 'Add more photos or a clip'}
            </span>
            <input
              ref={fileInputRef}
              type="file"
              multiple
              accept={effectiveAllowVideo ? "image/*,video/mp4,video/quicktime,video/webm" : "image/*"}
              onChange={handleFileSelect}
              className="hidden"
            />
          </CardContent>
        </Card>
      )}

      {/* Limits chips */}
      <div className="flex flex-wrap items-center justify-center gap-1.5 text-[11px]">
        <Chip>JPG · PNG · WEBP{effectiveAllowVideo ? ' · MP4' : ''}</Chip>
        <Chip>Photos ≤ 10 MB</Chip>
        {effectiveAllowVideo && <Chip>Clips ≤ 30s · {maxVideoSizeMB} MB</Chip>}
        <Chip>Up to {maxImages} items</Chip>
      </div>

      {/* Video Preview */}
      {videoItem && (
        <Card className="relative group backdrop-blur-sm bg-background/70 border-border/30 overflow-hidden">
          <div className="relative aspect-video">
            <video src={videoItem.url} className="w-full h-full object-cover" controls muted />
            <div className="absolute top-2 left-2 flex gap-2">
              <Badge variant="secondary" className="bg-primary/90 text-primary-foreground text-xs">
                <Video className="w-3 h-3 mr-1" />Video
              </Badge>
              <Badge variant="secondary" className="bg-amber-500/90 text-white text-xs">
                <Play className="w-3 h-3 mr-1" />Uploads on publish
              </Badge>
            </div>
            <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
              <Button
                size="sm"
                variant="secondary"
                className="bg-blue-500 hover:bg-blue-600 text-white"
                onClick={(e) => { e.stopPropagation(); openImageEditor(videoItem.id); }}
              >
                <Edit className="w-4 h-4" />
              </Button>
              <Button
                size="sm"
                variant="destructive"
                onClick={(e) => { e.stopPropagation(); removeMedia(videoItem.id); }}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      )}

      {/* Image Gallery */}
      {imageItems.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {imageItems.map((image, index) => {
            const isEnhancing = enhancingIds.has(image.id);
            return (
              <Card key={image.id} className="relative group backdrop-blur-sm bg-background/70 border-border/30 hover:shadow-lg transition-all">
                <div className="relative aspect-square overflow-hidden rounded-t-lg">
                  <img
                    src={image.url}
                    alt={`Product ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                  
                  {/* Shimmer overlay during enhancement */}
                  {isEnhancing && (
                    <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
                      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent" 
                        style={{ 
                          backgroundSize: '200% 100%',
                          animation: 'emi-shimmer 2.5s ease-in-out infinite',
                        }} 
                      />
                    </div>
                  )}

                  {/* Quality indicator */}
                  <div className="absolute top-2 left-2">
                    {image.enhanced ? (
                      <Badge variant="secondary" className="bg-violet-500/90 text-white text-xs gap-1">
                        <Sparkles className="w-3 h-3" /> EMI Enhanced
                      </Badge>
                    ) : image.isHighQuality ? (
                      <Badge variant="secondary" className="bg-green-500/90 text-white text-xs">
                        <CheckCircle className="w-3 h-3 mr-1" /> High Quality
                      </Badge>
                    ) : (
                      <Badge variant="secondary" className="bg-orange-500/90 text-white text-xs">
                        <AlertTriangle className="w-3 h-3 mr-1" /> Can Improve
                      </Badge>
                    )}
                  </div>

                  {index === 0 && (
                    <div className="absolute top-2 right-2">
                      <Badge variant="secondary" className="bg-blue-500/90 text-white text-xs">Primary</Badge>
                    </div>
                  )}

                  {/* Action buttons */}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => openImageEditor(image.id)}
                      className="bg-blue-500 hover:bg-blue-600 text-white"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => removeMedia(image.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="p-2 text-xs text-center text-muted-foreground">
                  Quality: {image.qualityScore}/100
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {/* Image Editor Modal */}
      {editingImage && editingImage.type !== 'video' && (
        <ImageEditor
          isOpen={!!editingImageId}
          onClose={() => setEditingImageId(null)}
          imageUrl={editingImage.url}
          onSave={handleImageEditorSave}
        />
      )}
    </div>
  );
};

const Chip: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-muted text-muted-foreground border border-border">
    {children}
  </span>
);
