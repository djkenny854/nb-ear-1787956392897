import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Play, Pause, X, Check, Loader2, RotateCcw } from 'lucide-react';
import { toast } from 'sonner';

interface VideoTrimmerDialogProps {
  open: boolean;
  onClose: () => void;
  videoFile: File;
  videoUrl: string;
  onTrimComplete: (trimmedFile: File, previewUrl: string) => void;
}

const formatTime = (seconds: number) => {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
};

const VideoTrimmerDialog: React.FC<VideoTrimmerDialogProps> = ({
  open,
  onClose,
  videoFile,
  videoUrl,
  onTrimComplete,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  
  const timelineRef = useRef<HTMLDivElement>(null);

  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [trimStart, setTrimStart] = useState(0);
  const [trimEnd, setTrimEnd] = useState(0);
  const [dragging, setDragging] = useState<'start' | 'end' | null>(null);
  const [isRendering, setIsRendering] = useState(false);
  const [thumbnails, setThumbnails] = useState<string[]>([]);

  // Load video metadata
  useEffect(() => {
    if (!open) return;
    const video = videoRef.current;
    if (!video) return;

    const onLoaded = () => {
      setDuration(video.duration);
      setTrimEnd(video.duration);
      setTrimStart(0);
      setCurrentTime(0);
      generateThumbnails(video);
    };

    video.addEventListener('loadedmetadata', onLoaded);
    return () => video.removeEventListener('loadedmetadata', onLoaded);
  }, [open, videoUrl]);

  // Time update — loop within trim range
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onTimeUpdate = () => {
      setCurrentTime(video.currentTime);
      if (video.currentTime >= trimEnd) {
        video.pause();
        setIsPlaying(false);
        video.currentTime = trimStart;
      }
    };

    video.addEventListener('timeupdate', onTimeUpdate);
    return () => video.removeEventListener('timeupdate', onTimeUpdate);
  }, [trimEnd, trimStart]);

  const generateThumbnails = async (video: HTMLVideoElement) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 64;
    canvas.height = 80;
    const thumbs: string[] = [];
    const count = Math.min(20, Math.max(8, Math.floor(video.duration * 2)));

    for (let i = 0; i < count; i++) {
      const time = (i / count) * video.duration;
      await new Promise<void>((resolve) => {
        video.currentTime = time;
        const onSeeked = () => {
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          thumbs.push(canvas.toDataURL('image/jpeg', 0.4));
          video.removeEventListener('seeked', onSeeked);
          resolve();
        };
        video.addEventListener('seeked', onSeeked);
      });
    }

    setThumbnails(thumbs);
    video.currentTime = 0;
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (isPlaying) {
      video.pause();
    } else {
      if (video.currentTime < trimStart || video.currentTime >= trimEnd) {
        video.currentTime = trimStart;
      }
      video.play();
    }
    setIsPlaying(!isPlaying);
  };

  // Timeline drag handling
  const getTimeFromPosition = useCallback((clientX: number) => {
    const timeline = timelineRef.current;
    if (!timeline || !duration) return 0;
    const rect = timeline.getBoundingClientRect();
    const x = Math.max(0, Math.min(clientX - rect.left, rect.width));
    return (x / rect.width) * duration;
  }, [duration]);

  const handleHandleDown = (e: React.MouseEvent | React.TouchEvent, type: 'start' | 'end') => {
    e.preventDefault();
    e.stopPropagation();
    setDragging(type);
  };

  useEffect(() => {
    if (!dragging) return;

    const handleMove = (e: MouseEvent | TouchEvent) => {
      e.preventDefault(); // Prevent page scrolling during trim drag
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      const time = getTimeFromPosition(clientX);

      if (dragging === 'start') {
        const newStart = Math.max(0, Math.min(time, trimEnd - 1));
        setTrimStart(newStart);
        if (videoRef.current) videoRef.current.currentTime = newStart;
        setCurrentTime(newStart);
      } else if (dragging === 'end') {
        const newEnd = Math.min(duration, Math.max(time, trimStart + 1));
        setTrimEnd(newEnd);
        if (videoRef.current) videoRef.current.currentTime = newEnd;
        setCurrentTime(newEnd);
      }
    };

    const handleUp = () => setDragging(null);

    window.addEventListener('mousemove', handleMove);
    window.addEventListener('mouseup', handleUp);
    window.addEventListener('touchmove', handleMove, { passive: false });
    window.addEventListener('touchend', handleUp);

    return () => {
      window.removeEventListener('mousemove', handleMove);
      window.removeEventListener('mouseup', handleUp);
      window.removeEventListener('touchmove', handleMove);
      window.removeEventListener('touchend', handleUp);
    };
  }, [dragging, trimStart, trimEnd, duration, getTimeFromPosition]);

  // Click on timeline to seek
  const handleTimelineClick = (e: React.MouseEvent) => {
    if (dragging) return;
    const time = getTimeFromPosition(e.clientX);
    const clampedTime = Math.max(trimStart, Math.min(time, trimEnd));
    setCurrentTime(clampedTime);
    if (videoRef.current) {
      videoRef.current.currentTime = clampedTime;
    }
  };

  // Render trimmed video
  const handleApplyTrim = async () => {
    const video = videoRef.current;
    if (!video) return;

    if (trimStart === 0 && trimEnd === duration) {
      onTrimComplete(videoFile, videoUrl);
      onClose();
      return;
    }

    setIsRendering(true);
    try {
      // Seek to trim start
      video.currentTime = trimStart;
      video.muted = false;

      await new Promise<void>((resolve) => {
        const onSeeked = () => {
          video.removeEventListener('seeked', onSeeked);
          resolve();
        };
        video.addEventListener('seeked', onSeeked);
      });

      // Capture stream directly from video element (preserves quality + audio)
      const stream = (video as any).captureStream() as MediaStream;

      const mimeType = MediaRecorder.isTypeSupported('video/webm;codecs=vp9,opus')
        ? 'video/webm;codecs=vp9,opus'
        : MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')
        ? 'video/webm;codecs=vp8,opus'
        : 'video/webm';

      const recorder = new MediaRecorder(stream, { 
        mimeType,
        videoBitsPerSecond: 5000000, // 5 Mbps for good quality
      });
      const chunks: Blob[] = [];

      recorder.ondataavailable = (e) => {
        if (e.data.size > 0) chunks.push(e.data);
      };

      const recordingDone = new Promise<Blob>((resolve) => {
        recorder.onstop = () => {
          resolve(new Blob(chunks, { type: mimeType }));
        };
      });

      recorder.start(100); // Collect data every 100ms for smoother output

      // Monitor playback and stop at trim end
      const checkEnd = () => {
        if (video.currentTime >= trimEnd || video.paused) {
          video.pause();
          recorder.stop();
          return;
        }
        requestAnimationFrame(checkEnd);
      };

      video.play();
      requestAnimationFrame(checkEnd);

      const blob = await recordingDone;
      const trimmedFile = new File([blob], videoFile.name.replace(/\.\w+$/, '.webm'), {
        type: mimeType,
      });

      const previewUrl = URL.createObjectURL(blob);
      onTrimComplete(trimmedFile, previewUrl);
      toast.success(`Video trimmed to ${formatTime(trimEnd - trimStart)}`);
      onClose();
    } catch (error) {
      console.error('Trim error:', error);
      toast.error('Failed to trim video. Please try again.');
    } finally {
      setIsRendering(false);
    }
  };

  const trimmedDuration = trimEnd - trimStart;
  const startPercent = duration ? (trimStart / duration) * 100 : 0;
  const endPercent = duration ? (trimEnd / duration) * 100 : 100;
  const playheadPercent = duration ? (currentTime / duration) * 100 : 0;

  // Generate time markers
  const timeMarkers = [];
  if (duration > 0) {
    const step = duration <= 10 ? 1 : duration <= 30 ? 5 : duration <= 120 ? 10 : 30;
    for (let t = 0; t <= duration; t += step) {
      timeMarkers.push(t);
    }
  }

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-black flex flex-col">
      {/* Top bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/80">
        <button
          onClick={() => !isRendering && onClose()}
          className="text-white/80 hover:text-white transition-colors p-1"
        >
          <X className="w-6 h-6" />
        </button>
        <span className="text-white/60 text-sm font-medium">Trim Video</span>
        <button
          onClick={handleApplyTrim}
          disabled={isRendering}
          className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-[#25D366] hover:bg-[#1ebe57] text-white text-sm font-semibold transition-colors disabled:opacity-50"
        >
          {isRendering ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Check className="w-4 h-4" />
          )}
          {isRendering ? 'Rendering...' : 'Done'}
        </button>
      </div>

      {/* Video preview area */}
      <div className="flex-1 relative flex items-center justify-center bg-black min-h-0">
        <video
          ref={videoRef}
          src={videoUrl}
          className="max-w-full max-h-full object-contain"
          playsInline
          preload="auto"
          onClick={togglePlay}
        />
        

        {/* Play/pause overlay */}
        {!isPlaying && (
          <button
            onClick={togglePlay}
            className="absolute inset-0 flex items-center justify-center"
          >
            <div className="w-16 h-16 rounded-full bg-black/40 backdrop-blur-sm flex items-center justify-center border border-white/20">
              <Play className="w-7 h-7 text-white ml-1" />
            </div>
          </button>
        )}
      </div>

      {/* Bottom section: time + timeline + controls */}
      <div className="bg-[#1a1a1a] pt-3 pb-6 px-[6px] sm:px-4">
        {/* Time display */}
        <div className="flex items-center justify-between mb-3 px-1">
          <span className="text-white/70 text-xs font-mono">
            {formatTime(trimStart)}
          </span>
          <span className="text-white text-sm font-semibold">
            {formatTime(trimmedDuration)}
          </span>
          <span className="text-white/70 text-xs font-mono">
            {formatTime(trimEnd)}
          </span>
        </div>

        {/* Timeline with frame thumbnails — 2px breathing room from device edges */}
        <div className="relative mb-4 mx-[2px]" ref={timelineRef}>
          {/* Frame thumbnails strip */}
          <div
            className="relative h-[52px] rounded-lg overflow-hidden cursor-pointer"
            onClick={handleTimelineClick}
          >
            {/* Thumbnails */}
            <div className="absolute inset-0 flex">
              {thumbnails.map((thumb, i) => (
                <div
                  key={i}
                  className="flex-1 h-full bg-cover bg-center"
                  style={{ backgroundImage: `url(${thumb})` }}
                />
              ))}
              {thumbnails.length === 0 && (
                <div className="flex-1 bg-neutral-800 animate-pulse" />
              )}
            </div>

            {/* Dimmed regions outside trim */}
            <div
              className="absolute inset-y-0 left-0 bg-black/75 z-10"
              style={{ width: `${startPercent}%` }}
            />
            <div
              className="absolute inset-y-0 right-0 bg-black/75 z-10"
              style={{ width: `${100 - endPercent}%` }}
            />

            {/* Active trim region border (yellow like WhatsApp) */}
            <div
              className="absolute inset-y-0 z-20 pointer-events-none border-y-[3px] border-[#FFD60A]"
              style={{
                left: `${startPercent}%`,
                width: `${endPercent - startPercent}%`,
              }}
            />

            {/* Playhead (thin white line) */}
            <div
              className="absolute inset-y-0 z-30 pointer-events-none"
              style={{ left: `${playheadPercent}%` }}
            >
              <div className="w-[2px] h-full bg-white shadow-[0_0_6px_rgba(255,255,255,0.6)]" />
            </div>
          </div>

          {/* Left handle (yellow) - larger touch target on mobile */}
          <div
            className="absolute top-0 bottom-0 z-30 cursor-col-resize flex items-center touch-none"
            style={{ left: `calc(${startPercent}% - 20px)` }}
            onMouseDown={(e) => handleHandleDown(e, 'start')}
            onTouchStart={(e) => handleHandleDown(e, 'start')}
          >
            <div className="w-[20px] h-full bg-[#FFD60A] rounded-l-md flex items-center justify-center">
              <div className="w-[2px] h-5 bg-black/40 rounded" />
            </div>
          </div>

          {/* Right handle (yellow) - larger touch target on mobile */}
          <div
            className="absolute top-0 bottom-0 z-30 cursor-col-resize flex items-center touch-none"
            style={{ left: `${endPercent}%` }}
            onMouseDown={(e) => handleHandleDown(e, 'end')}
            onTouchStart={(e) => handleHandleDown(e, 'end')}
          >
            <div className="w-[20px] h-full bg-[#FFD60A] rounded-r-md flex items-center justify-center">
              <div className="w-[2px] h-5 bg-black/40 rounded" />
            </div>
          </div>
        </div>

        {/* Time ruler */}
        <div className="flex justify-between px-1 mb-4">
          {timeMarkers.map((t, i) => (
            <span key={i} className="text-[10px] text-white/40 font-mono">
              {formatTime(t)}
            </span>
          ))}
        </div>

        {/* Bottom controls */}
        <div className="flex items-center justify-center gap-6">
          <button
            onClick={() => {
              setTrimStart(0);
              setTrimEnd(duration);
              if (videoRef.current) videoRef.current.currentTime = 0;
              setCurrentTime(0);
            }}
            className="flex flex-col items-center gap-1 text-white/50 hover:text-white/80 transition-colors"
          >
            <RotateCcw className="w-5 h-5" />
            <span className="text-[10px]">Reset</span>
          </button>
          <button
            onClick={togglePlay}
            className="w-14 h-14 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition-colors border border-white/20"
          >
            {isPlaying ? (
              <Pause className="w-6 h-6 text-white" />
            ) : (
              <Play className="w-6 h-6 text-white ml-0.5" />
            )}
          </button>
          <div className="w-12" /> {/* Spacer for symmetry */}
        </div>
      </div>
    </div>
  );
};

export default VideoTrimmerDialog;
