
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { FormFieldConfig } from './FormFieldConfig';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { FieldMapping } from '@/types/listing';

interface PromotionFormProps {
  formData: Record<string, any>;
  onFormChange: (field: string, value: any) => void;
}

export const PromotionForm: React.FC<PromotionFormProps> = ({
  formData,
  onFormChange
}) => {
  const { data: fieldMappings, isLoading } = useQuery({
    queryKey: ['field-mappings', 'promotions'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('category_field_mappings')
        .select('*')
        .eq('listing_type', 'promotions')
        .order('display_order');
      
      if (error) throw error;
      return data as FieldMapping[];
    }
  });

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-pulse space-y-4">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-16 bg-gray-200 rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="backdrop-blur-lg bg-white/95 border-white/30 shadow-2xl">
      <CardHeader>
        <CardTitle className="text-xl font-bold bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">
          Promotion Details
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {fieldMappings?.map((field) => (
          <FormFieldConfig
            key={field.id}
            field={field}
            value={formData[field.field_name]}
            onChange={(value) => onFormChange(field.field_name, value)}
          />
        ))}
      </CardContent>
    </Card>
  );
};
