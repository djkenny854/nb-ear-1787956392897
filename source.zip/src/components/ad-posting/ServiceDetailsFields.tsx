import { useState } from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { X, Plus, Clock, MapPin, Shield, Star, Briefcase, Phone, Calendar, Camera, CheckCircle2, Home } from 'lucide-react';
import { SERVICE_CATEGORIES } from './CategoryDynamicFields';

const ACCOMMODATION_TYPES = ['Apartment', 'Single Room', 'Double Room', 'Hostel', 'Studio', 'Guest House', 'Hotel', 'Bedsitter'];
const PRICE_PERIODS = ['Per Night', 'Per Week', 'Per Month', 'Per Year'];
const BEDROOM_OPTIONS = ['Studio', '1', '2', '3', '4', '5', '6+'];
const BATHROOM_OPTIONS = ['1', '2', '3', '4', '5+'];
const FURNISHED_OPTIONS = ['Fully Furnished', 'Semi Furnished', 'Unfurnished'];
const FLOOR_OPTIONS = ['Ground', '1st', '2nd', '3rd', '4th', '5th+'];
const AMENITY_OPTIONS = ['WiFi', 'CCTV/Security', 'Water Heater', 'Air Conditioning', 'Generator/Backup Power', 'Elevator', 'Swimming Pool', 'Gym', 'Parking', 'Balcony', 'Kitchen', 'Laundry', 'TV/Cable'];
const BOOKING_METHODS = [
  { value: 'phone', label: 'Phone Call' },
  { value: 'website', label: 'Website URL' },
];

// Price type options
const PRICE_TYPES = [
  { value: 'per_hour', label: 'Per Hour' },
  { value: 'per_day', label: 'Per Day' },
  { value: 'per_job', label: 'Per Job/Fixed' },
  { value: 'negotiable', label: 'Negotiable' },
  { value: 'contact', label: 'Contact for Quote' },
];

// Location served options
const LOCATION_SERVED = [
  { value: 'on_site', label: 'On-site (I come to you)' },
  { value: 'remote', label: 'Remote/Online' },
  { value: 'both', label: 'Both On-site & Remote' },
  { value: 'client_visits', label: 'Client visits my location' },
];

// Working days
const WORKING_DAYS = [
  'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'
];

export interface ServiceFormData {
  // Basic Info
  title: string;
  category: string;
  description: string;
  
  // Pricing
  starting_price: number | null;
  price_max: number | null;
  price_type: string;
  currency: string;
  
  // Location
  location_served: string;
  districts_served: string[];
  service_address: string;
  
  // Provider Details
  business_name: string;
  provider_type: 'individual' | 'business';
  years_experience: number | null;
  certifications: string[];
  response_time: string;
  
  // Availability
  working_days: string[];
  working_hours_start: string;
  working_hours_end: string;
  emergency_service: boolean;
  booking_required: boolean;
  
  // Service Proof
  portfolio_images: string[];
  completed_jobs_count: number | null;
  client_testimonials: string[];
  
  // Contact
  contact_phone: string;
  contact_whatsapp: string;
  contact_email: string;
  
  // Skills
  skills: string[];
}

interface ServiceDetailsFieldsProps {
  formData: ServiceFormData;
  onChange: (field: keyof ServiceFormData, value: any) => void;
  step: 'basic' | 'details' | 'availability' | 'proof';
}

export default function ServiceDetailsFields({ formData, onChange, step }: ServiceDetailsFieldsProps) {
  const [certInput, setCertInput] = useState('');
  const [skillInput, setSkillInput] = useState('');
  const [testimonialInput, setTestimonialInput] = useState('');
  const [districtInput, setDistrictInput] = useState('');
  
  const addCertification = () => {
    if (certInput.trim() && !formData.certifications.includes(certInput.trim())) {
      onChange('certifications', [...formData.certifications, certInput.trim()]);
      setCertInput('');
    }
  };
  
  const addSkill = () => {
    if (skillInput.trim() && !formData.skills.includes(skillInput.trim())) {
      onChange('skills', [...formData.skills, skillInput.trim()]);
      setSkillInput('');
    }
  };
  
  const addDistrict = () => {
    if (districtInput.trim() && !formData.districts_served.includes(districtInput.trim())) {
      onChange('districts_served', [...formData.districts_served, districtInput.trim()]);
      setDistrictInput('');
    }
  };
  
  const addTestimonial = () => {
    if (testimonialInput.trim()) {
      onChange('client_testimonials', [...formData.client_testimonials, testimonialInput.trim()]);
      setTestimonialInput('');
    }
  };
  
  const toggleWorkingDay = (day: string) => {
    if (formData.working_days.includes(day)) {
      onChange('working_days', formData.working_days.filter(d => d !== day));
    } else {
      onChange('working_days', [...formData.working_days, day]);
    }
  };
  
  if (step === 'basic') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Briefcase className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Basic Service Info</h3>
            <p className="text-sm text-muted-foreground">Tell us about your service</p>
          </div>
        </div>
        
        <div>
          <Label htmlFor="title" className="text-base font-medium">Service Title *</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => onChange('title', e.target.value)}
            placeholder="e.g., Professional Plumbing Services - 24/7 Emergency"
            className="h-12 text-base mt-2"
          />
          <p className="text-xs text-muted-foreground mt-2">
            Be clear and include your specialty
          </p>
        </div>
        
        <div>
          <Label htmlFor="category" className="text-base font-medium">Service Category *</Label>
          <Select value={formData.category} onValueChange={(v) => onChange('category', v)}>
            <SelectTrigger className="h-12 text-base mt-2">
              <SelectValue placeholder="Select service category" />
            </SelectTrigger>
            <SelectContent className="bg-popover z-[200]">
              {SERVICE_CATEGORIES.map((cat) => (
                <SelectItem key={cat.value} value={cat.value}>{cat.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Accommodation Dynamic Fields */}
        {formData.category === 'accommodation' && (
          <div className="space-y-4 p-4 bg-muted/20 rounded-lg border border-border">
            <h4 className="font-semibold flex items-center gap-2">
              <Home className="w-5 h-5 text-primary" />
              Accommodation Details
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Accommodation Type *</Label>
                <Select value={(formData as any).accommodation_type || ''} onValueChange={(v) => onChange('accommodation_type' as any, v)}>
                  <SelectTrigger className="h-11 mt-1.5"><SelectValue placeholder="Select type" /></SelectTrigger>
                  <SelectContent className="bg-popover z-[200]">
                    {ACCOMMODATION_TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Price Period *</Label>
                <Select value={(formData as any).price_period || ''} onValueChange={(v) => onChange('price_period' as any, v)}>
                  <SelectTrigger className="h-11 mt-1.5"><SelectValue placeholder="Select period" /></SelectTrigger>
                  <SelectContent className="bg-popover z-[200]">
                    {PRICE_PERIODS.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Bedrooms</Label>
                <Select value={(formData as any).bedrooms || ''} onValueChange={(v) => onChange('bedrooms' as any, v)}>
                  <SelectTrigger className="h-11 mt-1.5"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent className="bg-popover z-[200]">
                    {BEDROOM_OPTIONS.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Bathrooms</Label>
                <Select value={(formData as any).bathrooms || ''} onValueChange={(v) => onChange('bathrooms' as any, v)}>
                  <SelectTrigger className="h-11 mt-1.5"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent className="bg-popover z-[200]">
                    {BATHROOM_OPTIONS.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Furnished Status</Label>
                <Select value={(formData as any).furnished_status || ''} onValueChange={(v) => onChange('furnished_status' as any, v)}>
                  <SelectTrigger className="h-11 mt-1.5"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent className="bg-popover z-[200]">
                    {FURNISHED_OPTIONS.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Floor Level</Label>
                <Select value={(formData as any).floor_level || ''} onValueChange={(v) => onChange('floor_level' as any, v)}>
                  <SelectTrigger className="h-11 mt-1.5"><SelectValue placeholder="Select" /></SelectTrigger>
                  <SelectContent className="bg-popover z-[200]">
                    {FLOOR_OPTIONS.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Multi-select Amenities */}
            <div>
              <Label className="mb-2 block">Amenities (select multiple)</Label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                {AMENITY_OPTIONS.map(amenity => {
                  const selected = ((formData as any).amenities || []) as string[];
                  const isChecked = selected.includes(amenity);
                  return (
                    <label key={amenity} className="flex items-center gap-2 p-2 rounded-lg border border-border hover:bg-muted/50 cursor-pointer transition-colors">
                      <Checkbox
                        checked={isChecked}
                        onCheckedChange={(checked) => {
                          const current = [...selected];
                          if (checked) {
                            current.push(amenity);
                          } else {
                            const idx = current.indexOf(amenity);
                            if (idx > -1) current.splice(idx, 1);
                          }
                          onChange('amenities' as any, current);
                        }}
                      />
                      <span className="text-sm">{amenity}</span>
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <Switch
                  checked={(formData as any).pets_allowed || false}
                  onCheckedChange={(v) => onChange('pets_allowed' as any, v)}
                />
                <Label>Pets Allowed</Label>
              </div>
              <div>
                <Label>Deposit Required</Label>
                <Input
                  value={(formData as any).deposit_required || ''}
                  onChange={(e) => onChange('deposit_required' as any, e.target.value)}
                  placeholder="e.g., 2 months rent"
                  className="h-11 mt-1.5"
                />
              </div>
              <div>
                <Label>Available From</Label>
                <Input
                  value={(formData as any).available_from || ''}
                  onChange={(e) => onChange('available_from' as any, e.target.value)}
                  placeholder="e.g., Immediately"
                  className="h-11 mt-1.5"
                />
              </div>
            </div>

            {/* Booking Method */}
            <div className="space-y-3">
              <div>
                <Label>Booking Method</Label>
                <Select value={(formData as any).booking_method || ''} onValueChange={(v) => onChange('booking_method' as any, v)}>
                  <SelectTrigger className="h-11 mt-1.5"><SelectValue placeholder="How to book?" /></SelectTrigger>
                  <SelectContent className="bg-popover z-[200]">
                    {BOOKING_METHODS.map(m => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {(formData as any).booking_method === 'phone' && (
                <div>
                  <Label>Booking Phone Number</Label>
                  <Input
                    value={(formData as any).booking_phone || ''}
                    onChange={(e) => onChange('booking_phone' as any, e.target.value)}
                    placeholder="e.g., +256 700 123456"
                    className="h-11 mt-1.5"
                  />
                </div>
              )}
              {(formData as any).booking_method === 'website' && (
                <div>
                  <Label>Booking Website URL</Label>
                  <Input
                    value={(formData as any).booking_url || ''}
                    onChange={(e) => onChange('booking_url' as any, e.target.value)}
                    placeholder="e.g., https://booking.example.com"
                    className="h-11 mt-1.5"
                  />
                </div>
              )}
            </div>
          </div>
        )}
        
        <div>
          <Label htmlFor="description" className="text-base font-medium">Service Description *</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => onChange('description', e.target.value)}
            placeholder="Describe what services you offer, your approach, and what makes you stand out..."
            className="min-h-[150px] mt-2"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="provider_type" className="text-base font-medium">Provider Type</Label>
            <Select value={formData.provider_type} onValueChange={(v) => onChange('provider_type', v as 'individual' | 'business')}>
              <SelectTrigger className="h-12 mt-2">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover z-[200]">
                <SelectItem value="individual">Individual / Freelancer</SelectItem>
                <SelectItem value="business">Registered Business</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <Label htmlFor="business_name" className="text-base font-medium">
              {formData.provider_type === 'business' ? 'Business Name' : 'Display Name'} (Optional)
            </Label>
            <Input
              id="business_name"
              value={formData.business_name}
              onChange={(e) => onChange('business_name', e.target.value)}
              placeholder={formData.provider_type === 'business' ? 'Your company name' : 'Your professional name'}
              className="h-12 mt-2"
            />
          </div>
        </div>
        
        <div>
          <Label className="text-base font-medium mb-3 block">Skills & Expertise</Label>
          <div className="flex gap-2">
            <Input
              value={skillInput}
              onChange={(e) => setSkillInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
              placeholder="Add skills (e.g., Pipe Fitting, Electrical, AC Repair)"
              className="h-11"
            />
            <Button type="button" onClick={addSkill} size="sm" className="h-11 px-4">
              <Plus className="w-4 h-4" />
            </Button>
          </div>
          {formData.skills.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-3">
              {formData.skills.map((skill) => (
                <Badge key={skill} variant="secondary" className="gap-1 px-3 py-1">
                  {skill}
                  <X 
                    className="w-3 h-3 cursor-pointer hover:text-destructive" 
                    onClick={() => onChange('skills', formData.skills.filter(s => s !== skill))}
                  />
                </Badge>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  }
  
  if (step === 'details') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Pricing & Provider Details</h3>
            <p className="text-sm text-muted-foreground">Set your rates and experience</p>
          </div>
        </div>
        
        {/* Pricing */}
        <div className="space-y-4 p-4 bg-muted/20 rounded-lg border border-border">
          <h4 className="font-semibold flex items-center gap-2">
            <span className="text-lg">💰</span> Pricing
          </h4>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="col-span-2">
              <Label>Price Type *</Label>
              <Select value={formData.price_type} onValueChange={(v) => onChange('price_type', v)}>
                <SelectTrigger className="h-11 mt-1.5">
                  <SelectValue placeholder="How do you charge?" />
                </SelectTrigger>
                <SelectContent className="bg-popover z-[200]">
                  {PRICE_TYPES.map((type) => (
                    <SelectItem key={type.value} value={type.value}>{type.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {formData.price_type !== 'contact' && (
              <>
                <div>
                  <Label>Starting Price</Label>
                  <Input
                    type="number"
                    value={formData.starting_price || ''}
                    onChange={(e) => onChange('starting_price', parseFloat(e.target.value) || null)}
                    placeholder="From"
                    className="h-11 mt-1.5"
                  />
                </div>
                
                <div>
                  <Label>Max Price (Optional)</Label>
                  <Input
                    type="number"
                    value={formData.price_max || ''}
                    onChange={(e) => onChange('price_max', parseFloat(e.target.value) || null)}
                    placeholder="Up to"
                    className="h-11 mt-1.5"
                  />
                </div>
              </>
            )}
          </div>
          
          <div className="w-32">
            <Label>Currency</Label>
            <Select value={formData.currency} onValueChange={(v) => onChange('currency', v)}>
              <SelectTrigger className="h-11 mt-1.5">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-popover z-[200]">
                <SelectItem value="UGX">UGX</SelectItem>
                <SelectItem value="USD">USD</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        {/* Location */}
        <div className="space-y-4 p-4 bg-muted/20 rounded-lg border border-border">
          <h4 className="font-semibold flex items-center gap-2">
            <MapPin className="w-5 h-5" /> Service Location
          </h4>
          
          <div>
            <Label>How do you serve clients? *</Label>
            <Select value={formData.location_served} onValueChange={(v) => onChange('location_served', v)}>
              <SelectTrigger className="h-11 mt-1.5">
                <SelectValue placeholder="Select location type" />
              </SelectTrigger>
              <SelectContent className="bg-popover z-[200]">
                {LOCATION_SERVED.map((loc) => (
                  <SelectItem key={loc.value} value={loc.value}>{loc.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {formData.location_served !== 'remote' && (
            <div>
              <Label>Districts/Areas Served</Label>
              <div className="flex gap-2 mt-1.5">
                <Input
                  value={districtInput}
                  onChange={(e) => setDistrictInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addDistrict())}
                  placeholder="Add areas (e.g., Kampala, Wakiso)"
                />
                <Button type="button" onClick={addDistrict} size="sm" className="h-10 px-3">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              {formData.districts_served.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {formData.districts_served.map((district) => (
                    <Badge key={district} variant="outline" className="gap-1">
                      {district}
                      <X 
                        className="w-3 h-3 cursor-pointer" 
                        onClick={() => onChange('districts_served', formData.districts_served.filter(d => d !== district))}
                      />
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          )}
          
          <div>
            <Label>Service Address (Optional)</Label>
            <Input
              value={formData.service_address}
              onChange={(e) => onChange('service_address', e.target.value)}
              placeholder="Your business location address"
              className="h-11 mt-1.5"
            />
          </div>
        </div>
        
        {/* Experience */}
        <div className="space-y-4 p-4 bg-muted/20 rounded-lg border border-border">
          <h4 className="font-semibold flex items-center gap-2">
            <Star className="w-5 h-5" /> Experience & Credentials
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Years of Experience</Label>
              <Input
                type="number"
                min={0}
                value={formData.years_experience || ''}
                onChange={(e) => onChange('years_experience', parseInt(e.target.value) || null)}
                placeholder="e.g., 5"
                className="h-11 mt-1.5"
              />
            </div>
            
            <div>
              <Label>Average Response Time</Label>
              <Select value={formData.response_time} onValueChange={(v) => onChange('response_time', v)}>
                <SelectTrigger className="h-11 mt-1.5">
                  <SelectValue placeholder="How fast do you respond?" />
                </SelectTrigger>
                <SelectContent className="bg-popover z-[200]">
                  <SelectItem value="within_1_hour">Within 1 hour</SelectItem>
                  <SelectItem value="within_few_hours">Within a few hours</SelectItem>
                  <SelectItem value="same_day">Same day</SelectItem>
                  <SelectItem value="within_24_hours">Within 24 hours</SelectItem>
                  <SelectItem value="1_2_days">1-2 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <Label>Certifications & Qualifications (Optional)</Label>
            <div className="flex gap-2 mt-1.5">
              <Input
                value={certInput}
                onChange={(e) => setCertInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addCertification())}
                placeholder="Add certifications (e.g., Licensed Electrician)"
              />
              <Button type="button" onClick={addCertification} size="sm" className="h-10 px-3">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            {formData.certifications.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-3">
                {formData.certifications.map((cert) => (
                  <Badge key={cert} variant="secondary" className="gap-1 bg-emerald-500/10 text-emerald-600">
                    <CheckCircle2 className="w-3 h-3" />
                    {cert}
                    <X 
                      className="w-3 h-3 cursor-pointer" 
                      onClick={() => onChange('certifications', formData.certifications.filter(c => c !== cert))}
                    />
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  }
  
  if (step === 'availability') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Calendar className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Availability & Contact</h3>
            <p className="text-sm text-muted-foreground">When and how can clients reach you?</p>
          </div>
        </div>
        
        {/* Working Days */}
        <div className="space-y-4 p-4 bg-muted/20 rounded-lg border border-border">
          <h4 className="font-semibold flex items-center gap-2">
            <Clock className="w-5 h-5" /> Working Schedule
          </h4>
          
          <div>
            <Label className="mb-3 block">Working Days *</Label>
            <div className="flex flex-wrap gap-2">
              {WORKING_DAYS.map((day) => (
                <Badge
                  key={day}
                  variant={formData.working_days.includes(day) ? 'default' : 'outline'}
                  className="cursor-pointer px-4 py-2 transition-all"
                  onClick={() => toggleWorkingDay(day)}
                >
                  {day.slice(0, 3)}
                </Badge>
              ))}
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Working Hours - Start</Label>
              <Input
                type="time"
                value={formData.working_hours_start}
                onChange={(e) => onChange('working_hours_start', e.target.value)}
                className="h-11 mt-1.5"
              />
            </div>
            <div>
              <Label>Working Hours - End</Label>
              <Input
                type="time"
                value={formData.working_hours_end}
                onChange={(e) => onChange('working_hours_end', e.target.value)}
                className="h-11 mt-1.5"
              />
            </div>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-background rounded-lg border">
            <div>
              <Label className="font-medium">Emergency/24hr Service</Label>
              <p className="text-xs text-muted-foreground">Available for urgent calls</p>
            </div>
            <Switch
              checked={formData.emergency_service}
              onCheckedChange={(v) => onChange('emergency_service', v)}
            />
          </div>
          
          <div className="flex items-center justify-between p-3 bg-background rounded-lg border">
            <div>
              <Label className="font-medium">Booking Required</Label>
              <p className="text-xs text-muted-foreground">Clients must book in advance</p>
            </div>
            <Switch
              checked={formData.booking_required}
              onCheckedChange={(v) => onChange('booking_required', v)}
            />
          </div>
        </div>
        
        {/* Contact */}
        <div className="space-y-4 p-4 bg-muted/20 rounded-lg border border-border">
          <h4 className="font-semibold flex items-center gap-2">
            <Phone className="w-5 h-5" /> Contact Information
          </h4>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Phone Number *</Label>
              <Input
                type="tel"
                value={formData.contact_phone}
                onChange={(e) => onChange('contact_phone', e.target.value)}
                placeholder="+256 700 000000"
                className="h-11 mt-1.5"
              />
            </div>
            
            <div>
              <Label>WhatsApp Number (Optional)</Label>
              <Input
                type="tel"
                value={formData.contact_whatsapp}
                onChange={(e) => onChange('contact_whatsapp', e.target.value)}
                placeholder="+256 700 000000"
                className="h-11 mt-1.5"
              />
            </div>
          </div>
          
          <div>
            <Label>Email Address (Optional)</Label>
            <Input
              type="email"
              value={formData.contact_email}
              onChange={(e) => onChange('contact_email', e.target.value)}
              placeholder="your@email.com"
              className="h-11 mt-1.5"
            />
          </div>
        </div>
      </div>
    );
  }
  
  if (step === 'proof') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-primary/10 rounded-lg">
            <Camera className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-bold">Service Proof & Testimonials</h3>
            <p className="text-sm text-muted-foreground">Build trust with evidence of your work</p>
          </div>
        </div>
        
        {/* Track Record */}
        <div className="space-y-4 p-4 bg-muted/20 rounded-lg border border-border">
          <h4 className="font-semibold">📊 Track Record</h4>
          
          <div>
            <Label>Completed Jobs Count</Label>
            <Input
              type="number"
              min={0}
              value={formData.completed_jobs_count || ''}
              onChange={(e) => onChange('completed_jobs_count', parseInt(e.target.value) || null)}
              placeholder="e.g., 50"
              className="h-11 mt-1.5 max-w-[200px]"
            />
            <p className="text-xs text-muted-foreground mt-1">
              How many jobs have you successfully completed?
            </p>
          </div>
        </div>
        
        {/* Client Testimonials */}
        <div className="space-y-4 p-4 bg-muted/20 rounded-lg border border-border">
          <h4 className="font-semibold">⭐ Client Testimonials (Optional)</h4>
          <p className="text-sm text-muted-foreground">
            Add quotes from satisfied clients to build trust
          </p>
          
          <div className="flex gap-2">
            <Textarea
              value={testimonialInput}
              onChange={(e) => setTestimonialInput(e.target.value)}
              placeholder="e.g., 'Great work! John fixed my plumbing issue quickly and professionally.' - Sarah K."
              className="min-h-[80px]"
            />
          </div>
          <Button type="button" onClick={addTestimonial} size="sm" variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Add Testimonial
          </Button>
          
          {formData.client_testimonials.length > 0 && (
            <div className="space-y-2 mt-4">
              {formData.client_testimonials.map((testimonial, index) => (
                <div key={index} className="relative p-3 bg-background rounded-lg border italic text-sm">
                  "{testimonial}"
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute top-1 right-1 h-6 w-6 p-0"
                    onClick={() => onChange('client_testimonials', formData.client_testimonials.filter((_, i) => i !== index))}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
        
        <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
          <p className="text-sm text-emerald-700 dark:text-emerald-400">
            💡 <strong>Tip:</strong> Services with portfolio images and testimonials get 3x more inquiries!
          </p>
        </div>
      </div>
    );
  }
  
  return null;
}
