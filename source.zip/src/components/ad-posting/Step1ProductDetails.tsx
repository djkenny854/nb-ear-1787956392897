
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface ProductFormData {
  title: string;
  description: string;
  price: string;
  currency: string;
  category: string;
  subcategory: string;
  condition: string;
  brand: string;
  model: string;
  color: string;
  size: string;
  weight: string;
  dimensions: string;
  features: string;
  warranty: string;
  yearManufactured: string;
}

interface Step1Props {
  formData: ProductFormData;
  onFormChange: (field: keyof ProductFormData, value: string) => void;
  categories: any[];
  subcategories: any[];
}

export const Step1ProductDetails: React.FC<Step1Props> = ({
  formData,
  onFormChange,
  categories,
  subcategories
}) => {
  const conditions = [
    'Brand New',
    'Like New',
    'Excellent',
    'Good',
    'Fair',
    'Poor'
  ];

  const currencies = [
    { code: 'UGX', name: 'Ugandan Shilling' },
    { code: 'USD', name: 'US Dollar' },
    { code: 'KES', name: 'Kenyan Shilling' },
    { code: 'TZS', name: 'Tanzanian Shilling' }
  ];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Basic Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="title">Product Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => onFormChange('title', e.target.value)}
              placeholder="Enter a clear, descriptive title"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => onFormChange('description', e.target.value)}
              placeholder="Describe your product in detail. Include key features, benefits, and any important information buyers should know."
              rows={4}
              required
            />
            <p className="text-xs text-muted-foreground mt-1">
              Press <kbd className="px-1 py-0.5 rounded border bg-muted">Enter</kbd> for a new line.
              Start a line with <code>-</code> to add a bullet point.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="price">Price *</Label>
              <Input
                id="price"
                type="number"
                value={formData.price}
                onChange={(e) => onFormChange('price', e.target.value)}
                placeholder="0.00"
                required
              />
            </div>
            <div>
              <Label htmlFor="currency">Currency</Label>
              <Select
                value={formData.currency}
                onValueChange={(value) => onFormChange('currency', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  {currencies.map((currency) => (
                    <SelectItem key={currency.code} value={currency.code}>
                      {currency.code} - {currency.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Category & Classification</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="category">Category *</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => onFormChange('category', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {formData.category && subcategories && subcategories.length > 0 && (
              <div>
                <Label htmlFor="subcategory">Subcategory</Label>
                <Select
                  value={formData.subcategory}
                  onValueChange={(value) => onFormChange('subcategory', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a subcategory" />
                  </SelectTrigger>
                  <SelectContent>
                    {subcategories.map((subcategory) => (
                      <SelectItem key={subcategory.id} value={subcategory.id}>
                        {subcategory.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div>
            <Label htmlFor="condition">Condition *</Label>
            <Select
              value={formData.condition}
              onValueChange={(value) => onFormChange('condition', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select condition" />
              </SelectTrigger>
              <SelectContent>
                {conditions.map((condition) => (
                  <SelectItem key={condition} value={condition}>
                    {condition}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Product Specifications</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="brand">Brand</Label>
              <Input
                id="brand"
                value={formData.brand}
                onChange={(e) => onFormChange('brand', e.target.value)}
                placeholder="e.g. Apple, Samsung, Nike"
              />
            </div>
            <div>
              <Label htmlFor="model">Model</Label>
              <Input
                id="model"
                value={formData.model}
                onChange={(e) => onFormChange('model', e.target.value)}
                placeholder="e.g. iPhone 13, Galaxy S21"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="color">Color</Label>
              <Input
                id="color"
                value={formData.color}
                onChange={(e) => onFormChange('color', e.target.value)}
                placeholder="e.g. Black, White, Red"
              />
            </div>
            <div>
              <Label htmlFor="size">Size</Label>
              <Input
                id="size"
                value={formData.size}
                onChange={(e) => onFormChange('size', e.target.value)}
                placeholder="e.g. Large, 42, 10GB"
              />
            </div>
            <div>
              <Label htmlFor="weight">Weight</Label>
              <Input
                id="weight"
                value={formData.weight}
                onChange={(e) => onFormChange('weight', e.target.value)}
                placeholder="e.g. 500g, 2kg"
              />
            </div>
          </div>

          <div>
            <Label htmlFor="dimensions">Dimensions (L x W x H)</Label>
            <Input
              id="dimensions"
              value={formData.dimensions}
              onChange={(e) => onFormChange('dimensions', e.target.value)}
              placeholder="e.g. 20cm x 15cm x 5cm"
            />
          </div>

          <div>
            <Label htmlFor="features">Key Features</Label>
            <Textarea
              id="features"
              value={formData.features}
              onChange={(e) => onFormChange('features', e.target.value)}
              placeholder="List the main features and benefits (one per line)"
              rows={3}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="warranty">Warranty</Label>
              <Input
                id="warranty"
                value={formData.warranty}
                onChange={(e) => onFormChange('warranty', e.target.value)}
                placeholder="e.g. 1 year, 6 months, No warranty"
              />
            </div>
            <div>
              <Label htmlFor="yearManufactured">Year Manufactured</Label>
              <Input
                id="yearManufactured"
                type="number"
                value={formData.yearManufactured}
                onChange={(e) => onFormChange('yearManufactured', e.target.value)}
                placeholder="2023"
                min="1990"
                max={new Date().getFullYear()}
              />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
