import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Spinner } from '@/components/ui/spinner';
import { 
  Crop, 
  RotateCw, 
  Contrast, 
  Sun, 
  Palette, 
  Save, 
  X,
  Undo,
  Redo,
  Maximize2,
  Square,
  RectangleHorizontal,
  Check,
  RefreshCw
} from 'lucide-react';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';
import ReactCrop, { Crop as CropType, PixelCrop, centerCrop, makeAspectCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';

interface ImageEditorProps {
  isOpen: boolean;
  onClose: () => void;
  imageUrl: string;
  onSave: (editedImageBlob: Blob) => void;
}

interface EditSettings {
  brightness: number;
  contrast: number;
  saturation: number;
  hue: number;
  rotation: number;
}

type EditorTab = 'adjust' | 'crop' | 'rotate';

const aspectRatios = [
  { label: 'Free', value: undefined, icon: Maximize2 },
  { label: '1:1', value: 1, icon: Square },
  { label: '4:3', value: 4/3, icon: RectangleHorizontal },
  { label: '16:9', value: 16/9, icon: RectangleHorizontal },
];

export const ImageEditor: React.FC<ImageEditorProps> = ({
  isOpen,
  onClose,
  imageUrl,
  onSave
}) => {
  const imgRef = useRef<HTMLImageElement>(null);
  const previewCanvasRef = useRef<HTMLCanvasElement>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [activeTab, setActiveTab] = useState<EditorTab>('adjust');
  const [editHistory, setEditHistory] = useState<EditSettings[]>([]);
  const [currentHistoryIndex, setCurrentHistoryIndex] = useState(-1);
  const [completedCrop, setCompletedCrop] = useState<PixelCrop | null>(null);
  const [crop, setCrop] = useState<CropType>();
  const [aspect, setAspect] = useState<number | undefined>(undefined);
  
  const [settings, setSettings] = useState<EditSettings>({
    brightness: 100,
    contrast: 100,
    saturation: 100,
    hue: 0,
    rotation: 0
  });

  // Reset state when dialog opens
  useEffect(() => {
    if (isOpen) {
      setSettings({
        brightness: 100,
        contrast: 100,
        saturation: 100,
        hue: 0,
        rotation: 0
      });
      setEditHistory([]);
      setCurrentHistoryIndex(-1);
      setCrop(undefined);
      setCompletedCrop(null);
      setActiveTab('adjust');
      setIsLoading(true);
    }
  }, [isOpen, imageUrl]);

  const onImageLoad = useCallback((e: React.SyntheticEvent<HTMLImageElement>) => {
    const { width, height } = e.currentTarget;
    setIsLoading(false);
    
    // Initialize history
    const initialSettings = {
      brightness: 100,
      contrast: 100,
      saturation: 100,
      hue: 0,
      rotation: 0
    };
    setEditHistory([initialSettings]);
    setCurrentHistoryIndex(0);
    
    // Set initial center crop if aspect is set
    if (aspect) {
      const newCrop = centerCrop(
        makeAspectCrop({ unit: '%', width: 80 }, aspect, width, height),
        width,
        height
      );
      setCrop(newCrop);
    }
  }, [aspect]);

  const handleSettingChange = (key: keyof EditSettings, value: number) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    
    // Add to history
    const newHistory = editHistory.slice(0, currentHistoryIndex + 1);
    newHistory.push(newSettings);
    setEditHistory(newHistory);
    setCurrentHistoryIndex(newHistory.length - 1);
  };

  const handleUndo = () => {
    if (currentHistoryIndex > 0) {
      const newIndex = currentHistoryIndex - 1;
      setCurrentHistoryIndex(newIndex);
      setSettings(editHistory[newIndex]);
    }
  };

  const handleRedo = () => {
    if (currentHistoryIndex < editHistory.length - 1) {
      const newIndex = currentHistoryIndex + 1;
      setCurrentHistoryIndex(newIndex);
      setSettings(editHistory[newIndex]);
    }
  };

  const handleRotate = (direction: 'cw' | 'ccw') => {
    const delta = direction === 'cw' ? 90 : -90;
    let newRotation = (settings.rotation + delta) % 360;
    if (newRotation < 0) newRotation += 360;
    handleSettingChange('rotation', newRotation);
  };

  const resetSettings = () => {
    const defaultSettings: EditSettings = {
      brightness: 100,
      contrast: 100,
      saturation: 100,
      hue: 0,
      rotation: 0
    };
    setSettings(defaultSettings);
    setEditHistory([defaultSettings]);
    setCurrentHistoryIndex(0);
    setCrop(undefined);
    setCompletedCrop(null);
  };

  const handleAspectChange = (newAspect: number | undefined) => {
    setAspect(newAspect);
    
    if (imgRef.current && newAspect) {
      const { width, height } = imgRef.current;
      const newCrop = centerCrop(
        makeAspectCrop({ unit: '%', width: 80 }, newAspect, width, height),
        width,
        height
      );
      setCrop(newCrop);
    } else {
      setCrop(undefined);
    }
  };

  const getFilterStyle = () => {
    return {
      filter: `brightness(${settings.brightness}%) contrast(${settings.contrast}%) saturate(${settings.saturation}%) hue-rotate(${settings.hue}deg)`,
      transform: `rotate(${settings.rotation}deg)`,
      transition: 'filter 0.2s ease, transform 0.3s ease'
    };
  };

  const handleSave = async () => {
    if (!imgRef.current) return;
    
    setIsSaving(true);
    try {
      const image = imgRef.current;
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) throw new Error('Could not get canvas context');

      // Calculate dimensions based on crop or full image
      let sourceX = 0, sourceY = 0, sourceWidth = image.naturalWidth, sourceHeight = image.naturalHeight;
      
      if (completedCrop && completedCrop.width > 0 && completedCrop.height > 0) {
        // Calculate scale between displayed image and natural size
        const scaleX = image.naturalWidth / image.width;
        const scaleY = image.naturalHeight / image.height;
        
        sourceX = completedCrop.x * scaleX;
        sourceY = completedCrop.y * scaleY;
        sourceWidth = completedCrop.width * scaleX;
        sourceHeight = completedCrop.height * scaleY;
      }

      // Handle rotation
      const rotation = settings.rotation;
      const isRotated90or270 = rotation === 90 || rotation === 270;
      
      if (isRotated90or270) {
        canvas.width = sourceHeight;
        canvas.height = sourceWidth;
      } else {
        canvas.width = sourceWidth;
        canvas.height = sourceHeight;
      }

      // Apply transformations
      ctx.save();
      
      // Move to center for rotation
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate((rotation * Math.PI) / 180);
      
      // Apply filters
      ctx.filter = `brightness(${settings.brightness}%) contrast(${settings.contrast}%) saturate(${settings.saturation}%) hue-rotate(${settings.hue}deg)`;
      
      // Draw image
      if (isRotated90or270) {
        ctx.drawImage(
          image,
          sourceX, sourceY, sourceWidth, sourceHeight,
          -sourceHeight / 2, -sourceWidth / 2, sourceHeight, sourceWidth
        );
      } else {
        ctx.drawImage(
          image,
          sourceX, sourceY, sourceWidth, sourceHeight,
          -sourceWidth / 2, -sourceHeight / 2, sourceWidth, sourceHeight
        );
      }
      
      ctx.restore();

      // Convert to blob
      canvas.toBlob((blob) => {
        if (blob) {
          onSave(blob);
          toast.success('Image saved successfully!');
          onClose();
        } else {
          throw new Error('Failed to create image blob');
        }
        setIsSaving(false);
      }, 'image/jpeg', 0.92);
    } catch (error) {
      console.error('Save error:', error);
      toast.error('Failed to save image');
      setIsSaving(false);
    }
  };

  const TabButton = ({ tab, label, icon: Icon }: { tab: EditorTab; label: string; icon: React.ElementType }) => (
    <button
      onClick={() => setActiveTab(tab)}
      className={cn(
        "flex flex-col items-center gap-1 px-4 py-2.5 rounded-xl transition-all duration-200",
        activeTab === tab
          ? "bg-primary text-primary-foreground shadow-lg scale-105"
          : "bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground"
      )}
    >
      <Icon className="w-5 h-5" />
      <span className="text-xs font-medium">{label}</span>
    </button>
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] sm:max-w-2xl lg:max-w-4xl p-0 gap-0 overflow-hidden bg-background/95 backdrop-blur-xl border-border/50 animate-scale-in">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-muted/30">
          <div className="flex items-center gap-3">
            <h2 className="text-lg font-semibold">Edit Image</h2>
            <div className="flex gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleUndo}
                disabled={currentHistoryIndex <= 0}
                className="h-8 w-8 rounded-lg"
              >
                <Undo className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleRedo}
                disabled={currentHistoryIndex >= editHistory.length - 1}
                className="h-8 w-8 rounded-lg"
              >
                <Redo className="w-4 h-4" />
              </Button>
            </div>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8 rounded-lg">
            <X className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex flex-col lg:flex-row">
          {/* Image Preview Area */}
          <div className="flex-1 p-4 bg-black/5 dark:bg-white/5 min-h-[300px] lg:min-h-[400px] flex items-center justify-center overflow-hidden">
            {isLoading && (
              <div className="flex flex-col items-center gap-3 animate-fade-in">
                <Spinner size="lg" className="text-primary" />
                <p className="text-sm text-muted-foreground">Loading image...</p>
              </div>
            )}
            
            <div className={cn(
              "relative max-w-full max-h-[50vh] lg:max-h-[60vh] transition-opacity duration-300",
              isLoading ? "opacity-0" : "opacity-100"
            )}>
              {activeTab === 'crop' ? (
                <ReactCrop
                  crop={crop}
                  onChange={(_, percentCrop) => setCrop(percentCrop)}
                  onComplete={(c) => setCompletedCrop(c)}
                  aspect={aspect}
                  className="max-h-[50vh] lg:max-h-[60vh]"
                >
                  <img
                    ref={imgRef}
                    src={imageUrl}
                    alt="Edit"
                    onLoad={onImageLoad}
                    className="max-w-full max-h-[50vh] lg:max-h-[60vh] object-contain"
                    crossOrigin="anonymous"
                    style={getFilterStyle()}
                  />
                </ReactCrop>
              ) : (
                <img
                  ref={imgRef}
                  src={imageUrl}
                  alt="Edit"
                  onLoad={onImageLoad}
                  className="max-w-full max-h-[50vh] lg:max-h-[60vh] object-contain rounded-lg shadow-2xl"
                  crossOrigin="anonymous"
                  style={getFilterStyle()}
                />
              )}
            </div>
          </div>

          {/* Controls Panel */}
          <div className="w-full lg:w-72 border-t lg:border-t-0 lg:border-l border-border/50 bg-background">
            {/* Tab Navigation */}
            <div className="flex justify-center gap-2 p-3 border-b border-border/50">
              <TabButton tab="adjust" label="Adjust" icon={Sun} />
              <TabButton tab="crop" label="Crop" icon={Crop} />
              <TabButton tab="rotate" label="Rotate" icon={RotateCw} />
            </div>

            {/* Tab Content */}
            <div className="p-4 space-y-4 max-h-[40vh] lg:max-h-[50vh] overflow-y-auto">
              {activeTab === 'adjust' && (
                <div className="space-y-5 animate-fade-in">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="flex items-center gap-2 text-sm">
                        <Sun className="w-4 h-4 text-amber-500" />
                        Brightness
                      </Label>
                      <span className="text-xs text-muted-foreground font-mono">{settings.brightness}%</span>
                    </div>
                    <Slider
                      value={[settings.brightness]}
                      onValueChange={(value) => handleSettingChange('brightness', value[0])}
                      max={200}
                      min={50}
                      step={1}
                      className="touch-pan-y"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="flex items-center gap-2 text-sm">
                        <Contrast className="w-4 h-4 text-blue-500" />
                        Contrast
                      </Label>
                      <span className="text-xs text-muted-foreground font-mono">{settings.contrast}%</span>
                    </div>
                    <Slider
                      value={[settings.contrast]}
                      onValueChange={(value) => handleSettingChange('contrast', value[0])}
                      max={200}
                      min={50}
                      step={1}
                      className="touch-pan-y"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="flex items-center gap-2 text-sm">
                        <Palette className="w-4 h-4 text-purple-500" />
                        Saturation
                      </Label>
                      <span className="text-xs text-muted-foreground font-mono">{settings.saturation}%</span>
                    </div>
                    <Slider
                      value={[settings.saturation]}
                      onValueChange={(value) => handleSettingChange('saturation', value[0])}
                      max={200}
                      min={0}
                      step={1}
                      className="touch-pan-y"
                    />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label className="flex items-center gap-2 text-sm">
                        <Palette className="w-4 h-4 text-pink-500" />
                        Hue
                      </Label>
                      <span className="text-xs text-muted-foreground font-mono">{settings.hue}°</span>
                    </div>
                    <Slider
                      value={[settings.hue]}
                      onValueChange={(value) => handleSettingChange('hue', value[0])}
                      max={360}
                      min={0}
                      step={1}
                      className="touch-pan-y"
                    />
                  </div>
                </div>
              )}

              {activeTab === 'crop' && (
                <div className="space-y-4 animate-fade-in">
                  <p className="text-sm text-muted-foreground text-center">
                    Drag on the image to select crop area
                  </p>
                  
                  <div className="space-y-2">
                    <Label className="text-sm">Aspect Ratio</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {aspectRatios.map((ratio) => (
                        <button
                          key={ratio.label}
                          onClick={() => handleAspectChange(ratio.value)}
                          className={cn(
                            "flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg border transition-all duration-200",
                            aspect === ratio.value
                              ? "border-primary bg-primary/10 text-primary"
                              : "border-border hover:border-primary/50 hover:bg-muted"
                          )}
                        >
                          <ratio.icon className="w-4 h-4" />
                          <span className="text-sm font-medium">{ratio.label}</span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {completedCrop && completedCrop.width > 0 && (
                    <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg text-center">
                      <Check className="w-5 h-5 text-green-500 mx-auto mb-1" />
                      <p className="text-xs text-green-600 dark:text-green-400">
                        Crop area selected
                      </p>
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'rotate' && (
                <div className="space-y-4 animate-fade-in">
                  <div className="flex justify-center gap-3">
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={() => handleRotate('ccw')}
                      className="flex-1 h-16 flex-col gap-1"
                    >
                      <RotateCw className="w-5 h-5 transform -scale-x-100" />
                      <span className="text-xs">-90°</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="lg"
                      onClick={() => handleRotate('cw')}
                      className="flex-1 h-16 flex-col gap-1"
                    >
                      <RotateCw className="w-5 h-5" />
                      <span className="text-xs">+90°</span>
                    </Button>
                  </div>
                  
                  <div className="text-center py-3 px-4 bg-muted/50 rounded-lg">
                    <p className="text-2xl font-bold">{settings.rotation}°</p>
                    <p className="text-xs text-muted-foreground">Current rotation</p>
                  </div>
                </div>
              )}
            </div>

            {/* Footer Actions */}
            <div className="p-4 border-t border-border/50 space-y-2">
              <Button
                variant="ghost"
                onClick={resetSettings}
                className="w-full text-muted-foreground hover:text-foreground"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Reset All
              </Button>
              
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={onClose}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSave}
                  disabled={isSaving}
                  className="flex-1 bg-primary hover:bg-primary/90"
                >
                  {isSaving ? (
                    <>
                      <Spinner size="sm" className="mr-2" />
                      Saving...
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      Save
                    </>
                  )}
                </Button>
              </div>
            </div>
          </div>
        </div>

        <canvas ref={previewCanvasRef} className="hidden" />
      </DialogContent>
    </Dialog>
  );
};

export default ImageEditor;
