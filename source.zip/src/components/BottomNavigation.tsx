import React, { useState, useEffect, RefObject } from 'react';
import { User, LogOut, Rocket, Wallet, Shield, BarChart3, HelpCircle, ChevronRight, Feather, CheckCircle, Phone } from 'lucide-react';
import {
  House,
  Storefront,
  Compass,
  Bell as PhBell,
  ChatCircle,
  GearSix,
  ChatTeardropDots,
  BookmarkSimple,
  FileText as PhFileText,
  Plus as PhPlus,
} from '@phosphor-icons/react';
import { adaptPhosphor } from '@/components/icons/PhosphorAdapter';
import GeminiSparkIcon from '@/components/icons/GeminiSparkIcon';
import { openEarlyMarketAI } from '@/components/ai/EarlyMarketAIIntroDialog';
import { getChatUrl, storeChatIntent } from '@/lib/chatNavigation';

const Home = adaptPhosphor(House);
const Store = adaptPhosphor(Storefront);
const Users = adaptPhosphor(Compass);
const Bell = adaptPhosphor(PhBell);
const Mail = adaptPhosphor(ChatCircle);
const Settings = adaptPhosphor(GearSix);
const MessageSquare = adaptPhosphor(ChatTeardropDots);
const Bookmark = adaptPhosphor(BookmarkSimple);
const FileText = adaptPhosphor(PhFileText);
import { useNavigate, useLocation } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useUnreadMessages } from '@/hooks/useUnreadMessages';
import { useLanguage } from '@/contexts/LanguageContext';
import { useQuery } from '@tanstack/react-query';
import VerificationBadge from '@/components/VerificationBadge';
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
} from '@/components/ui/drawer';
import { Separator } from '@/components/ui/separator';
import MobilePublishMenu from '@/components/publish/MobilePublishMenu';
import AIQuickChat from '@/components/ai/AIQuickChat';
import { useOrganizationStatus } from '@/hooks/useOrganizationStatus';


interface BottomNavigationProps {
  scrollContainerRef?: RefObject<HTMLDivElement>;
  hidden?: boolean;
}

const BottomNavigation: React.FC<BottomNavigationProps> = ({ scrollContainerRef, hidden = false }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, signOut } = useAuth();
  const { unreadCount } = useUnreadMessages();
  const { t } = useLanguage();
  const { isOrganization } = useOrganizationStatus();

  const [showPostModal, setShowPostModal] = useState(false);
  const [showAccountMenu, setShowAccountMenu] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [scrollDirection, setScrollDirection] = useState<'up' | 'down'>('up');

  const [filterModalOpen, setFilterModalOpen] = useState(false);
  const [notificationCount, setNotificationCount] = useState(0);
  const [followingNewCount, setFollowingNewCount] = useState(0);
  const [plusIdle, setPlusIdle] = useState(false);
  const [businessPhone, setBusinessPhone] = useState<string | null>(null);
  const [listingPhone, setListingPhone] = useState<string | null>(null);
  const [listingSellerId, setListingSellerId] = useState<string | null>(null);
  const [listingAdId, setListingAdId] = useState<string | null>(null);
  const [listingTitle, setListingTitle] = useState<string | null>(null);
  const [listingSellerName, setListingSellerName] = useState<string | null>(null);
  const [listingType, setListingType] = useState<string | null>(null);

  // Read seller phone exposed by SellerProfile and listing context exposed by
  // detail pages (AdDetails, ServiceDetails, etc.) via body dataset.
  useEffect(() => {
    const read = () => {
      setBusinessPhone(document.body.dataset.businessPhone || null);
      setListingPhone(document.body.dataset.listingPhone || null);
      setListingSellerId(document.body.dataset.listingSellerId || null);
      setListingAdId(document.body.dataset.listingAdId || null);
      setListingTitle(document.body.dataset.listingTitle || null);
      setListingSellerName(document.body.dataset.listingSellerName || null);
      setListingType(document.body.dataset.listingType || null);
    };
    read();
    const observer = new MutationObserver(read);
    observer.observe(document.body, {
      attributes: true,
      attributeFilter: [
        'data-business-phone',
        'data-listing-phone',
        'data-listing-seller-id',
        'data-listing-ad-id',
        'data-listing-title',
        'data-listing-seller-name',
        'data-listing-type',
      ],
    });
    return () => observer.disconnect();
  }, []);

  // Fetch seller profile for business logo and name
  const { data: sellerProfile } = useQuery({
    queryKey: ['bottom-nav-seller-profile', user?.id],
    queryFn: async () => {
      if (!user?.id) return null;
      const { data } = await supabase
        .from('seller_profiles')
        .select('business_name, business_logo_url, is_verified, business_email')
        .eq('user_id', user.id)
        .maybeSingle();
      return data;
    },
    enabled: !!user?.id,
    staleTime: 1000 * 60 * 5,
  });

  // Fetch notification count
  useEffect(() => {
    if (!user?.id) return;

    const fetchNotificationCount = async () => {
      const { count } = await supabase
        .from('notifications')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('is_read', false)
        .or('notification_type.is.null,notification_type.neq.new_message');
      setNotificationCount(count || 0);
    };
    fetchNotificationCount();
    
    // Subscribe to real-time updates
    const channelName = `notifications-count-${user.id}-${crypto.randomUUID()}`;
    const channel = supabase
      .channel(channelName)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'notifications' }, fetchNotificationCount)
      .subscribe();
      
    return () => { supabase.removeChannel(channel); };
  }, [user?.id]);
  
  // Get user avatar - prefer business logo, fallback to Google avatar
  const businessLogo = sellerProfile?.business_logo_url;
  const userAvatar = businessLogo || user?.user_metadata?.avatar_url || user?.user_metadata?.picture;

  // Listen for filter modal open/close
  useEffect(() => {
    const observer = new MutationObserver(() => {
      const isFilterOpen = document.body.hasAttribute('data-filter-open');
      setFilterModalOpen(isFilterOpen);
    });
    
    observer.observe(document.body, { attributes: true, attributeFilter: ['data-filter-open'] });
    return () => observer.disconnect();
  }, []);

  // Handle scroll direction
  // NOTE: We only track scroll direction here for the plus button animation
  // The actual nav visibility is controlled by the parent Layout component via the `hidden` prop
  // This avoids conflicts between two scroll listeners fighting over visibility
  useEffect(() => {
    let prevScrollY = 0;
    let currentContainer: HTMLElement | null = null;
    
    const handleScroll = (scrollY: number) => {
      if (scrollY > prevScrollY && scrollY > 50) {
        setScrollDirection('down');
      } else {
        setScrollDirection('up');
      }
      prevScrollY = scrollY;
    };

    const handleContainerScroll = (e: Event) => {
      handleScroll((e.target as HTMLElement).scrollTop);
    };

    const handleWindowScroll = () => {
      handleScroll(window.scrollY);
    };
    
    // Always listen to window scroll
    window.addEventListener('scroll', handleWindowScroll, { passive: true });

    // Poll for the feed container so we catch it even after async render
    const tryAttach = () => {
      const el = scrollContainerRef?.current || document.getElementById('social-feed-scroll-container');
      if (el && el !== currentContainer) {
        currentContainer?.removeEventListener('scroll', handleContainerScroll);
        currentContainer = el;
        currentContainer.addEventListener('scroll', handleContainerScroll, { passive: true });
      }
    };
    
    tryAttach();
    const interval = setInterval(tryAttach, 500);

    return () => {
      clearInterval(interval);
      window.removeEventListener('scroll', handleWindowScroll);
      currentContainer?.removeEventListener('scroll', handleContainerScroll);
    };
  }, [scrollContainerRef]);

  const navItems = [
    { icon: Home, path: '/', isProfile: false, badge: 0, iconFilled: true, label: t('home') },
    { icon: Users, path: '/discover', isProfile: false, badge: followingNewCount, iconFilled: false, label: t('discover') },
    { icon: Store, path: '/marketplace', isProfile: false, badge: 0, iconFilled: false, label: 'Market' },
    { icon: Bell, path: '/notifications', isProfile: false, badge: notificationCount, iconFilled: false, label: t('notifications') },
    { icon: Mail, path: '/messages', isProfile: false, badge: unreadCount, iconFilled: false, label: t('messages') },
    { icon: User, path: '/profile', isProfile: true, badge: 0, iconFilled: false, label: t('profile') },
  ];

  // Post options moved to MobilePublishMenu component

  const accountMenuItems = [
    { icon: User, label: t('profile'), path: '/profile' },
    { icon: Bookmark, label: 'Bookmarks', path: '/bookmarks' },
    { icon: FileText, label: 'Drafts', path: '/drafts' },
    { icon: Rocket, label: 'Boost Ad', path: '/boost-ad' },
    { icon: BarChart3, label: 'Sales Analytics', path: '/sales-analytics' },
    { icon: Wallet, label: 'Payment Methods', path: '/payment-methods' },
    { icon: Shield, label: 'Get Verified', path: '/verification' },
    { icon: MessageSquare, label: 'Feedback', path: '/feedback' },
    { icon: Settings, label: t('settings'), path: '/account-settings' },
    { icon: HelpCircle, label: t('helpSupport'), path: '/help' },
    { icon: GeminiSparkIcon as any, label: 'EarlyMarket AI', path: '/ai' },
  ];

  const handleSignOut = async () => {
    setShowAccountMenu(false);
    await signOut();
    navigate('/');
  };

  const handleAccountClick = () => {
    if (user) {
      setShowAccountMenu(true);
    } else {
      navigate('/auth');
    }
  };

  // Determine if we should hide the plus button on certain pages
  const isPublishPage = location.pathname.startsWith('/publish') || location.pathname.startsWith('/messages') || location.pathname.startsWith('/create-business-account') || location.pathname.startsWith('/onboarding');
  // On a business page the Plus FAB morphs into a Call button, so hide the
  // regular AI+Plus stack there.
  const isBusinessPage = location.pathname.startsWith('/business/') || location.pathname.startsWith('/seller/');
  // On a listing details page (product / service / event / promo / digital / job / post)
  // the Plus + AI buttons are replaced with Message + Call buttons.
  const isListingDetailPage = /^\/(ad|service|event|promotion|digital|job|post)\//.test(location.pathname);
  const hideFabStack = isPublishPage || isBusinessPage || isListingDetailPage;
  // Show the dedicated Call pill when on a business page that has a phone number.
  const showCallButton = isBusinessPage && !!businessPhone;
  // Show the Message + Call combo on a listing detail page when we have context.
  const showListingActions = isListingDetailPage && (!!listingSellerId || !!listingPhone);
  // Only business / organization accounts can publish, so the Plus FAB is
  // hidden for regular personal accounts.
  const canPublish = !!sellerProfile || isOrganization;


  // Plus button becomes semi-transparent after 2 seconds of idle
  useEffect(() => {
    if (hidden || isPublishPage) return;
    setPlusIdle(false);
    const timer = setTimeout(() => setPlusIdle(true), 2000);
    return () => clearTimeout(timer);
  }, [hidden, isPublishPage, scrollDirection]);

  // Close publish menu on scroll
  useEffect(() => {
    if (!showPostModal) return;
    
    const handleScroll = () => {
      setShowPostModal(false);
    };

    // Listen on multiple scroll targets
    const scrollEl = document.getElementById('social-feed-scroll-container');
    window.addEventListener('scroll', handleScroll, { passive: true });
    scrollEl?.addEventListener('scroll', handleScroll, { passive: true });
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      scrollEl?.removeEventListener('scroll', handleScroll);
    };
  }, [showPostModal]);

  // Close publish menu when clicking outside
  useEffect(() => {
    if (!showPostModal) return;
    
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      // Don't close if clicking within the publish menu or the plus button
      if (target.closest('[data-publish-menu]') || target.closest('[data-plus-button]')) return;
      setShowPostModal(false);
    };

    // Delay to avoid immediate close from the same click
    const timeout = setTimeout(() => {
      document.addEventListener('click', handleClickOutside);
    }, 100);
    
    return () => {
      clearTimeout(timeout);
      document.removeEventListener('click', handleClickOutside);
    };
  }, [showPostModal]);

  return (
    <>
      <div 
        className={`fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur-md border-t border-border z-[100] md:hidden transition-opacity duration-300 ease-out ${
          filterModalOpen ? 'opacity-0 pointer-events-none' : (hidden || scrollDirection === 'down') ? 'opacity-30' : 'opacity-100'
        }`}
        style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
      >

          {/* Floating Action Stack — AI on top, Plus below (business accounts only). */}
          {!hideFabStack && (
            <div
              className="absolute right-4 flex flex-col items-center gap-3 pointer-events-none"
              style={{ bottom: 'calc(100% + 5px)' }}
            >
              {/* AI button */}
              <button
                data-tour="ai-button"
                onClick={() => setAiOpen(true)}
                className={`pointer-events-auto w-12 h-12 rounded-full shadow-lg flex items-center justify-center origin-bottom group ${
                  filterModalOpen || showPostModal
                    ? 'scale-0 rotate-[-180deg] opacity-0 pointer-events-none'
                    : (plusIdle || scrollDirection === 'down')
                      ? 'scale-100 rotate-0 opacity-40'
                      : 'scale-100 rotate-0 opacity-100'
                }`}
                style={{
                  background: 'linear-gradient(135deg, hsl(var(--foreground)) 0%, hsl(var(--foreground)/0.85) 100%)',
                  color: 'hsl(var(--background))',
                  transition: 'transform 400ms cubic-bezier(0.34, 1.56, 0.64, 1), opacity 300ms ease-out',
                  willChange: 'transform, opacity',
                }}
                aria-label="EarlyMarket AI"
              >
                <span
                  className={`inline-flex transition-transform duration-500 ease-out ${
                    filterModalOpen || showPostModal ? 'rotate-[-180deg]' : 'rotate-0'
                  }`}
                >
                  <GeminiSparkIcon className="w-5 h-5" filled />
                </span>
              </button>

              {/* Plus button — business & organization accounts only */}
              {canPublish && (
                <button
                  data-plus-button
                  data-tour="plus-button"
                  onClick={() => setShowPostModal(!showPostModal)}
                  className={`pointer-events-auto w-14 h-14 rounded-full flex items-center justify-center origin-bottom group ${
                    filterModalOpen || showPostModal
                      ? 'scale-0 rotate-180 opacity-0 pointer-events-none'
                      : (plusIdle || scrollDirection === 'down')
                        ? 'scale-100 rotate-0 opacity-40'
                        : 'scale-100 rotate-0 opacity-100'
                  }`}
                  style={{
                    background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary)/0.85) 100%)',
                    color: 'hsl(var(--primary-foreground))',
                    boxShadow: '0 10px 30px -8px hsl(var(--primary) / 0.55), 0 4px 10px -2px rgba(0,0,0,0.15)',
                    transition: 'transform 400ms cubic-bezier(0.34, 1.56, 0.64, 1), opacity 300ms ease-out',
                    willChange: 'transform, opacity',
                  }}
                  aria-label="Create"
                >
                  <PhPlus weight="bold" size={26} className="transition-transform duration-300 group-hover:rotate-90" />
                </button>
              )}
            </div>
          )}


          {/* Call button — replaces the Plus FAB on business pages */}
          {showCallButton && (
            <div
              className="absolute right-4 pointer-events-none"
              style={{ bottom: 'calc(100% + 5px)' }}
            >
              <a
                href={`tel:${businessPhone}`}
                aria-label="Call business"
                className={`pointer-events-auto flex items-center gap-2 rounded-full pl-4 pr-5 h-14 origin-bottom ${
                  hidden || filterModalOpen
                    ? 'scale-0 rotate-180 opacity-0 pointer-events-none'
                    : plusIdle
                      ? 'scale-100 rotate-0 opacity-50'
                      : 'scale-100 rotate-0 opacity-100'
                }`}
                style={{
                  background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary)/0.85) 100%)',
                  color: 'hsl(var(--primary-foreground))',
                  boxShadow: '0 10px 30px -8px hsl(var(--primary) / 0.55), 0 4px 10px -2px rgba(0,0,0,0.15)',
                  transition: 'transform 400ms cubic-bezier(0.34, 1.56, 0.64, 1), opacity 300ms ease-out',
                  willChange: 'transform, opacity',
                }}
              >
                <Phone className="w-5 h-5" />
                <span className="font-semibold text-sm">Call</span>
              </a>
            </div>
          )}

          {/* Message + Call combo — replaces the Plus/AI FAB on listing detail pages */}
          {showListingActions && (
            <div
              className="absolute right-4 flex flex-col items-center gap-3 pointer-events-none"
              style={{ bottom: 'calc(100% + 5px)' }}
            >
              {!!listingPhone && (
                <a
                  href={`tel:${listingPhone}`}
                  aria-label="Call seller"
                  className={`pointer-events-auto w-12 h-12 rounded-full shadow-lg flex items-center justify-center origin-bottom ${
                    hidden || filterModalOpen
                      ? 'scale-0 rotate-[-180deg] opacity-0 pointer-events-none'
                      : plusIdle
                        ? 'scale-100 rotate-0 opacity-50'
                        : 'scale-100 rotate-0 opacity-100'
                  }`}
                  style={{
                    background: 'linear-gradient(135deg, hsl(var(--foreground)) 0%, hsl(var(--foreground)/0.85) 100%)',
                    color: 'hsl(var(--background))',
                    transition: 'transform 400ms cubic-bezier(0.34, 1.56, 0.64, 1), opacity 300ms ease-out',
                    willChange: 'transform, opacity',
                  }}
                >
                  <Phone className="w-5 h-5" />
                </a>
              )}
              {!!listingSellerId && (
                <button
                  onClick={() => {
                    if (!user) { navigate('/auth'); return; }
                    const chatIntent = {
                      recipientId: listingSellerId,
                      recipientName: listingSellerName || undefined,
                      adId: listingAdId || undefined,
                      adTitle: listingTitle || undefined,
                      listingType: listingType || undefined,
                    };
                    storeChatIntent(chatIntent);
                    navigate(getChatUrl(chatIntent), { state: chatIntent });
                  }}

                  aria-label="Message seller"
                  className={`pointer-events-auto w-14 h-14 rounded-full flex items-center justify-center origin-bottom ${
                    hidden || filterModalOpen
                      ? 'scale-0 rotate-180 opacity-0 pointer-events-none'
                      : plusIdle
                        ? 'scale-100 rotate-0 opacity-50'
                        : 'scale-100 rotate-0 opacity-100'
                  }`}
                  style={{
                    background: 'linear-gradient(135deg, hsl(var(--primary)) 0%, hsl(var(--primary)/0.85) 100%)',
                    color: 'hsl(var(--primary-foreground))',
                    boxShadow: '0 10px 30px -8px hsl(var(--primary) / 0.55), 0 4px 10px -2px rgba(0,0,0,0.15)',
                    transition: 'transform 400ms cubic-bezier(0.34, 1.56, 0.64, 1), opacity 300ms ease-out',
                    willChange: 'transform, opacity',
                  }}
                >
                  <MessageSquare className="w-6 h-6" />
                </button>
              )}
            </div>
          )}

        <div data-tour="bottom-nav" className="flex justify-around items-center py-3 px-1 gap-1">

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            
            // Profile button with avatar - opens account menu
            if (item.isProfile) {
              return (
                <button
                  key={item.path}
                  onClick={handleAccountClick}
                  className="flex items-center justify-center p-1.5 transition-colors"
                >
                  {userAvatar ? (
                    <div className={`p-[2px] rounded-full transition-all ${
                      isActive || showAccountMenu 
                        ? 'bg-gradient-to-tr from-primary via-accent to-primary' 
                        : 'bg-gradient-to-tr from-primary/40 via-accent/40 to-primary/40'
                    }`}>
                      <Avatar className="w-7 h-7 border-2 border-background">
                        <AvatarImage src={userAvatar} alt="Profile" />
                        <AvatarFallback className="bg-primary/10 text-primary text-xs">
                          {sellerProfile?.business_name?.charAt(0).toUpperCase() || user?.email?.charAt(0).toUpperCase() || 'U'}
                        </AvatarFallback>
                      </Avatar>
                    </div>
                  ) : (
                    <div className={`p-[2px] rounded-full transition-all ${
                      isActive || showAccountMenu 
                        ? 'bg-gradient-to-tr from-primary via-accent to-primary' 
                        : 'bg-gradient-to-tr from-muted-foreground/30 via-muted-foreground/20 to-muted-foreground/30'
                    }`}>
                      <div className="w-7 h-7 rounded-full flex items-center justify-center bg-background">
                        <User className="w-4 h-4 text-muted-foreground" />
                      </div>
                    </div>
                  )}
                </button>
              );
            }
            
            return (
              <button
                key={item.path}
                data-tour={`nav-${item.path === '/' ? 'home' : item.path.slice(1)}`}
                onClick={() => navigate(item.path)}
                className="flex items-center justify-center p-2 transition-colors relative flex-1"
              >
                <Icon 
                  className={`w-7 h-7 transition-all ${
                    isActive 
                      ? 'text-foreground' 
                      : 'text-foreground/70'
                  }`}
                  strokeWidth={isActive ? 2.5 : 1.8}
                  fill={isActive && item.iconFilled ? 'currentColor' : 'none'}
                />
                {/* Badge for notifications/messages/following */}
                {item.badge > 0 && (
                  <span className="absolute top-0.5 right-1/4 min-w-[18px] h-[18px] flex items-center justify-center bg-primary text-primary-foreground text-[10px] font-bold rounded-full px-1">
                    {item.badge > 99 ? '99+' : item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Mobile Publish Menu */}
      <MobilePublishMenu isOpen={showPostModal} onClose={() => setShowPostModal(false)} />

      {/* EarlyMarket AI quick surface */}
      <AIQuickChat open={aiOpen} onOpenChange={setAiOpen} />


      {/* Account Menu Drawer */}
      <Drawer open={showAccountMenu} onOpenChange={setShowAccountMenu}>
        <DrawerContent className="max-h-[80vh]">
          <DrawerHeader className="px-6 pb-4">
            <DrawerTitle className="text-left">Account</DrawerTitle>
          </DrawerHeader>
          
          <div className="overflow-y-auto flex-1">
            {/* User Info */}
            {user && (
              <div className="px-6 pb-4">
                <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-xl">
                  <Avatar className="w-12 h-12">
                    <AvatarImage src={businessLogo || userAvatar} alt="Profile" />
                    <AvatarFallback className="bg-primary/10 text-primary text-lg">
                      {sellerProfile?.business_name?.charAt(0).toUpperCase() || user.email?.charAt(0).toUpperCase() || 'U'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="font-semibold text-foreground truncate">
                        {sellerProfile?.business_name || user.user_metadata?.full_name || user.email?.split('@')[0]}
                      </p>
                      {sellerProfile?.is_verified && (
                        <VerificationBadge isVerified={true} size="sm" />
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{sellerProfile?.business_email || user.email}</p>
                  </div>
                </div>
              </div>
            )}
            
            <Separator />
            
            {/* Menu Items */}
            <div className="py-2">
              {accountMenuItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.path}
                    onClick={() => {
                      setShowAccountMenu(false);
                      if (item.path === '/ai') {
                        openEarlyMarketAI(navigate);
                      } else {
                        navigate(item.path);
                      }
                    }}
                    className="w-full flex items-center gap-4 px-6 py-3.5 hover:bg-muted/50 transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                      <Icon className="w-5 h-5 text-foreground" />
                    </div>
                    <span className="flex-1 text-left font-medium text-foreground">{item.label}</span>
                    <ChevronRight className="w-5 h-5 text-muted-foreground" />
                  </button>
                );
              })}
            </div>
            
            <Separator />
            
            {/* Sign Out */}
            <div className="pt-2 pb-6 px-6">
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-4 px-4 py-3.5 rounded-xl bg-destructive/10 hover:bg-destructive/20 transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-destructive/20 flex items-center justify-center">
                  <LogOut className="w-5 h-5 text-destructive" />
                </div>
                <span className="flex-1 text-left font-medium text-destructive">Sign Out</span>
              </button>
            </div>
          </div>
        </DrawerContent>
      </Drawer>
    </>
  );
};

export default BottomNavigation;