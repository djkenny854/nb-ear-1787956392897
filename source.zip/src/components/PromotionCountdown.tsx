import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Clock, Zap } from 'lucide-react';

interface PromotionCountdownProps {
  validUntil?: string | null;
  startAt?: string | null;
}

export const PromotionCountdown = ({ validUntil, startAt }: PromotionCountdownProps) => {
  const [timeLeft, setTimeLeft] = useState('');
  const [mode, setMode] = useState<'countdown' | 'starting' | 'live' | 'expired'>('live');

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      
      // FIX: Handle date-only inputs by ensuring valid datetime parsing
      let endTime: number | null = null;
      let startTime: number | null = null;
      
      if (validUntil) {
        try {
          // Try parsing as-is first
          endTime = new Date(validUntil).getTime();
          // If invalid, try adding default time
          if (isNaN(endTime)) {
            endTime = new Date(`${validUntil}T23:59:59`).getTime();
          }
        } catch (e) {
          endTime = null;
        }
      }
      
      if (startAt) {
        try {
          startTime = new Date(startAt).getTime();
          if (isNaN(startTime)) {
            startTime = new Date(`${startAt}T00:00:00`).getTime();
          }
        } catch (e) {
          startTime = null;
        }
      }

      // Determine countdown mode
      // 1. If validUntil exists and is in the future: show "Ends in X"
      // 2. If validUntil is in the past: show "Expired"
      // 3. If startAt is in the future (and no validUntil or validUntil is also future): show "Starts in X"
      // 4. Otherwise: show "Live Now"
      
      if (endTime && !isNaN(endTime)) {
        const difference = endTime - now;
        
        if (difference <= 0) {
          setMode('expired');
          setTimeLeft('Expired');
          return;
        }
        
        // Check if it hasn't started yet
        if (startTime && !isNaN(startTime) && startTime > now) {
          const startDiff = startTime - now;
          setMode('starting');
          setTimeLeft(formatTimeLeft(startDiff));
          return;
        }
        
        // Countdown to end
        setMode('countdown');
        setTimeLeft(formatTimeLeft(difference));
        return;
      }
      
      // No validUntil, check startAt
      if (startTime && !isNaN(startTime) && startTime > now) {
        const startDiff = startTime - now;
        setMode('starting');
        setTimeLeft(formatTimeLeft(startDiff));
        return;
      }
      
      // Default: Live now
      setMode('live');
      setTimeLeft('Live Now');
    };

    const formatTimeLeft = (difference: number): string => {
      const days = Math.floor(difference / (1000 * 60 * 60 * 24));
      const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((difference % (1000 * 60)) / 1000);

      if (days > 0) {
        return `${days}d ${hours}h ${minutes}m`;
      } else if (hours > 0) {
        return `${hours}h ${minutes}m ${seconds}s`;
      } else if (minutes > 0) {
        return `${minutes}m ${seconds}s`;
      } else {
        return `${seconds}s`;
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [validUntil, startAt]);

  if (mode === 'expired') {
    return (
      <Badge variant="destructive" className="gap-1">
        <Clock className="w-3 h-3" />
        Expired
      </Badge>
    );
  }

  if (mode === 'starting') {
    return (
      <Badge variant="secondary" className="gap-1 bg-purple-500/10 text-purple-600 border-purple-500/20">
        <Clock className="w-3 h-3" />
        Starts in {timeLeft}
      </Badge>
    );
  }

  if (mode === 'live') {
    return (
      <Badge variant="secondary" className="gap-1 bg-green-500/10 text-green-600 border-green-500/20">
        <Zap className="w-3 h-3" />
        Live Now
      </Badge>
    );
  }

  // countdown mode
  return (
    <Badge variant="secondary" className="gap-1 bg-orange-500/10 text-orange-600 border-orange-500/20">
      <Clock className="w-3 h-3" />
      Ends in {timeLeft}
    </Badge>
  );
};
