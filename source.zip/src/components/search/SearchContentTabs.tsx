import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ShoppingBag,
  Users,
  Briefcase,
  Store,
  Tag,
  Plus,
  Layers,
  Calendar,
  Download,
  Check,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';

export interface SearchTabOption {
  value: string;
  label: string;
  icon?: React.ComponentType<{ className?: string }>;
  count?: number;
}

interface Props {
  value: string;
  onChange: (value: string) => void;
  counts?: {
    total?: number;
    products?: number;
    sellers?: number;
    jobs?: number;
    services?: number;
    promotions?: number;
  };
  t: (key: string) => string;
}

const EXTRA_OPTIONS: SearchTabOption[] = [
  { value: 'events', label: 'Events', icon: Calendar },
  { value: 'digital', label: 'Digital products', icon: Download },
];

const SearchContentTabs: React.FC<Props> = ({ value, onChange, counts, t }) => {
  const isMobile = useIsMobile();
  const [pickerOpen, setPickerOpen] = useState(false);

  const baseTabs: SearchTabOption[] = [
    { value: 'all', label: t('all'), icon: Layers, count: counts?.total },
    { value: 'products', label: t('products'), icon: ShoppingBag, count: counts?.products },
    { value: 'services', label: t('services'), icon: Store, count: counts?.services },
    { value: 'jobs', label: t('jobs'), icon: Briefcase, count: counts?.jobs },
    { value: 'promotions', label: t('promotions'), icon: Tag, count: counts?.promotions },
    { value: 'sellers', label: t('accounts'), icon: Users, count: counts?.sellers },
  ];

  // If an extra option is active, render it inline so the underline can attach
  const activeExtra = EXTRA_OPTIONS.find((o) => o.value === value);
  const tabs = activeExtra ? [...baseTabs, activeExtra] : baseTabs;

  const handleSelect = (next: string) => {
    if (next !== value) onChange(next);
  };

  const Picker = isMobile ? (
    <Drawer open={pickerOpen} onOpenChange={setPickerOpen}>
      <DrawerContent>
        <DrawerHeader>
          <DrawerTitle>More categories</DrawerTitle>
        </DrawerHeader>
        <div className="px-4 pb-6 grid gap-2">
          {EXTRA_OPTIONS.map((opt) => {
            const Icon = opt.icon!;
            const active = opt.value === value;
            return (
              <button
                key={opt.value}
                onClick={() => {
                  handleSelect(opt.value);
                  setPickerOpen(false);
                }}
                className={cn(
                  'flex items-center gap-3 rounded-xl border border-border px-4 py-3 text-left transition-colors',
                  active ? 'bg-primary/10 border-primary text-primary' : 'hover:bg-muted'
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="flex-1 font-medium">{opt.label}</span>
                {active && <Check className="w-4 h-4" />}
              </button>
            );
          })}
        </div>
      </DrawerContent>
    </Drawer>
  ) : (
    <Dialog open={pickerOpen} onOpenChange={setPickerOpen}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>More categories</DialogTitle>
        </DialogHeader>
        <div className="grid gap-2">
          {EXTRA_OPTIONS.map((opt) => {
            const Icon = opt.icon!;
            const active = opt.value === value;
            return (
              <button
                key={opt.value}
                onClick={() => {
                  handleSelect(opt.value);
                  setPickerOpen(false);
                }}
                className={cn(
                  'flex items-center gap-3 rounded-xl border border-border px-4 py-3 text-left transition-colors',
                  active ? 'bg-primary/10 border-primary text-primary' : 'hover:bg-muted'
                )}
              >
                <Icon className="w-5 h-5" />
                <span className="flex-1 font-medium">{opt.label}</span>
                {active && <Check className="w-4 h-4" />}
              </button>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );

  return (
    <div className="relative">
      <div className="flex items-center gap-0 overflow-x-auto scrollbar-hide">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const active = tab.value === value;
          return (
            <button
              key={tab.value}
              onClick={() => handleSelect(tab.value)}
              className={cn(
                'relative shrink-0 px-4 h-12 flex items-center gap-1.5 text-sm font-medium transition-colors',
                active ? 'text-primary' : 'text-muted-foreground hover:text-foreground'
              )}
            >
              {Icon && <Icon className="w-4 h-4" />}
              <AnimatePresence mode="wait" initial={false}>
                <motion.span
                  key={tab.label}
                  initial={{ opacity: 0, y: 2 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -2 }}
                  transition={{ duration: 0.15 }}
                >
                  {tab.label}
                </motion.span>
              </AnimatePresence>
              {typeof tab.count === 'number' && (
                <Badge
                  variant="secondary"
                  className={cn(
                    'h-5 px-1.5 text-[10px] font-semibold transition-colors',
                    active ? 'bg-primary/10 text-primary' : 'bg-muted'
                  )}
                >
                  {tab.count}
                </Badge>
              )}
              {active && (
                <motion.span
                  layoutId="search-tab-underline"
                  className="absolute left-2 right-2 bottom-0 h-[2px] rounded-full bg-primary"
                  transition={{ type: 'spring', stiffness: 500, damping: 35 }}
                />
              )}
            </button>
          );
        })}

        {/* Plus / more button */}
        <button
          type="button"
          onClick={() => setPickerOpen(true)}
          className={cn(
            'shrink-0 ml-1 mr-2 inline-flex items-center justify-center w-9 h-9 rounded-full border border-border bg-background',
            'text-muted-foreground hover:text-primary hover:border-primary transition-colors'
          )}
          aria-label="More categories"
          title="More categories"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      {Picker}
    </div>
  );
};

export default SearchContentTabs;
