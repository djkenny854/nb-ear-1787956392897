import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent, DialogOverlay } from '@/components/ui/dialog';
import { Drawer, DrawerContent } from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { useIsMobile } from '@/hooks/use-mobile';
import { 
  X, Sparkles, MapPin, SlidersHorizontal, Tag, Shield, 
  Clock, Truck, Package, Briefcase, Image, TrendingUp,
  Star, Percent, Wallet, Languages, Accessibility, Zap
} from 'lucide-react';
import FilterSections from './FilterSections';
import FilterOverview from './FilterOverview';
import InteractiveUgandaMap from './InteractiveUgandaMap';
interface AdvancedFilterModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  filters: any;
  onFiltersChange: (filters: any) => void;
  onApply: () => void;
  onClear: () => void;
  listingCounts?: {
    [key: string]: number;
  };
  /** Active marketplace tab — controls which filter sections are shown. */
  activeTab?: 'products' | 'services' | 'jobs' | 'promos' | 'accounts' | 'events';
}

type NavSection = 'overview' | 'location' | 'price' | 'seller' | 'features' | 'date' | 'delivery' | 'brands' | 'ratings' | 'deals' | 'more';

// Working filters first, coming soon at the end
const allNavItems = [
  // Working
  { id: 'overview' as NavSection, label: 'Overview', icon: SlidersHorizontal, comingSoon: false },
  { id: 'price' as NavSection, label: 'Price', icon: Tag, comingSoon: false },
  { id: 'seller' as NavSection, label: 'Seller', icon: Shield, comingSoon: false },
  { id: 'features' as NavSection, label: 'Features', icon: Image, comingSoon: false },
  { id: 'date' as NavSection, label: 'Date Posted', icon: Clock, comingSoon: false },
  { id: 'deals' as NavSection, label: 'Deals', icon: Percent, comingSoon: false },
  { id: 'brands' as NavSection, label: 'Brands', icon: Package, comingSoon: false },
  // Coming soon
  { id: 'location' as NavSection, label: 'Location', icon: MapPin, comingSoon: true },
  { id: 'delivery' as NavSection, label: 'Delivery', icon: Truck, comingSoon: true },
  { id: 'ratings' as NavSection, label: 'Ratings', icon: Star, comingSoon: true },
  { id: 'more' as NavSection, label: 'More Options', icon: Zap, comingSoon: true },
];

// Which sections show per marketplace tab
const tabSectionMap: Record<string, NavSection[]> = {
  products: ['overview', 'price', 'seller', 'features', 'date', 'deals', 'brands', 'location', 'delivery', 'ratings', 'more'],
  services: ['overview', 'price', 'seller', 'date', 'location', 'ratings'],
  jobs:     ['overview', 'seller', 'date', 'location', 'features'],
  promos:   ['overview', 'deals', 'brands', 'seller', 'date'],
  accounts: ['overview', 'seller', 'location', 'ratings'],
  events:   ['overview', 'date', 'location', 'price'],
};

const FilterLoadingSkeleton = () => (
  <div className="flex h-full">
    {/* Sidebar skeleton */}
    <div className="w-56 border-r border-border p-4 space-y-2">
      {Array.from({ length: 8 }).map((_, i) => (
        <Skeleton key={i} className="h-10 w-full rounded-lg bg-muted animate-pulse" />
      ))}
    </div>
    {/* Content skeleton */}
    <div className="flex-1 p-6 space-y-6">
      <div className="space-y-2">
        <Skeleton className="h-7 w-40 bg-muted animate-pulse" />
        <Skeleton className="h-4 w-64 bg-muted animate-pulse" />
      </div>
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center justify-between py-4 border-b border-border">
            <div className="space-y-1">
              <Skeleton className="h-5 w-32 bg-muted animate-pulse" />
              <Skeleton className="h-3 w-48 bg-muted animate-pulse" />
            </div>
            <Skeleton className="h-9 w-32 rounded-lg bg-muted animate-pulse" />
          </div>
        ))}
      </div>
    </div>
  </div>
);

const SettingsRow = ({ 
  label, 
  description, 
  children 
}: { 
  label: string; 
  description?: string; 
  children: React.ReactNode;
}) => (
  <div className="flex items-center justify-between py-4 border-b border-border last:border-0">
    <div className="space-y-0.5 flex-1 pr-4">
      <p className="text-sm font-medium text-foreground">{label}</p>
      {description && (
        <p className="text-xs text-muted-foreground">{description}</p>
      )}
    </div>
    <div className="shrink-0">
      {children}
    </div>
  </div>
);

const AdvancedFilterModal: React.FC<AdvancedFilterModalProps> = ({
  open,
  onOpenChange,
  filters,
  onFiltersChange,
  onApply,
  onClear,
  listingCounts = {},
  activeTab = 'products',
}) => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [isLoading, setIsLoading] = useState(true);
  const [activeSection, setActiveSection] = useState<NavSection>('overview');
  const [activeFiltersCount, setActiveFiltersCount] = useState(0);

  const navItems = React.useMemo(() => {
    const allowed = tabSectionMap[activeTab] || tabSectionMap.products;
    return allNavItems.filter((n) => allowed.includes(n.id));
  }, [activeTab]);

  // Reset to overview when tab changes
  useEffect(() => {
    if (!navItems.some((n) => n.id === activeSection)) {
      setActiveSection('overview');
    }
  }, [navItems, activeSection]);


  useEffect(() => {
    if (open) {
      setIsLoading(true);
      const timer = setTimeout(() => setIsLoading(false), 600);
      return () => clearTimeout(timer);
    }
  }, [open]);

  useEffect(() => {
    let count = 0;
    if (filters.listingTypes?.length) count += filters.listingTypes.length;
    if (filters.region) count++;
    if (filters.district) count++;
    if (filters.priceRange?.[0] > 0 || filters.priceRange?.[1] < 10000000) count++;
    if (filters.verifiedOnly) count++;
    if (filters.hasImages) count++;
    if (filters.hasVideo) count++;
    if (filters.datePosted) count++;
    if (filters.brands?.length) count += filters.brands.length;
    if (filters.condition) count++;
    setActiveFiltersCount(count);
  }, [filters]);

  const handleQuickSearch = (query: string) => {
    onFiltersChange({ ...filters, searchQuery: query });
    onApply();
    onOpenChange(false);
    navigate(`/search?q=${encodeURIComponent(query)}`);
  };

  const handleFilterChange = (key: string, value: any) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  const handleClearFilter = (key: string) => {
    const newFilters = { ...filters };
    delete newFilters[key];
    onFiltersChange(newFilters);
  };

  const handleLocationSelect = (district: string) => {
    onFiltersChange({ ...filters, district });
  };

  const renderSectionContent = () => {
    switch (activeSection) {
      case 'overview':
        return (
          <FilterOverview
            filters={filters}
            onFilterChange={handleFilterChange}
            onClearFilter={handleClearFilter}
            onQuickSearch={handleQuickSearch}
          />
        );
      case 'location':
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
                Location
                <Badge variant="outline" className="text-[10px] bg-amber-500/10 text-amber-600 border-amber-500/30">Coming Soon</Badge>
              </h2>
              <p className="text-sm text-muted-foreground">Find listings near you or in specific areas</p>
            </div>
            <div className="p-4 bg-muted/30 rounded-xl border border-border text-center">
              <MapPin className="w-10 h-10 mx-auto text-muted-foreground/50 mb-3" />
              <p className="text-sm font-medium text-muted-foreground">Location filter not available at the moment</p>
              <p className="text-xs text-muted-foreground/70 mt-1">This feature will be unlocked when listings accumulate</p>
            </div>
            <div className="opacity-30 pointer-events-none">
              <InteractiveUgandaMap 
                onLocationSelect={handleLocationSelect}
                selectedRegion={filters.district}
              />
            </div>
          </div>
        );
      default:
        return (
          <div className="space-y-6">
            <div>
              <h2 className="text-lg font-semibold text-foreground">
                {navItems.find(item => item.id === activeSection)?.label}
              </h2>
              <p className="text-sm text-muted-foreground">Configure your filter preferences</p>
            </div>
            <FilterSections 
              filters={filters}
              onFiltersChange={onFiltersChange}
              activeSection={activeSection}
            />
          </div>
        );
    }
  };

  const content = (
    <div className="flex flex-col h-full bg-background overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 md:px-6 py-3 md:py-4 border-b border-border shrink-0">
        <div className="flex items-center gap-2 md:gap-3">
          <div className="p-1.5 md:p-2 bg-primary/10 rounded-lg md:rounded-xl">
            <SlidersHorizontal className="w-4 h-4 md:w-5 md:h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-base md:text-lg font-semibold text-foreground">Advanced Filters</h1>
            <p className="text-[10px] md:text-xs text-muted-foreground">
              {activeFiltersCount > 0 ? `${activeFiltersCount} filters active` : 'Customize your search'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 md:gap-3">
          {activeFiltersCount > 0 && (
            <Badge variant="secondary" className="bg-primary/10 text-primary font-medium text-xs">
              {activeFiltersCount}
            </Badge>
          )}
          <Button variant="ghost" size="icon" onClick={() => onOpenChange(false)} className="rounded-full h-8 w-8 md:h-9 md:w-9">
            <X className="w-4 h-4 md:w-5 md:h-5" />
          </Button>
        </div>
      </div>

      {/* Mobile Tab Navigation - Horizontal scrollable */}
      <div className="md:hidden border-b border-border bg-muted/30 shrink-0 overflow-hidden">
        <div className="overflow-x-auto scrollbar-hide">
          <div className="flex p-2 gap-1 w-max">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                    isActive
                      ? 'bg-primary text-primary-foreground shadow-sm'
                      : item.comingSoon 
                        ? 'bg-muted/50 text-muted-foreground/60'
                        : 'bg-background text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  {item.label}
                  {item.comingSoon && <span className="text-[8px] ml-0.5 opacity-60">Soon</span>}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Content Area - Takes remaining space */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Desktop Sidebar Navigation - Independent scroll */}
        <div className="w-52 border-r border-border bg-muted/30 hidden md:flex md:flex-col shrink-0 overflow-hidden">
          <div className="flex-1 overflow-y-auto">
            <div className="p-2 space-y-0.5">
              {navItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveSection(item.id)}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                      isActive
                        ? 'bg-background text-foreground shadow-sm'
                        : item.comingSoon
                          ? 'text-muted-foreground/50 hover:bg-background/30'
                          : 'text-muted-foreground hover:text-foreground hover:bg-background/50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="flex-1 text-left">{item.label}</span>
                    {item.comingSoon && (
                      <Badge variant="outline" className="text-[8px] px-1 py-0 h-4 bg-amber-500/10 text-amber-600 border-amber-500/30">Soon</Badge>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Content Area - Independent scroll */}
        <div className="flex-1 flex flex-col min-h-0 overflow-hidden">
          <div className="flex-1 overflow-y-auto">
            <div className="p-4 md:p-6 pb-4">
              {isLoading ? (
                <div className="space-y-4 md:space-y-6">
                  <div className="space-y-2">
                    <Skeleton className="h-6 md:h-7 w-36 md:w-40 bg-muted animate-pulse" />
                    <Skeleton className="h-3 md:h-4 w-56 md:w-64 bg-muted animate-pulse" />
                  </div>
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div key={i} className="flex items-center justify-between py-3 md:py-4 border-b border-border">
                      <div className="space-y-1 md:space-y-1.5">
                        <Skeleton className="h-4 md:h-5 w-28 md:w-32 bg-muted animate-pulse" />
                        <Skeleton className="h-2.5 md:h-3 w-40 md:w-48 bg-muted animate-pulse" />
                      </div>
                      <Skeleton className="h-8 md:h-9 w-28 md:w-32 rounded-lg bg-muted animate-pulse" />
                    </div>
                  ))}
                </div>
              ) : (
                renderSectionContent()
              )}
            </div>
          </div>

          {/* Footer - Fixed at bottom */}
          <div className="border-t border-border p-3 md:p-4 bg-background shrink-0">
            <div className="flex gap-2 md:gap-3">
              <Button
                variant="outline"
                className="flex-1 h-10 md:h-10 text-sm"
                onClick={onClear}
              >
                Clear All
              </Button>
              <Button
                className="flex-1 h-10 md:h-10 text-sm"
                onClick={() => {
                  onApply();
                  onOpenChange(false);
                }}
              >
                Apply Filters
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // Hide bottom navigation when filter modal is open
  useEffect(() => {
    if (open) {
      document.body.setAttribute('data-filter-open', 'true');
      // Prevent body scroll when modal is open
      document.body.style.overflow = 'hidden';
    } else {
      document.body.removeAttribute('data-filter-open');
      document.body.style.overflow = '';
    }
    return () => {
      document.body.removeAttribute('data-filter-open');
      document.body.style.overflow = '';
    };
  }, [open]);

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="h-[92vh] max-h-[92vh] flex flex-col !z-[200]">
          {content}
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogOverlay className="bg-background/80 backdrop-blur-md !z-[200]" />
      <DialogContent 
        className="max-w-[1100px] w-[95vw] h-[85vh] p-0 gap-0 overflow-hidden border-border flex flex-col !z-[200]"
        hideCloseButton
      >
        {content}
      </DialogContent>
    </Dialog>
  );
};

export default AdvancedFilterModal;
