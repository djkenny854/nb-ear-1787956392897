import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import HomeProductCard from '@/components/cards/HomeProductCard';
import { Sparkles } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface RelatedItemsProps {
  category?: string;
  excludeIds?: string[];
  searchQuery?: string;
}

const RelatedItemsSkeleton = () => (
  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
    {Array.from({ length: 6 }).map((_, i) => (
      <div key={i} className="bg-background rounded-xl border border-border p-3">
        <Skeleton className="h-32 w-full rounded-lg mb-3" />
        <Skeleton className="h-4 w-3/4 mb-2" />
        <Skeleton className="h-5 w-1/2" />
      </div>
    ))}
  </div>
);

const RelatedItems: React.FC<RelatedItemsProps> = ({ 
  category, 
  excludeIds = [],
  searchQuery 
}) => {
  const { data: relatedItems = [], isLoading } = useQuery({
    queryKey: ['related-items', category, excludeIds.join(',')],
    queryFn: async () => {
      // First try to get items from the same category
      let query = supabase
        .from('ads')
        .select(`
          *,
          seller_profiles (
            id,
            business_name,
            business_logo_url,
            is_verified
          )
        `)
        .eq('status', 'active')
        .order('is_boosted', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(12);

      if (category) {
        query = query.ilike('category', `%${category}%`);
      }

      if (excludeIds.length > 0) {
        query = query.not('id', 'in', `(${excludeIds.join(',')})`);
      }

      const { data, error } = await query;
      
      if (error) {
        console.error('Error fetching related items:', error);
        return [];
      }

      // If we didn't get enough items from category, fetch trending items
      if (data.length < 6) {
        const { data: trendingData } = await supabase
          .from('ads')
          .select(`
            *,
            seller_profiles (
              id,
              business_name,
              business_logo_url,
              is_verified
            )
          `)
          .eq('status', 'active')
          .order('view_count', { ascending: false })
          .order('created_at', { ascending: false })
          .limit(12 - data.length);

        if (trendingData) {
          // Merge and deduplicate
          const existingIds = new Set(data.map(d => d.id));
          const newItems = trendingData.filter(d => !existingIds.has(d.id));
          return [...data, ...newItems];
        }
      }

      return data;
    },
    enabled: true,
  });

  if (isLoading) {
    return (
      <div className="mt-8 p-6 bg-muted/30 rounded-2xl border border-border">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-primary" />
          <h3 className="text-lg font-semibold text-foreground">You Might Also Like</h3>
        </div>
        <RelatedItemsSkeleton />
      </div>
    );
  }

  if (relatedItems.length === 0) {
    return null;
  }

  return (
    <div className="mt-8 p-6 bg-muted/30 rounded-2xl border border-border">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="w-5 h-5 text-primary" />
        <h3 className="text-lg font-semibold text-foreground">
          {searchQuery 
            ? `Can't find "${searchQuery}"? Check these out!` 
            : 'You Might Also Like'}
        </h3>
      </div>
      
      <p className="text-sm text-muted-foreground mb-4">
        {category 
          ? `Popular items in ${category}` 
          : 'Trending items you might be interested in'}
      </p>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {relatedItems.map((item: any) => (
          <HomeProductCard
            key={item.id}
            id={item.id}
            title={item.title}
            price={item.price || 0}
            originalPrice={item.original_price}
            images={item.images || []}
            location={item.location}
            viewCount={item.view_count}
            isBoosted={item.is_boosted}
            hasDiscount={item.has_discount}
            createdAt={item.created_at}
            seller={item.seller_profiles ? {
              business_name: item.seller_profiles.business_name,
              business_logo_url: item.seller_profiles.business_logo_url,
              is_verified: item.seller_profiles.is_verified,
              district: item.seller_profiles.district,
              sub_county: item.seller_profiles.sub_county
            } : null}
          />
        ))}
      </div>
    </div>
  );
};

export default RelatedItems;
