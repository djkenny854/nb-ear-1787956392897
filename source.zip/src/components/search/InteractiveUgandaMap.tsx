import React, { useState } from 'react';
import { MapPin, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

interface InteractiveUgandaMapProps {
  onLocationSelect: (region: string) => void;
  selectedRegion?: string;
}

// Accurate Uganda regions based on real geographic boundaries
const ugandaRegions = [
  { 
    id: 'northern', 
    name: 'Northern', 
    // Northern region - includes Acholi, Lango, West Nile, Karamoja
    path: 'M45,5 L65,3 L95,5 L130,8 L160,15 L175,25 L180,45 L178,70 L170,90 L155,105 L135,115 L110,120 L85,118 L60,112 L40,100 L25,85 L15,65 L12,45 L18,25 L30,12 Z',
    centerX: 95,
    centerY: 60,
    districts: ['Gulu', 'Lira', 'Arua', 'Kitgum', 'Moroto', 'Adjumani', 'Moyo', 'Nebbi', 'Apac', 'Kotido'], 
    count: 980,
  },
  { 
    id: 'eastern', 
    name: 'Eastern', 
    // Eastern region - includes Busoga, Bukedi, Bugisu, Teso, Sebei
    path: 'M155,105 L170,90 L180,95 L190,110 L195,135 L192,165 L185,195 L175,220 L160,235 L140,242 L125,240 L115,225 L110,200 L108,170 L112,145 L120,125 L135,115 Z',
    centerX: 155,
    centerY: 170,
    districts: ['Jinja', 'Mbale', 'Tororo', 'Soroti', 'Iganga', 'Busia', 'Bugiri', 'Kapchorwa', 'Pallisa', 'Kumi'], 
    count: 2180,
  },
  { 
    id: 'central', 
    name: 'Central', 
    // Central region - includes Buganda heartland
    path: 'M60,112 L85,118 L110,120 L120,125 L112,145 L108,170 L110,200 L115,225 L105,240 L85,250 L65,252 L50,245 L40,230 L35,205 L38,175 L45,145 L50,125 Z',
    centerX: 75,
    centerY: 180,
    districts: ['Kampala', 'Wakiso', 'Mukono', 'Mpigi', 'Masaka', 'Entebbe', 'Luwero', 'Mityana', 'Kayunga', 'Nakasongola'], 
    count: 5420,
  },
  { 
    id: 'western', 
    name: 'Western', 
    // Western region - includes Ankole, Kigezi, Tooro, Bunyoro
    path: 'M5,75 L15,65 L25,85 L40,100 L50,125 L45,145 L38,175 L35,205 L40,230 L35,255 L25,275 L12,285 L5,270 L2,240 L3,200 L5,160 L8,120 Z',
    centerX: 25,
    centerY: 175,
    districts: ['Mbarara', 'Kabale', 'Fort Portal', 'Kasese', 'Hoima', 'Masindi', 'Bushenyi', 'Rukungiri', 'Ibanda', 'Bundibugyo'], 
    count: 1890,
  },
];

// Water bodies with accurate positions
const waterBodies = [
  { 
    name: 'Lake Victoria', 
    // Lake Victoria - southeastern corner, shared with Kenya and Tanzania
    path: 'M85,250 L105,240 L125,240 L140,242 L155,255 L160,275 L150,295 L125,305 L95,300 L70,285 L65,265 L70,255 Z',
    labelX: 115,
    labelY: 275
  },
  { 
    name: 'Lake Albert', 
    // Lake Albert - western border with DRC
    path: 'M5,120 L12,110 L18,120 L15,150 L10,170 L5,160 Z',
    labelX: 12,
    labelY: 140
  },
  { 
    name: 'Lake Kyoga', 
    // Lake Kyoga - central Uganda
    path: 'M85,130 L105,125 L125,128 L135,140 L125,155 L105,160 L85,155 L78,145 Z',
    labelX: 105,
    labelY: 142
  },
];

// Major cities with accurate geographic positions
const cities = [
  { name: 'Kampala', x: 78, y: 210, isCapital: true },
  { name: 'Jinja', x: 115, y: 215, isCapital: false },
  { name: 'Mbarara', x: 32, y: 245, isCapital: false },
  { name: 'Gulu', x: 95, y: 50, isCapital: false },
  { name: 'Mbale', x: 165, y: 165, isCapital: false },
  { name: 'Fort Portal', x: 18, y: 155, isCapital: false },
  { name: 'Arua', x: 35, y: 35, isCapital: false },
  { name: 'Lira', x: 105, y: 85, isCapital: false },
];

const InteractiveUgandaMap: React.FC<InteractiveUgandaMapProps> = ({
  onLocationSelect,
  selectedRegion,
}) => {
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);

  const getRegionFill = (regionId: string) => {
    switch (regionId) {
      case 'central': return 'hsl(var(--primary) / 0.85)';
      case 'eastern': return 'hsl(var(--primary) / 0.55)';
      case 'western': return 'hsl(var(--primary) / 0.45)';
      case 'northern': return 'hsl(var(--primary) / 0.3)';
      default: return 'hsl(var(--primary) / 0.4)';
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-emerald-500/10 rounded-lg">
            <MapPin className="w-4 h-4 text-emerald-500" />
          </div>
          <h3 className="font-medium text-sm text-foreground">Select Region</h3>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setZoom(Math.min(zoom + 0.2, 1.6))}
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setZoom(Math.max(zoom - 0.2, 0.7))}
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7"
            onClick={() => setZoom(1)}
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Map Container */}
      <div 
        className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-2xl border border-border overflow-hidden"
        style={{ height: '320px' }}
      >
        {/* Background Grid Pattern */}
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full">
            <defs>
              <pattern id="uganda-grid" width="20" height="20" patternUnits="userSpaceOnUse">
                <path d="M 20 0 L 0 0 0 20" fill="none" stroke="currentColor" strokeWidth="0.3" className="text-primary"/>
              </pattern>
            </defs>
            <rect width="100%" height="100%" fill="url(#uganda-grid)" />
          </svg>
        </div>

        {/* SVG Map */}
        <div 
          className="absolute inset-0 flex items-center justify-center transition-transform duration-300"
          style={{ transform: `scale(${zoom})` }}
        >
          <TooltipProvider>
            <svg 
              viewBox="0 0 200 320" 
              className="w-full h-full max-w-[280px] max-h-[300px]"
              style={{ filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.3))' }}
            >
              <defs>
                {/* Water gradient */}
                <linearGradient id="waterGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.7" />
                  <stop offset="100%" stopColor="#1d4ed8" stopOpacity="0.5" />
                </linearGradient>

                {/* Glow filter */}
                <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
              </defs>

              {/* Uganda outline border */}
              <path
                d="M5,75 L15,65 L12,45 L18,25 L30,12 L45,5 L65,3 L95,5 L130,8 L160,15 L175,25 L180,45 L178,70 L180,95 L190,110 L195,135 L192,165 L185,195 L175,220 L160,235 L155,255 L160,275 L150,295 L125,305 L95,300 L70,285 L65,265 L50,245 L35,255 L25,275 L12,285 L5,270 L2,240 L3,200 L5,160 L5,120 Z"
                fill="none"
                stroke="rgba(255,255,255,0.2)"
                strokeWidth="2"
              />

              {/* Regions */}
              {ugandaRegions.map((region) => {
                const isHovered = hoveredRegion === region.id;
                const isSelected = selectedRegion === region.name;
                
                return (
                  <Tooltip key={region.id}>
                    <TooltipTrigger asChild>
                      <g
                        className="cursor-pointer transition-all duration-300"
                        onMouseEnter={() => setHoveredRegion(region.id)}
                        onMouseLeave={() => setHoveredRegion(null)}
                        onClick={() => onLocationSelect(region.name)}
                      >
                        <path
                          d={region.path}
                          fill={getRegionFill(region.id)}
                          className={`transition-all duration-300 ${
                            isHovered || isSelected ? 'opacity-100' : 'opacity-80'
                          }`}
                          stroke={isSelected ? 'hsl(var(--primary))' : 'rgba(255,255,255,0.3)'}
                          strokeWidth={isSelected ? 2.5 : 1}
                          filter={isHovered ? 'url(#glow)' : undefined}
                        />
                        
                        {/* Region label */}
                        <text
                          x={region.centerX}
                          y={region.centerY - 4}
                          textAnchor="middle"
                          className="fill-white text-[9px] font-bold pointer-events-none"
                          style={{ textShadow: '0 1px 3px rgba(0,0,0,0.8)' }}
                        >
                          {region.name}
                        </text>
                        <text
                          x={region.centerX}
                          y={region.centerY + 8}
                          textAnchor="middle"
                          className="fill-white/70 text-[7px] pointer-events-none"
                        >
                          {region.count.toLocaleString()} listings
                        </text>

                        {/* Selection indicator */}
                        {isSelected && (
                          <circle
                            cx={region.centerX}
                            cy={region.centerY}
                            r="15"
                            className="fill-none stroke-primary animate-ping opacity-50"
                            strokeWidth="1.5"
                          />
                        )}
                      </g>
                    </TooltipTrigger>
                    <TooltipContent side="top" className="bg-background/95 backdrop-blur border shadow-xl">
                      <div className="space-y-2 p-1">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 rounded-full bg-primary" />
                          <p className="font-bold">{region.name} Region</p>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          {region.count.toLocaleString()} active listings
                        </p>
                        <div className="flex flex-wrap gap-1 max-w-[180px]">
                          {region.districts.slice(0, 5).map(d => (
                            <Badge key={d} variant="secondary" className="text-[10px] px-1.5 py-0">
                              {d}
                            </Badge>
                          ))}
                          {region.districts.length > 5 && (
                            <Badge variant="outline" className="text-[10px] px-1.5 py-0">
                              +{region.districts.length - 5} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                );
              })}

              {/* Water Bodies */}
              {waterBodies.map((water) => (
                <Tooltip key={water.name}>
                  <TooltipTrigger asChild>
                    <g className="cursor-pointer">
                      <path
                        d={water.path}
                        fill="url(#waterGrad)"
                        className="stroke-blue-400/40 hover:stroke-blue-400/70 transition-all"
                        strokeWidth="1"
                      />
                    </g>
                  </TooltipTrigger>
                  <TooltipContent side="top" className="bg-blue-950 border-blue-800">
                    <p className="text-xs font-medium text-blue-100">{water.name}</p>
                  </TooltipContent>
                </Tooltip>
              ))}

              {/* Cities */}
              {cities.map((city) => (
                <Tooltip key={city.name}>
                  <TooltipTrigger asChild>
                    <g 
                      className="cursor-pointer"
                      onClick={() => onLocationSelect(city.name)}
                    >
                      {city.isCapital ? (
                        <>
                          <circle cx={city.x} cy={city.y} r="5" className="fill-amber-400 animate-pulse" />
                          <circle cx={city.x} cy={city.y} r="8" className="fill-none stroke-amber-400/50" strokeWidth="1.5" />
                        </>
                      ) : (
                        <circle cx={city.x} cy={city.y} r="3" className="fill-white/80 hover:fill-white transition-colors" />
                      )}
                    </g>
                  </TooltipTrigger>
                  <TooltipContent side="top">
                    <p className="text-xs font-medium">
                      {city.name} {city.isCapital && '(Capital)'}
                    </p>
                  </TooltipContent>
                </Tooltip>
              ))}
            </svg>
          </TooltipProvider>
        </div>

        {/* Legend */}
        <div className="absolute bottom-3 left-3 flex items-center gap-3 bg-black/60 backdrop-blur-sm rounded-lg px-3 py-2">
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-primary" />
            <span className="text-[10px] text-white/80">High activity</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-primary/50" />
            <span className="text-[10px] text-white/80">Medium</span>
          </div>
          <div className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full bg-blue-500" />
            <span className="text-[10px] text-white/80">Water</span>
          </div>
        </div>

        {/* Capital indicator */}
        <div className="absolute bottom-3 right-3 flex items-center gap-1.5 bg-black/60 backdrop-blur-sm rounded-lg px-2 py-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
          <span className="text-[10px] text-white/80">Capital</span>
        </div>
      </div>

      {/* Quick Select Buttons */}
      <div className="grid grid-cols-2 gap-2">
        {ugandaRegions.map((region) => (
          <button
            key={region.id}
            onClick={() => onLocationSelect(region.name)}
            className={`flex items-center justify-between p-3 rounded-xl border transition-all duration-200 hover:scale-[1.02] ${
              selectedRegion === region.name
                ? 'bg-primary/15 border-primary/40 shadow-sm shadow-primary/20'
                : 'bg-muted/30 border-border hover:bg-muted/50'
            }`}
          >
            <div className="flex items-center gap-2">
              <MapPin className={`w-4 h-4 ${selectedRegion === region.name ? 'text-primary' : 'text-muted-foreground'}`} />
              <span className="font-medium text-sm">{region.name}</span>
            </div>
            <Badge variant="secondary" className="text-[10px]">
              {region.count.toLocaleString()}
            </Badge>
          </button>
        ))}
      </div>
    </div>
  );
};

export default InteractiveUgandaMap;
