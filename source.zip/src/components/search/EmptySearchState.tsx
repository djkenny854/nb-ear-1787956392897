import React from 'react';
import { Search, Package, Sparkles, ArrowRight, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from 'framer-motion';

interface EmptySearchStateProps {
  searchQuery?: string;
  activeFiltersCount?: number;
  onClearFilters?: () => void;
  onBrowseAll?: () => void;
}

const EmptySearchState: React.FC<EmptySearchStateProps> = ({
  searchQuery,
  activeFiltersCount = 0,
  onClearFilters,
  onBrowseAll,
}) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="flex flex-col items-center justify-center py-16 px-4"
    >
      {/* Animated Icon */}
      <div className="relative mb-6">
        <motion.div
          animate={{ 
            scale: [1, 1.1, 1],
            rotate: [0, 5, -5, 0]
          }}
          transition={{ 
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="w-32 h-32 rounded-3xl bg-gradient-to-br from-primary/20 via-primary/10 to-transparent flex items-center justify-center"
        >
          <Package className="w-16 h-16 text-primary/60" />
        </motion.div>
        
        {/* Floating particles */}
        <motion.div
          animate={{ y: [-5, 5, -5] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="absolute -top-2 -right-2 w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center"
        >
          <Sparkles className="w-4 h-4 text-amber-500" />
        </motion.div>
        
        <motion.div
          animate={{ y: [5, -5, 5] }}
          transition={{ duration: 2.5, repeat: Infinity }}
          className="absolute -bottom-2 -left-2 w-6 h-6 rounded-full bg-primary/30 flex items-center justify-center"
        >
          <Search className="w-3 h-3 text-primary" />
        </motion.div>
      </div>

      {/* Message */}
      <div className="text-center max-w-md space-y-3 mb-8">
        <h3 className="text-xl font-semibold text-foreground">
          {searchQuery ? 'No matches found' : 'No items here yet'}
        </h3>
        
        <p className="text-muted-foreground">
          {searchQuery ? (
            <>
              We couldn't find anything matching "<span className="text-foreground font-medium">{searchQuery}</span>"
              {activeFiltersCount > 0 && (
                <span className="block mt-1 text-sm">
                  Try adjusting your {activeFiltersCount} active filter{activeFiltersCount > 1 ? 's' : ''}
                </span>
              )}
            </>
          ) : activeFiltersCount > 0 ? (
            'No items match your current filters. Try broadening your search criteria.'
          ) : (
            'Be the first to discover amazing items in this category!'
          )}
        </p>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        {activeFiltersCount > 0 && onClearFilters && (
          <Button
            variant="outline"
            onClick={onClearFilters}
            className="gap-2 px-6"
          >
            <RefreshCw className="w-4 h-4" />
            Clear all filters
          </Button>
        )}
        
        {onBrowseAll && (
          <Button
            onClick={onBrowseAll}
            className="gap-2 px-6 bg-primary text-primary-foreground hover:bg-primary/90"
          >
            Browse all items
            <ArrowRight className="w-4 h-4" />
          </Button>
        )}
      </div>

      {/* Suggestions */}
      <div className="mt-12 w-full max-w-lg">
        <p className="text-sm text-muted-foreground text-center mb-4">
          Popular searches you might like:
        </p>
        <div className="flex flex-wrap justify-center gap-2">
          {['iPhone', 'Laptops', 'Cars', 'Fashion', 'Electronics', 'Services'].map((suggestion) => (
            <motion.button
              key={suggestion}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-4 py-2 rounded-full bg-muted/50 border border-border text-sm text-foreground hover:bg-primary/10 hover:border-primary/30 transition-colors"
              onClick={() => {
                // Navigate to search with this query
                window.location.href = `/search?q=${encodeURIComponent(suggestion)}`;
              }}
            >
              {suggestion}
            </motion.button>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default EmptySearchState;
