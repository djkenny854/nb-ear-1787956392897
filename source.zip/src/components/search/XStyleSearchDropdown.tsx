import React, { useState, useEffect, useRef } from 'react';
import { Search, X, TrendingUp, Clock, User, ChevronRight, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';

interface TrendingItem {
  title: string;
  category: string;
}

interface UserSuggestion {
  id: string;
  name: string;
  handle: string;
  avatar?: string;
  isVerified?: boolean;
  verificationBadgeColor?: BadgeColor;
  isFollowing?: boolean;
}

interface XStyleSearchDropdownProps {
  isOpen: boolean;
  onClose: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  anchorRef?: React.RefObject<HTMLElement>;
  sellerId?: string; // When provided, search only within this seller's products
  sellerName?: string; // Name of the seller for contextual placeholder
  className?: string;
  /**
   * Optional submit handler. When provided, the dropdown will call this
   * instead of navigating on Enter / search submit. Used by pages that
   * want to open a local results modal (e.g. own-profile product search)
   * without losing focus on each keystroke.
   */
  onSubmit?: (query: string) => void;
}

const XStyleSearchDropdown: React.FC<XStyleSearchDropdownProps> = ({
  isOpen,
  onClose,
  searchQuery,
  onSearchChange,
  anchorRef,
  sellerId,
  sellerName,
  className,
  onSubmit,
}) => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [trendingSearches, setTrendingSearches] = useState<TrendingItem[]>([
    { title: 'Electronics Uganda', category: 'Trending' },
    { title: 'Fashion deals', category: 'Trending' },
    { title: 'Mobile phones', category: 'Trending' },
  ]);
  const [userSuggestions, setUserSuggestions] = useState<UserSuggestion[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load recent searches from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('recentSearches');
    if (saved) {
      setRecentSearches(JSON.parse(saved));
    }
  }, []);

  // Focus input when opened
  useEffect(() => {
    if (isOpen && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [isOpen]);

  // Search for users/products when query changes
  useEffect(() => {
    if (!searchQuery.trim()) {
      setUserSuggestions([]);
      return;
    }

    const searchItems = async () => {
      setLoading(true);
      try {
        if (sellerId) {
          // Search within seller's products + events
          const [adsResult, eventsResult] = await Promise.all([
            supabase
              .from('ads')
              .select('id, title, images, price, currency, listing_type')
              .eq('seller_id', sellerId)
              .eq('status', 'active')
              .ilike('title', `%${searchQuery}%`)
              .limit(5),
            supabase
              .from('events')
              .select('id, title, images, category')
              .eq('seller_id', sellerId)
              .eq('is_active', true)
              .ilike('title', `%${searchQuery}%`)
              .limit(3),
          ]);

          const suggestions: UserSuggestion[] = [];
          
          if (adsResult.data) {
            suggestions.push(
              ...adsResult.data.map((ad) => ({
                id: ad.id,
                name: ad.title,
                handle: ad.listing_type || 'product',
                avatar: ad.images?.[0] || undefined,
                isVerified: false,
              }))
            );
          }
          
          if (eventsResult.data) {
            suggestions.push(
              ...eventsResult.data.map((event) => ({
                id: event.id,
                name: event.title,
                handle: 'event',
                avatar: event.images?.[0] || undefined,
                isVerified: false,
              }))
            );
          }
          
          setUserSuggestions(suggestions);
        } else {
          // Global search for sellers
          const { data, error } = await supabase
            .from('seller_profiles')
            .select('id, business_name, store_slug, business_logo_url, is_verified, verification_badge_color')
            .ilike('business_name', `%${searchQuery}%`)
            .eq('is_active', true)
            .limit(5);

          if (!error && data) {
            setUserSuggestions(
              data.map((seller) => ({
                id: seller.id,
                name: seller.business_name,
                handle: `@${seller.store_slug || seller.business_name.toLowerCase().replace(/\s+/g, '')}`,
                avatar: seller.business_logo_url || undefined,
                isVerified: seller.is_verified,
                verificationBadgeColor: seller.verification_badge_color,
              }))
            );
          }
        }
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setLoading(false);
      }
    };

    const debounce = setTimeout(searchItems, 300);
    return () => clearTimeout(debounce);
  }, [searchQuery, sellerId]);

  // Handle click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        anchorRef?.current &&
        !anchorRef.current.contains(event.target as Node)
      ) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      return () => document.removeEventListener('mousedown', handleClickOutside);
    }
  }, [isOpen, onClose, anchorRef]);

  const handleTrendingClick = (item: TrendingItem) => {
    saveToRecent(item.title);
    navigate(`/search?q=${encodeURIComponent(item.title)}`);
    onClose();
  };

  const handleUserClick = (user: UserSuggestion) => {
    if (sellerId) {
      // Navigate based on listing_type
      const type = user.handle;
      if (type === 'promotions') {
        navigate(`/promotion/${user.id}`);
      } else if (type === 'jobs') {
        navigate(`/job/${user.id}`);
      } else if (type === 'services') {
        navigate(`/service/${user.id}`);
      } else if (type === 'event') {
        navigate(`/event/${user.id}`);
      } else {
        navigate(`/ad/${user.id}`);
      }
    } else {
      navigate(`/business/${user.handle?.replace('@', '') || user.id}`);
    }
    onClose();
  };

  const saveToRecent = (query: string) => {
    const updated = [query, ...recentSearches.filter((s) => s !== query)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('recentSearches', JSON.stringify(updated));
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      saveToRecent(searchQuery);
      if (onSubmit) {
        onSubmit(searchQuery);
        return;
      }
      if (sellerId) {
        // For seller-specific search, just close - results are shown inline
        onClose();
      } else {
        navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
        onClose();
      }
    }
  };

  const clearInput = () => {
    onSearchChange('');
    inputRef.current?.focus();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          ref={dropdownRef}
          initial={{ opacity: 0, y: -10, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -10, scale: 0.95 }}
          transition={{ duration: 0.2, ease: 'easeOut' }}
          className={cn(
            'absolute top-full left-0 right-0 mt-2 bg-background border border-border rounded-2xl shadow-2xl overflow-hidden z-[100]',
            'min-w-[300px] max-w-[400px]',
            className
          )}
        >
          {/* Search Input */}
          <form onSubmit={handleSearch} className="p-3 border-b border-border">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                ref={inputRef}
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder={sellerId && sellerName ? `Search in ${sellerName}...` : "Search"}
                className="pl-10 pr-10 h-10 bg-muted/50 border-0 rounded-full focus-visible:ring-1 focus-visible:ring-primary"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={clearInput}
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 rounded-full bg-primary flex items-center justify-center"
                >
                  <X className="w-3 h-3 text-primary-foreground" />
                </button>
              )}
            </div>
            {sellerId && sellerName && (
              <p className="text-xs text-muted-foreground mt-2 px-1">
                Searching products within <span className="font-medium text-foreground">{sellerName}</span>
              </p>
            )}
          </form>

          <ScrollArea className="max-h-[400px]">
            <div className="py-2">
              {/* Loading State */}
              {loading && (
                <div className="flex items-center justify-center py-4">
                  <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
                </div>
              )}

              {/* User Suggestions */}
              {!loading && userSuggestions.length > 0 && (
                <div className="px-1">
                  {userSuggestions.map((user) => (
                    <button
                      key={user.id}
                      onClick={() => handleUserClick(user)}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-accent/50 transition-colors text-left"
                    >
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={user.avatar} />
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {user.name.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-1">
                          <span className="font-semibold text-sm truncate">{user.name}</span>
                          <UnifiedVerifiedBadge 
                            isVerified={user.isVerified} 
                            badgeColor={user.verificationBadgeColor}
                            size="sm" 
                          />
                        </div>
                        <span className="text-sm text-muted-foreground truncate block">
                          {user.handle}
                        </span>
                        {user.isFollowing && (
                          <span className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                            <User className="w-3 h-3" />
                            Following
                          </span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {/* Trending Searches (when no query) */}
              {!loading && !searchQuery && (
                <div className="px-1">
                  {trendingSearches.map((item, index) => (
                    <button
                      key={index}
                      onClick={() => handleTrendingClick(item)}
                      className="w-full flex items-center gap-3 px-4 py-3 hover:bg-accent/50 transition-colors text-left"
                    >
                      <Search className="w-5 h-5 text-muted-foreground" />
                      <div className="flex-1 min-w-0">
                        <span className="font-medium text-sm">{item.title}</span>
                        <span className="text-xs text-muted-foreground block">
                          {item.category}
                        </span>
                      </div>
                    </button>
                  ))}

                  {/* Show More Link */}
                  <button className="w-full px-4 py-3 text-primary text-sm hover:bg-accent/30 transition-colors text-left">
                    Show more
                  </button>
                </div>
              )}

              {/* No Results */}
              {!loading && searchQuery && userSuggestions.length === 0 && (
                <div className="px-4 py-8 text-center">
                  <Search className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">
                    No results for "{searchQuery}"
                  </p>
                </div>
              )}
            </div>
          </ScrollArea>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default XStyleSearchDropdown;
