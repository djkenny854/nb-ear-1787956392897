import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { 
  TrendingUp, Clock, Flame, Zap, X, Tag, 
  Sparkles, ShoppingBag, Package, Star, Image, Users
} from 'lucide-react';

interface FilterOverviewProps {
  filters: {
    category?: string;
    subcategory?: string;
    brands?: string[];
    condition?: string;
    verifiedOnly?: boolean;
    onSale?: boolean;
    hasImages?: boolean;
    datePosted?: string;
  };
  onFilterChange: (key: string, value: any) => void;
  onClearFilter: (key: string) => void;
  onQuickSearch: (query: string) => void;
}

const quickFilters = [
  { id: 'verifiedOnly', label: 'Verified Sellers', icon: Star, color: 'bg-amber-500/10 text-amber-600 border-amber-500/30' },
  { id: 'onSale', label: 'On Sale', icon: Tag, color: 'bg-red-500/10 text-red-600 border-red-500/30' },
  { id: 'hasImages', label: 'With Photos', icon: Image, color: 'bg-purple-500/10 text-purple-600 border-purple-500/30' },
];

// Condition options that map to database values
const conditionFilters = [
  { label: 'Brand New', dbValues: ['New', 'new', 'NEW'] },
  { label: 'Like New', dbValues: ['like_new', 'like-new', 'Like New'] },
  { label: 'Used', dbValues: ['Used', 'used', 'good', 'fair', 'second_hand'] },
];

const FilterOverview: React.FC<FilterOverviewProps> = ({
  filters,
  onFilterChange,
  onClearFilter,
  onQuickSearch,
}) => {
  // Fetch trending items from database based on view counts
  const { data: trendingItems = [], isLoading: loadingTrending } = useQuery({
    queryKey: ['trending-searches'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select('title, view_count, category')
        .eq('status', 'active')
        .not('title', 'is', null)
        .not('title', 'eq', '')
        .order('view_count', { ascending: false, nullsFirst: false })
        .limit(6);
      
      if (error) throw error;
      
      // Format the data for display
      return (data || []).filter(item => item.title && item.title.trim()).map(item => ({
        label: item.title.length > 25 ? item.title.substring(0, 25) + '...' : item.title,
        count: formatViewCount(item.view_count || 0),
        hot: (item.view_count || 0) > 500
      }));
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Fetch popular brands from database with logos
  const { data: popularBrands = [], isLoading: loadingBrands } = useQuery({
    queryKey: ['popular-brands-filter'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('brands')
        .select('id, name, logo_url, is_popular')
        .eq('is_popular', true)
        .order('name')
        .limit(8);
      
      if (error) throw error;
      return data || [];
    },
    staleTime: 1000 * 60 * 10, // 10 minutes
  });

  // Get active filters for display
  const activeFilters = Object.entries(filters).filter(([key, value]) => {
    if (key === 'brands') return Array.isArray(value) && value.length > 0;
    return value !== undefined && value !== '' && value !== false;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h2 className="text-lg font-semibold text-foreground">Filters Overview</h2>
        <p className="text-sm text-muted-foreground">Refine your search with smart filters</p>
      </div>

      {/* Active Filters */}
      {activeFilters.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium text-foreground">Active Filters</h3>
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs text-muted-foreground hover:text-foreground"
              onClick={() => {
                activeFilters.forEach(([key]) => onClearFilter(key));
              }}
            >
              Clear All
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {activeFilters.map(([key, value]) => {
              const displayValue = Array.isArray(value) ? value.join(', ') : String(value);
              return (
                <Badge
                  key={key}
                  variant="secondary"
                  className="pl-2 pr-1 py-1 bg-primary/10 text-primary border border-primary/20 flex items-center gap-1.5"
                >
                  <span className="text-xs capitalize">{key}: {displayValue}</span>
                  <button
                    onClick={() => onClearFilter(key)}
                    className="p-0.5 hover:bg-primary/20 rounded-full transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              );
            })}
          </div>
        </div>
      )}

      {/* Quick Filters removed per user request */}

      {/* Condition Filters */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-green-500/10 rounded-lg">
            <Package className="w-4 h-4 text-green-600" />
          </div>
          <h3 className="font-medium text-sm text-foreground">Condition</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          {conditionFilters.map((conditionOption) => {
            // Check if current filter matches any of the db values or the label
            const isActive = filters.condition === conditionOption.label || 
              conditionOption.dbValues.some(v => filters.condition?.toLowerCase() === v.toLowerCase());
            
            return (
              <button
                key={conditionOption.label}
                onClick={() => onFilterChange('condition', isActive ? '' : conditionOption.label)}
                className={`px-3 py-1.5 rounded-full border text-xs font-medium transition-all duration-200 ${
                  isActive
                    ? 'bg-primary text-primary-foreground border-primary'
                    : 'bg-muted/50 border-border hover:bg-muted hover:border-primary/30'
                }`}
              >
                {conditionOption.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Popular Brands - from database */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-rose-500/10 rounded-lg">
            <Tag className="w-4 h-4 text-rose-600" />
          </div>
          <h3 className="font-medium text-sm text-foreground">Popular Brands</h3>
        </div>
        {loadingBrands ? (
          <div className="grid grid-cols-4 gap-2">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="h-16 rounded-xl" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-4 gap-2">
            {popularBrands.map((brand) => {
              const isActive = filters.brands?.includes(brand.name);
              return (
                <button
                  key={brand.id}
                  onClick={() => {
                    const currentBrands = filters.brands || [];
                    const newBrands = isActive
                      ? currentBrands.filter(b => b !== brand.name)
                      : [...currentBrands, brand.name];
                    onFilterChange('brands', newBrands.length > 0 ? newBrands : undefined);
                  }}
                  className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all duration-200 ${
                    isActive
                      ? 'bg-primary/10 border-primary/30 ring-1 ring-primary/20'
                      : 'bg-muted/30 border-border hover:bg-muted/50 hover:border-primary/20'
                  }`}
                >
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={brand.logo_url || ''} alt={brand.name} />
                    <AvatarFallback className="text-xs bg-muted">
                      {brand.name.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  <span className={`text-[10px] font-medium ${
                    isActive ? 'text-primary' : 'text-muted-foreground'
                  }`}>
                    {brand.name}
                  </span>
                </button>
              );
            })}
          </div>
        )}
        {filters.brands && filters.brands.length > 0 && (
          <div className="flex items-center gap-2 mt-2">
            <span className="text-xs text-muted-foreground">
              Selected: {filters.brands.join(', ')}
            </span>
            <button
              onClick={() => onFilterChange('brands', undefined)}
              className="text-xs text-primary hover:underline"
            >
              Clear
            </button>
          </div>
        )}
      </div>

      {/* Trending Searches - from database */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-orange-500/10 rounded-lg">
            <Flame className="w-4 h-4 text-orange-500" />
          </div>
          <h3 className="font-medium text-sm text-foreground">Trending Now</h3>
        </div>
        {loadingTrending ? (
          <div className="flex flex-wrap gap-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-8 w-24 rounded-full" />
            ))}
          </div>
        ) : (
          <div className="flex flex-wrap gap-2">
            {trendingItems.map((item, index) => (
              <button
                key={index}
                onClick={() => onQuickSearch(item.label)}
                className="group relative flex items-center gap-1.5 px-3 py-1.5 bg-muted/50 hover:bg-primary/10 border border-border hover:border-primary/30 rounded-full transition-all duration-200"
              >
                {item.hot && <Zap className="w-3 h-3 text-orange-500" />}
                <span className="text-sm text-foreground group-hover:text-primary transition-colors">
                  {item.label}
                </span>
                {/* Count hidden - was inaccurate */}
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

// Helper function to format view counts
function formatViewCount(count: number): string {
  if (count >= 1000) {
    return (count / 1000).toFixed(1) + 'k';
  }
  return count.toString();
}

export default FilterOverview;
