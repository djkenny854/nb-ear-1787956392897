import React from 'react';
import { TrendingUp, Clock, Flame, Zap } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface TrendingSearchesProps {
  onSelect: (query: string) => void;
}

const trendingItems = [
  { label: 'iPhone 15', count: '2.3k', hot: true },
  { label: 'Toyota Wish', count: '1.8k', hot: true },
  { label: 'Laptops', count: '1.5k', hot: false },
  { label: 'Apartments Kampala', count: '1.2k', hot: false },
  { label: 'Generator', count: '980', hot: false },
  { label: 'Land for Sale', count: '850', hot: false },
  { label: 'PS5', count: '720', hot: true },
  { label: 'Samsung TV', count: '650', hot: false },
];

const recentSearches = [
  'Electronics Kampala',
  'Used Cars',
  'Office Space',
  'Remote Jobs',
];

const suggestedCategories = [
  { label: 'Jobs', icon: '💼', color: 'bg-blue-500/10 text-blue-600' },
  { label: 'Electronics', icon: '📱', color: 'bg-purple-500/10 text-purple-600' },
  { label: 'Vehicles', icon: '🚗', color: 'bg-green-500/10 text-green-600' },
  { label: 'Real Estate', icon: '🏠', color: 'bg-orange-500/10 text-orange-600' },
  { label: 'Services', icon: '🔧', color: 'bg-pink-500/10 text-pink-600' },
  { label: 'Fashion', icon: '👕', color: 'bg-cyan-500/10 text-cyan-600' },
];

const TrendingSearches: React.FC<TrendingSearchesProps> = ({ onSelect }) => {
  return (
    <div className="space-y-5">
      {/* Trending Now */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-orange-500/10 rounded-lg">
            <Flame className="w-4 h-4 text-orange-500" />
          </div>
          <h3 className="font-medium text-sm text-foreground">Trending Now</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          {trendingItems.map((item, index) => (
            <button
              key={index}
              onClick={() => onSelect(item.label)}
              className="group relative flex items-center gap-1.5 px-3 py-1.5 bg-muted/50 hover:bg-primary/10 border border-border hover:border-primary/30 rounded-full transition-all duration-200"
            >
              {item.hot && (
                <Zap className="w-3 h-3 text-orange-500" />
              )}
              <span className="text-sm text-foreground group-hover:text-primary transition-colors">
                {item.label}
              </span>
              <span className="text-xs text-muted-foreground">
                {item.count}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Quick Categories */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-primary/10 rounded-lg">
            <TrendingUp className="w-4 h-4 text-primary" />
          </div>
          <h3 className="font-medium text-sm text-foreground">Popular Categories</h3>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {suggestedCategories.map((cat, index) => (
            <button
              key={index}
              onClick={() => onSelect(cat.label)}
              className={`flex items-center gap-2 px-3 py-2.5 ${cat.color} rounded-xl hover:scale-[1.02] transition-transform duration-200`}
            >
              <span className="text-lg">{cat.icon}</span>
              <span className="text-xs font-medium truncate">{cat.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Searches */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 bg-muted rounded-lg">
            <Clock className="w-4 h-4 text-muted-foreground" />
          </div>
          <h3 className="font-medium text-sm text-foreground">Recent Searches</h3>
        </div>
        <div className="flex flex-wrap gap-2">
          {recentSearches.map((search, index) => (
            <button
              key={index}
              onClick={() => onSelect(search)}
              className="px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground bg-muted/30 hover:bg-muted/50 border border-transparent hover:border-border rounded-full transition-all duration-200"
            >
              {search}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TrendingSearches;
