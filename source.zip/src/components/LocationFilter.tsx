import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ugandaDistricts, getSubCounties } from '@/data/ugandaDistricts';
import { MapPin, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface LocationFilterProps {
  selectedRegion: string;
  selectedDistrict: string;
  selectedSubCounty: string;
  onRegionChange: (region: string) => void;
  onDistrictChange: (district: string) => void;
  onSubCountyChange: (subCounty: string) => void;
}

const LocationFilter: React.FC<LocationFilterProps> = ({
  selectedRegion,
  selectedDistrict,
  selectedSubCounty,
  onRegionChange,
  onDistrictChange,
  onSubCountyChange
}) => {
  const [districtSearch, setDistrictSearch] = useState('');

  const regions = ['All', 'Central', 'Eastern', 'Northern', 'Western'];

  const filteredDistricts = useMemo(() => {
    let districts = ugandaDistricts;
    if (selectedRegion && selectedRegion !== 'All') {
      districts = districts.filter(d => d.region === selectedRegion);
    }
    if (districtSearch) {
      districts = districts.filter(d => 
        d.name.toLowerCase().includes(districtSearch.toLowerCase())
      );
    }
    return districts;
  }, [selectedRegion, districtSearch]);

  const subCounties = useMemo(() => {
    if (!selectedDistrict) return [];
    return getSubCounties(selectedDistrict);
  }, [selectedDistrict]);

  const clearAll = () => {
    onRegionChange('');
    onDistrictChange('');
    onSubCountyChange('');
    setDistrictSearch('');
  };

  const hasActiveFilters = selectedRegion || selectedDistrict || selectedSubCounty;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-primary" />
          <Label className="text-sm font-semibold">Location</Label>
        </div>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={clearAll}
            className="h-6 px-2 text-xs"
          >
            <X className="w-3 h-3 mr-1" />
            Clear
          </Button>
        )}
      </div>

      {/* Region Selection */}
      <div className="space-y-2">
        <Label className="text-xs text-muted-foreground">Region</Label>
        <Select value={selectedRegion} onValueChange={onRegionChange}>
          <SelectTrigger className="h-9">
            <SelectValue placeholder="Select region" />
          </SelectTrigger>
          <SelectContent>
            {regions.map((region) => (
              <SelectItem key={region} value={region}>
                {region}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* District Selection */}
      <div className="space-y-2">
        <Label className="text-xs text-muted-foreground">District</Label>
        <Input
          placeholder="Search district..."
          value={districtSearch}
          onChange={(e) => setDistrictSearch(e.target.value)}
          className="h-9 mb-2"
        />
        <Select value={selectedDistrict} onValueChange={onDistrictChange}>
          <SelectTrigger className="h-9">
            <SelectValue placeholder="Select district" />
          </SelectTrigger>
          <SelectContent>
            <div className="max-h-64 overflow-y-auto">
              {filteredDistricts.map((district) => (
                <SelectItem key={district.id} value={district.name}>
                  {district.name}
                  <Badge variant="secondary" className="ml-2 text-xs">
                    {district.region}
                  </Badge>
                </SelectItem>
              ))}
            </div>
          </SelectContent>
        </Select>
      </div>

      {/* Sub-county Selection */}
      {selectedDistrict && subCounties.length > 0 && (
        <div className="space-y-2">
          <Label className="text-xs text-muted-foreground">Sub-county</Label>
          <Select value={selectedSubCounty} onValueChange={onSubCountyChange}>
            <SelectTrigger className="h-9">
              <SelectValue placeholder="Select sub-county" />
            </SelectTrigger>
            <SelectContent>
              <div className="max-h-64 overflow-y-auto">
                {subCounties.map((subCounty, index) => (
                  <SelectItem key={index} value={subCounty}>
                    {subCounty}
                  </SelectItem>
                ))}
              </div>
            </SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
};

export default LocationFilter;
