import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Users, Briefcase, DollarSign, ChevronDown, ChevronUp, 
  Sparkles, CheckCircle2, Mail, Phone, Globe
} from 'lucide-react';

interface Position {
  role: string;
  quantity: number;
  job_type?: string;
  salary_min?: number;
  salary_max?: number;
  salary_negotiable?: boolean;
  requirements?: string;
}

interface MultiPositionsBlockProps {
  positions: Position[];
  campaignTitle?: string;
  campaignOverview?: string;
  salaryCurrency: string;
  applyMethod?: string;
  contactEmail?: string | null;
  contactPhone?: string | null;
  externalUrl?: string | null;
  onApplyToRole: (role: string) => void;
}

export default function MultiPositionsBlock({
  positions,
  campaignTitle,
  campaignOverview,
  salaryCurrency,
  applyMethod,
  contactEmail,
  contactPhone,
  externalUrl,
  onApplyToRole
}: MultiPositionsBlockProps) {
  const [expandedPositions, setExpandedPositions] = useState<Set<number>>(new Set());

  const togglePosition = (index: number) => {
    const newExpanded = new Set(expandedPositions);
    if (newExpanded.has(index)) {
      newExpanded.delete(index);
    } else {
      newExpanded.add(index);
    }
    setExpandedPositions(newExpanded);
  };

  const totalOpenings = positions.reduce((sum, p) => sum + (p.quantity || 1), 0);

  const isExternalMethod = applyMethod && applyMethod !== 'earlymarket';

  const getApplyButtonConfig = () => {
    switch (applyMethod) {
      case 'email':
        return { icon: Mail, label: 'Apply via Email', className: 'bg-blue-500 hover:bg-blue-600' };
      case 'phone':
        return { icon: Phone, label: 'Call to Apply', className: 'bg-purple-500 hover:bg-purple-600' };
      case 'website':
        return { icon: Globe, label: 'Apply on Website', className: 'bg-orange-500 hover:bg-orange-600' };
      default:
        return { icon: Sparkles, label: 'Apply', className: 'bg-primary hover:bg-primary/90' };
    }
  };

  const applyConfig = getApplyButtonConfig();
  const ApplyIcon = applyConfig.icon;

  return (
    <div className="lg:col-span-12 bg-gradient-to-br from-amber-500/10 via-orange-500/10 to-background rounded-3xl p-6 border-2 border-amber-500/20">
      {/* Header */}
      <div className="flex items-start justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Badge className="bg-amber-500/20 text-amber-700 dark:text-amber-400 border-0">
              <Users className="w-3 h-3 mr-1" />
              Multiple Roles
            </Badge>
            <Badge variant="outline" className="border-amber-500/30">
              {totalOpenings} total openings
            </Badge>
          </div>
          <h3 className="text-xl font-bold text-foreground">
            {campaignTitle || 'Hiring Campaign'}
          </h3>
          {campaignOverview && (
            <p className="text-muted-foreground mt-2 max-w-2xl">
              {campaignOverview}
            </p>
          )}
        </div>
      </div>

      {/* External Apply Method Banner */}
      {isExternalMethod && (
        <div className="mb-4 p-3 rounded-xl border border-border bg-muted/30 flex items-center gap-3">
          <ApplyIcon className="h-5 w-5 text-primary flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium">
              {applyMethod === 'email' && `Applications via email: ${contactEmail}`}
              {applyMethod === 'phone' && `Applications via phone: ${contactPhone}`}
              {applyMethod === 'website' && `Applications via external website`}
            </p>
          </div>
        </div>
      )}

      {/* Positions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {positions.map((position, index) => (
          <motion.div
            key={index}
            layout
            className="bg-card rounded-2xl border border-border overflow-hidden hover:border-primary/50 transition-colors"
          >
            {/* Position Header - Always visible */}
            <button
              onClick={() => togglePosition(index)}
              className="w-full p-4 text-left flex items-start justify-between hover:bg-accent/30 transition-colors"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-semibold text-foreground truncate">{position.role}</h4>
                  {position.quantity > 1 && (
                    <Badge variant="secondary" className="text-xs">
                      {position.quantity} positions
                    </Badge>
                  )}
                </div>
                <div className="flex flex-wrap items-center gap-2 text-sm">
                  {position.job_type && (
                    <span className="text-muted-foreground">{position.job_type}</span>
                  )}
                  {(position.salary_min || position.salary_negotiable) && (
                    <span className="text-primary font-medium flex items-center gap-1">
                      <DollarSign className="w-3 h-3" />
                      {position.salary_negotiable 
                        ? 'Negotiable' 
                        : `${salaryCurrency} ${position.salary_min?.toLocaleString()}${position.salary_max ? ` - ${position.salary_max.toLocaleString()}` : ''}`
                      }
                    </span>
                  )}
                </div>
              </div>
              <div className="flex-shrink-0 ml-2">
                {expandedPositions.has(index) ? (
                  <ChevronUp className="w-5 h-5 text-muted-foreground" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-muted-foreground" />
                )}
              </div>
            </button>

            {/* Expanded Content */}
            <AnimatePresence>
              {expandedPositions.has(index) && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: 'auto', opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="overflow-hidden"
                >
                  <div className="px-4 pb-4 space-y-3 border-t border-border pt-3">
                    {/* Requirements */}
                    {position.requirements && (
                      <div>
                        <p className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Requirements</p>
                        <p className="text-sm text-foreground whitespace-pre-wrap">{position.requirements}</p>
                      </div>
                    )}

                    {/* Quick Info */}
                    <div className="flex flex-wrap gap-2">
                      {position.job_type && (
                        <Badge variant="outline" className="text-xs">
                          <Briefcase className="w-3 h-3 mr-1" />
                          {position.job_type}
                        </Badge>
                      )}
                      <Badge variant="outline" className="text-xs">
                        <Users className="w-3 h-3 mr-1" />
                        {position.quantity || 1} opening{(position.quantity || 1) > 1 ? 's' : ''}
                      </Badge>
                    </div>

                    {/* Apply Button */}
                    <Button 
                      onClick={(e) => {
                        e.stopPropagation();
                        onApplyToRole(position.role);
                      }}
                      size="sm" 
                      className={`w-full rounded-full mt-2 ${isExternalMethod ? applyConfig.className : ''}`}
                    >
                      <ApplyIcon className="w-4 h-4 mr-2" />
                      {isExternalMethod ? applyConfig.label : `Apply for ${position.role}`}
                    </Button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        ))}
      </div>

      {/* Apply to All Roles */}
      <div className="mt-6 p-4 bg-background/50 rounded-2xl flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
            <CheckCircle2 className="h-5 w-5 text-primary" />
          </div>
          <div>
            <p className="font-medium">
              {isExternalMethod ? 'Apply for all roles' : 'Apply to all roles at once'}
            </p>
            <p className="text-sm text-muted-foreground">
              {isExternalMethod 
                ? `Use the ${applyMethod === 'email' ? 'email' : applyMethod === 'phone' ? 'phone number' : 'website'} to apply`
                : `Submit a single application for all open positions`
              }
            </p>
          </div>
        </div>
        <Button 
          onClick={() => onApplyToRole('all')} 
          className={`rounded-full ${isExternalMethod ? applyConfig.className : ''}`}
        >
          <ApplyIcon className="w-4 h-4 mr-2" />
          {isExternalMethod ? applyConfig.label : 'Apply for All'}
        </Button>
      </div>
    </div>
  );
}
