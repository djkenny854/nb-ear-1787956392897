import React from 'react';
import { cn } from '@/lib/utils';
import verifiedBadge from '@/assets/verified-badge.png';

export type BadgeColor = 'blue' | 'orange' | 'gold' | string | null | undefined;

interface UnifiedVerifiedBadgeProps {
  isVerified?: boolean;
  badgeColor?: BadgeColor;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  showTooltip?: boolean;
}

const sizeClasses = {
  xs: 'w-3 h-3',
  sm: 'w-4 h-4',
  md: 'w-5 h-5',
  lg: 'w-6 h-6',
  xl: 'w-8 h-8'
};

// Orange verified badge SVG - for organizations or special users
const OrangeBadgeSVG: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 512 512" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Background scalloped shape */}
    <path 
      d="M256 32c-12.5 0-24.5 2.2-35.8 6.4-10.8 4-21 9.9-30.2 17.2-9.3-7.3-19.5-13.2-30.3-17.2-11.3-4.2-23.3-6.4-35.7-6.4-47.3 0-88 30.5-102.2 72.9-14.4 42.9-2.4 90.2 30.3 122.9L256 432l204-204c32.7-32.7 44.7-80 30.3-122.9C476 62.5 435.3 32 388 32c-12.4 0-24.4 2.2-35.7 6.4-10.8 4-21 9.9-30.3 17.2-9.2-7.3-19.4-13.2-30.2-17.2C280.5 34.2 268.5 32 256 32z" 
      fill="none"
    />
    {/* Main badge shape with scalloped edges - orange version */}
    <path 
      d="M438.9 256c0.4-14-4.7-27.7-12.4-39.5-7.7-11.7-18.5-21.1-31.3-27.1 4.9-13.2 5.9-27.5 3-41.2-2.8-13.8-9.5-26.5-19.2-36.7-10.2-9.7-22.9-16.4-36.7-19.2-13.7-2.9-28 0-41.2 3-6-12.8-15.3-23.6-27-31.3-11.8-7.8-25.5-12.9-39.5-12.5-14-0.4-27.7 4.7-39.5 12.4-11.7 7.7-21.1 18.5-27.1 31.3-13.2-4.9-27.5-5.9-41.4-3-13.8 2.9-26.5 9.5-36.7 19.2-9.7 10.2-16.2 22.9-19.1 36.7-2.8 13.7-0.2 28 3 41.2-12.8 6-23.6 15.3-31.4 27-7.7 11.8-12.8 25.5-12.4 39.5-0.4 14 4.7 27.7 12.4 39.5 7.7 11.7 18.6 21.1 31.4 27.1-4.9 13.2-5.8 27.5-3 41.2 2.9 13.8 9.4 26.5 19.1 36.7 10.2 9.7 22.9 16.3 36.7 19.1 13.9 2.9 28.2 0.1 41.4-3 6 12.8 15.4 23.6 27.1 31.3 11.8 7.7 25.5 12.8 39.5 12.4 14 0.4 27.7-4.6 39.5-12.4 11.7-7.7 21-18.5 27-31.3 13.2 4.9 27.5 5.7 41.2 2.9 13.8-2.8 26.5-9.4 36.7-19.1 10-10.2 16.4-22.9 19.2-36.7 2.9-13.7 0.2-28-3-41.2 12.8-6 23.6-15.4 31.3-27.1 7.7-11.8 12.8-25.5 12.4-39.5z" 
      fill="#F97316"
      stroke="#EA580C"
      strokeWidth="16"
    />
    {/* Inner lighter fill */}
    <path 
      d="M256 96c88.4 0 160 71.6 160 160s-71.6 160-160 160S96 344.4 96 256 167.6 96 256 96z" 
      fill="#FDBA74"
      opacity="0.4"
    />
    {/* Checkmark */}
    <path 
      d="M210.1 323.5l-74.5-74.5 28.1-28.3 45 45.1 95.6-104.1 29.3 27.1z" 
      fill="#FFFFFF"
    />
  </svg>
);

// Gold verified badge SVG - for premium/special users
const GoldBadgeSVG: React.FC<{ className?: string }> = ({ className }) => (
  <svg viewBox="0 0 512 512" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Main badge shape with scalloped edges - gold version */}
    <path 
      d="M438.9 256c0.4-14-4.7-27.7-12.4-39.5-7.7-11.7-18.5-21.1-31.3-27.1 4.9-13.2 5.9-27.5 3-41.2-2.8-13.8-9.5-26.5-19.2-36.7-10.2-9.7-22.9-16.4-36.7-19.2-13.7-2.9-28 0-41.2 3-6-12.8-15.3-23.6-27-31.3-11.8-7.8-25.5-12.9-39.5-12.5-14-0.4-27.7 4.7-39.5 12.4-11.7 7.7-21.1 18.5-27.1 31.3-13.2-4.9-27.5-5.9-41.4-3-13.8 2.9-26.5 9.5-36.7 19.2-9.7 10.2-16.2 22.9-19.1 36.7-2.8 13.7-0.2 28 3 41.2-12.8 6-23.6 15.3-31.4 27-7.7 11.8-12.8 25.5-12.4 39.5-0.4 14 4.7 27.7 12.4 39.5 7.7 11.7 18.6 21.1 31.4 27.1-4.9 13.2-5.8 27.5-3 41.2 2.9 13.8 9.4 26.5 19.1 36.7 10.2 9.7 22.9 16.3 36.7 19.1 13.9 2.9 28.2 0.1 41.4-3 6 12.8 15.4 23.6 27.1 31.3 11.8 7.7 25.5 12.8 39.5 12.4 14 0.4 27.7-4.6 39.5-12.4 11.7-7.7 21-18.5 27-31.3 13.2 4.9 27.5 5.7 41.2 2.9 13.8-2.8 26.5-9.4 36.7-19.1 10-10.2 16.4-22.9 19.2-36.7 2.9-13.7 0.2-28-3-41.2 12.8-6 23.6-15.4 31.3-27.1 7.7-11.8 12.8-25.5 12.4-39.5z" 
      fill="#EAB308"
      stroke="#CA8A04"
      strokeWidth="16"
    />
    {/* Inner lighter fill */}
    <path 
      d="M256 96c88.4 0 160 71.6 160 160s-71.6 160-160 160S96 344.4 96 256 167.6 96 256 96z" 
      fill="#FEF08A"
      opacity="0.4"
    />
    {/* Checkmark */}
    <path 
      d="M210.1 323.5l-74.5-74.5 28.1-28.3 45 45.1 95.6-104.1 29.3 27.1z" 
      fill="#FFFFFF"
    />
  </svg>
);

/**
 * UnifiedVerifiedBadge - A consistent verification badge used across all components
 * 
 * @param isVerified - Whether to show the badge
 * @param badgeColor - Color of the badge: 'blue' (default image), 'orange' (SVG), 'gold' (SVG)
 * @param size - Size of the badge: 'xs' | 'sm' | 'md' | 'lg' | 'xl'
 * @param className - Additional CSS classes
 */
const UnifiedVerifiedBadge: React.FC<UnifiedVerifiedBadgeProps> = ({
  isVerified = false,
  badgeColor = 'blue',
  size = 'sm',
  className
}) => {
  if (!isVerified) return null;

  const sizeClass = sizeClasses[size];
  const normalizedColor = badgeColor?.toLowerCase() || 'blue';

  // Render orange SVG badge
  if (normalizedColor === 'orange') {
    return (
      <OrangeBadgeSVG className={cn(sizeClass, 'flex-shrink-0', className)} />
    );
  }

  // Render gold SVG badge
  if (normalizedColor === 'gold') {
    return (
      <GoldBadgeSVG className={cn(sizeClass, 'flex-shrink-0', className)} />
    );
  }

  // Default: Render blue badge image (the official asset)
  return (
    <img 
      src={verifiedBadge} 
      alt="Verified" 
      className={cn(sizeClass, 'flex-shrink-0', className)}
    />
  );
};

export default UnifiedVerifiedBadge;
