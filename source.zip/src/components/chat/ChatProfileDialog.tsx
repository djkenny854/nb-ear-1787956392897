import React from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Phone, Video, User, MoreHorizontal, Ban, Flag, BellOff } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  recipient: {
    id: string;
    name: string;
    avatar?: string;
    handle?: string;
  };
  currentUserId?: string;
  conversationId?: string;
  adId?: string;
  onBlocked?: () => void;
}

const ChatProfileDialog: React.FC<Props> = ({
  open, onOpenChange, recipient, currentUserId, conversationId, adId, onBlocked,
}) => {
  const navigate = useNavigate();
  const initials = recipient.name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();

  const handleBlock = async () => {
    if (!currentUserId) return;
    try {
      const { error } = await supabase.from('blocked_users').insert({
        blocker_user_id: currentUserId,
        blocked_user_id: recipient.id,
      });
      if (error && error.code !== '23505') throw error;
      toast({ title: `Blocked ${recipient.name}`, description: "You won't see their messages anymore." });
      onBlocked?.();
      onOpenChange(false);
    } catch {
      toast({ title: 'Error', description: 'Failed to block user.', variant: 'destructive' });
    }
  };

  const handleReport = () => {
    const params = new URLSearchParams();
    params.set('userId', recipient.id);
    if (conversationId) params.set('conversationId', conversationId);
    if (adId) params.set('adId', adId);
    onOpenChange(false);
    navigate(`/reports?${params.toString()}`);
  };

  const QuickAction = ({ icon: Icon, label, onClick, disabled }: any) => (
    <button
      onClick={onClick}
      disabled={disabled}
      className="flex flex-col items-center gap-1.5 flex-1 group"
    >
      <span className="w-12 h-12 rounded-full border border-border flex items-center justify-center group-hover:bg-muted transition-colors disabled:opacity-50">
        <Icon className="w-5 h-5" />
      </span>
      <span className="text-xs text-foreground/80">{label}</span>
    </button>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md p-0 overflow-hidden rounded-3xl">
        <div className="px-6 pt-8 pb-6 flex flex-col items-center">
          <Avatar className="w-24 h-24 mb-3 ring-4 ring-background shadow-md">
            <AvatarImage src={recipient.avatar} />
            <AvatarFallback className="text-2xl">{initials}</AvatarFallback>
          </Avatar>
          <h2 className="text-xl font-bold">{recipient.name}</h2>
          {recipient.handle && (
            <p className="text-muted-foreground text-sm">@{recipient.handle}</p>
          )}

          <div className="flex items-stretch gap-2 mt-6 w-full">
            <QuickAction icon={Phone} label="Voice" onClick={() => toast({ title: 'Voice calls coming soon' })} />
            <QuickAction icon={Video} label="Video" onClick={() => toast({ title: 'Video calls coming soon' })} />
            <QuickAction
              icon={User}
              label="Profile"
              onClick={() => {
                onOpenChange(false);
                navigate(`/seller/${recipient.id}`);
              }}
            />
            <QuickAction icon={MoreHorizontal} label="More" onClick={() => {}} />
          </div>
        </div>

        <div className="border-t border-border bg-muted/30 px-3 py-2 space-y-1">
          <button
            onClick={() => toast({ title: 'Muted notifications', description: 'You won\'t get notified for this chat.' })}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors text-left"
          >
            <BellOff className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm font-medium">Mute notifications</span>
          </button>
          <button
            onClick={handleReport}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors text-left"
          >
            <Flag className="w-5 h-5 text-muted-foreground" />
            <span className="text-sm font-medium">Report</span>
          </button>
          <button
            onClick={handleBlock}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl hover:bg-destructive/10 transition-colors text-left"
          >
            <Ban className="w-5 h-5 text-destructive" />
            <span className="text-sm font-medium text-destructive">Block messages</span>
          </button>
        </div>

        <p className="text-[11px] text-muted-foreground text-center py-3 border-t border-border">
          Messages are deleted after 90 days
        </p>
      </DialogContent>
    </Dialog>
  );
};

export default ChatProfileDialog;
