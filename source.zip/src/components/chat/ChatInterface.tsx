
import React, { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import WhatsAppChat from './WhatsAppChat';
import ChatAuthPrompt from './ChatAuthPrompt';
import { Spinner } from '@/components/ui/spinner';

interface ChatInterfaceProps {
  sellerId: string; // Can be either seller_profiles.id or user_id
  adId?: string;
  contentType?: string;
  onBack: () => void;
}

const ChatInterface: React.FC<ChatInterfaceProps> = ({ sellerId, adId, contentType, onBack }) => {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showAuthPrompt, setShowAuthPrompt] = useState(false);
  const [resolvedUserId, setResolvedUserId] = useState<string | null>(null);
  const [sellerName, setSellerName] = useState<string>('Seller');

  useEffect(() => {
    // Check current auth state
    const checkUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
      
      // If no user, show auth prompt
      if (!user) {
        setShowAuthPrompt(true);
      }
    };

    checkUser();

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user ?? null);
        if (session?.user) {
          setShowAuthPrompt(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  // Normalize sellerId: resolve seller_profiles.id to user_id if needed
  useEffect(() => {
    const resolveSellerId = async () => {
      if (!sellerId) {
        setLoading(false);
        return;
      }

      try {
        // First, try to find by seller_profiles.id (most common case from AdDetails/SellerProfile)
        const { data: byProfileId } = await supabase
          .from('seller_profiles')
          .select('user_id, business_name')
          .eq('id', sellerId)
          .single();

        if (byProfileId) {
          setResolvedUserId(byProfileId.user_id);
          setSellerName(byProfileId.business_name || 'Seller');
          setLoading(false);
          return;
        }

        // If not found by id, try to find by user_id (in case sellerId is already a user_id)
        const { data: byUserId } = await supabase
          .from('seller_profiles')
          .select('user_id, business_name')
          .eq('user_id', sellerId)
          .single();

        if (byUserId) {
          setResolvedUserId(byUserId.user_id);
          setSellerName(byUserId.business_name || 'Seller');
          setLoading(false);
          return;
        }

        // If neither found, use the original sellerId as-is (fallback for direct user messaging)
        console.warn('Could not resolve sellerId to seller_profiles, using as-is:', sellerId);
        setResolvedUserId(sellerId);
        setLoading(false);
      } catch (error) {
        console.error('Error resolving seller ID:', error);
        // Fallback: use original sellerId
        setResolvedUserId(sellerId);
        setLoading(false);
      }
    };

    resolveSellerId();
  }, [sellerId]);

  const handleAuthSuccess = () => {
    setShowAuthPrompt(false);
    // The auth state change listener will update the user
  };

  if (loading || !resolvedUserId) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Spinner size="lg" className="text-primary" />
      </div>
    );
  }

  // Always show the chat interface - it will handle auth internally
  return (
    <>
      <WhatsAppChat 
        sellerId={resolvedUserId} 
        adId={adId}
        contentType={contentType}
        onBack={onBack} 
      />
      
      {/* Auth prompt will show if needed */}
      <ChatAuthPrompt
        isOpen={showAuthPrompt}
        onClose={() => setShowAuthPrompt(false)}
        onAuthSuccess={handleAuthSuccess}
        sellerName={sellerName}
        isSellerOnline={false}
      />
    </>
  );
};

export default ChatInterface;
