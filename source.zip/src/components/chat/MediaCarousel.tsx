import React, { useState, useEffect, useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface MediaCarouselProps {
  images: string[];
  autoSlide?: boolean;
  slideInterval?: number;
  className?: string;
  showDots?: boolean;
  showArrows?: boolean;
}

const MediaCarousel: React.FC<MediaCarouselProps> = ({ 
  images, 
  autoSlide = true, 
  slideInterval = 5000, // Changed to 5 seconds
  className = "",
  showDots = true,
  showArrows = true
}) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const carouselRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const carouselId = useRef(Math.random().toString(36).substring(7));

  // Generate unique intervals for each carousel instance (7-9 seconds)
  const getUniqueInterval = () => {
    const baseInterval = slideInterval;
    const variation = Math.random() * 2000 - 1000; // ±1 second variation
    const uniqueId = parseInt(carouselId.current, 36) % 1000;
    return Math.max(baseInterval + variation + uniqueId, 6000); // Minimum 6 seconds
  };

  // Enhanced Intersection Observer for viewport detection
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        const wasVisible = isVisible;
        setIsVisible(entry.isIntersecting);
        
        if (entry.isIntersecting && !wasVisible) {
          console.log(`MediaCarousel ${carouselId.current}: Now visible, starting autoplay`);
        } else if (!entry.isIntersecting && wasVisible) {
          console.log(`MediaCarousel ${carouselId.current}: Hidden, stopping autoplay`);
        }
      },
      { 
        threshold: 0.3,
        rootMargin: '50px'
      }
    );

    if (carouselRef.current) {
      observer.observe(carouselRef.current);
    }

    return () => {
      if (carouselRef.current) {
        observer.unobserve(carouselRef.current);
      }
    };
  }, [isVisible]);

  // Enhanced auto-slide with unique intervals per instance
  useEffect(() => {
    if (!autoSlide || !isVisible || isPaused || images.length <= 1) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      return;
    }

    const startInterval = () => {
      intervalRef.current = setTimeout(() => {
        setCurrentIndex((prevIndex) => 
          prevIndex === images.length - 1 ? 0 : prevIndex + 1
        );
        startInterval(); // Restart with new unique interval
      }, getUniqueInterval());
    };

    startInterval();

    return () => {
      if (intervalRef.current) {
        clearTimeout(intervalRef.current);
      }
    };
  }, [autoSlide, isVisible, isPaused, images.length, currentIndex, slideInterval]);

  const goToPrevious = () => {
    setCurrentIndex(currentIndex === 0 ? images.length - 1 : currentIndex - 1);
  };

  const goToNext = () => {
    setCurrentIndex(currentIndex === images.length - 1 ? 0 : currentIndex + 1);
  };

  const goToSlide = (index: number) => {
    setCurrentIndex(index);
  };

  if (!images || images.length === 0) return null;

  return (
    <div 
      ref={carouselRef}
      className={`relative w-full h-64 md:h-80 overflow-hidden rounded-lg group ${className}`}
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      {/* Image Container with Enhanced Fade Transition */}
      <div className="relative w-full h-full">
        {images.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-all duration-1000 ease-in-out ${
              index === currentIndex 
                ? 'opacity-100 scale-100' 
                : 'opacity-0 scale-105'
            }`}
          >
            <img
              src={image}
              alt={`Media ${index + 1}`}
              className="w-full h-full object-cover"
              loading={index === 0 ? 'eager' : 'lazy'}
            />
          </div>
        ))}
      </div>

      {/* Enhanced Navigation Arrows */}
      {showArrows && images.length > 1 && (
        <>
          <Button
            onClick={goToPrevious}
            variant="ghost"
            size="sm"
            className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-all duration-300 backdrop-blur-sm shadow-lg"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          
          <Button
            onClick={goToNext}
            variant="ghost"
            size="sm"
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-all duration-300 backdrop-blur-sm shadow-lg"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </>
      )}

      {/* Enhanced Dots Indicator */}
      {showDots && images.length > 1 && (
        <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2 h-2 rounded-full transition-all duration-300 ${
                index === currentIndex 
                  ? 'bg-white scale-125 shadow-lg' 
                  : 'bg-white/50 hover:bg-white/70'
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}

      {/* Enhanced Progress Bar */}
      {autoSlide && isVisible && !isPaused && images.length > 1 && (
        <div className="absolute bottom-0 left-0 w-full h-1 bg-black/20">
          <div 
            className="h-full bg-primary transition-all duration-100 ease-linear"
            style={{
              width: `${((currentIndex + 1) / images.length) * 100}%`
            }}
          />
        </div>
      )}
    </div>
  );
};

export default MediaCarousel;
