
import React from 'react';

interface VoiceWaveformProps {
  isAnimating?: boolean;
  duration?: number;
  className?: string;
}

const VoiceWaveform: React.FC<VoiceWaveformProps> = ({ 
  isAnimating = false, 
  duration = 0,
  className = "" 
}) => {
  const bars = 15;
  
  return (
    <div className={`flex items-center justify-center gap-0.5 ${className}`}>
      {[...Array(bars)].map((_, i) => {
        const baseHeight = 4;
        const maxHeight = 24;
        const animatedHeight = isAnimating 
          ? baseHeight + Math.abs(Math.sin((duration * 3 + i) * 0.7)) * (maxHeight - baseHeight)
          : baseHeight + (i % 3 === 0 ? 8 : i % 2 === 0 ? 4 : 2);
        
        return (
          <div
            key={i}
            className={`w-1 rounded-full transition-all duration-150 ${
              isAnimating ? 'bg-red-500' : 'bg-gray-400'
            }`}
            style={{
              height: `${animatedHeight}px`,
              animationDelay: `${i * 0.05}s`
            }}
          />
        );
      })}
    </div>
  );
};

export default VoiceWaveform;
