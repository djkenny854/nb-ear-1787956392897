import React, { useEffect, useRef, useState } from 'react';
import { cn } from '@/lib/utils';

interface DynamicWaveformProps {
  analyserNode?: AnalyserNode | null;
  isAnimating?: boolean;
  barCount?: number;
  className?: string;
  barColor?: string;
  activeColor?: string;
}

const DynamicWaveform: React.FC<DynamicWaveformProps> = ({
  analyserNode,
  isAnimating = false,
  barCount = 25,
  className = "",
  barColor = "bg-foreground/30",
  activeColor = "bg-foreground"
}) => {
  const [heights, setHeights] = useState<number[]>(Array(barCount).fill(4));
  const animationRef = useRef<number | null>(null);
  const dataArrayRef = useRef<Uint8Array>(new Uint8Array(32));

  useEffect(() => {
    if (!analyserNode || !isAnimating) {
      // Static waveform pattern when not animating
      const staticHeights = Array(barCount).fill(0).map((_, i) => {
        const center = barCount / 2;
        const dist = Math.abs(i - center) / center;
        return 4 + (1 - dist) * 12 + Math.random() * 4;
      });
      setHeights(staticHeights);
      return;
    }

    analyserNode.fftSize = 64;
    const bufferLength = analyserNode.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    const updateWaveform = () => {
      if (!analyserNode) return;

      analyserNode.getByteFrequencyData(dataArray);

      const newHeights = Array(barCount).fill(0).map((_, i) => {
        const dataIndex = Math.floor((i / barCount) * bufferLength);
        const value = dataArray[dataIndex] || 0;
        // Map 0-255 to 4-24 pixels height
        return 4 + (value / 255) * 20;
      });

      setHeights(newHeights);
      animationRef.current = requestAnimationFrame(updateWaveform);
    };

    updateWaveform();

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [analyserNode, isAnimating, barCount]);

  return (
    <div className={cn("flex items-center justify-center gap-[2px] h-6", className)}>
      {heights.map((height, i) => (
        <div
          key={i}
          className={cn(
            "w-[2px] rounded-full transition-all duration-75",
            isAnimating ? activeColor : barColor
          )}
          style={{ 
            height: `${Math.max(4, Math.min(24, height))}px`,
          }}
        />
      ))}
    </div>
  );
};

export default DynamicWaveform;
