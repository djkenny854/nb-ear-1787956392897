import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Play, Pause } from 'lucide-react';
import { cn } from '@/lib/utils';
import DynamicWaveform from './DynamicWaveform';

interface VoiceMessagePlayerProps {
  audioUrl: string;
  duration?: number;
  className?: string;
  isCurrentUser?: boolean;
}

const VoiceMessagePlayer: React.FC<VoiceMessagePlayerProps> = ({
  audioUrl,
  duration = 0,
  className = "",
  isCurrentUser = false
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [audioDuration, setAudioDuration] = useState(duration);
  const [isLoading, setIsLoading] = useState(false);
  const audioRef = useRef<HTMLAudioElement>(null);
  const waveformRef = useRef<HTMLDivElement>(null);

  // Waveform animation bars
  const bars = 35;
  const [waveformData, setWaveformData] = useState<number[]>([]);

  // Initialize waveform data
  useEffect(() => {
    const data = Array.from({ length: bars }, () => Math.random() * 0.8 + 0.2);
    setWaveformData(data);
  }, []);

  // Audio event handlers
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleLoadedMetadata = () => {
      setAudioDuration(audio.duration);
      setIsLoading(false);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleEnded = () => {
      setIsPlaying(false);
      setCurrentTime(0);
    };

    const handleLoadStart = () => {
      setIsLoading(true);
    };

    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('loadstart', handleLoadStart);

    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('loadstart', handleLoadStart);
    };
  }, []);

  const togglePlayPause = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().catch(console.error);
      setIsPlaying(true);
    }
  };

  const handleWaveformClick = (event: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    const waveform = waveformRef.current;
    if (!audio || !audioDuration || !waveform) return;

    const rect = waveform.getBoundingClientRect();
    const clickX = event.clientX - rect.left;
    const percentage = clickX / rect.width;
    const newTime = percentage * audioDuration;
    
    audio.currentTime = newTime;
    setCurrentTime(newTime);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const progress = audioDuration > 0 ? (currentTime / audioDuration) * 100 : 0;

  return (
    <div className={cn(
      "flex items-center gap-4 px-4 py-3 rounded-2xl min-w-[240px] max-w-[280px]",
      isCurrentUser 
        ? "bg-muted/80" 
        : "bg-card border border-border shadow-sm",
      className
    )}>
      <audio ref={audioRef} src={audioUrl} preload="metadata" />
      
      {/* Play/Pause Button */}
      <Button
        onClick={togglePlayPause}
        disabled={isLoading}
        size="sm"
        variant="ghost"
        className={cn(
          "w-10 h-10 p-0 rounded-full flex-shrink-0 flex items-center justify-center",
          isCurrentUser
            ? "bg-foreground/10 hover:bg-foreground/20 text-foreground"
            : "bg-muted hover:bg-muted/80 text-foreground"
        )}
      >
        {isLoading ? (
          <div className="w-4 h-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
        ) : isPlaying ? (
          <Pause className="w-4 h-4 fill-current" />
        ) : (
          <Play className="w-4 h-4 fill-current ml-0.5" />
        )}
      </Button>

      {/* Waveform and Time */}
      <div className="flex-1 flex flex-col gap-2 items-center justify-center">
        {/* Waveform visualization */}
        <div 
          className="flex items-center justify-center gap-[2px] h-6 cursor-pointer w-full"
          onClick={handleWaveformClick}
          ref={waveformRef}
        >
          {waveformData.map((height, i) => {
            const waveHeight = 6 + height * 18;
            const isActive = progress > (i / bars) * 100;
            return (
              <div
                key={i}
                className={cn(
                  "w-[3px] rounded-full transition-all duration-150",
                  isActive
                    ? "bg-primary"
                    : "bg-muted-foreground/30"
                )}
                style={{ height: `${waveHeight}px` }}
              />
            );
          })}
        </div>
        
        {/* Time display */}
        <div className="flex justify-between w-full text-xs text-muted-foreground">
          <span>{formatTime(currentTime)}</span>
          <span>{formatTime(audioDuration)}</span>
        </div>
      </div>
    </div>
  );
};

export default VoiceMessagePlayer;