
import React from 'react';
import { Button } from '@/components/ui/button';
import { X, Reply, Mic } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ReplyInputProps {
  replyingTo: any;
  onCancelReply: () => void;
  senderName?: string;
}

const ReplyInput: React.FC<ReplyInputProps> = ({ replyingTo, onCancelReply, senderName }) => {
  return (
    <div className="bg-green-50 border border-green-200 p-3 rounded-lg mb-3">
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <Reply className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-green-800">
              Replying to {senderName || 'User'}
            </span>
          </div>
          {replyingTo.is_voice_message ? (
            <div className="flex items-center gap-2 text-green-700">
              <Mic className="w-3 h-3" />
              <span className="text-sm">Voice message</span>
            </div>
          ) : (
            <p className="text-sm text-green-700 truncate">
              {replyingTo.content}
            </p>
          )}
        </div>
        <Button
          onClick={onCancelReply}
          size="sm"
          variant="ghost"
          className="p-1 h-6 w-6 text-green-600 hover:bg-green-100"
        >
          <X className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};

export default ReplyInput;
