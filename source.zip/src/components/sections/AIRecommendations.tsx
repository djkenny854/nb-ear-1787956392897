import React from 'react';
import { Sparkles, ArrowRight } from 'lucide-react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import ListingCard from '@/components/cards/ListingCard';
import { mockListings } from '@/data/mockData';

interface AIRecommendationsProps {
  category?: string;
  onExplore?: () => void;
}

const AIRecommendations: React.FC<AIRecommendationsProps> = ({ 
  category = 'Electronics',
  onExplore 
}) => {
  const recommendations = mockListings.filter(
    (item) => item.category === category
  ).slice(0, 4);

  return (
    <motion.section
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="py-4"
    >
      {/* AI Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-primary/20 via-primary/10 to-accent/20 p-5 mb-4">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiM5Qzk0QjAiIGZpbGwtb3BhY2l0eT0iMC4xIj48cGF0aCBkPSJNMzYgMzRoLTJ2LTRoMnY0em0wLTZ2LTRoLTJ2NGgyek0zNCAzNmgydjRoLTJ2LTR6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-50" />
        
        <div className="relative flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center flex-shrink-0">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          
          <div className="flex-1">
            <h3 className="font-bold text-foreground">Smart AI Suggestion</h3>
            <p className="text-sm text-muted-foreground mt-1">
              We noticed you've been viewing <span className="font-semibold text-primary">{category}</span> — here are our top picks for you.
            </p>
            
            <Button 
              variant="ghost" 
              size="sm" 
              className="mt-2 p-0 h-auto text-primary hover:text-primary/80"
              onClick={onExplore}
            >
              Explore more <ArrowRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>

      {/* Recommendations */}
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4">
        {recommendations.map((listing) => (
          <div key={listing.id} style={{ scrollSnapAlign: 'start' }}>
            <ListingCard listing={listing} />
          </div>
        ))}
      </div>
    </motion.section>
  );
};

export default AIRecommendations;
