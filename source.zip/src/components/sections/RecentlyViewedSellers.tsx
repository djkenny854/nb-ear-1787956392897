import React from 'react';
import { Clock } from 'lucide-react';
import ContentCarousel from './ContentCarousel';
import SellerCardCompact from '@/components/cards/SellerCardCompact';
import { mockSellers } from '@/data/mockData';

interface RecentlyViewedSellersProps {
  onSeeAll?: () => void;
}

const RecentlyViewedSellers: React.FC<RecentlyViewedSellersProps> = ({ onSeeAll }) => {
  return (
    <ContentCarousel
      title="Recently Viewed Sellers"
      subtitle="Shops you've checked out"
      icon={<Clock className="w-5 h-5" />}
      onSeeAll={onSeeAll}
    >
      {mockSellers.map((seller) => (
        <div key={seller.id} style={{ scrollSnapAlign: 'start' }}>
          <SellerCardCompact seller={seller} />
        </div>
      ))}
    </ContentCarousel>
  );
};

export default RecentlyViewedSellers;
