import React from 'react';
import { Layers } from 'lucide-react';
import ContentCarousel from './ContentCarousel';
import CollectionCard from '@/components/cards/CollectionCard';
import { mockCollections } from '@/data/mockData';

interface CuratedCollectionsProps {
  onSeeAll?: () => void;
}

const CuratedCollections: React.FC<CuratedCollectionsProps> = ({ onSeeAll }) => {
  return (
    <ContentCarousel
      title="EarlyMarket Collections"
      subtitle="Curated picks just for you"
      icon={<Layers className="w-5 h-5" />}
      onSeeAll={onSeeAll}
    >
      {mockCollections.map((collection) => (
        <div key={collection.id} style={{ scrollSnapAlign: 'start' }}>
          <CollectionCard collection={collection} />
        </div>
      ))}
    </ContentCarousel>
  );
};

export default CuratedCollections;
