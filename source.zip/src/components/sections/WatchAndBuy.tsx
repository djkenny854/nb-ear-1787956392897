import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Play, MoreVertical } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import SmartVideo from '@/components/media/SmartVideo';
import GoogleSpinner from '@/components/common/GoogleSpinner';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { cn } from '@/lib/utils';
import { prepareVideoPreview } from '@/utils/videoPrefetch';
import RailScroller from '@/components/common/RailScroller';

interface VideoAd {
  id: string;
  title: string;
  price: number | null;
  images: string[] | null;
  b2_video_url: string | null;
  video_thumbnail_url: string | null;
  listing_type: string | null;
  seller_profiles?: {
    business_name: string | null;
    business_logo_url: string | null;
  } | null;
}

const MAX_ITEMS = 8;
const CLIP_MS = 3000;

const fmtDuration = (secs: number) => {
  if (!isFinite(secs) || secs <= 0) return null;
  const m = Math.floor(secs / 60);
  const s = Math.floor(secs % 60);
  return `${m}:${s.toString().padStart(2, '0')}`;
};

const CardSkeleton = () => (
  <div className="w-[168px] md:w-[190px] shrink-0">
    <div className="aspect-[3/4] rounded-2xl skeleton-shimmer" />
    <div className="mt-2.5 h-3.5 w-full rounded skeleton-shimmer" />
    <div className="mt-1.5 h-3.5 w-3/4 rounded skeleton-shimmer" />
    <div className="mt-2.5 flex items-center gap-2">
      <div className="h-5 w-5 rounded-full skeleton-shimmer" />
      <div className="h-3 w-20 rounded skeleton-shimmer" />
    </div>
  </div>
);

const VideoCard: React.FC<{
  item: VideoAd;
  active: boolean;
  prepared: boolean;
  onClick: () => void;
}> = ({ item, active, prepared, onClick }) => {
  const [ready, setReady] = useState(false);
  const [duration, setDuration] = useState<number | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const owner = item.seller_profiles?.business_name || 'EarlyMarket seller';
  const poster = item.video_thumbnail_url || item.images?.[0] || null;

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (active && prepared) {
      try {
        v.currentTime = 0;
        v.play().catch(() => {});
      } catch {
        /* noop */
      }
    } else {
      try {
        v.pause();
      } catch {
        /* noop */
      }
    }
  }, [active, prepared]);

  // Read the intrinsic duration once metadata lands.
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const read = () => setDuration(v.duration);
    v.addEventListener('loadedmetadata', read);
    if (v.readyState >= 1) read();
    return () => v.removeEventListener('loadedmetadata', read);
  }, [ready]);

  const durationLabel = duration ? fmtDuration(duration) : null;

  return (
    <div className="w-[168px] md:w-[190px] shrink-0 snap-start">
      <button
        type="button"
        onClick={onClick}
        className="block w-full text-left group"
      >
        <div
          className={cn(
            'relative aspect-[3/4] rounded-2xl overflow-hidden bg-muted border border-border/40',
            prepared && active && !ready && 'video-loading-border'
          )}
        >
          {!poster && !ready && (
            <div className="absolute inset-0 z-[2] flex items-center justify-center">
              <GoogleSpinner size={22} />
            </div>
          )}
          <SmartVideo
            ref={videoRef}
            src={item.b2_video_url}
            poster={poster}
            wrapped
            className="w-full h-full"
            muted
            loop
            playsInline
            onReady={() => setReady(true)}
            style={{ objectFit: 'cover' }}
          />

          {/* Duration pill — play glyph + time, like the reference rail */}
          <span className="absolute bottom-2 left-2 z-[3] inline-flex items-center gap-1 rounded-full bg-black/75 pl-1.5 pr-2 py-1 backdrop-blur-sm">
            <Play className="w-3 h-3 text-white" fill="currentColor" strokeWidth={0} />
            {durationLabel && (
              <span className="text-[11px] font-semibold text-white tabular-nums leading-none">
                {durationLabel}
              </span>
            )}
          </span>

        </div>
      </button>

      {/* Title */}
      <button type="button" onClick={onClick} className="block w-full text-left">
        <p className="mt-2.5 text-[13.5px] leading-[1.35] font-medium text-foreground line-clamp-2">
          {item.title}
        </p>
      </button>

      {/* Owner row */}
      <div className="mt-2 flex items-center gap-1.5">
        <Avatar className="w-5 h-5 shrink-0">
          <AvatarImage src={item.seller_profiles?.business_logo_url || undefined} alt="" />
          <AvatarFallback className="text-[9px] bg-muted text-muted-foreground">
            {owner.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <span className="text-[12px] text-muted-foreground truncate flex-1">{owner}</span>
        <MoreVertical className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
      </div>
    </div>
  );
};

/** Watch & buy — one 3-second clip plays at a time, auto-advancing across the rail. */
const WatchAndBuy: React.FC = () => {
  const navigate = useNavigate();
  const railRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const [page, setPage] = useState(0);
  const [preparedIds, setPreparedIds] = useState<Set<string>>(new Set());
  // Manual scrolling always wins over the auto-advance animation.
  const [userActive, setUserActive] = useState(false);
  const [railInView, setRailInView] = useState(true);
  const idleTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const autoScrollingRef = useRef(false);

  const markUserActive = useCallback(() => {
    setUserActive(true);
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    idleTimerRef.current = setTimeout(() => setUserActive(false), 6000);
  }, []);

  useEffect(() => () => { if (idleTimerRef.current) clearTimeout(idleTimerRef.current); }, []);

  // Pause the rotation entirely when the rail is off-screen.
  useEffect(() => {
    const rail = railRef.current;
    if (!rail) return;
    const obs = new IntersectionObserver(([e]) => setRailInView(e.isIntersecting), {
      threshold: 0.25,
    });
    obs.observe(rail);
    return () => obs.disconnect();
  }, []);

  const { data, isLoading } = useQuery({
    queryKey: ['home-watch-and-buy'],
    staleTime: 5 * 60 * 1000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select(
          'id, title, price, images, b2_video_url, video_thumbnail_url, listing_type, seller_profiles(business_name, business_logo_url)'
        )
        .eq('status', 'active')
        .not('b2_video_url', 'is', null)
        .order('created_at', { ascending: false })
        .limit(MAX_ITEMS);
      if (error) throw error;
      return (data || []) as unknown as VideoAd[];
    },
  });

  const items = useMemo(
    () => (data || []).filter((i) => i.b2_video_url).slice(0, MAX_ITEMS),
    [data]
  );

  // Warm a bounded opening range for every card. Rotation waits for the
  // complete rail to be prepared, while full media remains lazy and only the
  // active card is asked to play.
  useEffect(() => {
    let cancelled = false;
    setPreparedIds(new Set());
    if (!items.length) return () => { cancelled = true; };

    Promise.all(items.map(async (item) => {
      await prepareVideoPreview(item.b2_video_url);
      if (!cancelled) {
        setPreparedIds((current) => {
          const next = new Set(current);
          next.add(item.id);
          return next;
        });
      }
    })).catch(() => {});

    return () => { cancelled = true; };
  }, [items]);

  const allPrepared = items.length > 0 && items.every((item) => preparedIds.has(item.id));

  // Round-robin: play each clip for 3s, then move to the next card.
  useEffect(() => {
    if (items.length < 2 || !allPrepared || userActive || !railInView) return;
    const t = setInterval(() => {
      setActiveIndex((i) => (i + 1) % items.length);
    }, CLIP_MS);
    return () => clearInterval(t);
  }, [items.length, allPrepared, userActive, railInView]);

  // Keep the playing card in view — never while the user is scrolling.
  useEffect(() => {
    const rail = railRef.current;
    if (!rail || userActive) return;
    const child = rail.children[activeIndex] as HTMLElement | undefined;
    if (!child) return;
    const railBox = rail.getBoundingClientRect();
    const childBox = child.getBoundingClientRect();
    if (childBox.right > railBox.right - 8 || childBox.left < railBox.left + 8) {
      autoScrollingRef.current = true;
      rail.scrollTo({ left: child.offsetLeft - 8, behavior: 'smooth' });
      setTimeout(() => { autoScrollingRef.current = false; }, 600);
    }
  }, [activeIndex, userActive]);

  // Dots reflect scroll pages of the rail.
  const pageCount = useMemo(() => {
    const rail = railRef.current;
    if (!rail || items.length === 0) return Math.min(4, Math.ceil(items.length / 2));
    return Math.max(1, Math.ceil(rail.scrollWidth / Math.max(1, rail.clientWidth)));
  }, [items.length]);

  const onRailScroll = useCallback(() => {
    const rail = railRef.current;
    if (!rail) return;
    setPage(Math.round(rail.scrollLeft / Math.max(1, rail.clientWidth)));
  }, []);

  if (!isLoading && items.length === 0) return null;

  return (
    <section className="py-4">
      <div className="flex items-end justify-between mb-3 px-1">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-foreground">Short videos</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Short clips from sellers — tap to open</p>
        </div>
      </div>

      <RailScroller>
      <div
        ref={railRef}
        onScroll={onRailScroll}
        onPointerDown={markUserActive}
        onTouchStart={markUserActive}
        onWheel={markUserActive}
        className="flex gap-3.5 overflow-x-auto scrollbar-hide pb-1 -mx-4 px-4 snap-x"
      >
        {isLoading
          ? Array.from({ length: 5 }).map((_, i) => <CardSkeleton key={i} />)
          : items.map((item, i) => (
              <VideoCard
                key={item.id}
                item={item}
                active={allPrepared && i === activeIndex && railInView}
                prepared={preparedIds.has(item.id)}
                onClick={() => navigate(`/ad/${item.id}`)}
              />
            ))}
      </div>
      </RailScroller>

      {/* Pagination dots */}
      {!isLoading && pageCount > 1 && (
        <div className="mt-3 flex items-center justify-center gap-1.5">
          {Array.from({ length: pageCount }).map((_, i) => (
            <span
              key={i}
              className={cn(
                'h-1.5 rounded-full transition-all duration-300',
                i === page ? 'w-5 bg-foreground/70' : 'w-1.5 bg-muted-foreground/35'
              )}
            />
          ))}
        </div>
      )}
    </section>
  );
};

export default WatchAndBuy;
