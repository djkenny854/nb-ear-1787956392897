import React from 'react';
import { ChevronRight, Pin, Percent, Store } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import RailScroller from '@/components/common/RailScroller';

interface ProductItem {
  id: string;
  title: string;
  price: number;
  images: string[];
  seller_id: string;
  seller_name: string;
  is_pinned?: boolean;
  has_discount?: boolean;
  original_price?: number;
}

interface PersonalizedFeedSectionsProps {
  pinnedProducts: ProductItem[];
  discountedProducts: ProductItem[];
  sellerProducts?: {
    seller_id: string;
    seller_name: string;
    seller_logo?: string;
    products: ProductItem[];
  };
}

const HorizontalProductCard: React.FC<{ product: ProductItem; showDiscount?: boolean }> = ({ 
  product, 
  showDiscount 
}) => {
  const navigate = useNavigate();
  
  return (
    <div 
      onClick={() => navigate(`/ad/${product.id}`)}
      className="flex-shrink-0 w-36 cursor-pointer group"
    >
      <div className="relative aspect-square rounded-xl overflow-hidden mb-2 bg-muted">
        {product.images?.[0] ? (
          <img 
            src={product.images[0]} 
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <Store className="w-8 h-8" />
          </div>
        )}
        {showDiscount && product.original_price && (
          <Badge className="absolute top-2 left-2 bg-red-500 text-white text-[10px] px-1.5 py-0.5">
            {Math.round(((product.original_price - product.price) / product.original_price) * 100)}% OFF
          </Badge>
        )}
        {product.is_pinned && (
          <div className="absolute top-2 right-2 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
            <Pin className="w-3 h-3 text-primary-foreground" />
          </div>
        )}
      </div>
      <p className="text-xs font-medium text-foreground line-clamp-1">{product.title}</p>
      <div className="flex items-center gap-1">
        <span className="text-xs font-bold text-primary">{(localStorage.getItem('app_currency') || 'UGX')} {product.price?.toLocaleString()}</span>
        {showDiscount && product.original_price && (
          <span className="text-[10px] text-muted-foreground line-through">
            {product.original_price.toLocaleString()}
          </span>
        )}
      </div>
    </div>
  );
};

export const PinnedProductsSection: React.FC<{ products: ProductItem[] }> = ({ products }) => {
  const navigate = useNavigate();
  
  // Hide when seller has no other listings (or only the one being viewed)
  if (!products || products.length < 2) return null;

  return (
    <div className="bg-card md:rounded-2xl shadow-sm border-x-0 md:border border-y border-border px-3 py-4 md:p-4 md:mb-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Pin className="w-4 h-4 text-primary" />
          <h3 className="font-semibold text-sm text-foreground">Pinned Products</h3>
        </div>
        <button 
          onClick={() => navigate('/search?filter=pinned')}
          className="text-xs text-primary flex items-center gap-0.5"
        >
          See all <ChevronRight className="w-3 h-3" />
        </button>
      </div>
      <RailScroller>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-3 px-3">
        {products.map((product) => (
          <HorizontalProductCard key={product.id} product={product} />
        ))}
      </div>
      </RailScroller>
    </div>
  );
};

export const DiscountedProductsSection: React.FC<{ products: ProductItem[] }> = ({ products }) => {
  const navigate = useNavigate();
  
  if (!products || products.length === 0) return null;

  return (
    <div className="bg-card md:rounded-2xl shadow-sm border-x-0 md:border border-y border-border px-3 py-4 md:p-4 md:mb-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Percent className="w-4 h-4 text-red-500" />
          <h3 className="font-semibold text-sm text-foreground">Hot Deals</h3>
        </div>
        <button 
          onClick={() => navigate('/search?filter=discounts')}
          className="text-xs text-primary flex items-center gap-0.5"
        >
          See all <ChevronRight className="w-3 h-3" />
        </button>
      </div>
      <RailScroller>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-3 px-3">
        {products.map((product) => (
          <HorizontalProductCard key={product.id} product={product} showDiscount />
        ))}
      </div>
      </RailScroller>
    </div>
  );
};

export const MoreFromSellerSection: React.FC<{ 
  seller_id: string;
  seller_name: string;
  seller_logo?: string;
  products: ProductItem[];
}> = ({ seller_id, seller_name, seller_logo, products }) => {
  const navigate = useNavigate();
  
  if (!products || products.length === 0) return null;

  return (
    <div className="bg-card md:rounded-2xl shadow-sm border-x-0 md:border border-y border-border px-3 py-4 md:p-4 md:mb-4">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          {seller_logo ? (
            <img src={seller_logo} alt={seller_name} className="w-6 h-6 rounded-full object-cover" />
          ) : (
            <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center">
              <Store className="w-3 h-3 text-primary" />
            </div>
          )}
          <h3 className="font-semibold text-sm text-foreground">More from {seller_name}</h3>
        </div>
        <button 
          onClick={() => navigate(`/business/${seller_id}`)}
          className="text-xs text-primary flex items-center gap-0.5"
        >
          View store <ChevronRight className="w-3 h-3" />
        </button>
      </div>
      <RailScroller>
      <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide -mx-3 px-3">
        {products.map((product) => (
          <HorizontalProductCard 
            key={product.id} 
            product={product} 
            showDiscount={product.has_discount} 
          />
        ))}
      </div>
      </RailScroller>
    </div>
  );
};

const PersonalizedFeedSections: React.FC<PersonalizedFeedSectionsProps> = ({
  pinnedProducts,
  discountedProducts,
  sellerProducts
}) => {
  return (
    <>
      {pinnedProducts.length > 0 && <PinnedProductsSection products={pinnedProducts} />}
      {discountedProducts.length > 0 && <DiscountedProductsSection products={discountedProducts} />}
      {sellerProducts && sellerProducts.products.length > 0 && (
        <MoreFromSellerSection {...sellerProducts} />
      )}
    </>
  );
};

export default PersonalizedFeedSections;
