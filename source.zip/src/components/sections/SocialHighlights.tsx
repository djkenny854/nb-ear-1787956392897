import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { CheckCircle2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import SmartVideo from '@/components/media/SmartVideo';
import GoogleSpinner from '@/components/common/GoogleSpinner';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface FeedPost {
  id: string;
  title: string | null;
  content: string | null;
  images: string[] | null;
  video_url: string | null;
  video_thumbnail_url: string | null;
  created_at: string;
  seller_profiles?: {
    business_name?: string | null;
    business_logo_url?: string | null;
    is_verified?: boolean | null;
  } | null;
}

const formatDate = (iso: string) => {
  const d = new Date(iso);
  const now = Date.now();
  const diff = now - d.getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${Math.max(1, mins)}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
};

const PostThumb: React.FC<{ post: FeedPost }> = ({ post }) => {
  const image = post.images?.find(Boolean);
  const [ready, setReady] = useState(false);

  if (image) {
    return (
      <div className="relative w-[88px] h-[88px] md:w-[104px] md:h-[104px] shrink-0 rounded-2xl overflow-hidden bg-muted">
        <img
          src={image}
          alt={post.title || 'Post image'}
          loading="lazy"
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  if (post.video_url) {
    return (
      <div className="relative w-[88px] h-[88px] md:w-[104px] md:h-[104px] shrink-0 rounded-2xl overflow-hidden bg-muted">
        {!ready && (
          <div className="absolute inset-0 z-[1] flex items-center justify-center">
            <GoogleSpinner size={20} />
          </div>
        )}
        <SmartVideo
          src={post.video_url}
          poster={post.video_thumbnail_url}
          wrapped
          className="w-full h-full"
          muted
          loop
          autoPlayInView
          inViewThreshold={0.5}
          onReady={() => setReady(true)}
          onTimeUpdate={(e) => {
            const v = e.currentTarget;
            // 3-second looping preview keeps the homepage light.
            if (v.currentTime > 3) v.currentTime = 0;
          }}
          style={{ objectFit: 'cover' }}
        />
      </div>
    );
  }

  return null;
};

const HighlightRow: React.FC<{ post: FeedPost; onClick: () => void }> = ({ post, onClick }) => {
  const author = post.seller_profiles?.business_name || 'EarlyMarket';
  const body = (post.content || '').replace(/\s+/g, ' ').trim();
  return (
    <button
      type="button"
      onClick={onClick}
      className="group w-full text-left flex items-start gap-4 py-4 first:pt-0 last:pb-0 border-b border-border/60 last:border-b-0"
    >
      <div className="min-w-0 flex-1">
        <h3 className="text-[15px] md:text-base font-semibold text-foreground leading-snug line-clamp-2 group-hover:underline decoration-border underline-offset-2">
          {post.title || body.slice(0, 70) || 'Post'}
        </h3>
        <p className="mt-1 text-[13px] text-muted-foreground line-clamp-2">
          <span className="text-foreground/70">{formatDate(post.created_at)}</span>
          {body ? <span> · {body}</span> : null}
        </p>
        <div className="mt-2 flex items-center gap-1.5">
          {post.seller_profiles?.business_logo_url ? (
            <img
              src={post.seller_profiles.business_logo_url}
              alt=""
              className="w-4 h-4 rounded-full object-cover"
            />
          ) : (
            <span className="w-4 h-4 rounded-full bg-muted" />
          )}
          <span className="text-[12px] text-muted-foreground truncate max-w-[160px]">{author}</span>
          {post.seller_profiles?.is_verified && (
            <CheckCircle2 className="w-3 h-3 text-primary shrink-0" />
          )}
        </div>
      </div>
      <PostThumb post={post} />
    </button>
  );
};

const RowSkeleton = () => (
  <div className="flex items-start gap-4 py-4 border-b border-border/60 last:border-b-0">
    <div className="flex-1 space-y-2">
      <div className="h-4 w-[85%] rounded skeleton-shimmer" />
      <div className="h-3 w-[60%] rounded skeleton-shimmer" />
      <div className="h-3 w-[40%] rounded skeleton-shimmer" />
    </div>
    <div className="w-[88px] h-[88px] md:w-[104px] md:h-[104px] rounded-2xl skeleton-shimmer" />
  </div>
);

/**
 * Homepage "From the feed" — editorial list of social posts only.
 * 3 items on mobile (with Show all), up to 6 in a 2-column grid on desktop.
 */
const SocialHighlights: React.FC = () => {
  const navigate = useNavigate();

  const { data, isLoading } = useQuery({
    queryKey: ['home-social-highlights'],
    staleTime: 2 * 60 * 1000,
    queryFn: async () => {
      const { data, error } = await supabase
        .from('posts')
        .select(
          'id, title, content, images, video_url, video_thumbnail_url, created_at, visibility, seller_profiles(business_name, business_logo_url, is_verified)'
        )
        .eq('is_active', true)
        .eq('visibility', 'everyone')
        .order('created_at', { ascending: false })
        .limit(8);
      if (error) throw error;
      return (data || []) as unknown as FeedPost[];
    },
  });

  const posts = useMemo(() => (data || []).slice(0, 6), [data]);

  if (!isLoading && posts.length === 0) return null;

  return (
    <section className="py-4">
      <div className="flex items-end justify-between mb-3 px-1">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-foreground">From the feed</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Latest posts from businesses on EarlyMarket</p>
        </div>
      </div>

      <div className="rounded-2xl border border-border/60 bg-card/40 px-4 md:px-5 py-4">
        {isLoading ? (
          <div>
            {Array.from({ length: 3 }).map((_, i) => (
              <RowSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className={cn('md:grid md:grid-cols-2 md:gap-x-8')}>
            {posts.map((post, i) => (
              <div key={post.id} className={cn(i > 2 && 'hidden md:block')}>
                <HighlightRow post={post} onClick={() => navigate(`/post/${post.id}`)} />
              </div>
            ))}
          </div>
        )}

        <div className="pt-4 flex justify-center">
          <Button
            variant="outline"
            size="sm"
            className="rounded-full px-5 text-xs font-semibold"
            onClick={() => navigate('/discover?tab=foryou')}
          >
            Show all
          </Button>
        </div>
      </div>
    </section>
  );
};

export default SocialHighlights;
