import React, { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Bookmark, History } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useCurrency } from '@/contexts/CurrencyContext';
import { cn } from '@/lib/utils';
import RailScroller from '@/components/common/RailScroller';

interface ItemRow {
  id: string;
  title: string;
  price: number | null;
  images: string[] | null;
  listing_type: string | null;
  location: string | null;
}

type Tagged = ItemRow & { bookmarked: boolean };

const routeFor = (item: ItemRow) => {
  switch (item.listing_type) {
    case 'jobs':
      return `/job/${item.id}`;
    case 'services':
      return `/service/${item.id}`;
    case 'promotions':
      return `/promotion/${item.id}`;
    case 'digital_products':
      return `/digital/${item.id}`;
    default:
      return `/ad/${item.id}`;
  }
};

const CardSkeleton = () => (
  <div className="w-[150px] shrink-0">
    <div className="aspect-square rounded-xl skeleton-shimmer" />
    <div className="mt-2 h-3 w-full rounded skeleton-shimmer" />
    <div className="mt-1.5 h-3 w-16 rounded skeleton-shimmer" />
  </div>
);

/** "Continue viewing" — recently viewed listings + bookmarked items with labels. */
const ContinueViewing: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { formatPriceCompact } = useCurrency();

  const { data, isLoading } = useQuery({
    queryKey: ['home-continue-viewing', user?.id],
    enabled: Boolean(user?.id),
    staleTime: 60 * 1000,
    queryFn: async () => {
      const [viewsRes, bookmarksRes] = await Promise.all([
        supabase
          .from('content_views')
          .select('content_id, content_type, created_at')
          .eq('user_id', user!.id)
          .in('content_type', ['ad', 'service'])
          .order('created_at', { ascending: false })
          .limit(40),
        supabase
          .from('bookmarks')
          .select('item_id, created_at')
          .eq('user_id', user!.id)
          .order('created_at', { ascending: false })
          .limit(20),
      ]);

      const bookmarkedIds = (bookmarksRes.data || []).map((b: any) => b.item_id as string);
      const viewedIds = Array.from(
        new Set((viewsRes.data || []).map((v: any) => v.content_id as string))
      );

      const ids = Array.from(new Set([...bookmarkedIds, ...viewedIds])).slice(0, 24);
      if (ids.length === 0) return { items: [] as Tagged[] };

      const { data: ads } = await supabase
        .from('ads')
        .select('id, title, price, images, listing_type, location')
        .in('id', ids)
        .eq('status', 'active');

      const byId = new Map<string, ItemRow>();
      for (const ad of (ads || []) as ItemRow[]) byId.set(ad.id, ad);

      // Bookmarked first (they carry a label), then recently viewed order.
      const ordered: Tagged[] = [];
      for (const id of bookmarkedIds) {
        const it = byId.get(id);
        if (it) ordered.push({ ...it, bookmarked: true });
      }
      for (const id of viewedIds) {
        if (ordered.some((o) => o.id === id)) continue;
        const it = byId.get(id);
        if (it) ordered.push({ ...it, bookmarked: false });
      }
      return { items: ordered.slice(0, 12) };
    },
  });

  const items = useMemo(() => data?.items || [], [data]);

  if (!user) return null;
  if (!isLoading && items.length === 0) return null;

  return (
    <section className="py-4">
      <div className="flex items-end justify-between mb-3 px-1">
        <div>
          <h2 className="text-lg md:text-xl font-bold text-foreground">Continue viewing</h2>
          <p className="text-xs text-muted-foreground mt-0.5">Picked up from where you left off</p>
        </div>
      </div>

      <RailScroller>
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4 snap-x">
        {isLoading
          ? Array.from({ length: 5 }).map((_, i) => <CardSkeleton key={i} />)
          : items.map((item) => (
              <button
                key={item.id}
                onClick={() => navigate(routeFor(item))}
                className="w-[150px] shrink-0 text-left group snap-start"
              >
                <div className="relative aspect-square rounded-xl overflow-hidden bg-muted border border-border/40">
                  {item.images?.[0] ? (
                    <img
                      src={item.images[0]}
                      alt={item.title}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="w-full h-full" />
                  )}
                  <span
                    className={cn(
                      'absolute top-1.5 left-1.5 inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[9px] font-semibold backdrop-blur-sm',
                      item.bookmarked
                        ? 'bg-primary/90 text-primary-foreground'
                        : 'bg-background/85 text-foreground'
                    )}
                  >
                    {item.bookmarked ? (
                      <>
                        <Bookmark className="w-2.5 h-2.5" /> You bookmarked
                      </>
                    ) : (
                      <>
                        <History className="w-2.5 h-2.5" /> Recently viewed
                      </>
                    )}
                  </span>
                </div>
                <p className="mt-2 text-[12px] font-medium text-foreground line-clamp-1">{item.title}</p>
                {item.price ? (
                  <p className="text-[12px] font-bold text-primary">{formatPriceCompact(item.price)}</p>
                ) : (
                  <p className="text-[11px] text-muted-foreground line-clamp-1">{item.location}</p>
                )}
              </button>
            ))}
      </div>
      </RailScroller>
    </section>
  );
};

export default ContinueViewing;
