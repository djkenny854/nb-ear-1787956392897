import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { ChevronDown, AreaChart as AreaChartIcon, GitCompare, Activity, ArrowUp, ArrowDown } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

type MetricKey = 'growth' | 'joins' | 'visits';
type Granularity = 'daily' | 'weekly' | 'cumulative';
type RangeKey = '1D' | '5D' | '1M' | '6M' | 'YTD' | '1Y' | 'MAX';

const METRICS: { key: MetricKey; label: string; hint: string }[] = [
  { key: 'growth', label: 'Business growth', hint: 'New business workspaces' },
  { key: 'joins', label: 'Joins', hint: 'New people on EarlyMarket' },
  { key: 'visits', label: 'Profile visits', hint: 'Visits to seller profiles' },
];

const GRANULARITY: { key: Granularity; label: string }[] = [
  { key: 'daily', label: 'Daily' },
  { key: 'weekly', label: 'Rolling 7-day' },
  { key: 'cumulative', label: 'Cumulative' },
];

const RANGES: { key: RangeKey; days: number }[] = [
  { key: '1D', days: 1 },
  { key: '5D', days: 5 },
  { key: '1M', days: 30 },
  { key: '6M', days: 180 },
  { key: 'YTD', days: Math.max(1, Math.ceil((Date.now() - new Date(new Date().getFullYear(), 0, 1).getTime()) / 86400000)) },
  { key: '1Y', days: 365 },
  { key: 'MAX', days: 730 },
];

interface Row {
  created_at: string;
}
interface ViewRow extends Row {
  content_type: string;
  source_page: string;
  content_id: string;
}
interface AdRow {
  id: string;
  category: string | null;
  created_at: string;
  view_count: number | null;
}

const dayKey = (d: Date) => d.toISOString().slice(0, 10);

function buildBuckets(days: number) {
  const out: { key: string; date: Date }[] = [];
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(today);
    d.setDate(d.getDate() - i);
    out.push({ key: dayKey(d), date: d });
  }
  return out;
}

/** Trading-terminal style line chart: axis labels, gridlines, prev-close marker. */
const TerminalChart: React.FC<{
  values: number[];
  overlay?: number[] | null;
  labels: string[];
  baseline: number;
}> = ({ values, overlay, labels, baseline }) => {
  const [hover, setHover] = useState<number | null>(null);
  const w = 900;
  const h = 320;
  const pad = { top: 18, right: 16, bottom: 8, left: 62 };
  const all = [...values, ...(overlay || []), baseline];
  const rawMax = Math.max(...all);
  const rawMin = Math.min(...all);
  const span = Math.max(1, rawMax - rawMin);
  const max = rawMax + span * 0.12;
  const min = Math.max(0, rawMin - span * 0.12);
  const innerW = w - pad.left - pad.right;
  const innerH = h - pad.top - pad.bottom;
  const x = (i: number) =>
    pad.left + (values.length <= 1 ? innerW / 2 : (i / (values.length - 1)) * innerW);
  const y = (v: number) => pad.top + innerH - ((v - min) / Math.max(1e-6, max - min)) * innerH;

  const line = (arr: number[]) => arr.map((v, i) => `${i === 0 ? 'M' : 'L'}${x(i)},${y(v)}`).join(' ');

  // Five evenly spaced value ticks.
  const ticks = Array.from({ length: 5 }, (_, i) => min + ((max - min) / 4) * i).reverse();
  // Three vertical gridlines with time labels.
  const vLines = [0.25, 0.5, 0.75];
  const last = values[values.length - 1] ?? 0;

  return (
    <div className="relative">
      <svg
        viewBox={`0 0 ${w} ${h}`}
        className="w-full h-[240px] md:h-[300px]"
        onMouseLeave={() => setHover(null)}
        onMouseMove={(e) => {
          const rect = e.currentTarget.getBoundingClientRect();
          const rel = ((e.clientX - rect.left) / rect.width - pad.left / w) / (innerW / w);
          const idx = Math.round(rel * (values.length - 1));
          setHover(Math.min(values.length - 1, Math.max(0, idx)));
        }}
      >
        {/* Y-axis ticks */}
        {ticks.map((t, i) => {
          const ty = pad.top + (innerH / 4) * i;
          const label = Math.round(t).toLocaleString();
          // Skip duplicated labels on very small integer ranges.
          if (i > 0 && Math.round(ticks[i - 1]).toLocaleString() === label) return null;
          return (
            <text
              key={i}
              x={pad.left - 12}
              y={ty + 4}
              textAnchor="end"
              className="fill-muted-foreground"
              style={{ fontSize: 12 }}
            >
              {label}
            </text>
          );
        })}


        {/* Vertical gridlines */}
        {vLines.map((t) => (
          <line
            key={t}
            x1={pad.left + innerW * t}
            x2={pad.left + innerW * t}
            y1={pad.top}
            y2={pad.top + innerH}
            stroke="hsl(var(--border))"
            strokeWidth="1"
            opacity="0.6"
          />
        ))}

        {/* Baseline (previous period) */}
        <line
          x1={pad.left}
          x2={w - pad.right}
          y1={y(baseline)}
          y2={y(baseline)}
          stroke="hsl(var(--muted-foreground))"
          strokeWidth="1"
          strokeDasharray="4 4"
          opacity="0.5"
        />

        {/* Overlay comparison */}
        {overlay && (
          <path
            d={line(overlay)}
            fill="none"
            stroke="hsl(var(--muted-foreground))"
            strokeWidth="1.5"
            strokeDasharray="5 4"
            vectorEffect="non-scaling-stroke"
          />
        )}

        {/* Main series */}
        <path
          d={line(values)}
          fill="none"
          stroke="hsl(142 70% 55%)"
          strokeWidth="2"
          strokeLinejoin="round"
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
        />

        {/* End marker */}
        <circle cx={x(values.length - 1)} cy={y(last)} r="4.5" fill="hsl(142 70% 55%)" />

        {hover !== null && (
          <>
            <line
              x1={x(hover)}
              x2={x(hover)}
              y1={pad.top}
              y2={pad.top + innerH}
              stroke="hsl(var(--foreground))"
              strokeWidth="1"
              opacity="0.4"
            />
            <circle cx={x(hover)} cy={y(values[hover])} r="4" fill="hsl(142 70% 55%)" />
          </>
        )}
      </svg>

      {/* Prev-close annotation */}
      <div className="pointer-events-none absolute right-2 bottom-14 text-[11px] text-muted-foreground">
        Prev period <span className="font-semibold text-foreground">{Math.round(baseline).toLocaleString()}</span>
      </div>

      {/* X-axis time labels */}
      <div className="flex justify-between pl-[7%] pr-2 -mt-1 text-[11px] text-muted-foreground">
        <span>{labels[0]}</span>
        <span>{labels[Math.floor(labels.length * 0.33)]}</span>
        <span>{labels[Math.floor(labels.length * 0.66)]}</span>
        <span>{labels[labels.length - 1]}</span>
      </div>

      {hover !== null && (
        <div className="absolute top-0 right-0 rounded-lg border border-border bg-popover px-2.5 py-1.5 text-[11px] shadow-sm">
          <div className="font-semibold text-foreground tabular-nums">{values[hover].toLocaleString()}</div>
          <div className="text-muted-foreground">{labels[hover]}</div>
        </div>
      )}
    </div>
  );
};

const ChartSkeleton = () => (
  <div className="space-y-3 p-4">
    <div className="h-4 w-52 rounded skeleton-shimmer" />
    <div className="h-8 w-40 rounded skeleton-shimmer" />
    <div className="h-3 w-32 rounded skeleton-shimmer" />
    <div className="h-9 w-full rounded-lg skeleton-shimmer" />
    <div className="h-[240px] md:h-[300px] rounded-xl skeleton-shimmer" />
    <div className="flex gap-2">
      {Array.from({ length: 7 }).map((_, i) => (
        <div key={i} className="h-6 w-10 rounded skeleton-shimmer" />
      ))}
    </div>
  </div>
);

const ToolbarButton: React.FC<{ icon: React.ElementType; label: string }> = ({ icon: Icon, label }) => (
  <span className="inline-flex items-center gap-1.5 rounded-md px-2.5 py-1.5 text-[13px] font-medium text-foreground hover:bg-accent transition-colors">
    <Icon className="w-4 h-4 text-muted-foreground" />
    {label}
    <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
  </span>
);

/** Homepage market intelligence panel — terminal-style chart over EarlyMarket data. */
const MarketPulse: React.FC = () => {
  const [metric, setMetric] = useState<MetricKey>('growth');
  const [category, setCategory] = useState<string>('all');
  const [granularity, setGranularity] = useState<Granularity>('daily');
  const [range, setRange] = useState<RangeKey>('1M');

  const days = RANGES.find((r) => r.key === range)!.days;
  const since = useMemo(() => {
    const d = new Date();
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() - (days - 1));
    return d.toISOString();
  }, [days]);

  const { data, isLoading } = useQuery({
    queryKey: ['home-market-pulse', range],
    staleTime: 5 * 60 * 1000,
    queryFn: async () => {
      const [sellers, joins, views, ads] = await Promise.all([
        supabase.from('seller_profiles').select('created_at').gte('created_at', since).limit(5000),
        supabase.from('profiles').select('created_at').gte('created_at', since).limit(5000),
        supabase
          .from('content_views')
          .select('created_at, content_type, source_page, content_id')
          .gte('created_at', since)
          .limit(8000),
        supabase
          .from('ads')
          .select('id, category, created_at, view_count')
          .eq('status', 'active')
          .limit(3000),
      ]);
      return {
        sellers: (sellers.data || []) as Row[],
        joins: (joins.data || []) as Row[],
        views: (views.data || []) as ViewRow[],
        ads: (ads.data || []) as AdRow[],
      };
    },
  });

  const buckets = useMemo(() => buildBuckets(Math.max(2, days)), [days]);

  const categories = useMemo(() => {
    const map = new Map<string, { listings: number; views: number }>();
    for (const ad of data?.ads || []) {
      const key = ad.category || 'Other';
      const cur = map.get(key) || { listings: 0, views: 0 };
      cur.listings += 1;
      cur.views += ad.view_count || 0;
      map.set(key, cur);
    }
    return Array.from(map.entries())
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.views - a.views)
      .slice(0, 8);
  }, [data?.ads]);

  const adCategory = useMemo(() => {
    const m = new Map<string, string>();
    for (const ad of data?.ads || []) m.set(ad.id, ad.category || 'Other');
    return m;
  }, [data?.ads]);

  const series = useMemo(() => {
    const counts = new Map(buckets.map((b) => [b.key, 0]));
    const bump = (iso: string) => {
      const k = iso.slice(0, 10);
      if (counts.has(k)) counts.set(k, (counts.get(k) || 0) + 1);
    };

    if (metric === 'growth') (data?.sellers || []).forEach((r) => bump(r.created_at));
    if (metric === 'joins') (data?.joins || []).forEach((r) => bump(r.created_at));
    if (metric === 'visits')
      (data?.views || [])
        .filter((v) => v.content_type === 'seller' || v.content_type === 'service')
        .forEach((r) => bump(r.created_at));

    let values = buckets.map((b) => counts.get(b.key) || 0);

    if (granularity === 'cumulative') {
      let acc = 0;
      values = values.map((v) => (acc += v));
    } else if (granularity === 'weekly') {
      values = values.map((_, i, arr) =>
        arr.slice(Math.max(0, i - 6), i + 1).reduce((s, v) => s + v, 0)
      );
    }
    return values;
  }, [buckets, data, metric, granularity]);

  const overlay = useMemo(() => {
    if (category === 'all') return null;
    const counts = new Map(buckets.map((b) => [b.key, 0]));
    for (const v of data?.views || []) {
      if (adCategory.get(v.content_id) !== category) continue;
      const k = v.created_at.slice(0, 10);
      if (counts.has(k)) counts.set(k, (counts.get(k) || 0) + 1);
    }
    let values = buckets.map((b) => counts.get(b.key) || 0);
    if (granularity === 'cumulative') {
      let acc = 0;
      values = values.map((v) => (acc += v));
    }
    return values;
  }, [category, buckets, data?.views, adCategory, granularity]);

  const total = series.reduce((s, v) => s + v, 0);
  const half = Math.floor(series.length / 2);
  const firstHalf = series.slice(0, half).reduce((s, v) => s + v, 0);
  const secondHalf = series.slice(half).reduce((s, v) => s + v, 0);
  const delta = firstHalf === 0 ? (secondHalf > 0 ? 100 : 0) : ((secondHalf - firstHalf) / firstHalf) * 100;
  const up = delta >= 0;
  const baseline = series.length ? total / series.length : 0;

  const labels = buckets.map((b) =>
    b.date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })
  );

  const activeMetric = METRICS.find((m) => m.key === metric)!;
  const stamp = new Date().toLocaleString('en-GB', {
    day: '2-digit',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <section className="py-4">
      <div className="rounded-2xl border border-border bg-card overflow-hidden">
        {isLoading ? (
          <ChartSkeleton />
        ) : (
          <>
            {/* ── Section 1: headline ── */}
            <div className="px-4 md:px-5 pt-4 pb-3 flex items-start justify-between gap-3">
              <div className="min-w-0">
                <h3 className="text-[15px] md:text-base font-semibold text-foreground truncate">
                  EarlyMarket {activeMetric.label} Index
                </h3>
                <div className="mt-1.5 flex items-baseline gap-2 flex-wrap">
                  <span className="text-[26px] md:text-[30px] font-bold leading-none text-foreground tabular-nums">
                    {total.toLocaleString()}
                  </span>
                  <span
                    className={cn(
                      'inline-flex items-center gap-1 text-[13px] font-semibold',
                      up ? 'text-emerald-500' : 'text-destructive'
                    )}
                  >
                    <span
                      className={cn(
                        'inline-flex items-center justify-center w-4 h-4 rounded-full',
                        up ? 'bg-emerald-500/20' : 'bg-destructive/20'
                      )}
                    >
                      {up ? <ArrowUp className="w-3 h-3" /> : <ArrowDown className="w-3 h-3" />}
                    </span>
                    {up ? '+' : ''}
                    {delta.toFixed(2)}% ({secondHalf - firstHalf >= 0 ? '+' : ''}
                    {(secondHalf - firstHalf).toLocaleString()}) Today
                  </span>
                </div>
                <p className="mt-1 text-[11.5px] text-muted-foreground">{stamp} EAT</p>
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger className="shrink-0 inline-flex items-center gap-1.5 rounded-full border border-border bg-muted/50 px-3 py-1.5 text-[12.5px] font-medium text-foreground hover:bg-accent transition-colors">
                  {activeMetric.label}
                  <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-60">
                  {METRICS.map((m) => (
                    <DropdownMenuItem key={m.key} onClick={() => setMetric(m.key)} className="flex-col items-start gap-0.5">
                      <span className="text-sm">{m.label}</span>
                      <span className="text-[11px] text-muted-foreground">{m.hint}</span>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* ── Section 2: toolbar + chart ── */}
            <div className="mx-3 md:mx-4 rounded-xl border border-border bg-background/60">
              <div className="flex items-center gap-1 border-b border-border px-2 py-1.5 overflow-x-auto scrollbar-hide">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button><ToolbarButton icon={AreaChartIcon} label="Area" /></button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-52">
                    {GRANULARITY.map((g) => (
                      <DropdownMenuItem key={g.key} onClick={() => setGranularity(g.key)}>
                        {g.label}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button><ToolbarButton icon={GitCompare} label={category === 'all' ? 'Compare' : category} /></button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-56 max-h-72 overflow-y-auto">
                    <DropdownMenuItem onClick={() => setCategory('all')}>No comparison</DropdownMenuItem>
                    {categories.map((c) => (
                      <DropdownMenuItem key={c.name} onClick={() => setCategory(c.name)} className="justify-between">
                        <span className="truncate">{c.name}</span>
                        <span className="text-[11px] text-muted-foreground">{c.listings}</span>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button><ToolbarButton icon={Activity} label="Indicators" /></button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start" className="w-56">
                    {METRICS.map((m) => (
                      <DropdownMenuItem key={m.key} onClick={() => setMetric(m.key)}>
                        {m.label}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>

              <div className="p-2 pb-3">
                <TerminalChart values={series} overlay={overlay} labels={labels} baseline={baseline} />
              </div>
            </div>

            {/* ── Section 3: ranges ── */}
            <div className="flex items-center gap-1 px-3 md:px-4 py-3 overflow-x-auto scrollbar-hide">
              {RANGES.map((r) => (
                <button
                  key={r.key}
                  onClick={() => setRange(r.key)}
                  className={cn(
                    'rounded-md px-2.5 py-1 text-[12.5px] font-medium transition-colors shrink-0',
                    range === r.key
                      ? 'bg-accent text-foreground font-bold'
                      : 'text-muted-foreground hover:bg-accent/60'
                  )}
                >
                  {r.key}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </section>
  );
};

export default MarketPulse;
