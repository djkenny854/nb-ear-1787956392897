import React, { useEffect, useState } from 'react';
import SectionSkeleton from '@/components/sections/SectionSkeleton';
import { MapPin, Navigation, Loader2, Info } from 'lucide-react';
import LocationInfoDialog from '@/components/sections/LocationInfoDialog';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import HomeProductCard from '@/components/cards/HomeProductCard';
import { useGeolocation } from '@/hooks/useGeolocation';
import { useAuth } from '@/components/auth/AuthContext';
import { rankMarketplaceItems } from '@/lib/feedRanking';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';
import RailScroller from '@/components/common/RailScroller';

interface PopularNearYouProps {
  location?: string;
  onSeeAll?: () => void;
}

const PopularNearYou: React.FC<PopularNearYouProps> = ({ 
  location: defaultLocation,
  onSeeAll 
}) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { locationName, district, subCounty, requestLocation, loading: geoLoading, hasLocation } = useGeolocation();
  const [hasRequestedLocation, setHasRequestedLocation] = useState(false);
  const [infoOpen, setInfoOpen] = useState(false);
  const { allBlockedIds } = useBlockedUsers();
  const { isOnline } = useNetworkStatus();
  
  const activeLocation = district || locationName || defaultLocation || null;

  useEffect(() => {
    if (!hasRequestedLocation && !hasLocation) {
      setHasRequestedLocation(true);
      requestLocation();
    }
  }, [hasRequestedLocation, hasLocation, requestLocation]);

  const { data: followedUserIds = [] } = useQuery({
    queryKey: ['followed-user-ids', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data } = await supabase
        .from('follows')
        .select('following_id')
        .eq('follower_id', user.id);
      return data?.map(f => f.following_id) || [];
    },
    enabled: !!user?.id,
    staleTime: 1000 * 60 * 5,
  });

  const { data: items, isLoading } = useQuery({
    queryKey: ['popular-near-you', activeLocation, subCounty, followedUserIds],
    queryFn: async () => {
      if (!activeLocation) return [];
      // Step 1: Query ads by location field directly
      const { data: locationAds, error: err1 } = await supabase
        .from('ads')
        .select(`
          id, title, price, original_price, images, b2_video_url, location, view_count,
          is_boosted, has_discount, inventory_count, is_sponsored, sponsored_until,
          created_at, seller_id,
          seller_profiles!ads_seller_id_fkey (
            id, user_id, business_name, business_logo_url, is_verified,
            is_featured, verification_badge_color, district, sub_county, working_hours
          )
        `)
        .eq('status', 'active')
        .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
        .in('listing_type', ['physical_products', 'digital_products'])
        .ilike('location', `%${activeLocation}%`)
        .order('view_count', { ascending: false })
        .limit(30);

      if (err1) throw err1;

      // Step 2: Find sellers in the same district and optionally sub-county
      let sellerIds: string[] = [];
      
      if (subCounty) {
        const { data: subCountySellers } = await supabase
          .from('seller_profiles')
          .select('id')
          .ilike('district', `%${activeLocation}%`)
          .ilike('sub_county', `%${subCounty}%`)
          .limit(50);
        
        const { data: districtSellers } = await supabase
          .from('seller_profiles')
          .select('id')
          .ilike('district', `%${activeLocation}%`)
          .limit(50);
        
        const allSellers = [...(subCountySellers || []), ...(districtSellers || [])];
        sellerIds = [...new Set(allSellers.map(s => s.id))];
      } else {
        const { data: districtSellers } = await supabase
          .from('seller_profiles')
          .select('id')
          .ilike('district', `%${activeLocation}%`)
          .limit(50);
        sellerIds = districtSellers?.map(s => s.id) || [];
      }
      let districtAds: any[] = [];

      if (sellerIds.length > 0) {
        const { data } = await supabase
          .from('ads')
          .select(`
            id, title, price, original_price, images, b2_video_url, location, view_count,
            is_boosted, has_discount, inventory_count, is_sponsored, sponsored_until,
            created_at, seller_id,
            seller_profiles!ads_seller_id_fkey (
              id, user_id, business_name, business_logo_url, is_verified,
              is_featured, verification_badge_color, district, sub_county, working_hours
            )
          `)
          .eq('status', 'active')
          .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
          .in('listing_type', ['physical_products', 'digital_products'])
          .in('seller_id', sellerIds)
          .order('view_count', { ascending: false })
          .limit(30);

        districtAds = data || [];
      }

      // Merge and deduplicate
      const allAds = locationAds || [];
      const seenIds = new Set(allAds.map(a => a.id));
      for (const ad of districtAds) {
        if (!seenIds.has(ad.id)) {
          allAds.push(ad);
          seenIds.add(ad.id);
        }
      }

      // Apply marketplace ranking
      const ranked = rankMarketplaceItems(
        allAds.map(item => ({
          ...item,
          listing_type: 'physical_products',
          content_type: 'ad' as const,
          is_sponsored: item.is_sponsored || false,
          sponsored_until: item.sponsored_until || null,
          seller: {
            is_verified: (item.seller_profiles as any)?.is_verified || false,
            is_featured: (item.seller_profiles as any)?.is_featured || false,
            user_id: (item.seller_profiles as any)?.user_id || '',
          },
        })),
        followedUserIds,
        activeLocation
      );
      
      // Shuffle results randomly then take top 8
      const shuffled = ranked.sort(() => Math.random() - 0.5);
      return shuffled.slice(0, 8).map(r => allAds.find(i => i.id === r.id)!).filter(Boolean);
    },
    staleTime: 1000 * 60 * 5,
    enabled: isOnline,
  });

  if (isLoading && isOnline) {
    return <SectionSkeleton type="listing" count={4} />;
  }

  const filteredItems = (items || []).filter(
    item => !allBlockedIds.includes((item.seller_profiles as any)?.user_id)
  );

  if (!filteredItems.length) {
    return null;
  }

  return (
    <section className="py-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          {geoLoading ? (
            <Loader2 className="w-7 h-7 text-primary animate-spin" />
          ) : (
            <MapPin className="w-7 h-7 text-primary" strokeWidth={2.5} />
          )}
          <div>
            <h2 className="text-xl font-bold text-foreground tracking-tight">Popular Near You</h2>
            <div className="flex items-center gap-1.5">
              <p className="text-xs text-muted-foreground">
                {activeLocation ? `Trending in ${activeLocation}` : 'Finding your area…'}
              </p>
              {hasLocation && (
                <Navigation className="w-3 h-3 text-primary" />
              )}
            </div>
          </div>
        </div>
        <button
          onClick={() => setInfoOpen(true)}
          className="inline-flex items-center justify-center h-9 w-9 rounded-full hover:bg-primary/10 text-primary transition-colors"
          aria-label="About Popular Near You"
          title="How does this work?"
        >
          <Info className="w-5 h-5" />
        </button>
      </div>

      <RailScroller>
      <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
        {filteredItems.map((item) => (
          <HomeProductCard
            key={item.id}
            id={item.id}
            title={item.title}
            price={item.price || 0}
            originalPrice={item.original_price}
            images={item.images || []}
            videoUrl={(item as any).b2_video_url || null}
            location={item.location}
            viewCount={item.view_count || 0}
            isBoosted={item.is_boosted || false}
            hasDiscount={item.has_discount || false}
            createdAt={item.created_at}
            inventoryCount={item.inventory_count || undefined}
            seller={item.seller_profiles}
            onClick={() => navigate(`/ad/${item.id}`)}
          />
        ))}
      </div>
      </RailScroller>

      <LocationInfoDialog
        open={infoOpen}
        onOpenChange={setInfoOpen}
        location={activeLocation}
        subCounty={subCounty}
        hasLocation={hasLocation}
        onRefreshLocation={requestLocation}
      />
    </section>
  );
};

export default PopularNearYou;
