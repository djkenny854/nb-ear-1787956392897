import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from '@/components/ui/drawer';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useIsMobile } from '@/hooks/use-mobile';
import { useNavigate } from 'react-router-dom';
import { Store, ExternalLink, BadgeCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

export interface DealSource {
  seller_id: string;
  business_name: string;
  business_logo_url?: string | null;
  is_verified?: boolean | null;
  store_slug?: string | null;
  deal_count?: number;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  sources: DealSource[];
}

const HotDealsSourcesDialog: React.FC<Props> = ({ open, onOpenChange, sources }) => {
  const isMobile = useIsMobile();
  const navigate = useNavigate();

  // Deduplicate by seller_id and aggregate deal counts
  const uniqueSources = React.useMemo(() => {
    const map = new Map<string, DealSource & { deal_count: number }>();
    sources.forEach(s => {
      if (!s.seller_id) return;
      const existing = map.get(s.seller_id);
      if (existing) {
        existing.deal_count = (existing.deal_count || 1) + 1;
      } else {
        map.set(s.seller_id, { ...s, deal_count: 1 });
      }
    });
    return Array.from(map.values()).sort((a, b) => (b.deal_count || 0) - (a.deal_count || 0));
  }, [sources]);

  const openStore = (s: DealSource) => {
    onOpenChange(false);
    navigate(`/seller/${s.store_slug || s.seller_id}`);
  };

  const content = (
    <ScrollArea className="max-h-[60vh]">
      <div className="space-y-2 pr-1">
        {uniqueSources.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">No source businesses found.</p>
        ) : (
          uniqueSources.map((s) => (
            <button
              key={s.seller_id}
              onClick={() => openStore(s)}
              className="w-full flex items-center gap-3 p-3 rounded-xl border border-border/60 hover:border-primary/40 hover:bg-muted/40 transition-colors text-left"
            >
              <Avatar className="w-10 h-10 border border-border/50">
                <AvatarImage src={s.business_logo_url || undefined} alt={s.business_name} />
                <AvatarFallback className="bg-primary/10 text-primary text-sm">
                  {s.business_name?.charAt(0)?.toUpperCase() || 'S'}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <p className="font-semibold text-sm truncate">{s.business_name}</p>
                  {s.is_verified && <BadgeCheck className="w-3.5 h-3.5 text-primary flex-shrink-0" />}
                </div>
                <p className="text-xs text-muted-foreground">
                  {s.deal_count} active deal{(s.deal_count || 0) !== 1 ? 's' : ''}
                </p>
              </div>
              <ExternalLink className="w-4 h-4 text-muted-foreground" />
            </button>
          ))
        )}
      </div>
    </ScrollArea>
  );

  const header = (
    <>
      <div className="flex items-center gap-3 mb-1">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-destructive/15 to-orange-500/15 flex items-center justify-center">
          <Store className="w-4 h-4 text-destructive" />
        </div>
        <div>
          <p className="font-semibold">Hot Deal Sources</p>
          <p className="text-xs text-muted-foreground">{uniqueSources.length} business{uniqueSources.length !== 1 ? 'es' : ''} offering these deals</p>
        </div>
      </div>
    </>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="px-4 pb-8">
          <DrawerHeader className="text-left">
            <DrawerTitle className="sr-only">Hot Deal Sources</DrawerTitle>
            <DrawerDescription className="sr-only">Businesses offering current hot deals</DrawerDescription>
            {header}
          </DrawerHeader>
          {content}
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="sr-only">Hot Deal Sources</DialogTitle>
          <DialogDescription className="sr-only">Businesses offering current hot deals</DialogDescription>
          {header}
        </DialogHeader>
        {content}
      </DialogContent>
    </Dialog>
  );
};

export default HotDealsSourcesDialog;
