import React from 'react';
import { History } from 'lucide-react';
import ContentCarousel from './ContentCarousel';
import ListingCard from '@/components/cards/ListingCard';
import { mockListings } from '@/data/mockData';

interface JumpBackInProps {
  onSeeAll?: () => void;
}

const JumpBackIn: React.FC<JumpBackInProps> = ({ onSeeAll }) => {
  // Simulate recently viewed items
  const recentItems = mockListings.slice(0, 6);

  return (
    <ContentCarousel
      title="Jump Back In"
      subtitle="Continue where you left off"
      icon={<History className="w-5 h-5" />}
      onSeeAll={onSeeAll}
    >
      {recentItems.map((listing) => (
        <div key={listing.id} style={{ scrollSnapAlign: 'start' }}>
          <ListingCard listing={listing} />
        </div>
      ))}
    </ContentCarousel>
  );
};

export default JumpBackIn;
