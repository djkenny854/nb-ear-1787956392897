import React from 'react';
import { Briefcase } from 'lucide-react';
import ContentCarousel from './ContentCarousel';
import JobCard from '@/components/cards/JobCard';
import { mockJobs } from '@/data/mockData';

interface RecommendedJobsProps {
  onSeeAll?: () => void;
}

const RecommendedJobs: React.FC<RecommendedJobsProps> = ({ onSeeAll }) => {
  return (
    <ContentCarousel
      title="Recommended Jobs For You"
      subtitle="Based on your interests"
      icon={<Briefcase className="w-5 h-5" />}
      onSeeAll={onSeeAll}
    >
      {mockJobs.map((job) => (
        <div key={job.id} style={{ scrollSnapAlign: 'start' }}>
          <JobCard job={job} />
        </div>
      ))}
    </ContentCarousel>
  );
};

export default RecommendedJobs;
