import React from 'react';
import { ChevronRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import SectionSkeleton from '@/components/sections/SectionSkeleton';
import HomeProductCard from '@/components/cards/HomeProductCard';
import RailScroller from '@/components/common/RailScroller';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';

const FreshFromSellers: React.FC = () => {
  const navigate = useNavigate();
  const { allBlockedIds } = useBlockedUsers();
  const { isOnline } = useNetworkStatus();

  const { data: items, isLoading } = useQuery({
    queryKey: ['home-fresh-from-sellers'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select(`
          id, title, price, original_price, images, b2_video_url, location, view_count,
          is_boosted, has_discount, inventory_count, created_at, seller_id,
          seller_profiles!ads_seller_id_fkey (
            id, user_id, business_name, business_logo_url, is_verified,
            is_featured, verification_badge_color, working_hours
          )
        `)
        .eq('status', 'active')
        .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
        .in('listing_type', ['physical_products', 'digital_products'])
        .order('created_at', { ascending: false })
        .limit(40);

      if (error) throw error;
      return (data || []).filter(a => (a.seller_profiles as any)?.is_verified).slice(0, 20);
    },
    staleTime: 1000 * 60 * 5,
    enabled: isOnline,
  });

  if (isLoading && isOnline) {
    return <SectionSkeleton type="listing" count={4} />;
  }

  const filteredItems = (items || []).filter(
    item => !allBlockedIds.includes((item.seller_profiles as any)?.user_id)
  );

  if (!filteredItems.length) return null;

  return (
    <section className="py-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Sparkles className="w-6 h-6 text-primary" strokeWidth={2.5} />
          <div>
            <h2 className="text-xl font-bold text-foreground tracking-tight">Fresh Listings From Verified Sellers</h2>
            <p className="text-xs text-muted-foreground">Newest items from sellers you can trust</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="sm"
          className="text-primary"
          onClick={() => navigate('/search?contentType=products')}
        >
          View more
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>

      <RailScroller>
        <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide -mx-4 px-4">
          {filteredItems.map((item) => (
            <HomeProductCard
              key={item.id}
              id={item.id}
              title={item.title}
              price={item.price || 0}
              originalPrice={item.original_price}
              images={item.images || []}
              videoUrl={(item as any).b2_video_url || null}
              location={item.location}
              viewCount={item.view_count || 0}
              isBoosted={item.is_boosted || false}
              hasDiscount={item.has_discount || false}
              createdAt={item.created_at}
              inventoryCount={item.inventory_count || undefined}
              seller={item.seller_profiles}
              onClick={() => navigate(`/ad/${item.id}`)}
            />
          ))}
        </div>
      </RailScroller>

      <div className="flex justify-center mt-4">
        <Button
          variant="outline"
          className="rounded-full px-6"
          onClick={() => navigate('/search?contentType=products')}
        >
          View more in marketplace
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </section>
  );
};

export default FreshFromSellers;
