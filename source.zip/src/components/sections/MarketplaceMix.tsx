import React, { useEffect } from 'react';
import SectionSkeleton from '@/components/sections/SectionSkeleton';
import { Store, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import HomeProductCard from '@/components/cards/HomeProductCard';
import { useAuth } from '@/components/auth/AuthContext';
import { useGeolocation } from '@/hooks/useGeolocation';
import { rankMarketplaceItems } from '@/lib/feedRanking';
import { saveToCache, loadFromCache, CACHE_KEYS } from '@/utils/offlineCache';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';

interface MarketplaceMixProps {
  onSeeAll?: () => void;
}

const MarketplaceMix: React.FC<MarketplaceMixProps> = ({ onSeeAll }) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { locationName } = useGeolocation();
  const { allBlockedIds } = useBlockedUsers();
  const { isOnline } = useNetworkStatus();

  const { data: followedUserIds = [] } = useQuery({
    queryKey: ['followed-user-ids', user?.id],
    queryFn: async () => {
      if (!user?.id) return [];
      const { data } = await supabase
        .from('follows')
        .select('following_id')
        .eq('follower_id', user.id);
      return data?.map(f => f.following_id) || [];
    },
    enabled: !!user?.id,
    staleTime: 1000 * 60 * 5,
  });

  const { data: items, isLoading } = useQuery({
    queryKey: ['marketplace-mix', locationName, followedUserIds],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select(`
          id,
          title,
          price,
          original_price,
          images,
          b2_video_url,
          location,
          view_count,
          is_boosted,
          has_discount,
          inventory_count,
          is_price_negotiable,
          is_sponsored,
          sponsored_until,
          warranty,
          created_at,
          seller_id,
          seller_profiles!ads_seller_id_fkey (
            id,
            user_id,
            business_name,
            business_logo_url,
            is_verified,
            is_featured,
            verification_badge_color,
            district,
            sub_county,
            working_hours
          )
        `)
        .eq('status', 'active')
        .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
        .eq('listing_type', 'physical_products')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      
      const rawItems = data || [];
      
      // Apply marketplace ranking: followed → near you → verified → recency
      const ranked = rankMarketplaceItems(
        rawItems.map(item => ({
          ...item,
          listing_type: 'physical_products',
          content_type: 'ad' as const,
          is_sponsored: item.is_sponsored || false,
          sponsored_until: item.sponsored_until || null,
          seller: {
            is_verified: (item.seller_profiles as any)?.is_verified || false,
            is_featured: (item.seller_profiles as any)?.is_featured || false,
            user_id: (item.seller_profiles as any)?.user_id || '',
          },
        })),
        followedUserIds,
        locationName
      );
      
      // Return first 8 for display
      const result = ranked.slice(0, 8).map(r => rawItems.find(i => i.id === r.id)!);
      
      // Save to offline cache
      saveToCache(CACHE_KEYS.MARKETPLACE, result);
      
      return result;
    },
    staleTime: 1000 * 60 * 5,
    enabled: isOnline,
    // Use cached data as placeholder while fetching
    placeholderData: undefined,
  });

  // Load cached data when offline or while loading
  const { data: cachedItems } = useQuery({
    queryKey: ['marketplace-mix-cache'],
    queryFn: () => loadFromCache<typeof items>(CACHE_KEYS.MARKETPLACE, 60 * 60 * 1000), // 1hr cache
    staleTime: Infinity,
  });

  const displayItems = (items || cachedItems || []).filter(
    item => !allBlockedIds.includes((item.seller_profiles as any)?.user_id)
  );

  if (isLoading && !displayItems.length) {
    return <SectionSkeleton type="listing" count={8} />;
  }

  if (!displayItems.length) {
    return null;
  }

  return (
    <section className="py-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Store className="w-7 h-7 text-primary" strokeWidth={2.5} />
          <div>
            <h2 className="text-xl font-bold text-foreground tracking-tight">Marketplace</h2>
            <p className="text-xs text-muted-foreground">Fresh listings from sellers</p>
          </div>
        </div>
        {onSeeAll && (
          <Button variant="ghost" size="sm" onClick={onSeeAll} className="text-primary">
            See All
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        )}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-3 sm:gap-4 justify-items-center">
        {displayItems.map((item) => {
          const sellerData = item.seller_profiles ? {
            ...item.seller_profiles,
            district: item.seller_profiles.district,
            sub_county: item.seller_profiles.sub_county,
            verification_badge_color: item.seller_profiles.verification_badge_color,
          } : null;
          
          return (
            <HomeProductCard
              key={item.id}
              id={item.id}
              title={item.title}
              price={item.price || 0}
              originalPrice={item.original_price}
              images={item.images || []}
              videoUrl={(item as any).b2_video_url || null}
              location={item.location}
              viewCount={item.view_count || 0}
              isBoosted={item.is_boosted || false}
              hasDiscount={item.has_discount || false}
              createdAt={item.created_at}
              inventoryCount={item.inventory_count || undefined}
              isPriceNegotiable={item.is_price_negotiable || false}
              warranty={item.warranty}
              seller={sellerData}
              onClick={() => navigate(`/ad/${item.id}`)}
            />
          );
        })}
      </div>

      {/* More Button */}
      <div className="flex justify-center mt-6">
        <Button
          onClick={() => navigate('/search?contentType=products')}
          className="px-8 py-3 rounded-xl font-semibold"
        >
          More
          <ChevronRight className="w-4 h-4 ml-1" />
        </Button>
      </div>
    </section>
  );
};

export default MarketplaceMix;
