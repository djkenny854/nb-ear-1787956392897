import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Smartphone, Shirt, Laptop, Wrench, Briefcase, 
  Home, Car, Gamepad2, Wheat, Dog, Palette, Baby, Book,
  TrendingUp, Monitor, Hammer, GraduationCap, Zap, Tv, Heart,
  Sofa, Settings, Star, CreditCard, ShoppingBag, Utensils,
  Music, Camera, Plane, Dumbbell, Pill, Factory, Gem, Globe,
  type LucideIcon
} from 'lucide-react';
import { motion } from 'framer-motion';
import { supabase } from '@/integrations/supabase/client';
import CategorySkeleton from '@/components/ui/category-skeleton';
import RailScroller from '@/components/common/RailScroller';

interface CategoryQuickAccessProps {
  onCategoryClick?: (category: string) => void;
}

interface Category {
  id: string;
  name: string;
  icon: string;
  ad_count?: number;
}

const iconMap: Record<string, LucideIcon> = {
  smartphone: Smartphone,
  shirt: Shirt,
  laptop: Laptop,
  monitor: Monitor,
  wrench: Wrench,
  briefcase: Briefcase,
  home: Home,
  car: Car,
  gamepad2: Gamepad2,
  wheat: Wheat,
  dog: Dog,
  palette: Palette,
  baby: Baby,
  book: Book,
  'trending-up': TrendingUp,
  hammer: Hammer,
  'graduation-cap': GraduationCap,
  zap: Zap,
  tv: Tv,
  heart: Heart,
  sofa: Sofa,
  settings: Settings,
  star: Star,
  'credit-card': CreditCard,
  'shopping-bag': ShoppingBag,
  utensils: Utensils,
  music: Music,
  camera: Camera,
  plane: Plane,
  dumbbell: Dumbbell,
  pill: Pill,
  factory: Factory,
  gem: Gem,
  globe: Globe,
};

const CategoryQuickAccess: React.FC<CategoryQuickAccessProps> = ({ onCategoryClick }) => {
  const navigate = useNavigate();
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [isUserScrolling, setIsUserScrolling] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const autoScrollRef = useRef<number | null>(null);
  const resumeTimeoutRef = useRef<number | null>(null);
  const isAutoScrollingRef = useRef(false);

  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const { data: categoriesData, error: categoriesError } = await supabase
          .from('categories')
          .select('id, name, icon')
          .eq('is_active', true)
          .not('name', 'in', '("Featured Ads","Boosted Listings")');

        if (categoriesError) throw categoriesError;

        const { data: adCounts, error: adCountsError } = await supabase
          .from('ads')
          .select('category')
          .eq('status', 'active');

        if (adCountsError) throw adCountsError;

        const countMap: Record<string, number> = {};
        adCounts?.forEach((ad) => {
          countMap[ad.category] = (countMap[ad.category] || 0) + 1;
        });

        const categoriesWithCounts = (categoriesData || [])
          .map((cat) => ({
            ...cat,
            ad_count: countMap[cat.name] || 0,
          }))
          .sort((a, b) => (b.ad_count || 0) - (a.ad_count || 0));

        setCategories(categoriesWithCounts);

        // ensure we always start at the beginning
        requestAnimationFrame(() => {
          if (scrollRef.current) scrollRef.current.scrollLeft = 0;
        });
      } catch (error) {
        console.error('Error fetching categories:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchCategories();
  }, []);

  const stopAutoScroll = useCallback(() => {
    if (autoScrollRef.current) {
      cancelAnimationFrame(autoScrollRef.current);
      autoScrollRef.current = null;
    }
  }, []);

  const scheduleResume = useCallback(() => {
    if (resumeTimeoutRef.current) window.clearTimeout(resumeTimeoutRef.current);
    // Resume after user stops interacting - give time for touch interactions
    resumeTimeoutRef.current = window.setTimeout(() => {
      setIsUserScrolling(false);
    }, 1500);
  }, []);

  // Continuous auto-scroll with smooth movement
  const startAutoScroll = useCallback(() => {
    if (!scrollRef.current || categories.length === 0) return;

    const scroller = scrollRef.current;
    // Marquee-like speed (px per second). Comfortable reading speed.
    const speedPxPerSecond = 40;
    let lastTs = 0;

    const tick = (ts: number) => {
      if (!scroller) return;

      // Stop if user is scrolling
      if (isUserScrolling) {
        autoScrollRef.current = null;
        lastTs = 0;
        return;
      }

      if (!lastTs) lastTs = ts;
      const delta = ts - lastTs;
      lastTs = ts;

      // Calculate max scroll (half because we duplicate categories)
      const maxScroll = scroller.scrollWidth / 2;
      const next = scroller.scrollLeft + (speedPxPerSecond * delta) / 1000;

      // Mark this scroll as programmatic so onScroll doesn't pause autoplay
      isAutoScrollingRef.current = true;
      scroller.scrollLeft = next >= maxScroll ? 0 : next;
      requestAnimationFrame(() => {
        isAutoScrollingRef.current = false;
      });

      autoScrollRef.current = requestAnimationFrame(tick);
    };

    // Start the animation loop
    if (!autoScrollRef.current) {
      autoScrollRef.current = requestAnimationFrame(tick);
    }
  }, [categories.length, isUserScrolling]);

  const handleUserScroll = useCallback(() => {
    // Ignore programmatic scroll events from autoplay
    if (isAutoScrollingRef.current) return;

    // User scroll pauses auto-scroll briefly
    if (!isUserScrolling) {
      setIsUserScrolling(true);
      stopAutoScroll();
    }
    scheduleResume();
  }, [isUserScrolling, scheduleResume, stopAutoScroll]);

  const handlePointerDown = useCallback(() => {
    setIsUserScrolling(true);
    stopAutoScroll();
    if (resumeTimeoutRef.current) window.clearTimeout(resumeTimeoutRef.current);
  }, [stopAutoScroll]);

  const handlePointerUp = useCallback(() => {
    scheduleResume();
  }, [scheduleResume]);

  useEffect(() => {
    if (!isUserScrolling && categories.length > 0) startAutoScroll();

    return () => {
      stopAutoScroll();
    };
  }, [categories.length, isUserScrolling, startAutoScroll, stopAutoScroll]);

  useEffect(() => {
    return () => {
      if (resumeTimeoutRef.current) window.clearTimeout(resumeTimeoutRef.current);
      stopAutoScroll();
    };
  }, [stopAutoScroll]);


  if (loading) {
    return <CategorySkeleton />;
  }

  // Duplicate categories for infinite scroll effect
  const duplicatedCategories = [...categories, ...categories];

  const handleCategoryClick = (categoryName: string) => {
    if (onCategoryClick) {
      onCategoryClick(categoryName);
    }
    navigate(`/search?category=${encodeURIComponent(categoryName)}`);
  };

  return (
    <div className="py-2 relative -mx-4 sm:-mx-6 lg:-mx-8">
      {/* Left fade */}
      <div className="absolute left-0 top-0 bottom-0 w-12 sm:w-16 bg-gradient-to-r from-background via-background/80 to-transparent z-10 pointer-events-none" />
      {/* Right fade */}
      <div className="absolute right-0 top-0 bottom-0 w-12 sm:w-16 bg-gradient-to-l from-background via-background/80 to-transparent z-10 pointer-events-none" />

      <RailScroller>
      <div
        ref={scrollRef}
        onScroll={handleUserScroll}
        onMouseDown={handlePointerDown}
        onMouseUp={handlePointerUp}
        onMouseLeave={handlePointerUp}
        onTouchStart={handlePointerDown}
        onTouchEnd={handlePointerUp}
        className="flex gap-4 overflow-x-auto scrollbar-hide pb-1 px-6 sm:px-8 touch-pan-x"
        style={{
          scrollBehavior: 'auto',
          WebkitOverflowScrolling: 'touch'
        }}
      >
        {duplicatedCategories.map((category, index) => {
          const Icon = iconMap[category.icon?.toLowerCase()] || ShoppingBag;

          return (
            <motion.button
              key={`${category.id}-${index}`}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: Math.min(index * 0.03, 0.5) }}
              whileHover={{ y: -2, scale: 1.04 }}
              whileTap={{ scale: 0.96 }}
              onClick={() => handleCategoryClick(category.name)}
              className="flex flex-col items-center gap-1.5 min-w-[64px] group"
            >
              {/* Transparent icon — no card background */}
              <div className="flex items-center justify-center transition-transform duration-300 group-hover:-translate-y-0.5">
                <Icon
                  className="w-6 h-6 md:w-7 md:h-7 text-muted-foreground group-hover:text-primary transition-colors"
                  strokeWidth={1.6}
                />
              </div>

              {/* Category Name */}
              <span className="text-[11px] font-medium text-muted-foreground text-center leading-tight max-w-[68px] line-clamp-2 group-hover:text-foreground transition-colors">
                {category.name}
              </span>
            </motion.button>
          );
        })}
      </div>
      </RailScroller>
    </div>
  );
};

export default CategoryQuickAccess;
