import React, { useEffect, useState } from 'react';
import EarlyMarketAIIcon from '@/components/icons/EarlyMarketAIIcon';

const LOADING_PHRASES = [
  'Finding the hottest deals near you…',
  'Comparing prices across sellers…',
  'Hunting biggest discounts today…',
  'Curating offers worth your time…',
  'Almost there — polishing results…',
];

/**
 * Loading skeleton for the Hot Deals section.
 * Mirrors the real HotDealsSwipeCard layout to avoid layout shift.
 */
const HotDealsSkeleton: React.FC = () => {
  const [phraseIdx, setPhraseIdx] = useState(0);

  useEffect(() => {
    const t = setInterval(() => {
      setPhraseIdx((i) => (i + 1) % LOADING_PHRASES.length);
    }, 1600);
    return () => clearInterval(t);
  }, []);

  // Shared shimmer class
  const shimmer =
    'relative overflow-hidden bg-muted/50 before:absolute before:inset-0 before:-translate-x-full before:bg-gradient-to-r before:from-transparent before:via-foreground/10 before:to-transparent before:animate-[shimmer_1.6s_infinite]';

  return (
    <div className="py-3">
      {/* Header row — same height & spacing as real card */}
      <div className="flex items-center justify-between mb-2 px-3">
        <div className="flex items-center gap-2">
          <div className={`h-4 w-20 rounded ${shimmer}`} />
          <div className={`h-3 w-14 rounded ${shimmer}`} />
        </div>
      </div>

      {/* Card body — fixed dims matching HotDealsSwipeCard */}
      <div className="relative bg-card overflow-hidden shadow-sm">
        <div className="flex gap-3 p-3">
          {/* image */}
          <div className={`w-24 h-24 rounded-xl flex-shrink-0 ${shimmer}`} />
          {/* text */}
          <div className="flex-1 min-w-0 space-y-2 py-1">
            <div className={`h-4 w-11/12 rounded ${shimmer}`} />
            <div className={`h-4 w-3/4 rounded ${shimmer}`} />
            <div className={`h-3 w-1/2 rounded ${shimmer}`} />
            <div className={`h-3 w-2/3 rounded ${shimmer}`} />
          </div>
        </div>

        {/* footer row */}
        <div className="flex items-center justify-between border-t border-border/50 px-3 py-2">
          <div className="flex items-center gap-2">
            <div className="flex -space-x-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className={`w-5 h-5 rounded-full border border-background ${shimmer}`} />
              ))}
            </div>
            <div className={`h-3 w-14 rounded ${shimmer}`} />
          </div>
          <div className="flex items-center gap-1">
            <div className={`h-10 w-10 rounded-full ${shimmer}`} />
            <div className={`h-8 w-8 rounded-full ${shimmer}`} />
          </div>
        </div>
      </div>

      {/* Rotating text placeholder */}
      <div className="flex items-center gap-2 mt-3 px-3 min-h-[20px]">
        <EarlyMarketAIIcon className="w-4 h-4 shrink-0" spin />
        <p
          key={phraseIdx}
          className="text-[12px] text-muted-foreground animate-in fade-in slide-in-from-bottom-1 duration-500 truncate"
        >
          {LOADING_PHRASES[phraseIdx]}
        </p>
      </div>
    </div>
  );
};

export default HotDealsSkeleton;
