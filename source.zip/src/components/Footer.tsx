import React from 'react';
import { Link } from 'react-router-dom';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { MapPin, Phone, Mail, Globe, Facebook, Twitter, Instagram, Linkedin, Youtube, Smartphone, Truck, Shield, Star, Award, Users, TrendingUp, Zap, Heart, ArrowRight } from 'lucide-react';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';
const Footer = () => {
  const { theme } = useTheme();
  const currentYear = new Date().getFullYear();
  const footerSections = [{
    title: 'For Buyers',
    links: [
      { label: 'Browse Products', path: '/marketplace' },
      { label: 'Categories', path: '/marketplace' },
      { label: 'Daily Deals', path: '/marketplace' },
      { label: 'Discover', path: '/discover' },
    ]
  }, {
    title: 'For Sellers',
    links: [
      { label: 'Start Selling', path: '/become-seller' },
      { label: 'Boost Your Ads', path: '/boost-ad' },
      { label: 'Business Account', path: '/create-business-account' },
      { label: 'My Store', path: '/profile' },
    ]
  }, {
    title: 'Support & Help',
    links: [
      { label: 'Documentation', path: '/docs' },
      { label: 'Contact Us', path: '/contact' },
      { label: 'Feedback', path: '/feedback' },
      { label: 'Report Issue', path: '/report' },
    ]
  }, {
    title: 'Company',
    links: [
      { label: 'About EarlyMarket', path: '/about' },
      { label: 'Careers', path: '/careers' },
      { label: 'Press & Media', path: '/about' },
    ]
  }, {
    title: 'Legal & Privacy',
    links: [
      { label: 'Terms of Service', path: '/terms' },
      { label: 'Privacy Policy', path: '/privacy' },
      { label: 'Cookie Policy', path: '/cookies' },
      { label: 'Community Guidelines', path: '/community-guidelines' },
      { label: 'Accessibility', path: '/accessibility' },
      { label: 'Delete Account', path: '/delete-account' },
    ]
  }];
  const statistics = [{
    icon: Users,
    value: '2.5M+',
    label: 'Active Users'
  }, {
    icon: TrendingUp,
    value: '50K+',
    label: 'Daily Listings'
  }, {
    icon: Award,
    value: '99.2%',
    label: 'Success Rate'
  }, {
    icon: Shield,
    value: '24/7',
    label: 'Protection'
  }];
  const countries = ['Uganda', 'Kenya', 'Tanzania', 'Rwanda', 'Burundi', 'South Sudan', 'Ethiopia', 'Somalia'];
  return <footer className="bg-gray-900 text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="w-full h-full" style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.1'%3E%3Ccircle cx='30' cy='30' r='2'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
      }} />
      </div>

      {/* Main Footer Content */}
      <div className="relative">
        <div className="max-w-7xl mx-auto px-4 py-16">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-12">
            {/* Company Info */}
            <div className="lg:col-span-2">
              <img src={earlymarketLogo} alt="EarlyMarket Group" className="h-16 w-auto mb-6" />
              <p className="text-gray-300 leading-relaxed mb-6">
                East Africa's premier marketplace connecting millions of buyers and sellers across the region. 
                Building the future of digital commerce in Africa.
              </p>
              
              {/* Contact Info */}
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3 text-gray-300">
                  <MapPin className="w-5 h-5 text-primary flex-shrink-0" />
                  <span>Plot 123, Kampala Road, Kampala, Uganda</span>
                </div>
                <div className="flex items-center gap-3 text-gray-300">
                  <Phone className="w-5 h-5 text-primary flex-shrink-0" />
                  <span>+256 700 123 456</span>
                </div>
                <div className="flex items-center gap-3 text-gray-300">
                  <Mail className="w-5 h-5 text-primary flex-shrink-0" />
                  <span>earlymarketug@gmail.com</span>
                </div>
                <div className="flex items-center gap-3 text-gray-300">
                  <Globe className="w-5 h-5 text-primary flex-shrink-0" />
                  <span>www.earlymarket.com</span>
                </div>
              </div>

              {/* Social Links */}
              <div className="flex items-center gap-4">
                <a href="https://www.youtube.com/@earlymarketug" target="_blank" rel="noopener noreferrer">
                  <Button size="icon" variant="ghost" className="w-10 h-10 bg-white/10 hover:bg-primary/20 rounded-full transition-all duration-300 hover:scale-110">
                    <Youtube className="w-5 h-5" />
                  </Button>
                </a>
                <a href="https://x.com/earlymarketug" target="_blank" rel="noopener noreferrer">
                  <Button size="icon" variant="ghost" className="w-10 h-10 bg-white/10 hover:bg-primary/20 rounded-full transition-all duration-300 hover:scale-110">
                    <Twitter className="w-5 h-5" />
                  </Button>
                </a>
                <a href="https://www.facebook.com/earlymarketug" target="_blank" rel="noopener noreferrer">
                  <Button size="icon" variant="ghost" className="w-10 h-10 bg-white/10 hover:bg-primary/20 rounded-full transition-all duration-300 hover:scale-110">
                    <Facebook className="w-5 h-5" />
                  </Button>
                </a>
                <a href="https://www.instagram.com/earlymarketug" target="_blank" rel="noopener noreferrer">
                  <Button size="icon" variant="ghost" className="w-10 h-10 bg-white/10 hover:bg-primary/20 rounded-full transition-all duration-300 hover:scale-110">
                    <Instagram className="w-5 h-5" />
                  </Button>
                </a>
              </div>
            </div>

            {/* Footer Sections */}
            {footerSections.map((section, index) => <div key={index}>
                <h4 className="font-bold text-lg mb-6 text-white">{section.title}</h4>
                <ul className="space-y-3">
                  {section.links.map(link => <li key={link.label}>
                      <Link to={link.path} className="text-gray-400 hover:text-primary transition-colors duration-300 hover:translate-x-1 transform inline-block">
                        {link.label}
                      </Link>
                    </li>)}
                </ul>
              </div>)}
          </div>
        </div>
      </div>

      {/* Service Areas */}
      <div className="relative border-t border-gray-800">
        
      </div>

      {/* Bottom Footer */}
      <div className="relative border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-6 text-gray-400">
              <p>&copy; {currentYear} EarlyMarket Group. All rights reserved.</p>
              <div className="hidden md:flex items-center gap-1">
                <Heart className="w-4 h-4 text-red-500" />
                <span>Made with love in Uganda</span>
              </div>
            </div>
            
            <div className="flex items-center gap-6">
              
              <div className="flex items-center gap-4 text-gray-400 text-sm">
                <span className="flex items-center gap-1">
                  <Smartphone className="w-4 h-4" />
                  Mobile App Coming Soon
                </span>
                <span className="flex items-center gap-1">
                  <Truck className="w-4 h-4" />
                  Free Delivery
                </span>
                <span className="flex items-center gap-1">
                  <Shield className="w-4 h-4" />
                  Secure Payments
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>;
};
export default Footer;