import React, { useEffect, useState } from 'react';
import { BellRing } from 'lucide-react';
import { isCapacitorNative } from '@/hooks/useCapacitor';
import { toast } from 'sonner';

// Big card shown on the Notifications page in native (Capacitor) builds
// when the OS-level push permission is not yet granted. Tapping the
// primary button requests permission and registers for push.
const NativeEnableNotificationsCard: React.FC = () => {
  const [visible, setVisible] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const check = async () => {
      if (!isCapacitorNative()) return;
      try {
        const mod = await import('@capacitor/push-notifications').catch(() => null);
        if (!mod?.PushNotifications) return;
        const perm = await mod.PushNotifications.checkPermissions();
        if (!cancelled && perm.receive !== 'granted') setVisible(true);
      } catch {
        /* ignore */
      }
    };
    check();
    return () => { cancelled = true; };
  }, []);

  if (!visible) return null;

  const enable = async () => {
    setBusy(true);
    try {
      const mod = await import('@capacitor/push-notifications').catch(() => null);
      if (!mod?.PushNotifications) return;
      const perm = await mod.PushNotifications.requestPermissions();
      if (perm.receive === 'granted') {
        await mod.PushNotifications.register();
        toast.success('Notifications enabled');
        setVisible(false);
      } else {
        toast('Enable notifications from your device settings');
      }
    } catch (e) {
      toast.error('Could not enable notifications');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-4 my-4 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 via-primary/5 to-transparent p-5">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-2xl bg-primary/15 flex items-center justify-center shrink-0">
          <BellRing className="w-6 h-6 text-primary" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="text-base font-semibold text-foreground mb-1">
            Turn on notifications
          </h3>
          <p className="text-sm text-muted-foreground mb-4">
            Get instant alerts on your device for messages, new followers, orders and deals near you.
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={enable}
              disabled={busy}
              className="h-11 px-5 rounded-full bg-primary text-primary-foreground text-sm font-semibold shadow-md active:scale-[0.98] disabled:opacity-60 transition"
            >
              {busy ? 'Enabling…' : 'Enable notifications'}
            </button>
            <button
              onClick={() => setVisible(false)}
              className="h-11 px-4 rounded-full text-sm font-medium text-muted-foreground hover:text-foreground"
            >
              Not now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NativeEnableNotificationsCard;
