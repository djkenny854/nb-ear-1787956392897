import { motion } from 'framer-motion';
import { 
  Briefcase, 
  MapPin, 
  Clock, 
  DollarSign, 
  Building2, 
  Users, 
  Calendar,
  Award,
  CheckCircle2,
  GraduationCap
} from 'lucide-react';

interface JobOverviewStepProps {
  jobDetails: any;
  selectedRole?: string | null;
}

export default function JobOverviewStep({ jobDetails }: JobOverviewStepProps) {
  const jobDetail = jobDetails?.job_details;

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-4"
      >
        {jobDetails?.seller_profiles?.business_logo_url && (
          <img 
            src={jobDetails.seller_profiles.business_logo_url} 
            alt="Company logo"
            className="w-24 h-24 rounded-2xl object-cover mx-auto shadow-lg"
          />
        )}
        <h1 className="text-4xl md:text-5xl font-bold">{jobDetails?.title}</h1>
        <p className="text-xl text-muted-foreground">
          {jobDetails?.seller_profiles?.business_name}
        </p>
      </motion.div>

      {/* Key Info Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4"
      >
        {jobDetail?.job_type && (
          <div className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm">
            <Briefcase className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm text-muted-foreground">Job Type</p>
            <p className="font-semibold text-lg">{jobDetail.job_type}</p>
          </div>
        )}
        
        {jobDetails?.location && (
          <div className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm">
            <MapPin className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm text-muted-foreground">Location</p>
            <p className="font-semibold text-lg">{jobDetails.location}</p>
          </div>
        )}

        {jobDetail?.location_type && (
          <div className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm">
            <Building2 className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm text-muted-foreground">Work Type</p>
            <p className="font-semibold text-lg capitalize">{jobDetail.location_type}</p>
          </div>
        )}

        {(jobDetail?.salary_min || jobDetail?.salary_max) && (
          <div className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm">
            <DollarSign className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm text-muted-foreground">Salary Range</p>
            <p className="font-semibold text-lg">
              {jobDetail.salary_currency} {jobDetail.salary_min?.toLocaleString()} - {jobDetail.salary_max?.toLocaleString()}
            </p>
          </div>
        )}

        {jobDetail?.experience_required && (
          <div className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm">
            <Clock className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm text-muted-foreground">Experience</p>
            <p className="font-semibold text-lg">{jobDetail.experience_required}</p>
          </div>
        )}

        {jobDetail?.number_of_positions && (
          <div className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm">
            <Users className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm text-muted-foreground">Positions</p>
            <p className="font-semibold text-lg">{jobDetail.number_of_positions} Available</p>
          </div>
        )}

        {jobDetail?.application_deadline && (
          <div className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm">
            <Calendar className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm text-muted-foreground">Deadline</p>
            <p className="font-semibold text-lg">
              {new Date(jobDetail.application_deadline).toLocaleDateString()}
            </p>
          </div>
        )}

        {jobDetail?.education_level && (
          <div className="p-4 bg-primary/5 rounded-xl backdrop-blur-sm">
            <Award className="w-5 h-5 text-primary mb-2" />
            <p className="text-sm text-muted-foreground">Education</p>
            <p className="font-semibold text-lg">{jobDetail.education_level}</p>
          </div>
        )}
      </motion.div>

      {/* Description */}
      {jobDetails?.description && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-3"
        >
          <h2 className="text-2xl font-bold">Job Description</h2>
          <p className="text-muted-foreground leading-relaxed whitespace-pre-line">
            {jobDetails.description}
          </p>
        </motion.div>
      )}

      {/* Requirements */}
      {jobDetail?.requirements && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="space-y-4"
        >
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <CheckCircle2 className="w-6 h-6 text-primary" />
            Requirements
          </h2>
          <div className="bg-muted/30 p-6 rounded-xl">
            <ul className="space-y-2">
              {jobDetail.requirements.split('\n').filter((line: string) => line.trim()).map((req: string, i: number) => (
                <li key={i} className="flex items-start gap-3 text-muted-foreground">
                  <CheckCircle2 className="w-4 h-4 text-primary mt-1 flex-shrink-0" />
                  <span className="leading-relaxed">{req.trim().replace(/^[-•*]\s*/, '')}</span>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>
      )}

      {/* Skills */}
      {jobDetail?.skills_required && jobDetail.skills_required.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="space-y-3"
        >
          <h2 className="text-2xl font-bold">Required Skills</h2>
          <div className="flex flex-wrap gap-2">
            {jobDetail.skills_required.map((skill: string, index: number) => (
              <div
                key={index}
                className="px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium"
              >
                {skill}
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* Benefits */}
      {jobDetail?.benefits && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="space-y-3"
        >
          <h2 className="text-2xl font-bold">Benefits</h2>
          <p className="text-muted-foreground leading-relaxed whitespace-pre-line">
            {jobDetail.benefits}
          </p>
        </motion.div>
      )}

      {/* Application Requirements */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="space-y-4 p-6 bg-primary/5 rounded-xl border border-primary/20"
      >
        <h2 className="text-2xl font-bold text-primary">Application Requirements</h2>
        <div className="space-y-3">
          {jobDetail?.cv_required && (
            <div className="flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold">Resume/CV Required</p>
                <p className="text-sm text-muted-foreground">You must upload your resume to apply for this position</p>
              </div>
            </div>
          )}
          {jobDetail?.application_deadline && (
            <div className="flex items-start gap-3">
              <Calendar className="w-5 h-5 text-primary mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold">Application Deadline</p>
                <p className="text-sm text-muted-foreground">
                  Submit your application before {new Date(jobDetail.application_deadline).toLocaleDateString('en-US', { 
                    weekday: 'long', 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </p>
              </div>
            </div>
          )}
          {jobDetail?.use_earlymarket_system === false && (
            <div className="flex items-start gap-3 p-4 bg-amber-500/10 border border-amber-500/20 rounded-lg">
              <Award className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold text-amber-900 dark:text-amber-100">External Application</p>
                <p className="text-sm text-amber-800 dark:text-amber-200">
                  This employer uses their own application system. You'll be redirected to apply directly.
                </p>
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* How to Apply & Contact */}
      {(jobDetail?.contact_email || jobDetail?.contact_phone || jobDetail?.allow_direct_calls) && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.55 }}
          className="space-y-4 p-6 bg-muted/30 rounded-xl"
        >
          <h2 className="text-2xl font-bold">Contact Information</h2>
          <div className="space-y-3">
            {jobDetail.contact_email && (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Award className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <p className="font-semibold">{jobDetail.contact_email}</p>
                </div>
              </div>
            )}
            {jobDetail.contact_phone && (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Award className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <p className="font-semibold">{jobDetail.contact_phone}</p>
                  {jobDetail.allow_direct_calls && (
                    <p className="text-xs text-green-600 dark:text-green-400">Direct calls welcome</p>
                  )}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      )}

      {/* Terms & Conditions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="space-y-4 p-6 bg-muted/30 rounded-xl border border-border"
      >
        <h2 className="text-2xl font-bold">Terms & Conditions</h2>
        <div className="space-y-3 text-sm text-muted-foreground">
          <p>By applying to this position, you acknowledge and agree to the following:</p>
          <ul className="list-disc list-inside space-y-2 ml-2">
            <li>All information provided in your application is accurate and truthful</li>
            <li>The employer may contact you via the email or phone number provided</li>
            <li>Your application materials (resume, cover letter) will be shared with the employer</li>
            <li>The employer reserves the right to verify your credentials and conduct background checks</li>
            <li>Submitting an application does not guarantee an interview or job offer</li>
            <li>You understand this platform facilitates job applications but employment decisions are made solely by the employer</li>
          </ul>
          {jobDetail?.employment_duration && (
            <p className="pt-3 border-t border-border">
              <span className="font-semibold text-foreground">Employment Duration:</span> {jobDetail.employment_duration}
            </p>
          )}
        </div>
      </motion.div>

      {/* Company Info */}
      {jobDetail?.about_company && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.65 }}
          className="space-y-3 p-6 bg-muted/30 rounded-2xl"
        >
          <h2 className="text-2xl font-bold">About the Company</h2>
          <p className="text-muted-foreground leading-relaxed whitespace-pre-line">
            {jobDetail.about_company}
          </p>
        </motion.div>
      )}

      {jobDetails?.seller_profiles?.business_bio && !jobDetail?.about_company && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.65 }}
          className="space-y-3 p-6 bg-muted/30 rounded-2xl"
        >
          <h2 className="text-2xl font-bold">About the Company</h2>
          <p className="text-muted-foreground leading-relaxed">
            {jobDetails.seller_profiles.business_bio}
          </p>
        </motion.div>
      )}
    </div>
  );
}
