import { motion } from 'framer-motion';
import { Upload, FileText, FileCheck, MessageSquare, StickyNote } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/hooks/use-toast';

interface ApplicationMaterialsStepProps {
  formData: {
    coverLetter: string;
    notes: string;
  };
  setFormData: (data: any) => void;
  resumeFile: File | null;
  setResumeFile: (file: File | null) => void;
  cvRequired?: boolean;
  coverLetterRequired?: boolean;
}

export default function ApplicationMaterialsStep({ 
  formData, 
  setFormData,
  resumeFile,
  setResumeFile,
  cvRequired = true,
  coverLetterRequired = false,
}: ApplicationMaterialsStepProps) {
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({ 
          title: 'File too large', 
          description: 'Resume must be under 5MB', 
          variant: 'destructive' 
        });
        return;
      }
      setResumeFile(file);
    }
  };

  const showCV = cvRequired;
  const showCoverLetter = coverLetterRequired;

  return (
    <div className="space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <h2 className="text-3xl md:text-4xl font-bold">Application Materials</h2>
        <p className="text-muted-foreground text-lg">
          {showCV || showCoverLetter 
            ? 'Share your documents and tell us why you\'re the perfect fit'
            : 'Tell us why you\'re the perfect fit for this role'}
        </p>
      </motion.div>

      <div className="max-w-2xl mx-auto space-y-8">
        {/* Resume Upload - only if CV required */}
        {showCV && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="space-y-4"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <FileText className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <Label className="text-base font-semibold">
                  Resume/CV *
                </Label>
                <p className="text-sm text-muted-foreground">
                  Upload your latest resume (PDF, DOC, DOCX - Max 5MB)
                </p>
              </div>
            </div>

            <label
              htmlFor="resume"
              className={`flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-2xl cursor-pointer transition-all ${
                resumeFile 
                  ? 'border-primary bg-primary/5' 
                  : 'border-muted-foreground/20 hover:border-primary/50 bg-muted/10'
              }`}
            >
              <div className="flex flex-col items-center justify-center p-8 text-center">
                {resumeFile ? (
                  <>
                    <FileCheck className="w-16 h-16 mb-4 text-primary" />
                    <p className="text-lg font-semibold mb-2">{resumeFile.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {(resumeFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                    <p className="text-sm text-primary mt-4">Click to change file</p>
                  </>
                ) : (
                  <>
                    <Upload className="w-16 h-16 mb-4 text-muted-foreground" />
                    <p className="text-lg font-semibold mb-2">
                      Drop your resume here or click to browse
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Supports PDF, DOC, and DOCX files up to 5MB
                    </p>
                  </>
                )}
              </div>
            </label>
            <input
              id="resume"
              type="file"
              accept=".pdf,.doc,.docx"
              onChange={handleFileChange}
              className="hidden"
              required
            />
          </motion.div>
        )}

        {/* Cover Letter - only if required */}
        {showCoverLetter && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="space-y-4"
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                <MessageSquare className="w-6 h-6 text-primary" />
              </div>
              <div className="flex-1">
                <Label htmlFor="coverLetter" className="text-base font-semibold">
                  Cover Letter {coverLetterRequired ? '*' : '(Optional)'}
                </Label>
                <p className="text-sm text-muted-foreground">
                  Tell us why you're interested in this role
                </p>
              </div>
            </div>
            <Textarea
              id="coverLetter"
              value={formData.coverLetter}
              onChange={(e) => setFormData((prev: any) => ({ ...prev, coverLetter: e.target.value }))}
              placeholder="Dear Hiring Manager,&#10;&#10;I am excited to apply for this position because..."
              rows={8}
              className="text-base border-2 resize-none"
            />
          </motion.div>
        )}

        {/* Additional Notes - always show */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: showCV || showCoverLetter ? 0.3 : 0.1 }}
          className="space-y-4"
        >
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <StickyNote className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <Label htmlFor="notes" className="text-base font-semibold">
                Additional Notes
              </Label>
              <p className="text-sm text-muted-foreground">
                Optional - Any other information you'd like to share
              </p>
            </div>
          </div>
          <Textarea
            id="notes"
            value={formData.notes}
            onChange={(e) => setFormData((prev: any) => ({ ...prev, notes: e.target.value }))}
            placeholder="Portfolio links, availability, references, etc."
            rows={4}
            className="text-base border-2 resize-none"
          />
        </motion.div>
      </div>
    </div>
  );
}