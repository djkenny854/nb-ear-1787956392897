import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Eye, Heart, Users, FileText, TrendingUp } from 'lucide-react';
import { format, subDays } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';

interface Props {
  sellerId: string;
  /** When provided, analytics are scoped to a single workspace (ad). */
  adId?: string;
}

interface DailyRow {
  day: string;
  views: number;
  engagements: number;
  new_followers: number;
  updates_count: number;
}

export default function WorkspaceAnalyticsTab({ sellerId, adId }: Props) {
  const { data, isLoading } = useQuery({
    queryKey: ['workspace-analytics', sellerId, adId || 'all'],
    queryFn: async () => {
      const sinceDate = subDays(new Date(), 29);
      const since = format(sinceDate, 'yyyy-MM-dd');
      const sinceIso = sinceDate.toISOString();

      // Per-workspace mode: aggregate content_views / content_clicks for this ad only
      if (adId) {
        const [viewsRes, clicksRes, updatesRes] = await Promise.all([
          supabase
            .from('content_views')
            .select('created_at')
            .eq('content_id', adId)
            .gte('created_at', sinceIso),
          supabase
            .from('content_clicks')
            .select('created_at')
            .eq('content_id', adId)
            .gte('created_at', sinceIso),
          supabase
            .from('service_updates' as any)
            .select('created_at')
            .eq('service_id', adId)
            .gte('created_at', sinceIso),
        ]);

        const byDay = new Map<string, DailyRow>();
        const ensure = (day: string) => {
          let r = byDay.get(day);
          if (!r) {
            r = { day, views: 0, engagements: 0, new_followers: 0, updates_count: 0 };
            byDay.set(day, r);
          }
          return r;
        };
        // seed 30 days
        for (let i = 29; i >= 0; i--) ensure(format(subDays(new Date(), i), 'yyyy-MM-dd'));

        (viewsRes.data || []).forEach((r: any) => {
          const d = (r.created_at || '').slice(0, 10);
          if (d) ensure(d).views += 1;
        });
        (clicksRes.data || []).forEach((r: any) => {
          const d = (r.created_at || '').slice(0, 10);
          if (d) ensure(d).engagements += 1;
        });
        (updatesRes.data || []).forEach((r: any) => {
          const d = (r.created_at || '').slice(0, 10);
          if (d) ensure(d).updates_count += 1;
        });

        return Array.from(byDay.values()).sort((a, b) => a.day.localeCompare(b.day));
      }

      // Fallback: per-seller aggregated view
      const { data, error } = await supabase
        .from('workspace_analytics_daily' as any)
        .select('day, views, engagements, new_followers, updates_count')
        .eq('seller_id', sellerId)
        .gte('day', since)
        .order('day', { ascending: true });
      if (error) throw error;
      return (data || []) as unknown as DailyRow[];
    },
    enabled: !!sellerId,
  });

  const totals = (data || []).reduce(
    (acc, r) => ({
      views: acc.views + (r.views || 0),
      engagements: acc.engagements + (r.engagements || 0),
      new_followers: acc.new_followers + (r.new_followers || 0),
      updates_count: acc.updates_count + (r.updates_count || 0),
    }),
    { views: 0, engagements: 0, new_followers: 0, updates_count: 0 },
  );

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-2xl" />
        ))}
      </div>
    );
  }

  const cards = [
    { icon: Eye, label: 'Views', value: totals.views, color: 'text-sky-500 bg-sky-500/10' },
    { icon: Heart, label: 'Engagements', value: totals.engagements, color: 'text-pink-500 bg-pink-500/10' },
    { icon: Users, label: 'New followers', value: totals.new_followers, color: 'text-emerald-500 bg-emerald-500/10' },
    { icon: FileText, label: 'Updates posted', value: totals.updates_count, color: 'text-primary bg-primary/10' },
  ];

  const maxVal = Math.max(1, ...(data || []).map((r) => r.views + r.engagements));

  return (
    <div className="space-y-6">
      <p className="text-xs text-muted-foreground">Last 30 days</p>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border border-border bg-card p-4">
            <div className={`h-9 w-9 rounded-xl flex items-center justify-center ${c.color}`}>
              <c.icon className="h-4 w-4" />
            </div>
            <p className="mt-3 text-2xl font-semibold tracking-tight">{c.value.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground">{c.label}</p>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-border bg-card p-4">
        <div className="flex items-center gap-2 mb-3">
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
          <p className="text-sm font-medium">Daily activity</p>
        </div>
        {(data || []).length === 0 ? (
          <p className="py-10 text-center text-sm text-muted-foreground">
            No activity yet — post your first update to start the chart.
          </p>
        ) : (
          <div className="flex items-end gap-1 h-32">
            {(data || []).map((r) => {
              const total = (r.views || 0) + (r.engagements || 0);
              const h = Math.max(4, (total / maxVal) * 100);
              return (
                <div key={r.day} className="flex-1 flex flex-col items-center gap-1 min-w-0" title={`${r.day}: ${total}`}>
                  <div
                    className="w-full rounded-t bg-primary/70 hover:bg-primary transition-colors"
                    style={{ height: `${h}%` }}
                  />
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
