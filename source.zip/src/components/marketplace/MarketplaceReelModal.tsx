import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ExternalLink, Volume2, VolumeX, Play, Pause } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { videoCdnUrl } from '@/utils/cdnUrl';
import { FALLBACK_THUMBNAIL, onImageError } from '@/utils/fallbackImage';
import SmartVideo from '@/components/media/SmartVideo';
import { useVideoModal } from '@/contexts/VideoModalContext';

interface ReelItem {
  id: string;
  title: string;
  images: string[] | null;
  b2_video_url: string | null;
  youtube_url: string | null;
  tiktok_url: string | null;
  price: number | null;
  location: string | null;
}

interface Props {
  open: boolean;
  onClose: () => void;
  item: ReelItem;
  originRect: DOMRect;
}

const MarketplaceReelModal: React.FC<Props> = ({ open, onClose, item, originRect }) => {
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const { globalMuted, setGlobalMuted, setIsVideoModalOpen } = useVideoModal();
  const [playing, setPlaying] = useState(true);

  useEffect(() => {
    setIsVideoModalOpen(open);
    return () => setIsVideoModalOpen(false);
  }, [open, setIsVideoModalOpen]);

  const thumb = item.images?.[0] || FALLBACK_THUMBNAIL;
  const src = item.b2_video_url ? videoCdnUrl(item.b2_video_url) : null;

  // Compute origin transform for scale-from-tile animation
  const vw = typeof window !== 'undefined' ? window.innerWidth : 375;
  const vh = typeof window !== 'undefined' ? window.innerHeight : 812;
  const originX = originRect.left + originRect.width / 2;
  const originY = originRect.top + originRect.height / 2;
  const scaleX = originRect.width / vw;
  const scaleY = originRect.height / vh;
  const translateX = originX - vw / 2;
  const translateY = originY - vh / 2;

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[100] bg-black"
          style={{ transformOrigin: `${originX}px ${originY}px` }}
          initial={{ opacity: 0, x: translateX, y: translateY, scaleX, scaleY }}
          animate={{ opacity: 1, x: 0, y: 0, scaleX: 1, scaleY: 1 }}
          exit={{ opacity: 0, x: translateX, y: translateY, scaleX, scaleY }}
          transition={{ type: 'tween', duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="relative w-full h-full flex items-center justify-center">
            {src ? (
              <SmartVideo
                ref={videoRef}
                src={src}
                poster={thumb}
                autoPlay
                loop
                playsInline
                muted={globalMuted}
                className="w-full h-full object-contain bg-black"
                onClick={() => {
                  const v = videoRef.current;
                  if (!v) return;
                  if (v.paused) { v.play(); setPlaying(true); } else { v.pause(); setPlaying(false); }
                }}
              />
            ) : (
              <div className="relative w-full h-full">
                <img
                  src={thumb}
                  alt={item.title}
                  onError={onImageError}
                  className="w-full h-full object-contain"
                />
                {(item.youtube_url || item.tiktok_url) && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <button
                      onClick={() => window.open(item.youtube_url || item.tiktok_url || '', '_blank')}
                      className="px-4 py-2 rounded-full bg-white text-black font-medium text-sm"
                    >
                      Open video
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* Top controls */}
            <div className="absolute top-0 inset-x-0 flex items-center justify-between p-4 pt-[calc(env(safe-area-inset-top)+12px)] bg-gradient-to-b from-black/60 to-transparent">
              <button
                onClick={onClose}
                className="w-10 h-10 rounded-full bg-black/50 backdrop-blur flex items-center justify-center text-white active:scale-95 transition"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2">
                {src && (
                  <button
                    onClick={() => setGlobalMuted(!globalMuted)}
                    className="w-10 h-10 rounded-full bg-black/50 backdrop-blur flex items-center justify-center text-white"
                    aria-label={globalMuted ? 'Unmute' : 'Mute'}
                  >
                    {globalMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                  </button>
                )}
              </div>
            </div>

            {/* Play/pause overlay when paused */}
            {src && !playing && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <div className="w-16 h-16 rounded-full bg-black/50 backdrop-blur flex items-center justify-center">
                  <Play className="w-8 h-8 text-white" fill="currentColor" />
                </div>
              </div>
            )}

            {/* Bottom info */}
            <div className="absolute bottom-0 inset-x-0 p-4 pb-[calc(env(safe-area-inset-bottom)+16px)] bg-gradient-to-t from-black/80 via-black/40 to-transparent">
              <p className="text-white text-base font-semibold line-clamp-2 mb-1">{item.title}</p>
              {item.price != null && (
                <p className="text-white/90 text-sm mb-3">UGX {item.price.toLocaleString()}</p>
              )}
              <button
                onClick={() => {
                  onClose();
                  setTimeout(() => navigate(`/ad/${item.id}`), 200);
                }}
                className="w-full py-3 rounded-xl bg-white text-black font-semibold flex items-center justify-center gap-2 active:scale-[0.98] transition"
              >
                <ExternalLink className="w-4 h-4" />
                View listing
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default MarketplaceReelModal;
