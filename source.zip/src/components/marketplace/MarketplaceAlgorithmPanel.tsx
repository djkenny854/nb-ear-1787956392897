import React, { useEffect, useMemo, useState } from 'react';
import { ChevronRight, Plus, MapPin, SlidersHorizontal, X, Loader2, Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import useServiceCategories from '@/hooks/useServiceCategories';
import AlgorithmAISummary from './AlgorithmAISummary';

export type MarketplaceTab = 'products' | 'accounts' | 'jobs' | 'services' | 'promos' | 'deals';

interface TabConfig {
  headline: string;
  moreLabel: string;
  moreSubtitle: string;
  lessLabel: string;
  suggestions: string[];
  extraFilters: string[];
}

const CONFIG: Record<MarketplaceTab, TabConfig> = {
  services: {
    headline: "Lately you've been into home repairs, photography and tailoring.",
    moreLabel: 'What services you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Near me', 'Plumbing', 'Hair & beauty', 'Cleaning', 'Photography', 'Tutoring', 'Catering', 'Tailoring', 'Mechanics', 'Event planning'],
    extraFilters: ['Verified only', 'Top rated', 'Has portfolio', 'Available today', 'Accepts mobile money', 'Same-day service'],
  },
  jobs: {
    headline: "Lately you've been browsing tech roles, sales gigs and remote work.",
    moreLabel: 'What kinds of jobs you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Near me', 'Remote', 'Full-time', 'Part-time', 'Internship', 'Contract', 'Software', 'Sales', 'Marketing', 'Driving', 'Customer support', 'Construction', 'Hospitality', 'Healthcare', 'Education'],
    extraFilters: ['Verified employers', 'Posted this week', 'No experience needed', 'Pays in USD', 'Urgent hire'],
  },
  accounts: {
    headline: "Lately you've been following local shops, creators and verified sellers.",
    moreLabel: 'What kinds of accounts you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Verified only', 'Near me', 'Top rated', 'New sellers', 'Fashion', 'Electronics', 'Food', 'Auto', 'Beauty', 'Home'],
    extraFilters: ['Verified only', 'Active this week', '4+ stars', 'Has video'],
  },
  promos: {
    headline: "Lately you've been into flash deals, weekend discounts and free shipping offers.",
    moreLabel: 'What promotions you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Near me', 'Flash sales', 'Free shipping', 'BOGO', 'Clearance', 'Fashion', 'Electronics', 'Food & drink', 'Beauty', 'Bundles'],
    extraFilters: ['Ends today', 'Ends in 3 days', 'Ends in 7 days', '50%+ off', 'Verified sellers'],
  },
  deals: {
    headline: "Lately you've been eyeing discounted electronics, fashion and home picks.",
    moreLabel: 'What deals you want to see more of',
    moreSubtitle: 'Based on your activity, summarised by AI',
    lessLabel: 'What you want to see less of',
    suggestions: ['Near me', 'Ending soon', 'Biggest discounts', 'Electronics', 'Fashion', 'Home', 'Beauty', 'Phones', 'Groceries', 'Under 50%'],
    extraFilters: ['Ends today', '50%+ off', 'Verified sellers', 'Free delivery'],
  },
  products: {
    headline: '',
    moreLabel: '',
    moreSubtitle: '',
    lessLabel: '',
    suggestions: [],
    extraFilters: [],
  },
};

const requestNearMe = async (): Promise<boolean> => {
  if (!('geolocation' in navigator)) {
    toast.error('Geolocation is not supported on this device');
    return false;
  }
  return new Promise((resolve) => {
    toast.message('Requesting your location…');
    navigator.geolocation.getCurrentPosition(
      () => {
        toast.success('Location detected — showing results near you');
        resolve(true);
      },
      (err) => {
        toast.error(err.code === err.PERMISSION_DENIED
          ? 'Location permission denied. Enable it in your browser settings.'
          : 'Could not detect your location');
        resolve(false);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  });
};

interface PanelBodyProps {
  tab: MarketplaceTab;
  draftSelected: string[];
  draftExcluded: string[];
  setDraftSelected: (next: string[]) => void;
  setDraftExcluded: (next: string[]) => void;
  onSave: () => void;
  saving?: boolean;
  inDrawer?: boolean;
}

const PanelBody: React.FC<PanelBodyProps> = ({
  tab,
  draftSelected,
  draftExcluded,
  setDraftSelected,
  setDraftExcluded,
  onSave,
  saving,
  inDrawer,
}) => {
  const cfg = CONFIG[tab];
  const { categories } = useServiceCategories();

  const categoryNames = useMemo(() => {
    if (tab === 'services') {
      return (categories || []).filter((c) => !c.parent_id).map((c) => c.name).slice(0, 24);
    }
    return [];
  }, [tab, categories]);

  const toggleSelected = async (s: string) => {
    if (s === 'Near me' && !draftSelected.includes(s)) {
      const ok = await requestNearMe();
      if (!ok) return;
    }
    setDraftSelected(
      draftSelected.includes(s) ? draftSelected.filter((x) => x !== s) : [...draftSelected, s]
    );
  };
  const toggleExcluded = (s: string) =>
    setDraftExcluded(
      draftExcluded.includes(s) ? draftExcluded.filter((x) => x !== s) : [...draftExcluded, s]
    );

  const allActive = draftSelected.length === 0;
  const visibleSuggestions = cfg.suggestions.filter((s) => !draftSelected.includes(s));
  const visibleCategories = categoryNames.filter((s) => !draftSelected.includes(s));
  const visibleExtras = cfg.extraFilters.filter((s) => !draftSelected.includes(s));

  return (
    <div className="flex flex-col h-full min-h-0">
      {inDrawer && (
        <h2 className="text-lg font-bold text-foreground mb-3 pr-8">Your algorithm</h2>
      )}

      <div className="flex-1 min-h-0 overflow-y-auto pr-1 pb-4">
        {/* Big AI headline — dynamic, summarised by EarlyMarket AI */}
        <AlgorithmAISummary tab={tab} selected={draftSelected} excluded={draftExcluded} />

        {/* More of */}
        <div className="mt-7">
          <h3 className="text-sm font-semibold text-foreground">{cfg.moreLabel}</h3>
          <button className="mt-0.5 inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors">
            {cfg.moreSubtitle}
            <ChevronRight className="h-3 w-3" />
          </button>

          <div className="mt-3 flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => setDraftSelected([])}
              className={cn(
                'px-3.5 h-8 rounded-full text-xs font-medium border transition-colors',
                allActive
                  ? 'bg-foreground text-background border-foreground'
                  : 'bg-transparent border-border text-foreground hover:bg-muted'
              )}
            >
              All
            </button>

            {draftSelected.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => toggleSelected(s)}
                className="px-3.5 h-8 rounded-full text-xs font-medium bg-foreground text-background border border-foreground transition-colors inline-flex items-center gap-1.5"
              >
                {s}
                <X className="h-3 w-3" />
              </button>
            ))}

            {visibleSuggestions.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => toggleSelected(s)}
                className="px-3.5 h-8 rounded-full text-xs font-medium bg-transparent border border-border/70 text-muted-foreground hover:text-foreground hover:border-border transition-colors inline-flex items-center gap-1.5"
              >
                {s === 'Near me' ? <MapPin className="h-3 w-3" /> : <Plus className="h-3 w-3" />}
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Categories */}
        {visibleCategories.length > 0 && (
          <div className="mt-7">
            <h3 className="text-sm font-semibold text-foreground">Categories</h3>
            <p className="mt-0.5 text-xs text-muted-foreground">Pick the categories you want featured</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {visibleCategories.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => toggleSelected(s)}
                  className="px-3.5 h-8 rounded-full text-xs font-medium bg-transparent border border-border/70 text-muted-foreground hover:text-foreground hover:border-border transition-colors inline-flex items-center gap-1.5"
                >
                  <Plus className="h-3 w-3" />
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Extra filters */}
        {visibleExtras.length > 0 && (
          <div className="mt-7">
            <h3 className="text-sm font-semibold text-foreground">More filters</h3>
            <p className="mt-0.5 text-xs text-muted-foreground">Refine results beyond categories</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {visibleExtras.map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => toggleSelected(s)}
                  className="px-3.5 h-8 rounded-full text-xs font-medium bg-transparent border border-border/70 text-muted-foreground hover:text-foreground hover:border-border transition-colors inline-flex items-center gap-1.5"
                >
                  <Plus className="h-3 w-3" />
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Less of */}
        <div className="mt-8">
          <h3 className="text-sm font-semibold text-foreground">{cfg.lessLabel}</h3>
          <div className="mt-3 flex flex-wrap gap-2">
            {draftExcluded.map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => toggleExcluded(s)}
                className="px-3.5 h-8 rounded-full text-xs font-medium bg-muted text-foreground border border-border hover:bg-muted/70 transition-colors inline-flex items-center gap-1.5"
              >
                {s}
                <X className="h-3 w-3" />
              </button>
            ))}
            <button
              type="button"
              onClick={() => {
                const v = window.prompt('Add something to see less of');
                if (v && !draftExcluded.includes(v)) toggleExcluded(v);
              }}
              className="px-3.5 h-8 rounded-full text-xs font-medium bg-transparent border border-border/70 text-muted-foreground hover:text-foreground hover:border-border transition-colors inline-flex items-center gap-1.5"
            >
              <Plus className="h-3 w-3" />
              Add
            </button>
          </div>
        </div>
        {/* Spacer so last chips clear the fixed save bar */}
        <div className="h-6" aria-hidden />
      </div>

      {/* Fixed save bar — flex sibling, never overlaps scroll content */}
      <div className={cn(
        'shrink-0 pt-3 pb-3 bg-gradient-to-t from-background via-background/95 to-background/70 border-t border-border/40',
        inDrawer && 'pb-6'
      )}>
        <Button
          onClick={onSave}
          disabled={saving}
          className="w-full h-11 rounded-full font-semibold"
        >
          {saving ? (
            <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving…</>
          ) : (
            <><Check className="h-4 w-4 mr-2" /> Save & apply</>
          )}
        </Button>
      </div>
    </div>
  );
};

interface MarketplaceAlgorithmPanelProps {
  tab: MarketplaceTab;
  selected: string[];
  excluded: string[];
  onApply: (next: { selected: string[]; excluded: string[] }) => void;
  variant?: 'sidebar' | 'mobile-trigger';
  /** Controlled open state for the mobile drawer (optional). */
  open?: boolean;
  onOpenChange?: (v: boolean) => void;
  /** Hide the built-in mobile trigger button (when controlled externally). */
  hideTrigger?: boolean;
}

const MarketplaceAlgorithmPanel: React.FC<MarketplaceAlgorithmPanelProps> = ({
  tab,
  selected,
  excluded,
  onApply,
  variant,
  open: openProp,
  onOpenChange,
  hideTrigger,
}) => {
  const [openInternal, setOpenInternal] = useState(false);
  const isControlled = openProp !== undefined;
  const open = isControlled ? openProp! : openInternal;
  const setOpen = (v: boolean) => {
    if (isControlled) onOpenChange?.(v);
    else setOpenInternal(v);
  };
  const [saving, setSaving] = useState(false);

  // Local draft — syncs from props
  const [draftSelected, setDraftSelected] = useState<string[]>(selected);
  const [draftExcluded, setDraftExcluded] = useState<string[]>(excluded);

  useEffect(() => setDraftSelected(selected), [selected, tab]);
  useEffect(() => setDraftExcluded(excluded), [excluded, tab]);

  // Don't render anything on products tab
  if (tab === 'products') return null;

  const handleSave = async () => {
    setSaving(true);
    onApply({ selected: draftSelected, excluded: draftExcluded });
    // brief visual confirmation; parent triggers skeleton via queryKey
    await new Promise((r) => setTimeout(r, 350));
    setSaving(false);
    setOpen(false);
    toast.success('Your algorithm has been updated');
  };

  const showSidebar = variant !== 'mobile-trigger';
  const showMobile = variant !== 'sidebar';

  return (
    <>
      {showSidebar && (
        <aside className="hidden lg:block w-[340px] xl:w-[380px] shrink-0 mt-14 xl:mt-16">
          <div className="sticky top-20 h-[calc(100vh-6rem)] overflow-hidden pl-2 pr-1 pt-2 pb-2 flex flex-col">
            <PanelBody
              tab={tab}
              draftSelected={draftSelected}
              draftExcluded={draftExcluded}
              setDraftSelected={setDraftSelected}
              setDraftExcluded={setDraftExcluded}
              onSave={handleSave}
              saving={saving}
            />
          </div>
        </aside>
      )}

      {showMobile && (
        <div className="lg:hidden">
          <Sheet open={open} onOpenChange={setOpen}>
            {!hideTrigger && (
            <SheetTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="rounded-full gap-1.5 h-9 px-3 text-xs"
              >
                <SlidersHorizontal className="h-3.5 w-3.5" />
                Your algorithm
                {(selected.length + excluded.length) > 0 && (
                  <span className="ml-1 inline-flex items-center justify-center min-w-[18px] h-[18px] px-1 rounded-full bg-foreground text-background text-[10px] font-semibold">
                    {selected.length + excluded.length}
                  </span>
                )}
              </Button>
            </SheetTrigger>
            )}
            <SheetContent side="bottom" className="h-[88vh] rounded-t-2xl flex flex-col p-5">
              <PanelBody
                tab={tab}
                draftSelected={draftSelected}
                draftExcluded={draftExcluded}
                setDraftSelected={setDraftSelected}
                setDraftExcluded={setDraftExcluded}
                onSave={handleSave}
                saving={saving}
                inDrawer
              />
            </SheetContent>
          </Sheet>
        </div>
      )}
    </>
  );
};

export default MarketplaceAlgorithmPanel;
