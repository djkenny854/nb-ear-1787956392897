import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Percent, Tag } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card } from '@/components/ui/card';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';
import RollingCountdown from './RollingCountdown';

interface Deal {
  id: string;
  title: string;
  price: number | null;
  originalPrice: number | null;
  images: string[];
  discountPercent: number;
  endsAt: string | null;
  sellerName: string;
  sellerLogo?: string;
  isVerified?: boolean;
  badgeColor?: any;
}

const formatUGX = (n: number) => `UGX ${new Intl.NumberFormat().format(Math.round(n))}`;

const DealsSkeletonRow: React.FC = () => (
  <div className="flex items-start gap-4 py-4 border-b border-border/40 animate-pulse">
    <div className="flex-1 min-w-0 space-y-2">
      <div className="h-4 w-3/4 rounded bg-muted" />
      <div className="h-3 w-1/3 rounded bg-muted/70" />
      <div className="h-3 w-1/2 rounded bg-muted/60" />
      <div className="flex -space-x-2 pt-1">
        {[0, 1, 2].map((i) => <div key={i} className="h-5 w-5 rounded-full bg-muted border-2 border-background" />)}
      </div>
    </div>
    <div className="h-16 w-16 sm:h-[72px] sm:w-[72px] rounded-full bg-muted shrink-0" />
  </div>
);

const MarketplaceDealsList: React.FC = () => {
  const navigate = useNavigate();

  const { data: deals = [], isLoading } = useQuery({
    queryKey: ['marketplace-deals-list'],
    queryFn: async (): Promise<Deal[]> => {
      const { data, error } = await supabase
        .from('ads')
        .select(`
          id, title, price, original_price, images, has_discount, created_at,
          seller_profiles!ads_seller_id_fkey(business_name, business_logo_url, is_verified, verification_badge_color)
        `)
        .eq('status', 'active')
        .in('listing_type', ['physical_products', 'digital_products'])
        .eq('has_discount', true)
        .not('original_price', 'is', null)
        .gt('original_price', 0)
        .order('created_at', { ascending: false })
        .limit(40);
      if (error) throw error;

      const rows = (data || []).filter(
        (r: any) => r.price && r.original_price && r.price < r.original_price,
      );

      // Fetch promotion end times for these ads (for countdown timers).
      const ids = rows.map((r: any) => r.id);
      const endMap: Record<string, string> = {};
      if (ids.length > 0) {
        const { data: promos } = await supabase
          .from('promotion_details')
          .select('ad_id, valid_until')
          .in('ad_id', ids)
          .not('valid_until', 'is', null);
        (promos || []).forEach((p: any) => {
          if (p.valid_until && new Date(p.valid_until).getTime() > Date.now()) {
            endMap[p.ad_id] = p.valid_until;
          }
        });
      }

      return rows.map((r: any) => {
        const sp = r.seller_profiles || {};
        const pct = r.original_price
          ? Math.round(((r.original_price - r.price) / r.original_price) * 100)
          : 0;
        return {
          id: r.id,
          title: r.title,
          price: r.price,
          originalPrice: r.original_price,
          images: r.images || [],
          discountPercent: pct,
          endsAt: endMap[r.id] || null,
          sellerName: sp.business_name || 'Seller',
          sellerLogo: sp.business_logo_url,
          isVerified: sp.is_verified,
          badgeColor: sp.verification_badge_color,
        };
      });
    },
    staleTime: 1000 * 60 * 5,
  });

  if (isLoading) {
    return (
      <div>
        {Array.from({ length: 6 }).map((_, i) => <DealsSkeletonRow key={i} />)}
      </div>
    );
  }

  if (!deals.length) {
    return (
      <div className="text-center py-16">
        <Card className="p-12 max-w-md mx-auto">
          <Tag className="w-10 h-10 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-3">No deals right now</h3>
          <p className="text-muted-foreground">Check back later for fresh discounts</p>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-1">
      <div className="flex items-center gap-3 pb-2">
        <div className="w-10 h-10 rounded-xl bg-destructive/15 flex items-center justify-center">
          <Percent className="w-5 h-5 text-destructive" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-foreground">Hot Deals</h2>
          <p className="text-xs text-muted-foreground">Products on discount right now</p>
        </div>
      </div>

      {deals.map((deal) => {
        const heroImage = deal.images.find((i) => i && !/\.(mp4|webm|mov|avi)$/i.test(i)) || deal.sellerLogo;
        const avatarPool = deal.images.filter((i) => i && !/\.(mp4|webm|mov|avi)$/i.test(i)).slice(0, 3);
        return (
          <article
            key={deal.id}
            onClick={() => navigate(`/ad/${deal.id}`)}
            className="group cursor-pointer w-full py-4 border-b border-border/40 last:border-b-0 hover:bg-foreground/[0.02] transition-colors -mx-1 px-1 rounded-md"
          >
            <div className="flex items-start gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <span className="inline-flex items-center gap-1 rounded-full bg-destructive/10 text-destructive text-[11px] font-bold px-2 py-0.5">
                    <Percent className="h-3 w-3" />-{deal.discountPercent}%
                  </span>
                  {deal.endsAt && <RollingCountdown endsAt={deal.endsAt} />}
                </div>

                <h3 className="font-bold text-base sm:text-[17px] leading-snug text-foreground line-clamp-2 group-hover:text-primary transition-colors">
                  {deal.title}
                </h3>

                <div className="mt-1.5 flex items-center gap-1.5 text-xs text-muted-foreground min-w-0">
                  <span className="truncate font-medium text-foreground/90">{deal.sellerName}</span>
                  {deal.isVerified && (
                    <UnifiedVerifiedBadge isVerified badgeColor={deal.badgeColor} size="sm" />
                  )}
                </div>

                <div className="mt-1.5 flex items-center gap-2">
                  <span className="text-sm font-bold text-foreground">{formatUGX(deal.price || 0)}</span>
                  {deal.originalPrice && (
                    <span className="text-xs text-muted-foreground line-through">{formatUGX(deal.originalPrice)}</span>
                  )}
                </div>

                {avatarPool.length > 0 && (
                  <div className="mt-2.5 flex -space-x-2">
                    {avatarPool.map((src, i) => (
                      <Avatar key={i} className="h-6 w-6 border-2 border-background ring-0">
                        <AvatarImage src={src} alt="" className="object-cover" />
                        <AvatarFallback className="text-[9px] bg-muted">{deal.sellerName.charAt(0)}</AvatarFallback>
                      </Avatar>
                    ))}
                  </div>
                )}
              </div>

              <div className="shrink-0">
                <div className="h-16 w-16 sm:h-[72px] sm:w-[72px] rounded-full overflow-hidden border border-border/60 bg-muted">
                  {heroImage ? (
                    <img src={heroImage} alt={deal.title} className="h-full w-full object-cover" loading="lazy" />
                  ) : (
                    <div className="h-full w-full flex items-center justify-center text-base font-semibold text-muted-foreground bg-muted">
                      {deal.sellerName.charAt(0)}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </article>
        );
      })}
    </div>
  );
};

export default MarketplaceDealsList;
