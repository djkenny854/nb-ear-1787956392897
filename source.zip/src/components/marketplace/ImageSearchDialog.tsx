import React, { useRef, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ImagePlus, Loader2, X, Camera } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import EMIIcon from '@/components/icons/EMIIcon';

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

const ImageSearchDialog: React.FC<Props> = ({ open, onOpenChange }) => {
  const { toast } = useToast();
  const navigate = useNavigate();
  const fileRef = useRef<HTMLInputElement>(null);
  const cameraRef = useRef<HTMLInputElement>(null);
  const [images, setImages] = useState<{ file: File; preview: string }[]>([]);
  const [loading, setLoading] = useState(false);

  const addFiles = (files: FileList | null) => {
    if (!files) return;
    const next = Array.from(files)
      .filter((f) => f.type.startsWith('image/'))
      .slice(0, 2 - images.length)
      .map((file) => ({ file, preview: URL.createObjectURL(file) }));
    setImages((prev) => [...prev, ...next].slice(0, 2));
  };

  const removeImage = (i: number) => {
    setImages((prev) => {
      URL.revokeObjectURL(prev[i].preview);
      return prev.filter((_, idx) => idx !== i);
    });
  };

  const handleSearch = async () => {
    if (!images.length) return;
    setLoading(true);
    try {
      const b64 = await new Promise<string>((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve((r.result as string).split(',')[1]);
        r.onerror = reject;
        r.readAsDataURL(images[0].file);
      });
      const { data, error } = await supabase.functions.invoke('image-search', {
        body: { imageBase64: b64 },
      });
      if (error) throw error;
      const q = data?.filters?.searchQuery || data?.searchQuery;
      if (q) {
        const params = new URLSearchParams({ q, contentType: 'products' });
        if (data?.filters?.category) params.set('category', data.filters.category);
        if (data?.filters?.condition) params.set('condition', data.filters.condition);
        navigate(`/search?${params.toString()}`);
        toast({ title: 'Image analyzed', description: `Searching for: ${q}` });
        setImages([]);
        onOpenChange(false);
      } else {
        toast({ title: 'No results', description: 'Could not identify products from image', variant: 'destructive' });
      }
    } catch (err: any) {
      toast({ title: 'Search failed', description: err?.message || 'Failed to analyze image', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <EMIIcon className="h-5 w-5" />
            Visual search
          </DialogTitle>
        </DialogHeader>

        <p className="text-sm text-muted-foreground -mt-2">
          Upload up to 2 images and we'll find matching products visually.
        </p>

        <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />
        <input ref={cameraRef} type="file" accept="image/*" capture="environment" className="hidden" onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />

        <div className="flex gap-3 flex-wrap">
          {images.map((img, i) => (
            <div key={i} className="relative w-24 h-24 rounded-lg overflow-hidden border border-border group">
              <img src={img.preview} alt="" className="w-full h-full object-cover" />
              <button
                onClick={() => removeImage(i)}
                className="absolute top-1 right-1 h-5 w-5 rounded-full bg-foreground/70 text-background flex items-center justify-center"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
          {images.length < 2 && (
            <>
              <button
                onClick={() => fileRef.current?.click()}
                className="w-24 h-24 rounded-lg border-2 border-dashed border-border hover:border-primary/60 flex flex-col items-center justify-center gap-1 transition-colors"
              >
                <ImagePlus className="h-5 w-5 text-muted-foreground" />
                <span className="text-[10px] text-muted-foreground">Gallery</span>
              </button>
              <button
                onClick={() => cameraRef.current?.click()}
                className="w-24 h-24 rounded-lg border-2 border-dashed border-border hover:border-primary/60 flex flex-col items-center justify-center gap-1 transition-colors"
              >
                <Camera className="h-5 w-5 text-muted-foreground" />
                <span className="text-[10px] text-muted-foreground">Camera</span>
              </button>
            </>
          )}
        </div>

        <button
          onClick={handleSearch}
          disabled={!images.length || loading}
          className="w-full h-11 rounded-lg bg-primary text-primary-foreground flex items-center justify-center gap-2 font-medium disabled:opacity-50 hover:bg-primary/90 transition-colors"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <EMIIcon className="h-4 w-4" />}
          {loading ? 'Analyzing…' : 'Search by image'}
        </button>

        <p className="text-[11px] text-muted-foreground text-center">
          Visual search is improving and may not always find exact matches.
        </p>
      </DialogContent>
    </Dialog>
  );
};

export default ImageSearchDialog;
