import React, { useEffect, useState } from 'react';

/**
 * Compact countdown timer with a rolling-digit animation (numbers roll up
 * as they change), used on deal cards to show time until a deal ends.
 */

interface Props {
  /** ISO string for when the deal ends. */
  endsAt: string;
  className?: string;
}

const getRemaining = (endsAt: string) => {
  const diff = Math.max(0, new Date(endsAt).getTime() - Date.now());
  const totalSeconds = Math.floor(diff / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return { diff, days, hours, minutes, seconds };
};

const pad = (n: number) => n.toString().padStart(2, '0');

const RollingDigit: React.FC<{ value: string }> = ({ value }) => {
  return (
    <span className="relative inline-block overflow-hidden tabular-nums" style={{ height: '1.1em', lineHeight: '1.1em' }}>
      <span key={value} className="digit-roll inline-block">
        {value}
      </span>
    </span>
  );
};

const Segment: React.FC<{ value: number; label: string }> = ({ value, label }) => {
  const str = pad(value);
  return (
    <div className="flex flex-col items-center">
      <div className="flex items-center rounded-md bg-foreground/90 text-background px-1.5 py-0.5 text-[11px] font-bold leading-none">
        <RollingDigit value={str[0]} />
        <RollingDigit value={str[1]} />
      </div>
      <span className="mt-0.5 text-[8px] uppercase tracking-wide text-muted-foreground">{label}</span>
    </div>
  );
};

const RollingCountdown: React.FC<Props> = ({ endsAt, className }) => {
  const [t, setT] = useState(() => getRemaining(endsAt));

  useEffect(() => {
    const id = setInterval(() => setT(getRemaining(endsAt)), 1000);
    return () => clearInterval(id);
  }, [endsAt]);

  if (t.diff <= 0) {
    return <span className={`text-[10px] font-semibold text-destructive ${className || ''}`}>Deal ended</span>;
  }

  return (
    <div className={`flex items-center gap-1 ${className || ''}`}>
      {t.days > 0 && (
        <>
          <Segment value={t.days} label="d" />
          <span className="text-foreground/40 text-xs font-bold -mt-2">:</span>
        </>
      )}
      <Segment value={t.hours} label="hrs" />
      <span className="text-foreground/40 text-xs font-bold -mt-2">:</span>
      <Segment value={t.minutes} label="min" />
      <span className="text-foreground/40 text-xs font-bold -mt-2">:</span>
      <Segment value={t.seconds} label="sec" />
    </div>
  );
};

export default RollingCountdown;
