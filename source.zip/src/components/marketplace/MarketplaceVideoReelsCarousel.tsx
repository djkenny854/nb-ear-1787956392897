import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Play, Video } from 'lucide-react';
import { FALLBACK_THUMBNAIL, onImageError } from '@/utils/fallbackImage';
import MarketplaceReelModal from './MarketplaceReelModal';

interface Props {
  query: string;
  category?: string | null;
}

interface ReelItem {
  id: string;
  title: string;
  images: string[] | null;
  b2_video_url: string | null;
  youtube_url: string | null;
  tiktok_url: string | null;
  price: number | null;
  location: string | null;
  seller_id: string;
}

const tokenize = (q: string) =>
  Array.from(new Set(
    q.toLowerCase().trim().split(/\s+/)
      .map(t => t.replace(/[^\p{L}\p{N}_-]+/gu, ''))
      .filter(t => t.length > 1)
  ));

const MarketplaceVideoReelsCarousel: React.FC<Props> = ({ query, category }) => {
  const [active, setActive] = useState<{ item: ReelItem; rect: DOMRect } | null>(null);

  const trimmed = query.trim();
  const enabled = trimmed.length >= 2;

  const { data: items = [] } = useQuery({
    queryKey: ['marketplace-reels', trimmed, category || null],
    enabled,
    staleTime: 1000 * 60 * 2,
    queryFn: async (): Promise<ReelItem[]> => {
      const tokens = tokenize(trimmed);
      const terms = tokens.length ? tokens : [trimmed];
      const textOr = terms.flatMap(t => [
        `title.ilike.%${t}%`,
        `description.ilike.%${t}%`,
        `brand.ilike.%${t}%`,
        `model.ilike.%${t}%`,
        `category.ilike.%${t}%`,
      ]).join(',');

      // Fetch a broader set of matching ads then filter to those with any video URL.
      let q = supabase
        .from('ads')
        .select('id, title, images, b2_video_url, youtube_url, tiktok_url, price, location, seller_id')
        .eq('status', 'active')
        .or(textOr)
        .order('created_at', { ascending: false })
        .limit(40);

      if (category) q = q.ilike('category', `%${category}%`);

      const { data, error } = await q;
      if (error) {
        console.warn('[MarketplaceReels]', error);
        return [];
      }
      const all = (data || []) as ReelItem[];
      return all.filter(a => a.b2_video_url || a.youtube_url || a.tiktok_url).slice(0, 10);
    },
  });

  const visible = useMemo(
    () => items.filter(i => i.b2_video_url || i.youtube_url || i.tiktok_url).slice(0, 10),
    [items]
  );

  if (!enabled || visible.length === 0) return null;

  return (
    <>
      <div className="max-w-7xl mx-auto px-4 pt-2 pb-3">
        <div className="flex items-center gap-2 mb-2">
          <Video className="w-4 h-4 text-primary" />
          <h3 className="text-sm font-semibold text-foreground">Videos for "{trimmed}"</h3>
        </div>
        <div className="flex gap-3 overflow-x-auto scrollbar-none -mx-4 px-4 snap-x snap-mandatory">
          {visible.map((item) => {
            const thumb = item.images?.[0] || FALLBACK_THUMBNAIL;
            return (
              <button
                key={item.id}
                type="button"
                onClick={(e) => {
                  const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                  setActive({ item, rect });
                }}
                className="relative flex-shrink-0 w-[112px] h-[168px] rounded-2xl overflow-hidden bg-muted snap-start group active:scale-[0.97] transition-transform"
                aria-label={`Play video for ${item.title}`}
              >
                <img
                  src={thumb}
                  alt={item.title}
                  loading="lazy"
                  onError={onImageError}
                  className="absolute inset-0 w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/10 via-transparent to-black/60" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="w-9 h-9 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center shadow-md group-hover:scale-110 transition-transform">
                    <Play className="w-4 h-4 text-black translate-x-[1px]" fill="currentColor" />
                  </span>
                </div>
                <div className="absolute bottom-1.5 right-1.5 px-1.5 py-0.5 rounded-md bg-black/70 text-white text-[10px] font-medium flex items-center gap-0.5">
                  <Video className="w-2.5 h-2.5" />
                  <span>Reel</span>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-2 pt-6">
                  <p className="text-white text-[11px] font-medium line-clamp-2 leading-tight drop-shadow">
                    {item.title}
                  </p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {active && (
        <MarketplaceReelModal
          open={!!active}
          onClose={() => setActive(null)}
          item={active.item}
          originRect={active.rect}
        />
      )}
    </>
  );
};

export default MarketplaceVideoReelsCarousel;
