import React, { useEffect, useMemo, useState } from 'react';
import EarlyMarketAIIcon from '@/components/icons/EarlyMarketAIIcon';
import type { MarketplaceTab } from './MarketplaceAlgorithmPanel';

/**
 * Dynamic, "AI-summarised" headline for the marketplace algorithm panel.
 *
 * Behaviour:
 *  - Whenever the tab or the user's selections change, it shows a
 *    3-line gradient text-placeholder skeleton with the EarlyMarket AI
 *    icon wrapped in a Google-style Material spinner (the same indeterminate
 *    ring x.com uses), then reveals an intelligent, dynamic summary.
 */

const DEFAULTS: Record<MarketplaceTab, string> = {
  services: "Lately you've been into home repairs, photography and tailoring.",
  jobs: "Lately you've been browsing tech roles, sales gigs and remote work.",
  accounts: "Lately you've been following local shops, creators and verified sellers.",
  promos: "Lately you've been into flash deals, weekend discounts and free shipping offers.",
  deals: "Lately you've been eyeing discounted electronics, fashion and home picks.",
  products: '',
};

const NOUN: Record<MarketplaceTab, string> = {
  services: 'services',
  jobs: 'jobs',
  accounts: 'accounts',
  promos: 'promotions',
  deals: 'deals',
  products: 'products',
};

const humanJoin = (arr: string[]): string => {
  const items = arr.map((s) => s.toLowerCase());
  if (items.length === 0) return '';
  if (items.length === 1) return items[0];
  if (items.length === 2) return `${items[0]} and ${items[1]}`;
  return `${items.slice(0, -1).join(', ')} and ${items[items.length - 1]}`;
};

const buildSummary = (
  tab: MarketplaceTab,
  selected: string[],
  excluded: string[],
): string => {
  const noun = NOUN[tab];
  if (selected.length > 0) {
    const focus = humanJoin(selected.slice(0, 3));
    let text = `Curating more ${focus} ${noun} for you.`;
    if (excluded.length > 0) {
      text += ` Quietly hiding ${humanJoin(excluded.slice(0, 2))}.`;
    }
    return text;
  }
  if (excluded.length > 0) {
    return `Showing the best ${noun}, while keeping ${humanJoin(excluded.slice(0, 2))} out of view.`;
  }
  return DEFAULTS[tab] || `Here are the ${noun} we think you'll love.`;
};

/** Google Material indeterminate spinner ringing the EarlyMarket AI icon. */
const AISpinnerIcon: React.FC = () => (
  <span className="relative inline-flex h-6 w-6 items-center justify-center shrink-0">
    <svg className="mat-spinner absolute inset-0 h-6 w-6" viewBox="0 0 50 50" aria-hidden>
      <circle
        className="mat-spinner-path"
        cx="25"
        cy="25"
        r="20"
        fill="none"
        strokeWidth="4"
      />
    </svg>
    <EarlyMarketAIIcon className="h-3.5 w-3.5" />
  </span>
);

interface Props {
  tab: MarketplaceTab;
  selected: string[];
  excluded: string[];
}

const AlgorithmAISummary: React.FC<Props> = ({ tab, selected, excluded }) => {
  const summary = useMemo(
    () => buildSummary(tab, selected, excluded),
    [tab, selected, excluded],
  );

  const [loading, setLoading] = useState(true);

  // Re-run the "AI generation" whenever the inputs that shape the summary change.
  const signature = `${tab}|${selected.join(',')}|${excluded.join(',')}`;
  useEffect(() => {
    setLoading(true);
    const t = setTimeout(() => setLoading(false), 2000);
    return () => clearTimeout(t);
  }, [signature]);

  if (loading) {
    return (
      <div className="space-y-2.5">
        <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
          <AISpinnerIcon />
          <span>EarlyMarket AI is summarising your feed…</span>
        </div>
        <div className="space-y-2 pt-1">
          <div className="algo-skel-line h-4 w-[92%] rounded-md" />
          <div className="algo-skel-line h-4 w-[80%] rounded-md" style={{ animationDelay: '0.15s' }} />
          <div className="algo-skel-line h-4 w-[55%] rounded-md" style={{ animationDelay: '0.3s' }} />
        </div>
      </div>
    );
  }

  return (
    <div className="animate-fade-in">
      <div className="flex items-center gap-1.5 text-[11px] font-medium text-muted-foreground mb-2">
        <EarlyMarketAIIcon className="h-3.5 w-3.5" />
        <span>Summarised by EarlyMarket AI</span>
      </div>
      <p className="text-[22px] sm:text-[24px] leading-tight font-bold text-foreground">
        {summary}
      </p>
    </div>
  );
};

export default AlgorithmAISummary;
