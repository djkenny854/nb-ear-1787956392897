import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { toast } from 'sonner';
import { Circle, Clock, XCircle, AlertCircle, Megaphone } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ServiceStatusType } from './ServiceStatusBadge';

interface ServiceStatusUpdaterProps {
  sellerId: string;
  currentStatus?: ServiceStatusType;
  currentMessage?: string | null;
  onUpdate?: () => void;
}

const statusOptions: { value: ServiceStatusType; label: string; icon: React.ElementType; description: string }[] = [
  { value: 'available', label: 'Available', icon: Circle, description: 'Ready to take new clients' },
  { value: 'busy', label: 'Busy', icon: Clock, description: 'Currently working, limited availability' },
  { value: 'limited_slots', label: 'Limited Slots', icon: AlertCircle, description: 'Only a few slots remaining' },
  { value: 'closed', label: 'Closed', icon: XCircle, description: 'Not accepting new work' },
];

const expirationOptions = [
  { value: '1', label: '1 day' },
  { value: '3', label: '3 days' },
  { value: '7', label: '1 week' },
  { value: '14', label: '2 weeks' },
  { value: '30', label: '1 month' },
];

export const ServiceStatusUpdater: React.FC<ServiceStatusUpdaterProps> = ({
  sellerId,
  currentStatus = 'available',
  currentMessage,
  onUpdate,
}) => {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [status, setStatus] = useState<ServiceStatusType>(currentStatus);
  const [message, setMessage] = useState(currentMessage || '');
  const [expirationDays, setExpirationDays] = useState('7');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!user) {
      toast.error('Please sign in to update status');
      return;
    }

    setIsSubmitting(true);
    try {
      const expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + parseInt(expirationDays));

      const { error } = await supabase.from('service_status_updates').insert({
        seller_id: sellerId,
        user_id: user.id,
        status_type: status,
        message: message.trim() || null,
        expires_at: expiresAt.toISOString(),
      });

      if (error) throw error;

      toast.success('Status updated successfully!');
      setIsOpen(false);
      onUpdate?.();
    } catch (error: any) {
      console.error('Error updating status:', error);
      toast.error(error.message || 'Failed to update status');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Megaphone className="w-4 h-4" />
          Update Status
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Megaphone className="w-5 h-5" />
            Quick Service Status
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 py-4">
          {/* Status Selection */}
          <div className="space-y-3">
            <Label>Your Availability</Label>
            <RadioGroup
              value={status}
              onValueChange={(v) => setStatus(v as ServiceStatusType)}
              className="grid grid-cols-2 gap-3"
            >
              {statusOptions.map((option) => {
                const Icon = option.icon;
                const isSelected = status === option.value;
                return (
                  <label
                    key={option.value}
                    className={cn(
                      'flex items-start gap-3 p-3 rounded-xl border-2 cursor-pointer transition-all',
                      isSelected
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                    )}
                  >
                    <RadioGroupItem value={option.value} className="mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <Icon className={cn(
                          'w-4 h-4',
                          option.value === 'available' && 'text-green-500',
                          option.value === 'busy' && 'text-amber-500',
                          option.value === 'limited_slots' && 'text-orange-500',
                          option.value === 'closed' && 'text-red-500'
                        )} />
                        <span className="font-medium text-sm">{option.label}</span>
                      </div>
                      <p className="text-[11px] text-muted-foreground mt-0.5">{option.description}</p>
                    </div>
                  </label>
                );
              })}
            </RadioGroup>
          </div>

          {/* Message */}
          <div className="space-y-2">
            <Label htmlFor="message">Short Message (optional)</Label>
            <Textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="e.g., Taking bookings for next week, Currently on a big project..."
              maxLength={200}
              className="resize-none h-20"
            />
            <p className="text-[11px] text-muted-foreground text-right">
              {message.length}/200
            </p>
          </div>

          {/* Expiration */}
          <div className="space-y-2">
            <Label>Auto-expire after</Label>
            <Select value={expirationDays} onValueChange={setExpirationDays}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {expirationOptions.map((opt) => (
                  <SelectItem key={opt.value} value={opt.value}>
                    {opt.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <Button
            onClick={handleSubmit}
            disabled={isSubmitting}
            className="w-full"
          >
            {isSubmitting ? 'Updating...' : 'Update Status'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ServiceStatusUpdater;
