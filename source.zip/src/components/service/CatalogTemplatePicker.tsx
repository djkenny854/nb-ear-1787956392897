import { useState, useMemo } from 'react';
import { Check, RefreshCw, Plus, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useServiceCatalogTemplates, CatalogTemplate } from '@/hooks/useServiceCatalogTemplates';
import CatalogTemplateSkeleton from './CatalogTemplateSkeleton';
import EarlyMarketAIIcon from '@/components/icons/EarlyMarketAIIcon';
import { cn } from '@/lib/utils';

export interface PickedCatalog {
  name: string;
  description?: string;
  price?: number;
  duration_minutes?: number;
  currency: string;
}

interface Props {
  category: string;
  value: PickedCatalog[];
  onChange: (next: PickedCatalog[]) => void;
  maxItems?: number;
  /** Scattered chip layout (rounded buttons, no descriptions). Default false. */
  scattered?: boolean;
  /** Show the "Add your own item" form. Default true. */
  allowCustom?: boolean;
}

export default function CatalogTemplatePicker({
  category, value, onChange, maxItems = 20, scattered = false, allowCustom = true,
}: Props) {
  const { templates, loading, generating, error, reload } = useServiceCatalogTemplates(category);
  const [showCustom, setShowCustom] = useState(false);
  const [custom, setCustom] = useState({ name: '', price: '', duration: '' });

  const selectedNames = useMemo(() => new Set(value.map(v => v.name.toLowerCase())), [value]);

  const toggle = (t: CatalogTemplate) => {
    const key = t.name.toLowerCase();
    if (selectedNames.has(key)) {
      onChange(value.filter(v => v.name.toLowerCase() !== key));
      return;
    }
    if (value.length >= maxItems) return;
    onChange([
      ...value,
      {
        name: t.name,
        description: t.description || undefined,
        // Always attach AI typical price/duration when available so catalog rows
        // never persist with NULL money. Users can still edit afterwards.
        price: t.typical_price_min ?? undefined,
        duration_minutes: t.duration_minutes ?? undefined,
        currency: t.currency || 'UGX',
      },
    ]);
  };

  const addCustom = () => {
    if (!custom.name.trim() || value.length >= maxItems) return;
    onChange([
      ...value,
      {
        name: custom.name.trim(),
        price: custom.price ? Number(custom.price) : undefined,
        duration_minutes: custom.duration ? Number(custom.duration) : undefined,
        currency: 'UGX',
      },
    ]);
    setCustom({ name: '', price: '', duration: '' });
    setShowCustom(false);
  };

  if (!category) {
    return (
      <div className="rounded-xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
        Pick a category first — we'll suggest a catalog for you.
      </div>
    );
  }

  const isFirstLoad = loading && templates.length === 0;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <EarlyMarketAIIcon className="h-4 w-4" />
          <h3 className="text-sm font-semibold">EarlyMarket AI for {category}</h3>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">{value.length}/{maxItems}</Badge>
          <Button size="sm" variant="ghost" onClick={reload} disabled={loading} className="h-7 px-2">
            <RefreshCw className={cn('h-3.5 w-3.5', loading && 'animate-spin')} />
          </Button>
        </div>
      </div>

      {generating && (
        <div className="flex items-center gap-2.5 rounded-xl border border-primary/20 bg-primary/5 px-3 py-2">
          <div className="relative h-6 w-6 shrink-0">
            <EarlyMarketAIIcon className="absolute inset-0 h-6 w-6" />
            <span className="absolute -inset-1 rounded-full border-2 border-primary/30 border-t-primary animate-spin" />
          </div>
          <span className="text-xs text-foreground/80">EarlyMarket AI is drafting catalog items…</span>
        </div>
      )}

      {isFirstLoad ? (
        <CatalogTemplateSkeleton count={8} />
      ) : scattered ? (
        // Scattered chip-card layout (matches uploaded reference)
        <div className="flex flex-wrap gap-2.5">
          {templates.map(t => {
            const isSel = selectedNames.has(t.name.toLowerCase());
            const atMax = value.length >= maxItems && !isSel;
            return (
              <button
                key={t.id}
                type="button"
                disabled={atMax}
                onClick={() => toggle(t)}
                className={cn(
                  'group inline-flex items-center gap-2 rounded-full border px-4 py-2 text-sm transition-all',
                  isSel
                    ? 'border-primary bg-primary text-primary-foreground shadow-sm'
                    : 'border-border bg-background text-foreground hover:border-primary/60 hover:bg-primary/[0.04]',
                  atMax && 'opacity-40 cursor-not-allowed',
                )}
              >
                <span className="font-medium leading-none">{t.name}</span>
                {isSel ? (
                  <Check className="h-4 w-4 shrink-0" />
                ) : (
                  <Plus className="h-4 w-4 shrink-0 text-foreground/70 group-hover:text-primary" />
                )}
              </button>
            );
          })}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {templates.map(t => {
            const isSel = selectedNames.has(t.name.toLowerCase());
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => toggle(t)}
                className={cn(
                  'relative text-left rounded-xl border p-3 transition-all',
                  isSel ? 'border-primary bg-primary/5 ring-1 ring-primary/40' : 'border-border bg-card hover:border-primary/50',
                )}
              >
                <div className="flex items-start gap-2">
                  <div className={cn(
                    'mt-0.5 h-5 w-5 rounded-md border flex items-center justify-center flex-shrink-0',
                    isSel ? 'bg-primary border-primary text-primary-foreground' : 'border-border'
                  )}>
                    {isSel && <Check className="h-3.5 w-3.5" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium leading-tight">{t.name}</p>
                    {t.description && (
                      <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{t.description}</p>
                    )}
                    <div className="flex items-center gap-3 mt-1.5 text-[11px] text-muted-foreground">
                      {t.typical_price_min != null && (
                        <span>UGX {t.typical_price_min.toLocaleString()}{t.typical_price_max && t.typical_price_max !== t.typical_price_min ? `–${t.typical_price_max.toLocaleString()}` : ''}</span>
                      )}
                      {t.duration_minutes != null && (
                        <span className="flex items-center gap-0.5"><Clock className="h-3 w-3" />{t.duration_minutes}m</span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )}

      {error && <p className="text-xs text-destructive">{error}</p>}

      {allowCustom && (
        !showCustom ? (
          <Button variant="outline" size="sm" onClick={() => setShowCustom(true)} className="gap-1.5">
            <Plus className="h-3.5 w-3.5" /> Add your own item
          </Button>
        ) : (
          <div className="rounded-xl border border-dashed border-border p-3 space-y-2 bg-muted/20">
            <input
              placeholder="Service name"
              value={custom.name}
              onChange={e => setCustom({ ...custom, name: e.target.value })}
              className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm"
            />
            <div className="flex gap-2">
              <input
                type="number"
                placeholder="UGX price"
                value={custom.price}
                onChange={e => setCustom({ ...custom, price: e.target.value })}
                className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm"
              />
              <input
                type="number"
                placeholder="Minutes"
                value={custom.duration}
                onChange={e => setCustom({ ...custom, duration: e.target.value })}
                className="flex-1 rounded-md border border-border bg-background px-3 py-2 text-sm"
              />
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={addCustom} disabled={!custom.name.trim()}>Add</Button>
              <Button size="sm" variant="ghost" onClick={() => setShowCustom(false)}>Cancel</Button>
            </div>
          </div>
        )
      )}
    </div>
  );
}
