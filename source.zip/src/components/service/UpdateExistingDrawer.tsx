import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { GitCompareArrows, Camera, Megaphone, Video, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  serviceId: string;
}

const ACTIONS = [
  { key: 'work', label: 'Photo work update', desc: 'Add up to 6 photos from a recent job', icon: Camera, color: 'text-sky-500' },
  { key: 'before_after', label: 'Before & after', desc: 'Show the transformation side-by-side', icon: GitCompareArrows, color: 'text-emerald-500' },
  { key: 'reel', label: 'Short video clip', desc: 'Upload a short video (under 50MB)', icon: Video, color: 'text-purple-500' },
  { key: 'promo', label: 'Promo or announcement', desc: 'Share an offer, discount, or news', icon: Megaphone, color: 'text-rose-500' },
];

export default function UpdateExistingDrawer({ open, onOpenChange, serviceId }: Props) {
  const navigate = useNavigate();

  const handle = (action: string) => {
    onOpenChange(false);
    navigate(`/workspace/manage/${serviceId}?compose=${action}`);
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-w-2xl mx-auto">
        <DrawerHeader>
          <DrawerTitle>Add an update</DrawerTitle>
          <p className="text-xs text-muted-foreground">Pick what you'd like to share — keep it quick.</p>
        </DrawerHeader>
        <div className="px-4 pb-6 space-y-2" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom, 0px) + 1.5rem)' }}>
          {ACTIONS.map(a => (
            <button
              key={a.key}
              onClick={() => handle(a.key)}
              className="w-full flex items-center gap-3 rounded-xl border border-border bg-card hover:bg-muted/40 transition-colors p-3 text-left"
            >
              <div className={`h-10 w-10 rounded-lg bg-muted flex items-center justify-center ${a.color}`}>
                <a.icon className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">{a.label}</p>
                <p className="text-xs text-muted-foreground line-clamp-1">{a.desc}</p>
              </div>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </button>
          ))}
        </div>
      </DrawerContent>
    </Drawer>
  );
}
