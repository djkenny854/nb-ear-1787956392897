import React, { useEffect, useState } from 'react';
import { Heart, MessageCircle, Share2, Bookmark, ArrowLeftRight, Video as VideoIcon, Megaphone, ImageIcon, Tag, TrendingUp, Star } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ServiceUpdate } from '@/hooks/useServiceUpdates';
import { formatDistanceToNow } from 'date-fns';
import { useBookmarks } from '@/hooks/useBookmarks';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import ReelVideoPlayer from '@/components/feed/ReelVideoPlayer';
import { useAuth } from '@/components/auth/AuthContext';
import { toast } from 'sonner';

const typeMeta: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  work: { label: 'Work', icon: ImageIcon, color: 'bg-primary/10 text-primary' },
  reel: { label: 'Reel', icon: VideoIcon, color: 'bg-purple-500/10 text-purple-500' },
  before_after: { label: 'Before / After', icon: ArrowLeftRight, color: 'bg-orange-500/10 text-orange-500' },
  promo: { label: 'Promo', icon: Tag, color: 'bg-pink-500/10 text-pink-500' },
  announcement: { label: 'News', icon: Megaphone, color: 'bg-blue-500/10 text-blue-500' },
  progress: { label: 'Progress', icon: TrendingUp, color: 'bg-emerald-500/10 text-emerald-500' },
  testimonial: { label: 'Testimonial', icon: Star, color: 'bg-amber-500/10 text-amber-500' },
};

interface Props {
  update: ServiceUpdate;
  isOwner?: boolean;
  onDelete?: (id: string) => void;
}

export const ServiceUpdateCard: React.FC<Props> = ({ update, isOwner, onDelete }) => {
  const meta = typeMeta[update.update_type] || typeMeta.work;
  const Icon = meta.icon;
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const bookmarked = isBookmarked(update.id);
  const { user } = useAuth();
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(update.like_count || 0);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user?.id) return;
    supabase.from('content_engagements')
      .select('id')
      .eq('user_id', user.id)
      .eq('content_id', update.id)
      .eq('content_type', 'service_update')
      .eq('engagement_type', 'like')
      .maybeSingle()
      .then(({ data }) => setLiked(!!data));
  }, [user?.id, update.id]);

  const toggleLike = async () => {
    if (!user?.id) { toast.error('Sign in to like'); return; }
    if (busy) return;
    setBusy(true);
    try {
      if (liked) {
        await supabase.from('content_engagements')
          .delete()
          .eq('user_id', user.id)
          .eq('content_id', update.id)
          .eq('content_type', 'service_update')
          .eq('engagement_type', 'like');
        setLiked(false); setLikeCount(c => Math.max(0, c - 1));
      } else {
        await supabase.from('content_engagements').insert({
          user_id: user.id,
          content_id: update.id,
          content_type: 'service_update',
          engagement_type: 'like',
        });
        setLiked(true); setLikeCount(c => c + 1);
        await supabase.rpc('record_workspace_engagement', { p_seller_id: update.seller_id });
      }
    } catch (e: any) {
      toast.error(e.message || 'Failed');
    } finally {
      setBusy(false);
    }
  };

  const handleShare = async () => {
    try {
      await navigator.share?.({ title: update.title || 'Service update', url: window.location.href });
      await supabase.rpc('record_workspace_engagement', { p_seller_id: update.seller_id });
    } catch { /* user cancelled */ }
  };

  return (
    <article className="bg-transparent border-b border-border/40 last:border-b-0 overflow-hidden">
      <header className="flex items-center justify-between px-1 pt-3 pb-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className={cn('w-8 h-8 rounded-full flex items-center justify-center shrink-0', meta.color)}>
            <Icon className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-sm font-semibold truncate">{meta.label}</span>
              {update.is_featured && (
                <Badge variant="outline" className="text-[10px] h-4 px-1">Featured</Badge>
              )}
            </div>
            <span className="text-[11px] text-muted-foreground">
              {formatDistanceToNow(new Date(update.created_at), { addSuffix: true })}
            </span>
          </div>
        </div>
        {isOwner && onDelete && (
          <Button size="sm" variant="ghost" onClick={() => onDelete(update.id)} className="text-destructive h-7">
            Delete
          </Button>
        )}
      </header>

      {update.title && <h3 className="px-1 font-semibold text-[15px] leading-snug">{update.title}</h3>}
      {update.caption && <p className="px-1 pb-2 pt-1 text-sm text-foreground/90 whitespace-pre-wrap leading-relaxed">{update.caption}</p>}

      {/* Media */}
      {update.update_type === 'before_after' && update.before_image_url && update.after_image_url ? (
        <div className="grid grid-cols-2 gap-1 rounded-xl overflow-hidden">
          <div className="relative">
            <img loading="lazy" decoding="async" src={update.before_image_url} className="w-full aspect-square object-cover rounded-l-xl" alt="Before" />
            <Badge className="absolute top-2 left-2 bg-black/70 text-white border-0">Before</Badge>
          </div>
          <div className="relative">
            <img loading="lazy" decoding="async" src={update.after_image_url} className="w-full aspect-square object-cover rounded-r-xl" alt="After" />
            <Badge className="absolute top-2 left-2 bg-primary text-primary-foreground border-0">After</Badge>
          </div>
        </div>
      ) : update.video_url ? (
        <div className="rounded-xl overflow-hidden">
          <ReelVideoPlayer
            src={update.video_url}
            poster={update.video_thumbnail_url}
          />
        </div>
      ) : update.images.length > 0 ? (
        <div className={cn(
          'grid gap-1 rounded-xl overflow-hidden',
          update.images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
        )}>
          {update.images.slice(0, 4).map((src) => (
            <img
              loading="lazy"
              decoding="async"
              key={src}
              src={src}
              className={cn(
                'w-full object-cover',
                update.images.length === 1
                  ? 'aspect-video max-h-56 sm:max-h-64 md:max-h-72 lg:max-h-60'
                  : 'aspect-square max-h-48 lg:max-h-40'
              )}
              alt=""
            />
          ))}
        </div>
      ) : null}

      {update.tags?.length > 0 && (
        <div className="flex flex-wrap gap-1 px-3 pt-2">
          {update.tags.map((t) => (
            <Badge key={t} variant="secondary" className="text-[10px]">#{t}</Badge>
          ))}
        </div>
      )}

      <footer className="flex items-center gap-1 p-2">
        <Button size="sm" variant="ghost" className="gap-1.5 h-8" onClick={toggleLike} disabled={busy}>
          <Heart className={cn('w-4 h-4', liked && 'fill-current text-red-500')} />
          <span className="text-xs">{likeCount || ''}</span>
        </Button>
        <Button size="sm" variant="ghost" className="gap-1.5 h-8" onClick={() => toast.info('Comments coming soon')}>
          <MessageCircle className="w-4 h-4" />
          <span className="text-xs">{update.comment_count || ''}</span>
        </Button>
        <Button size="sm" variant="ghost" className="gap-1.5 h-8" onClick={handleShare}>
          <Share2 className="w-4 h-4" />
        </Button>
        <Button size="sm" variant="ghost" className="gap-1.5 h-8 ml-auto"
          onClick={() => toggleBookmark(update.id, 'post')}>
          <Bookmark className={cn('w-4 h-4', bookmarked && 'fill-current')} />
        </Button>
      </footer>
    </article>
  );
};

export default ServiceUpdateCard;
