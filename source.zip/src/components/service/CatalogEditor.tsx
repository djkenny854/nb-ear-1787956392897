import React, { useState } from 'react';
import { Plus, Trash2, Clock, GripVertical } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useServiceCatalogs, ServiceCatalogItem } from '@/hooks/useServiceCatalogs';
import { useCurrency } from '@/contexts/CurrencyContext';
import { cn } from '@/lib/utils';

interface CatalogEditorProps {
  adId: string;
  sellerId: string;
}

const CatalogEditor: React.FC<CatalogEditorProps> = ({ adId, sellerId }) => {
  const { catalogs, isLoading, addCatalog, updateCatalog, deleteCatalog } = useServiceCatalogs(adId);
  const { formatPriceCompact } = useCurrency();
  const [newItem, setNewItem] = useState({ name: '', price: '', duration: '' });
  const [editingId, setEditingId] = useState<string | null>(null);

  const handleAdd = () => {
    if (!newItem.name.trim()) return;
    addCatalog.mutate({
      ad_id: adId,
      seller_id: sellerId,
      name: newItem.name.trim(),
      price: newItem.price ? Number(newItem.price) : undefined,
      duration_minutes: newItem.duration ? Number(newItem.duration) : undefined,
    });
    setNewItem({ name: '', price: '', duration: '' });
  };

  if (isLoading) {
    return <div className="animate-pulse space-y-2">
      {[1, 2].map(i => <div key={i} className="h-12 bg-muted rounded-lg" />)}
    </div>;
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">Catalog Items</Label>
        <span className="text-xs text-muted-foreground">{catalogs.length} items</span>
      </div>

      {/* Existing items */}
      {catalogs.map((item) => (
        <div key={item.id} className="flex items-center gap-2 p-2.5 bg-background rounded-lg border border-border group">
          <GripVertical className="w-3.5 h-3.5 text-muted-foreground/40 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            {editingId === item.id ? (
              <div className="flex gap-2">
                <Input
                  defaultValue={item.name}
                  className="h-8 text-sm"
                  autoFocus
                  onBlur={(e) => {
                    updateCatalog.mutate({ id: item.id, name: e.target.value });
                    setEditingId(null);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') (e.target as HTMLInputElement).blur();
                  }}
                />
              </div>
            ) : (
              <button
                className="text-left w-full"
                onClick={() => setEditingId(item.id)}
              >
                <p className="text-sm font-medium text-foreground truncate">{item.name}</p>
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  {item.price != null && <span>{item.currency} {item.price.toLocaleString()}</span>}
                  {item.duration_minutes && (
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-3 h-3" />{item.duration_minutes}min
                    </span>
                  )}
                </div>
              </button>
            )}
          </div>
          <Button
            size="icon"
            variant="ghost"
            className="h-7 w-7 opacity-0 group-hover:opacity-100 transition-opacity text-destructive hover:text-destructive"
            onClick={() => deleteCatalog.mutate(item.id)}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      ))}

      {/* Add new item */}
      <div className="space-y-2 p-3 rounded-lg border border-dashed border-border bg-muted/20">
        <Input
          placeholder="Service name (e.g., Pipe Repair)"
          value={newItem.name}
          onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
          className="h-9 text-sm"
        />
        <div className="flex gap-2">
          <div className="relative flex-1">
            <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">UGX</span>
            <Input
              type="number"
              placeholder="Price"
              value={newItem.price}
              onChange={(e) => setNewItem({ ...newItem, price: e.target.value })}
              className="h-9 text-sm pl-10"
            />
          </div>
          <div className="relative flex-1">
            <Clock className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <Input
              type="number"
              placeholder="Duration (min)"
              value={newItem.duration}
              onChange={(e) => setNewItem({ ...newItem, duration: e.target.value })}
              className="h-9 text-sm pl-8"
            />
          </div>
        </div>
        <Button
          size="sm"
          variant="outline"
          onClick={handleAdd}
          disabled={!newItem.name.trim() || addCatalog.isPending}
          className="w-full gap-1.5 h-8"
        >
          <Plus className="w-3.5 h-3.5" />
          Add Item
        </Button>
      </div>
    </div>
  );
};

export default CatalogEditor;
