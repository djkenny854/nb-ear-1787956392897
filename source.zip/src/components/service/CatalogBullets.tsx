import React from 'react';
import { useServiceCatalogs } from '@/hooks/useServiceCatalogs';
import { Clock } from 'lucide-react';

interface CatalogBulletsProps {
  adId: string;
  maxItems?: number;
  compact?: boolean;
}

const CatalogBullets: React.FC<CatalogBulletsProps> = ({ adId, maxItems = 3, compact = false }) => {
  const { catalogs, isLoading } = useServiceCatalogs(adId);

  if (isLoading || catalogs.length === 0) return null;

  const items = catalogs.slice(0, maxItems);
  const remaining = catalogs.length - maxItems;

  return (
    <div className="space-y-1">
      {items.map((item) => (
        <div key={item.id} className="flex items-center gap-1.5 text-xs">
          <span className="text-primary font-bold">•</span>
          <span className={compact ? "text-muted-foreground truncate" : "text-foreground font-medium truncate"}>
            {item.name}
          </span>
          {item.price != null && (
            <>
              <span className="text-muted-foreground">—</span>
              <span className="text-foreground font-medium whitespace-nowrap">
                {item.currency} {item.price.toLocaleString()}
              </span>
            </>
          )}
          {!compact && item.duration_minutes && (
            <span className="flex items-center gap-0.5 text-muted-foreground whitespace-nowrap ml-auto">
              <Clock className="w-3 h-3" />{item.duration_minutes}min
            </span>
          )}
        </div>
      ))}
      {remaining > 0 && (
        <p className="text-xs text-muted-foreground pl-4">+{remaining} more</p>
      )}
    </div>
  );
};

export default CatalogBullets;
