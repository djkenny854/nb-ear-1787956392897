import React, { useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { ChevronLeft, ChevronRight, Play, Star, Calendar, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import SmartVideo from '@/components/media/SmartVideo';

interface PortfolioItem {
  id: string;
  title: string;
  description?: string | null;
  images: string[];
  video_url?: string | null;
  client_name?: string | null;
  project_date?: string | null;
  tags?: string[] | null;
  is_featured: boolean;
}

interface ServicePortfolioGalleryProps {
  items: PortfolioItem[];
  maxDisplay?: number;
}

export const ServicePortfolioGallery: React.FC<ServicePortfolioGalleryProps> = ({
  items,
  maxDisplay = 6,
}) => {
  const [selectedItem, setSelectedItem] = useState<PortfolioItem | null>(null);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  if (!items || items.length === 0) {
    return null;
  }

  const displayItems = items.slice(0, maxDisplay);
  const hasMore = items.length > maxDisplay;

  const handlePrevImage = () => {
    if (!selectedItem) return;
    setCurrentImageIndex((prev) => 
      prev === 0 ? selectedItem.images.length - 1 : prev - 1
    );
  };

  const handleNextImage = () => {
    if (!selectedItem) return;
    setCurrentImageIndex((prev) => 
      prev === selectedItem.images.length - 1 ? 0 : prev + 1
    );
  };

  const openItem = (item: PortfolioItem) => {
    setSelectedItem(item);
    setCurrentImageIndex(0);
  };

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {displayItems.map((item, idx) => (
          <div
            key={item.id}
            onClick={() => openItem(item)}
            className={cn(
              "relative aspect-square rounded-xl overflow-hidden cursor-pointer group",
              "bg-muted hover:ring-2 hover:ring-primary/50 transition-all"
            )}
          >
            {item.images[0] ? (
              <img
                src={item.images[0]}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-muted">
                <span className="text-muted-foreground text-sm">No image</span>
              </div>
            )}

            {/* Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
              <div className="absolute bottom-2 left-2 right-2">
                <p className="text-white text-sm font-medium line-clamp-1">{item.title}</p>
                {item.tags && item.tags.length > 0 && (
                  <div className="flex gap-1 mt-1">
                    {item.tags.slice(0, 2).map((tag, i) => (
                      <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-white/20 text-white">
                        {tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Featured badge */}
            {item.is_featured && (
              <div className="absolute top-2 left-2">
                <Badge className="bg-amber-500 text-white text-[10px] gap-0.5">
                  <Star className="w-2.5 h-2.5 fill-current" />
                  Featured
                </Badge>
              </div>
            )}

            {/* Video indicator */}
            {item.video_url && (
              <div className="absolute top-2 right-2 w-7 h-7 rounded-full bg-black/60 flex items-center justify-center">
                <Play className="w-3.5 h-3.5 text-white fill-white" />
              </div>
            )}

            {/* More indicator on last item */}
            {idx === maxDisplay - 1 && hasMore && (
              <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                <span className="text-white text-xl font-bold">+{items.length - maxDisplay}</span>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Lightbox Dialog */}
      <Dialog open={!!selectedItem} onOpenChange={() => setSelectedItem(null)}>
        <DialogContent className="max-w-4xl p-0 bg-background border-0 overflow-hidden">
          {selectedItem && (
            <div className="relative">
              {/* Close button */}
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSelectedItem(null)}
                className="absolute top-4 right-4 z-50 rounded-full bg-black/50 hover:bg-black/70 text-white"
              >
                <X className="w-5 h-5" />
              </Button>

              {/* Image/Video display */}
              <div className="relative aspect-video bg-black">
                {selectedItem.video_url ? (
                  <SmartVideo
                    src={selectedItem.video_url}
                    poster={(selectedItem as any).video_thumbnail_url || selectedItem.images?.[0]}
                    controls
                    autoPlay
                    className="w-full h-full object-contain"
                  />
                ) : selectedItem.images[currentImageIndex] ? (
                  <img
                    src={selectedItem.images[currentImageIndex]}
                    alt={selectedItem.title}
                    className="w-full h-full object-contain"
                  />
                ) : null}

                {/* Navigation arrows */}
                {selectedItem.images.length > 1 && !selectedItem.video_url && (
                  <>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handlePrevImage}
                      className="absolute left-4 top-1/2 -translate-y-1/2 rounded-full bg-black/50 hover:bg-black/70 text-white"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={handleNextImage}
                      className="absolute right-4 top-1/2 -translate-y-1/2 rounded-full bg-black/50 hover:bg-black/70 text-white"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </Button>

                    {/* Image indicators */}
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5">
                      {selectedItem.images.map((_, idx) => (
                        <button
                          key={idx}
                          onClick={() => setCurrentImageIndex(idx)}
                          className={cn(
                            "w-2 h-2 rounded-full transition-all",
                            idx === currentImageIndex ? "bg-white w-4" : "bg-white/50"
                          )}
                        />
                      ))}
                    </div>
                  </>
                )}
              </div>

              {/* Info section */}
              <div className="p-6">
                <h3 className="text-xl font-bold">{selectedItem.title}</h3>
                
                {selectedItem.description && (
                  <p className="text-muted-foreground mt-2">{selectedItem.description}</p>
                )}

                <div className="flex flex-wrap items-center gap-3 mt-4">
                  {selectedItem.client_name && (
                    <span className="text-sm text-muted-foreground">
                      Client: <span className="text-foreground">{selectedItem.client_name}</span>
                    </span>
                  )}
                  {selectedItem.project_date && (
                    <span className="text-sm text-muted-foreground flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {formatDistanceToNow(new Date(selectedItem.project_date), { addSuffix: true })}
                    </span>
                  )}
                </div>

                {selectedItem.tags && selectedItem.tags.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {selectedItem.tags.map((tag, i) => (
                      <Badge key={i} variant="secondary">{tag}</Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ServicePortfolioGallery;
