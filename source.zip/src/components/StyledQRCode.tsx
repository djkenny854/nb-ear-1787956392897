import React, { useEffect, useRef, useState } from 'react';
import { Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { useTheme } from 'next-themes';
import QRCodeStyling from 'qr-code-styling';
import earlymarketLogo from '@/assets/earlymarket-mono.svg';
import { getAppBaseUrl } from '@/utils/getAppUrl';

interface StyledQRCodeProps {
  value: string;
  size?: number;
  showDownload?: boolean;
  title?: string;
  subtitle?: string;
}

const StyledQRCode: React.FC<StyledQRCodeProps> = ({
  value,
  size = 220,
  title,
  subtitle,
  showDownload = true,
}) => {
  const qrRef = useRef<HTMLDivElement>(null);
  const qrCode = useRef<QRCodeStyling | null>(null);
  const downloadQr = useRef<QRCodeStyling | null>(null);
  const [ready, setReady] = useState(false);
  const { resolvedTheme } = useTheme();

  // Always use production domain for QR codes
  const getAbsoluteUrl = (url: string) => {
    if (url.startsWith('http')) return url;
    return `${getAppBaseUrl()}${url.startsWith('/') ? '' : '/'}${url}`;
  };

  const absoluteUrl = getAbsoluteUrl(value);
  const isDark = resolvedTheme === 'dark';

  const [logoToUse, setLogoToUse] = useState(earlymarketLogo);

  useEffect(() => {
    if (isDark) {
      const img = new window.Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.width || 200;
        canvas.height = img.height || 200;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.filter = 'invert(1)';
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          setLogoToUse(canvas.toDataURL('image/png'));
        }
      };
      img.src = earlymarketLogo;
    } else {
      setLogoToUse(earlymarketLogo);
    }
  }, [isDark]);

  const qrOptions = {
    data: absoluteUrl,
    type: 'canvas' as const,
    dotsOptions: {
      type: 'rounded' as const,
      color: '#000000',
    },
    cornersSquareOptions: {
      type: 'extra-rounded' as const,
      color: '#000000',
    },
    cornersDotOptions: {
      type: 'dot' as const,
      color: '#000000',
    },
    backgroundOptions: {
      color: '#ffffff',
    },
    imageOptions: {
      crossOrigin: 'anonymous',
      margin: 6,
      imageSize: 0.35,
    },
    image: logoToUse,
    qrOptions: {
      errorCorrectionLevel: 'H' as const,
    },
  };

  useEffect(() => {
    // Display QR at the given size
    qrCode.current = new QRCodeStyling({
      ...qrOptions,
      width: size,
      height: size,
    });

    if (qrRef.current) {
      qrRef.current.innerHTML = '';
      qrCode.current.append(qrRef.current);
    }

    // Create a separate high-res instance for downloads (4K = 2048px)
    downloadQr.current = new QRCodeStyling({
      ...qrOptions,
      width: 2048,
      height: 2048,
    });

    const timer = setTimeout(() => setReady(true), 200);
    return () => clearTimeout(timer);
  }, [absoluteUrl, size, logoToUse]);

  const handleDownload = () => {
    if (!downloadQr.current) return;
    downloadQr.current.download({
      name: `earlymarket-qr-${Date.now()}`,
      extension: 'png',
    });
    toast.success('QR code downloaded in high quality!');
  };

  return (
    <div className="flex flex-col items-center gap-4">
      {title && (
        <div className="text-center">
          <h3 className="text-lg font-semibold text-foreground">{title}</h3>
          {subtitle && <p className="text-sm text-muted-foreground">{subtitle}</p>}
        </div>
      )}

      {/* QR Code Container */}
      <div
        className={`relative p-6 rounded-2xl bg-white shadow-lg transition-all duration-500 ${
          ready ? 'animate-in fade-in-50 zoom-in-95' : 'opacity-0'
        }`}
      >
        <div ref={qrRef} className="relative" />

        {/* Subtle corner accents */}
        <div className="absolute top-2 left-2 w-4 h-4 border-l-2 border-t-2 border-primary/30 rounded-tl" />
        <div className="absolute top-2 right-2 w-4 h-4 border-r-2 border-t-2 border-primary/30 rounded-tr" />
        <div className="absolute bottom-2 left-2 w-4 h-4 border-l-2 border-b-2 border-primary/30 rounded-bl" />
        <div className="absolute bottom-2 right-2 w-4 h-4 border-r-2 border-b-2 border-primary/30 rounded-br" />
      </div>

      <p className="text-xs text-muted-foreground">Point your camera to scan</p>

      {showDownload && (
        <Button
          onClick={handleDownload}
          variant="outline"
          size="sm"
          className="gap-2"
        >
          <Download className="w-4 h-4" />
          Download QR Code
        </Button>
      )}
    </div>
  );
};

export default StyledQRCode;
