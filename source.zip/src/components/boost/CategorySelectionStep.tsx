import { motion } from 'framer-motion';
import { Package, Briefcase, Megaphone, FileCode, Check, Zap, Shield, TrendingUp, Eye, Clock, Star } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { useState, useEffect } from 'react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

interface CategorySelectionStepProps {
  selectedCategory: string | null;
  onSelectCategory: (category: string) => void;
}

const CATEGORIES = [
  {
    id: 'physical_products',
    name: 'Physical Products',
    icon: Package,
    description: 'Tangible goods and merchandise',
    tagline: 'Get more buyers for your products',
    badge: 'Popular',
    basePrice: 15000,
    priceLabel: 'Starting at',
    color: 'from-blue-500 to-blue-600',
    bgColor: 'bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/20',
    borderColor: 'border-blue-200 dark:border-blue-800'
  },
  {
    id: 'digital_products',
    name: 'Digital Products',
    icon: FileCode,
    description: 'Software, ebooks and downloads',
    tagline: 'Reach tech-savvy audiences',
    badge: 'New',
    basePrice: 12000,
    priceLabel: 'Starting at',
    color: 'from-purple-500 to-pink-500',
    bgColor: 'bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-950/30 dark:to-pink-950/20',
    borderColor: 'border-purple-200 dark:border-purple-800'
  },
  {
    id: 'jobs',
    name: 'Job Listings',
    icon: Briefcase,
    description: 'Hiring and career opportunities',
    tagline: 'Find qualified candidates faster',
    badge: 'Hot',
    basePrice: 20000,
    priceLabel: 'Starting at',
    color: 'from-green-500 to-emerald-500',
    bgColor: 'bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/20',
    borderColor: 'border-green-200 dark:border-green-800'
  },
  {
    id: 'promotions',
    name: 'Promotions',
    icon: Megaphone,
    description: 'Marketing campaigns and offers',
    tagline: 'Amplify your reach instantly',
    badge: 'Best Value',
    basePrice: 18000,
    priceLabel: 'Starting at',
    color: 'from-orange-500 to-red-500',
    bgColor: 'bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/30 dark:to-red-950/20',
    borderColor: 'border-orange-200 dark:border-orange-800'
  }
];

const BENEFITS = [
  {
    icon: Eye,
    title: '10x More Views',
    description: 'Boosted ads get significantly more visibility'
  },
  {
    icon: TrendingUp,
    title: 'Priority Placement',
    description: 'Appear at the top of search results'
  },
  {
    icon: Clock,
    title: 'Flexible Duration',
    description: 'Choose from 3 to 30 days boost periods'
  },
  {
    icon: Shield,
    title: 'Money-Back Guarantee',
    description: 'Full refund if your ad gets no extra views'
  }
];

export default function CategorySelectionStep({ selectedCategory, onSelectCategory }: CategorySelectionStepProps) {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setTimeout(() => setLoading(false), 400);
  }, []);

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="text-center space-y-2">
          <Skeleton className="h-8 w-64 mx-auto" />
          <Skeleton className="h-4 w-48 mx-auto" />
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-3xl mx-auto">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-56 rounded-2xl" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-10 py-4">
      {/* Header */}
      <div className="text-center space-y-2">
        <motion.h2 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-2xl md:text-3xl font-bold text-foreground"
        >
          What do you want to boost?
        </motion.h2>
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="text-muted-foreground"
        >
          Select the type of listing you'd like to promote
        </motion.p>
      </div>

      {/* Category Cards - Google Style */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-3xl mx-auto">
        {CATEGORIES.map((category, index) => {
          const Icon = category.icon;
          const isSelected = selectedCategory === category.id;

          return (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.08 }}
              onClick={() => onSelectCategory(category.id)}
              className={`
                relative rounded-2xl cursor-pointer transition-all duration-300
                border-2 overflow-hidden
                ${isSelected 
                  ? `border-primary shadow-lg ring-2 ring-primary/20 ${category.bgColor}` 
                  : `border-border hover:border-primary/40 hover:shadow-md bg-card`
                }
              `}
            >
              {/* Badge */}
              <div className="flex justify-center pt-4">
                <Badge 
                  variant="secondary" 
                  className="bg-muted text-muted-foreground text-[10px] font-medium px-2.5 py-0.5 rounded-full"
                >
                  {category.badge}
                </Badge>
              </div>

              {/* Content */}
              <div className="p-5 pt-3 text-center space-y-3">
                {/* Title with superscript */}
                <h3 className="text-xl font-bold text-foreground">
                  {category.name}
                </h3>

                {/* Icon */}
                <div className={`
                  w-14 h-14 mx-auto rounded-xl bg-gradient-to-br ${category.color} 
                  flex items-center justify-center shadow-md
                `}>
                  <Icon className="w-7 h-7 text-white" />
                </div>

                {/* Description */}
                <p className="text-sm text-foreground font-medium">
                  {category.description}
                </p>

                {/* Price */}
                <div className="space-y-0.5">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs text-muted-foreground line-through">
                      UGX {(category.basePrice * 1.5).toLocaleString()}
                    </span>
                    <span className="text-lg font-bold text-foreground">
                      UGX {category.basePrice.toLocaleString()}
                    </span>
                    <span className="text-xs text-muted-foreground">/ 7 days</span>
                  </div>
                </div>

                {/* Tagline */}
                <p className="text-xs text-muted-foreground">
                  {category.tagline}
                </p>

                {/* Select Button */}
                <Button
                  variant={isSelected ? "default" : "outline"}
                  size="sm"
                  className={`w-full rounded-full mt-2 ${isSelected ? '' : 'hover:bg-primary hover:text-primary-foreground'}`}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectCategory(category.id);
                  }}
                >
                  {isSelected ? (
                    <>
                      <Check className="w-4 h-4 mr-1" />
                      Selected
                    </>
                  ) : (
                    <>
                      Select {category.name.split(' ')[0]} →
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Assurance / Benefits Section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="max-w-3xl mx-auto"
      >
        <div className="bg-muted/50 rounded-2xl p-6 border border-border">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary" />
            </div>
            <h3 className="font-semibold text-foreground">Why boost with EarlyMarket?</h3>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {BENEFITS.map((benefit, index) => {
              const BenefitIcon = benefit.icon;
              return (
                <motion.div
                  key={benefit.title}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                  className="text-center space-y-2"
                >
                  <div className="w-10 h-10 mx-auto rounded-full bg-card border border-border flex items-center justify-center">
                    <BenefitIcon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-foreground">{benefit.title}</p>
                    <p className="text-[10px] text-muted-foreground leading-tight">{benefit.description}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Trust badges */}
          <div className="flex items-center justify-center gap-4 mt-5 pt-4 border-t border-border">
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Shield className="w-3.5 h-3.5" />
              <span>Secure Payment</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Star className="w-3.5 h-3.5" />
              <span>4.9/5 Rating</span>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Clock className="w-3.5 h-3.5" />
              <span>24/7 Support</span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
