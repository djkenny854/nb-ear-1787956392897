import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Zap, TrendingUp, Rocket, Crown, Check, MapPin, Users, Target, Info } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import AnimatedLabel from '@/components/publish/AnimatedLabel';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ugandaDistricts } from '@/data/ugandaDistricts';
import { Badge } from '@/components/ui/badge';
import { useBoostPricing, BoostPlan, PlacementType } from '@/hooks/useBoostPricing';

interface EnhancedDurationPlanStepProps {
  duration: number;
  boostType: string;
  placementType: string;
  targetRegion: string;
  targetDistricts: string[];
  onDurationChange: (duration: number) => void;
  onBoostTypeChange: (type: string) => void;
  onPlacementTypeChange: (type: string) => void;
  onTargetRegionChange: (region: string) => void;
  onTargetDistrictsChange: (districts: string[]) => void;
  onTotalAmountChange: (amount: number) => void;
}

const ICON_MAP: Record<string, React.FC<{ className?: string }>> = {
  Zap,
  TrendingUp,
  Rocket,
  Crown,
  Target,
};

const REGIONS = ['All Uganda', 'Central', 'Eastern', 'Northern', 'Western'];

export default function EnhancedDurationPlanStep({
  duration,
  boostType,
  placementType,
  targetRegion,
  targetDistricts,
  onDurationChange,
  onBoostTypeChange,
  onPlacementTypeChange,
  onTargetRegionChange,
  onTargetDistrictsChange,
  onTotalAmountChange
}: EnhancedDurationPlanStepProps) {
  const { plans, placementTypes, pricingConfig, isLoading, calculatePrice } = useBoostPricing();
  const [calculatedPrice, setCalculatedPrice] = useState(0);
  const [estimatedReach, setEstimatedReach] = useState(0);

  useEffect(() => {
    if (plans.length > 0 && placementTypes.length > 0) {
      const { price, estimatedReach: reach } = calculatePrice(
        boostType,
        placementType,
        duration,
        targetRegion,
        targetDistricts
      );
      setCalculatedPrice(price);
      setEstimatedReach(reach);
      onTotalAmountChange(price);
    }
  }, [duration, boostType, placementType, targetRegion, targetDistricts, plans, placementTypes, calculatePrice, onTotalAmountChange]);

  const availableDistricts = targetRegion === 'All Uganda' 
    ? ugandaDistricts 
    : ugandaDistricts.filter(d => d.region === targetRegion);

  const handleDistrictToggle = (districtId: string) => {
    if (targetDistricts.includes(districtId)) {
      onTargetDistrictsChange(targetDistricts.filter(d => d !== districtId));
    } else {
      onTargetDistrictsChange([...targetDistricts, districtId]);
    }
  };

  const getIcon = (iconName: string) => {
    return ICON_MAP[iconName] || Zap;
  };

  if (isLoading) {
    return (
      <div className="space-y-12 py-8">
        <div className="text-center space-y-4">
          <AnimatedLabel showSkeleton className="text-3xl">Configure Your Boost</AnimatedLabel>
          <Skeleton className="h-6 w-2/3 mx-auto rounded bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
        </div>

        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-96 rounded-2xl bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
            ))}
          </div>

          <Skeleton className="h-64 rounded-2xl bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
          <Skeleton className="h-40 rounded-2xl bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-12 py-8">
      {/* Header */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <h2 className="text-4xl font-bold text-foreground">Configure Your Boost</h2>
        <p className="text-muted-foreground text-lg">
          Customize your campaign to reach the right audience at the right time
        </p>
      </div>

      {/* Boost Plans from Database */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Rocket className="w-6 h-6 text-primary" />
          <h3 className="text-2xl font-bold">Choose Your Plan</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan, index) => {
            const Icon = getIcon(plan.icon);
            const isSelected = boostType === plan.name;

            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                onClick={() => onBoostTypeChange(plan.name)}
                className={`
                  relative p-6 rounded-2xl cursor-pointer transition-all duration-300
                  border-2 hover:shadow-2xl hover:scale-105
                  ${isSelected 
                    ? `border-primary shadow-xl scale-105 bg-gradient-to-br from-${plan.gradient_from}/10 to-${plan.gradient_to}/5` 
                    : 'border-border hover:border-primary/50 bg-card'
                  }
                `}
              >
                {plan.is_popular && !isSelected && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-primary to-primary/80 text-primary-foreground text-xs font-bold rounded-full shadow-lg">
                    MOST POPULAR
                  </div>
                )}

                {isSelected && (
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-3 -right-3 w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center shadow-xl"
                  >
                    <Check className="w-5 h-5 text-primary-foreground" />
                  </motion.div>
                )}

                <div className={`w-16 h-16 rounded-xl bg-gradient-to-br from-${plan.gradient_from} to-${plan.gradient_to} flex items-center justify-center mb-4 shadow-lg`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-2xl font-bold mb-2">{plan.display_name}</h3>
                <div className="text-3xl font-bold mb-4 bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
                  {plan.base_price_per_day.toLocaleString()} 
                  <span className="text-sm text-muted-foreground font-normal ml-1">{pricingConfig.currency}/day</span>
                </div>

                <ul className="space-y-2.5">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm">
                      <Check className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-foreground/80">{feature}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Placement Types from Database */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Target className="w-6 h-6 text-primary" />
          <h3 className="text-2xl font-bold">Placement Type</h3>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {placementTypes.map((placement, index) => {
            const Icon = getIcon(placement.icon);
            const isSelected = placementType === placement.name;

            return (
              <motion.div
                key={placement.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => onPlacementTypeChange(placement.name)}
                className={`
                  relative p-6 rounded-xl cursor-pointer transition-all duration-300 text-center
                  border-2 hover:shadow-lg hover:scale-105
                  ${isSelected 
                    ? 'border-primary bg-primary/5 shadow-lg scale-105' 
                    : 'border-border hover:border-primary/50 bg-card'
                  }
                `}
              >
                {isSelected && (
                  <div className="absolute -top-2 -right-2 w-6 h-6 rounded-full bg-primary flex items-center justify-center">
                    <Check className="w-4 h-4 text-primary-foreground" />
                  </div>
                )}

                <div className={`w-12 h-12 mx-auto rounded-lg ${isSelected ? 'bg-primary' : 'bg-muted'} flex items-center justify-center mb-3`}>
                  <Icon className={`w-6 h-6 ${isSelected ? 'text-primary-foreground' : 'text-foreground'}`} />
                </div>

                <h4 className="font-bold text-sm mb-1">{placement.display_name}</h4>
                <p className="text-xs text-muted-foreground">{placement.description}</p>
                
                {placement.price_multiplier > 1 && (
                  <div className="mt-2 text-xs font-bold text-primary">
                    +{((placement.price_multiplier - 1) * 100).toFixed(0)}% reach
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Targeting Options */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <MapPin className="w-6 h-6 text-primary" />
          <h3 className="text-2xl font-bold">Target Audience</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Region Selection */}
          <div className="space-y-3">
            <AnimatedLabel>Target Region</AnimatedLabel>
            <Select value={targetRegion} onValueChange={(value) => {
              onTargetRegionChange(value);
              onTargetDistrictsChange([]);
            }}>
              <SelectTrigger className="h-12 text-base">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {REGIONS.map(region => (
                  <SelectItem key={region} value={region}>{region}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Info className="w-3 h-3" />
              Regional targeting gets {(pricingConfig.regional_discount * 100).toFixed(0)}% discount
            </p>
          </div>

          {/* Estimated Reach */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="p-6 rounded-xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20"
          >
            <div className="flex items-center gap-3 mb-2">
              <Users className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium text-muted-foreground">Estimated Reach</span>
            </div>
            <div className="text-4xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              {estimatedReach.toLocaleString()}
            </div>
            <p className="text-xs text-muted-foreground mt-1">potential viewers</p>
          </motion.div>
        </div>

        {/* District Selection */}
        {targetRegion !== 'All Uganda' && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            className="space-y-3"
          >
            <AnimatedLabel>
              Specific Districts (Optional)
              <span className="text-xs text-muted-foreground ml-2">
                {targetDistricts.length} selected
              </span>
            </AnimatedLabel>
            
            <div className="flex flex-wrap gap-2 p-4 rounded-xl bg-muted/30 border border-border max-h-64 overflow-y-auto">
              {availableDistricts.map(district => (
                <Badge
                  key={district.id}
                  variant={targetDistricts.includes(district.id) ? "default" : "outline"}
                  className="cursor-pointer px-3 py-1.5 text-sm transition-all hover:scale-105"
                  onClick={() => handleDistrictToggle(district.id)}
                >
                  {district.name}
                  {targetDistricts.includes(district.id) && (
                    <Check className="w-3 h-3 ml-1.5" />
                  )}
                </Badge>
              ))}
            </div>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Info className="w-3 h-3" />
              District targeting (1-10 districts) gets additional {(pricingConfig.district_discount * 100).toFixed(0)}% discount
            </p>
          </motion.div>
        )}
      </div>

      {/* Duration Slider */}
      <div className="space-y-6 p-8 rounded-2xl bg-gradient-to-br from-card to-card/50 border border-border shadow-lg">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <Zap className="w-5 h-5 text-primary" />
              <AnimatedLabel className="text-xl">Boost Duration</AnimatedLabel>
            </div>
            <p className="text-sm text-muted-foreground">
              How long should your ad stay boosted?
            </p>
          </div>
          <div className="text-right">
            <div className="text-5xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              {duration}
            </div>
            <div className="text-sm text-muted-foreground font-medium">days</div>
          </div>
        </div>

        <Slider
          value={[duration]}
          onValueChange={(value) => onDurationChange(value[0])}
          min={pricingConfig.min_duration_days}
          max={pricingConfig.max_duration_days}
          step={1}
          className="w-full"
        />

        <div className="flex justify-between text-xs text-muted-foreground font-medium">
          <span>{pricingConfig.min_duration_days} day</span>
          <span>7 days</span>
          <span>15 days</span>
          <span>{pricingConfig.max_duration_days} days</span>
        </div>
      </div>

      {/* Price Summary */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-8 rounded-2xl bg-gradient-to-br from-primary/10 via-primary/5 to-transparent border-2 border-primary/20 shadow-xl"
      >
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="text-sm text-muted-foreground font-medium">Total Investment</div>
            <div className="text-5xl md:text-6xl font-bold bg-gradient-to-r from-primary to-primary/70 bg-clip-text text-transparent">
              {calculatedPrice.toLocaleString()} 
              <span className="text-2xl text-muted-foreground font-normal ml-2">{pricingConfig.currency}</span>
            </div>
          </div>
          
          <div className="text-right space-y-2 text-sm text-muted-foreground">
            <div className="flex items-center justify-end gap-2">
              <Check className="w-4 h-4 text-green-500" />
              <span>Instant activation</span>
            </div>
            <div className="flex items-center justify-end gap-2">
              <Check className="w-4 h-4 text-green-500" />
              <span>Real-time analytics</span>
            </div>
            <div className="flex items-center justify-end gap-2">
              <Check className="w-4 h-4 text-green-500" />
              <span>No hidden fees</span>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
