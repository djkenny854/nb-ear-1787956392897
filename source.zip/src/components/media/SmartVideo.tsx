import React, { useEffect, useMemo, useRef, useState, forwardRef, useImperativeHandle } from 'react';
import { Play } from 'lucide-react';
import { cn } from '@/lib/utils';
import { videoCdnUrl } from '@/utils/cdnUrl';
import { attachDecodeWatchdog } from '@/utils/videoDecodeGuard';
import { FALLBACK_THUMBNAIL } from '@/utils/fallbackImage';

export interface SmartVideoProps
  extends Omit<
    React.VideoHTMLAttributes<HTMLVideoElement>,
    'src' | 'poster' | 'preload' | 'onCanPlay'
  > {
  src: string | null | undefined;
  poster?: string | null;
  /** Optional secondary fallback (e.g. low-res blur thumbnail). */
  blurThumbnail?: string | null;
  /** Wrap the <video> in a black container so there is never a white flash. */
  wrapped?: boolean;
  /** Tailwind classes on the <video> element (or the wrapper when wrapped). */
  className?: string;
  /** Auto play / pause based on viewport visibility (muted, loop). */
  autoPlayInView?: boolean;
  /** Optional scroll container for IntersectionObserver. */
  scrollRoot?: Element | null;
  /** Visibility ratio at which we upgrade preload + start playback. */
  inViewThreshold?: number;
  /** Called once the element can paint a frame. */
  onReady?: () => void;
}

/**
 * SmartVideo — the single low-level player every video surface in the app
 * delegates to.
 *
 * Lazy loading: The <video> element is rendered immediately but carries NO
 * `src` until the container intersects the viewport (threshold 0.25). This
 * stops bulk metadata fetches when a feed with many video cards mounts.
 *
 * Poster fallback: When no poster is provided, the wrapper paints a solid
 * black background with a centered play icon, so the user always sees a
 * thumbnail-like state before the first frame is ready.
 */
const SmartVideo = forwardRef<HTMLVideoElement, SmartVideoProps>(function SmartVideo(
  {
    src,
    poster,
    blurThumbnail,
    wrapped = false,
    className,
    autoPlayInView = false,
    scrollRoot = null,
    inViewThreshold = 0.6,
    onReady,
    muted,
    loop,
    controls,
    playsInline = true,
    onLoadedData,
    onError,
    ...rest
  },
  ref,
) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  useImperativeHandle(ref, () => videoRef.current as HTMLVideoElement);

  const [ready, setReady] = useState(false);
  const [decodeFailed, setDecodeFailed] = useState(false);
  // Lazy: only attach src once the player has been in view at least once.
  // When native controls are shown (detail/fullscreen), attach eagerly so the
  // browser's built-in play button can start playback on the very first tap.
  const eager = Boolean(controls) || Boolean((rest as { autoPlay?: boolean }).autoPlay);
  const [attached, setAttached] = useState<boolean>(eager);

  useEffect(() => {
    if (eager) setAttached(true);
  }, [eager]);

  const resolvedSrc = useMemo(() => {
    if (!src) return '';
    let s = videoCdnUrl(src) || src;
    while (s.match(/^https:\/\/https:\/\//)) {
      s = s.replace(/^https:\/\/https:\/\//, 'https://');
    }
    return s;
  }, [src]);

  // Every player always has a poster: real thumbnail -> blur thumbnail ->
  // shared black placeholder. A video element must never fall back to the
  // browser's default (grey) media UI.
  const resolvedPoster = poster || blurThumbnail || FALLBACK_THUMBNAIL;

  // Single IntersectionObserver drives both lazy-attach AND autoplay.
  useEffect(() => {
    const target = containerRef.current || videoRef.current;
    if (!target) return;
    if (!resolvedSrc) return;

    const v = videoRef.current;

    const io = new IntersectionObserver(
      (entries) => {
        const entry = entries[0];
        if (!entry) return;
        // Attach as soon as the player enters the (expanded) viewport box so a
        // parent that drives playback itself never calls play() on a source-less
        // element.
        const visible = entry.isIntersecting;
        const fullyVisible = entry.isIntersecting && entry.intersectionRatio >= inViewThreshold;

        if (visible && !attached) {
          setAttached(true);
        }

        if (!v || !autoPlayInView) return;

        if (fullyVisible) {
          v.preload = 'auto';
          // `canplaythrough` can never fire for long clips streamed over range
          // requests, which left feed videos frozen on their poster. Try to play
          // right away and again as soon as any data is decodable.
          const tryPlay = () => {
            v.play().catch(() => {
              v.muted = true;
              v.play().catch(() => {});
            });
          };
          tryPlay();
          v.addEventListener('loadeddata', tryPlay, { once: true });
          v.addEventListener('canplay', tryPlay, { once: true });
        } else if (!entry.isIntersecting || entry.intersectionRatio < 0.1) {
          try { v.pause(); } catch {}
        }
      },
      {
        threshold: [0, 0.1, 0.25, inViewThreshold, 1],
        root: scrollRoot ?? null,
        rootMargin: '250px 0px',
      },
    );


    io.observe(target);
    return () => io.disconnect();
  }, [autoPlayInView, inViewThreshold, scrollRoot, resolvedSrc, attached]);

  useEffect(() => {
    setDecodeFailed(false);
    return attachDecodeWatchdog(videoRef.current, () => setDecodeFailed(true));
  }, [resolvedSrc, attached]);

  // Non-faststart MP4s (moov atom written at the END of the file — typical for
  // raw phone-camera uploads) never fire `loadedmetadata` with preload="metadata"
  // because the browser only grabs the head of the file. The card then sits on a
  // black poster forever. If nothing has loaded shortly after attaching, escalate
  // to preload="auto" and re-issue load()/play() so the full file is fetched and
  // the trailing moov atom is reached.
  useEffect(() => {
    if (!attached || !resolvedSrc) return;
    const v = videoRef.current;
    if (!v) return;
    const timer = window.setTimeout(() => {
      if (v.readyState >= 1) return; // metadata already parsed — nothing to do
      try {
        v.preload = 'auto';
        v.load();
        if (autoPlayInView) {
          v.play().catch(() => {
            v.muted = true;
            v.play().catch(() => {});
          });
        }
      } catch { /* noop */ }
    }, 2500);
    return () => window.clearTimeout(timer);
  }, [attached, resolvedSrc, autoPlayInView]);


  const handleCanPlay = () => {
    setReady(true);
    onReady?.();
  };

  // Reset readiness whenever the source changes so the poster covers the gap.
  useEffect(() => {
    setReady(false);
  }, [resolvedSrc]);

  // Safety net: some engines (Android WebView, iOS Safari after a bfcache
  // restore) fire `canplay`/`loadeddata` before React attaches its listeners,
  // which used to leave the <video> stuck at opacity-0 while it was actually
  // playing — a black frame with a moving progress bar. Poll the element's own
  // readyState/currentTime and reveal it as soon as it can paint.
  useEffect(() => {
    if (!attached || ready) return;
    const v = videoRef.current;
    if (!v) return;
    const reveal = () => {
      if (v.readyState >= 2 || v.currentTime > 0) setReady(true);
    };
    reveal();
    v.addEventListener('playing', reveal);
    v.addEventListener('timeupdate', reveal);
    v.addEventListener('loadedmetadata', reveal);
    const id = window.setInterval(reveal, 400);
    return () => {
      window.clearInterval(id);
      v.removeEventListener('playing', reveal);
      v.removeEventListener('timeupdate', reveal);
      v.removeEventListener('loadedmetadata', reveal);
    };
  }, [attached, ready, resolvedSrc]);

  // Black + play-icon fallback when no poster image is available.
  const showPlaceholder = !ready;
  const hasPosterImage = Boolean(resolvedPoster);

  const videoEl = (
    <video
      ref={videoRef}
      // Only attach src once visible. Keeps no network activity for off-screen players.
      src={attached && resolvedSrc ? resolvedSrc : undefined}
      poster={resolvedPoster}
      preload={attached ? 'metadata' : 'none'}
      playsInline={playsInline}
      // Legacy inline-playback hints — Android WebView (Capacitor) and older
      // iOS builds otherwise hijack the video into a black fullscreen layer.
      // eslint-disable-next-line react/no-unknown-property
      {...({ 'webkit-playsinline': 'true', 'x5-playsinline': 'true' } as Record<string, string>)}
      muted={muted}
      loop={loop}
      controls={controls}
      onCanPlay={handleCanPlay}
      onPlaying={handleCanPlay}
      onLoadedData={(e) => {
        handleCanPlay();
        onLoadedData?.(e);
      }}
      onError={(e) => {
        setDecodeFailed(true);
        onError?.(e);
      }}
      className={cn(
        'transition-opacity duration-300',
        ready && !decodeFailed ? 'opacity-100' : 'opacity-0',
        wrapped ? 'w-full h-full' : className,
      )}
      {...rest}
    />
  );


  // When NOT wrapped, still provide a positioned container so the
  // poster/play-icon fallback can sit behind the video.
  return (
    <div
      ref={containerRef}
      className={cn(
        'relative overflow-hidden bg-black',
        wrapped ? className : 'w-full h-full',
      )}
      style={
        hasPosterImage
          ? {
              backgroundImage: `url(${resolvedPoster})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }
          : undefined
      }
    >
      {videoEl}
      {/* On decode failure we silently fall back to the poster/dark surface —
          never show an error message to the user. */}
      {showPlaceholder && !hasPosterImage && (
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-white/15 backdrop-blur-sm flex items-center justify-center">
            <Play className="w-7 h-7 text-white fill-white ml-0.5" />
          </div>
        </div>
      )}
    </div>
  );
});

export default SmartVideo;
