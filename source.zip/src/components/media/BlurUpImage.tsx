import React, { useMemo, useState } from 'react';
import { cn } from '@/lib/utils';
import { imageCdnUrl, imageLqipUrl } from '@/utils/cdnUrl';
import MaterialSpinner from '@/components/ui/MaterialSpinner';

/**
 * BlurHash-style progressive image for the web.
 *
 * Instead of storing a BlurHash string per row (which would need a DB
 * migration + encoder on upload), we request a ~24px CDN variant of the very
 * same object. It weighs well under 1KB, arrives almost instantly, and is
 * CSS-blurred + upscaled — visually identical to a BlurHash placeholder.
 * The full-resolution image is decoded off-thread and cross-fades over it.
 *
 * The wrapper always owns the layout box (fixed via aspect/size classes from
 * the caller), so no reflow ever happens while scrolling.
 */
export interface BlurUpImageProps
  extends Omit<React.ImgHTMLAttributes<HTMLImageElement>, 'onError' | 'src'> {
  src: string;
  alt: string;
  /** Rendered width hint used to pick the CDN variant. */
  width?: number;
  quality?: number;
  /** Class for the layout box (must define the size / aspect ratio). */
  containerClassName?: string;
  /** Visible items -> "high", off-screen queue -> "low". */
  priority?: 'high' | 'low' | 'auto';
  objectFit?: 'cover' | 'contain';
  onError?: React.ReactEventHandler<HTMLImageElement>;
}

const BlurUpImage: React.FC<BlurUpImageProps> = ({
  src,
  alt,
  width = 600,
  quality = 70,
  containerClassName,
  className,
  priority = 'auto',
  objectFit = 'cover',
  onError,
  ...imgProps
}) => {
  const [loaded, setLoaded] = useState(false);
  const [placeholderFailed, setPlaceholderFailed] = useState(false);

  // `null` when the deployment cannot generate a micro-thumbnail — we then
  // show the spinner instead of a broken/duplicate full-size request.
  const placeholder = useMemo(() => imageLqipUrl(src), [src]);
  const full = useMemo(
    () => imageCdnUrl(src, { width, quality }),
    [src, width, quality],
  );

  return (
    <div className={cn('relative overflow-hidden bg-muted', containerClassName)}>
      {/* Instant sub-1KB blurred placeholder */}
      {!loaded && placeholder && !placeholderFailed && (
        <img
          src={placeholder}
          alt=""
          aria-hidden
          draggable={false}
          onError={() => setPlaceholderFailed(true)}
          className="absolute inset-0 w-full h-full object-cover scale-110 blur-xl"
        />
      )}

      {/* No blur variant available -> never leave the user staring at nothing */}
      {!loaded && (!placeholder || placeholderFailed) && (
        <div className="absolute inset-0 flex items-center justify-center">
          <MaterialSpinner size={22} />
        </div>
      )}

      <img
        {...imgProps}
        src={full}
        alt={alt}
        loading={priority === 'high' ? 'eager' : 'lazy'}
        decoding="async"
        // @ts-expect-error - fetchpriority is valid HTML, typings lag behind
        fetchpriority={priority}
        draggable={false}
        onLoad={() => setLoaded(true)}
        onError={onError}
        className={cn(
          'absolute inset-0 w-full h-full transition-opacity duration-300',
          objectFit === 'cover' ? 'object-cover' : 'object-contain',
          loaded ? 'opacity-100' : 'opacity-0',
          className,
        )}
      />
    </div>
  );
};

export default React.memo(BlurUpImage);