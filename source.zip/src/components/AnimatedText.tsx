import React, { useEffect, useRef, useState } from 'react';

interface AnimatedTextProps {
  texts: string[];
  className?: string;
  duration?: number;
  delay?: number;
}

const AnimatedText: React.FC<AnimatedTextProps> = ({ 
  texts, 
  className = '', 
  duration = 3000,
  delay = 500 
}) => {
  const textRef = useRef<HTMLSpanElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (!textRef.current || texts.length <= 1) return;

    const animate = () => {
      if (!textRef.current) return;
      
      // Simple fade animation without anime.js
      textRef.current.style.opacity = '0';
      textRef.current.style.transform = 'translateY(-10px)';
      
      setTimeout(() => {
        setCurrentIndex((prev) => (prev + 1) % texts.length);
        
        setTimeout(() => {
          if (textRef.current) {
            textRef.current.style.opacity = '1';
            textRef.current.style.transform = 'translateY(0)';
          }
        }, delay);
      }, 300);
    };

    const interval = setInterval(animate, duration);
    return () => clearInterval(interval);
  }, [texts, duration, delay]);

  return (
    <span 
      ref={textRef}
      className={`inline-block transition-all duration-300 ${className}`}
      style={{ opacity: 1, transform: 'translateY(0)' }}
    >
      {texts[currentIndex]}
    </span>
  );
};

export default AnimatedText;