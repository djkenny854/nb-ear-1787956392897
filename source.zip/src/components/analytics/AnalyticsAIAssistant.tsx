import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowUp, Sparkles, Bot, User, Loader2, Lightbulb, TrendingUp, Target, AlertCircle, Mic, Lock } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

interface AnalyticsContext {
  totalViews: number;
  totalClicks: number;
  totalBookmarks: number;
  totalComments: number;
  totalReviews: number;
  activeAds: number;
  topProduct?: string;
  businessName?: string;
}

interface AnalyticsAIAssistantProps {
  analyticsContext: AnalyticsContext;
}

const quickPrompts = [
  { icon: Lightbulb, label: 'Tips to increase views', prompt: 'Give me 3 actionable tips to increase my product views' },
  { icon: TrendingUp, label: 'Improve conversions', prompt: 'How can I improve my click-to-save conversion rate?' },
  { icon: Target, label: 'Best posting times', prompt: 'What are the best times to post new listings for maximum visibility?' },
  { icon: AlertCircle, label: 'Fix low engagement', prompt: 'My engagement is low. What could be wrong and how do I fix it?' },
];

export default function AnalyticsAIAssistant({ analyticsContext }: AnalyticsAIAssistantProps) {
  const [messages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: `Hi! I'm your AI business advisor. I'll help you optimize your listings and grow your business with personalized insights.`
    }
  ]);
  const [input, setInput] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const isDisabled = true; // Feature is disabled for now

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      className="h-full flex flex-col bg-card/60 backdrop-blur-md rounded-2xl border border-border/50 overflow-hidden relative"
    >
      {/* Disabled Overlay */}
      {isDisabled && (
        <div className="absolute inset-0 z-20 bg-background/80 backdrop-blur-sm flex flex-col items-center justify-center rounded-2xl">
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="flex flex-col items-center text-center px-6"
          >
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-4 border border-primary/20">
              <Lock className="w-7 h-7 text-primary/60" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Coming Soon</h3>
            <p className="text-sm text-muted-foreground max-w-[200px]">
              AI Business Advisor is not available right now. Stay tuned for updates!
            </p>
          </motion.div>
        </div>
      )}

      {/* Header */}
      <div className="p-4 border-b border-border/50 bg-gradient-to-r from-primary/10 via-primary/5 to-transparent">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-primary to-primary/60 flex items-center justify-center shadow-lg shadow-primary/20">
            <Sparkles className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h3 className="font-semibold text-base">AI Business Advisor</h3>
            <p className="text-xs text-muted-foreground">Get personalized insights</p>
          </div>
        </div>
      </div>

      {/* Quick Prompts */}
      <div className="p-3 border-b border-border/30 bg-muted/20">
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium mb-2">Quick Actions</p>
        <div className="flex flex-wrap gap-1.5">
          {quickPrompts.map((qp, idx) => (
            <button
              key={idx}
              disabled={isDisabled}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs bg-background/80 hover:bg-background rounded-lg border border-border/50 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <qp.icon className="w-3 h-3 text-primary" />
              <span className="truncate">{qp.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Messages Area */}
      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          <AnimatePresence mode="popLayout">
            {messages.map((message) => (
              <motion.div
                key={message.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
              >
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 ${
                  message.role === 'assistant' 
                    ? 'bg-gradient-to-br from-primary/20 to-primary/10 text-primary' 
                    : 'bg-muted text-muted-foreground'
                }`}>
                  {message.role === 'assistant' ? <Bot className="w-4 h-4" /> : <User className="w-4 h-4" />}
                </div>
                <div className={`flex-1 p-3 rounded-2xl text-sm leading-relaxed ${
                  message.role === 'assistant'
                    ? 'bg-muted/50 border border-border/30'
                    : 'bg-primary text-primary-foreground'
                }`}>
                  {message.content}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </ScrollArea>

      {/* Modern Input Area */}
      <div className="p-3 border-t border-border/50 bg-muted/30">
        <div className="relative flex items-center">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask for business tips..."
            disabled={isDisabled}
            className="w-full pl-4 pr-24 py-3 bg-background rounded-xl border border-border/50 text-sm placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/50 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          />
          <div className="absolute right-2 flex items-center gap-1.5">
            {/* Voice Input Button */}
            <button
              disabled={isDisabled}
              className="w-9 h-9 rounded-lg flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/80 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Mic className="w-4 h-4" />
            </button>
            {/* Submit Button */}
            <button
              disabled={isDisabled || !input.trim()}
              className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center text-primary-foreground hover:bg-primary/90 transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow-sm"
            >
              <ArrowUp className="w-4 h-4" strokeWidth={2.5} />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
