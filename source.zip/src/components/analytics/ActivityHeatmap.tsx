import React, { useMemo } from 'react';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import { Skeleton } from '@/components/ui/skeleton';
import { format, subDays, startOfDay, eachDayOfInterval } from 'date-fns';
import { cn } from '@/lib/utils';

interface PostActivity {
  date: string;
  count: number;
  items: { type: string; title: string }[];
}

interface ActivityHeatmapProps {
  data: PostActivity[];
  loading?: boolean;
}

const ActivityHeatmap: React.FC<ActivityHeatmapProps> = ({ data, loading }) => {
  // Generate last 365 days
  const days = useMemo(() => {
    const end = new Date();
    const start = subDays(end, 364);
    return eachDayOfInterval({ start, end });
  }, []);

  // Create a map for quick lookup
  const activityMap = useMemo(() => {
    const map = new Map<string, PostActivity>();
    data.forEach(item => {
      map.set(item.date, item);
    });
    return map;
  }, [data]);

  // Get max count for color scaling
  const maxCount = useMemo(() => {
    return Math.max(1, ...data.map(d => d.count));
  }, [data]);

  // Get color intensity based on count
  const getColorClass = (count: number) => {
    if (count === 0) return 'bg-muted';
    const intensity = count / maxCount;
    if (intensity <= 0.25) return 'bg-primary/30';
    if (intensity <= 0.5) return 'bg-primary/50';
    if (intensity <= 0.75) return 'bg-primary/70';
    return 'bg-primary';
  };

  // Group days by week
  const weeks = useMemo(() => {
    const result: Date[][] = [];
    let currentWeek: Date[] = [];
    
    days.forEach((day, index) => {
      const dayOfWeek = day.getDay();
      
      // Start new week on Sunday
      if (dayOfWeek === 0 && currentWeek.length > 0) {
        result.push(currentWeek);
        currentWeek = [];
      }
      
      currentWeek.push(day);
      
      // Push last week
      if (index === days.length - 1) {
        result.push(currentWeek);
      }
    });
    
    return result;
  }, [days]);

  // Month labels
  const monthLabels = useMemo(() => {
    const labels: { month: string; index: number }[] = [];
    let lastMonth = -1;
    
    weeks.forEach((week, weekIndex) => {
      const firstDay = week[0];
      const month = firstDay.getMonth();
      
      if (month !== lastMonth) {
        labels.push({
          month: format(firstDay, 'MMM'),
          index: weekIndex
        });
        lastMonth = month;
      }
    });
    
    return labels;
  }, [weeks]);

  if (loading) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-6 w-48" />
        <Skeleton className="h-[120px] w-full" />
      </div>
    );
  }

  const dayLabels = ['', 'Mon', '', 'Wed', '', 'Fri', ''];

  return (
    <TooltipProvider delayDuration={100}>
      <div className="overflow-x-auto">
        {/* Month labels */}
        <div className="flex mb-1 text-[10px] text-muted-foreground">
          <div className="w-8" /> {/* Spacer for day labels */}
          <div className="flex-1 flex relative">
            {monthLabels.map((label, i) => (
              <div
                key={i}
                className="absolute text-muted-foreground"
                style={{ left: `${(label.index / weeks.length) * 100}%` }}
              >
                {label.month}
              </div>
            ))}
          </div>
        </div>

        <div className="flex gap-0.5">
          {/* Day labels */}
          <div className="flex flex-col gap-0.5 text-[10px] text-muted-foreground pr-1">
            {dayLabels.map((label, i) => (
              <div key={i} className="h-3 flex items-center justify-end">
                {label}
              </div>
            ))}
          </div>

          {/* Heatmap grid */}
          <div className="flex gap-0.5">
            {weeks.map((week, weekIndex) => (
              <div key={weekIndex} className="flex flex-col gap-0.5">
                {Array.from({ length: 7 }).map((_, dayIndex) => {
                  const day = week.find(d => d.getDay() === dayIndex);
                  
                  if (!day) {
                    return <div key={dayIndex} className="w-3 h-3" />;
                  }

                  const dateKey = format(day, 'yyyy-MM-dd');
                  const activity = activityMap.get(dateKey);
                  const count = activity?.count || 0;

                  return (
                    <Tooltip key={dayIndex}>
                      <TooltipTrigger asChild>
                        <div
                          className={cn(
                            'w-3 h-3 rounded-sm cursor-pointer transition-all hover:ring-1 hover:ring-foreground/30',
                            getColorClass(count)
                          )}
                        />
                      </TooltipTrigger>
                      <TooltipContent side="top" className="text-xs">
                        <p className="font-medium">{format(day, 'MMM d, yyyy')}</p>
                        <p className="text-muted-foreground">
                          {count === 0 
                            ? 'No posts' 
                            : `${count} post${count > 1 ? 's' : ''}`}
                        </p>
                        {activity?.items?.slice(0, 3).map((item, i) => (
                          <p key={i} className="text-muted-foreground text-[10px] truncate max-w-[150px]">
                            • {item.type}: {item.title}
                          </p>
                        ))}
                        {activity?.items && activity.items.length > 3 && (
                          <p className="text-muted-foreground text-[10px]">
                            +{activity.items.length - 3} more
                          </p>
                        )}
                      </TooltipContent>
                    </Tooltip>
                  );
                })}
              </div>
            ))}
          </div>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-2 mt-3 text-[10px] text-muted-foreground justify-end">
          <span>Less</span>
          <div className="flex gap-0.5">
            <div className="w-3 h-3 rounded-sm bg-muted" />
            <div className="w-3 h-3 rounded-sm bg-primary/30" />
            <div className="w-3 h-3 rounded-sm bg-primary/50" />
            <div className="w-3 h-3 rounded-sm bg-primary/70" />
            <div className="w-3 h-3 rounded-sm bg-primary" />
          </div>
          <span>More</span>
        </div>
      </div>
    </TooltipProvider>
  );
};

export default ActivityHeatmap;
