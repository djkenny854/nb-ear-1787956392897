import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Legend, AreaChart, Area
} from 'recharts';

interface DataPoint {
  label: string;
  views: number;
  clicks: number;
  bookmarks: number;
  comments: number;
  reviews?: number;
  followers?: number;
  interested?: number;
}

interface AnimatedLineChartProps {
  data: DataPoint[];
  title: string;
  subtitle?: string;
  type?: 'line' | 'area';
  showAll?: boolean;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-card border border-border rounded-xl p-3 shadow-xl"
      >
        <p className="font-medium text-sm mb-2">{label}</p>
        {payload.map((entry: any, index: number) => (
          <div key={index} className="flex items-center gap-2 text-xs">
            <div 
              className="w-2 h-2 rounded-full" 
              style={{ backgroundColor: entry.color }}
            />
            <span className="text-muted-foreground">{entry.name}:</span>
            <span className="font-medium">{entry.value.toLocaleString()}</span>
          </div>
        ))}
      </motion.div>
    );
  }
  return null;
};

export default function AnimatedLineChart({
  data,
  title,
  subtitle,
  type = 'area',
  showAll = false
}: AnimatedLineChartProps) {
  const [animatedData, setAnimatedData] = useState<DataPoint[]>([]);
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    setAnimatedData([]);
    setIsAnimating(true);
    
    // Animate data points appearing one by one
    data.forEach((point, index) => {
      setTimeout(() => {
        setAnimatedData(prev => [...prev, point]);
        if (index === data.length - 1) {
          setIsAnimating(false);
        }
      }, index * 100);
    });
  }, [data]);

  const colors = {
    views: 'hsl(221, 83%, 53%)',
    clicks: 'hsl(142, 76%, 36%)',
    bookmarks: 'hsl(38, 92%, 50%)',
    comments: 'hsl(262, 83%, 58%)',
    reviews: 'hsl(0, 84%, 60%)',
    followers: 'hsl(330, 81%, 60%)',
    interested: 'hsl(45, 93%, 47%)',
  };

  const Chart = type === 'area' ? AreaChart : LineChart;
  const DataElement = type === 'area' ? Area : Line;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="w-full h-full"
    >
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <Chart data={animatedData}>
            <defs>
              {Object.entries(colors).map(([key, color]) => (
                <linearGradient key={key} id={`gradient-${key}`} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={color} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={color} stopOpacity={0} />
                </linearGradient>
              ))}
            </defs>
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke="hsl(var(--muted))" 
              opacity={0.2} 
              vertical={false} 
            />
            <XAxis
              dataKey="label"
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: 'hsl(var(--muted-foreground))', fontSize: 11 }}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend 
              iconType="circle" 
              wrapperStyle={{ paddingTop: 16 }}
            />
            
            {type === 'area' ? (
              <>
                <Area
                  type="monotone"
                  dataKey="views"
                  name="Views"
                  stroke={colors.views}
                  fill={`url(#gradient-views)`}
                  strokeWidth={2}
                  dot={false}
                  animationDuration={1500}
                  animationEasing="ease-out"
                />
                <Area
                  type="monotone"
                  dataKey="clicks"
                  name="Clicks"
                  stroke={colors.clicks}
                  fill={`url(#gradient-clicks)`}
                  strokeWidth={2}
                  dot={false}
                  animationDuration={1500}
                  animationEasing="ease-out"
                />
                {showAll && (
                  <>
                    <Area
                      type="monotone"
                      dataKey="bookmarks"
                      name="Bookmarks"
                      stroke={colors.bookmarks}
                      fill={`url(#gradient-bookmarks)`}
                      strokeWidth={2}
                      dot={false}
                      animationDuration={1500}
                      animationEasing="ease-out"
                    />
                    <Area
                      type="monotone"
                      dataKey="comments"
                      name="Comments"
                      stroke={colors.comments}
                      fill={`url(#gradient-comments)`}
                      strokeWidth={2}
                      dot={false}
                      animationDuration={1500}
                      animationEasing="ease-out"
                    />
                    <Area
                      type="monotone"
                      dataKey="followers"
                      name="Followers"
                      stroke={colors.followers}
                      fill={`url(#gradient-followers)`}
                      strokeWidth={2}
                      dot={false}
                      animationDuration={1500}
                      animationEasing="ease-out"
                    />
                    <Area
                      type="monotone"
                      dataKey="interested"
                      name="Interested"
                      stroke={colors.interested}
                      fill={`url(#gradient-interested)`}
                      strokeWidth={2}
                      dot={false}
                      animationDuration={1500}
                      animationEasing="ease-out"
                    />
                  </>
                )}
              </>
            ) : (
              <>
                <Line
                  type="monotone"
                  dataKey="views"
                  name="Views"
                  stroke={colors.views}
                  strokeWidth={2}
                  dot={{ fill: colors.views, strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, strokeWidth: 2 }}
                  animationDuration={1500}
                  animationEasing="ease-out"
                />
                <Line
                  type="monotone"
                  dataKey="clicks"
                  name="Clicks"
                  stroke={colors.clicks}
                  strokeWidth={2}
                  dot={{ fill: colors.clicks, strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, strokeWidth: 2 }}
                  animationDuration={1500}
                  animationEasing="ease-out"
                />
                {showAll && (
                  <>
                    <Line
                      type="monotone"
                      dataKey="bookmarks"
                      name="Bookmarks"
                      stroke={colors.bookmarks}
                      strokeWidth={2}
                      dot={{ fill: colors.bookmarks, strokeWidth: 2, r: 4 }}
                      animationDuration={1500}
                      animationEasing="ease-out"
                    />
                    <Line
                      type="monotone"
                      dataKey="comments"
                      name="Comments"
                      stroke={colors.comments}
                      strokeWidth={2}
                      dot={{ fill: colors.comments, strokeWidth: 2, r: 4 }}
                      animationDuration={1500}
                      animationEasing="ease-out"
                    />
                  </>
                )}
              </>
            )}
          </Chart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}
