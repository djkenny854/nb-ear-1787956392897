import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { useLocation } from 'react-router-dom';

/**
 * KeepAlive routing
 *
 * Purpose
 *   Keep the social feed (/discover) and marketplace (/marketplace)
 *   components mounted for the lifetime of the browser session so that
 *   in-app navigation away and back is instant, state survives, and
 *   browser-native scroll position is preserved without any JS.
 *
 * Architecture
 *   ┌──────────────────────────────────────────────────────────────┐
 *   │  <KeepAliveProvider>                  (App root)              │
 *   │    ├─ <Routes> ... (normal routes, mount/unmount as usual)    │
 *   │    └─ <KeepAliveHost>                                         │
 *   │         renders every registered slot once; toggles visibility│
 *   │         based on the active route                             │
 *   │              ├─ slot "/discover"   ← real <SocialFeed/>       │
 *   │              └─ slot "/marketplace"← real <Search/>           │
 *   └──────────────────────────────────────────────────────────────┘
 *
 *   The `<Route path="discover">` / `<Route path="marketplace">` entries
 *   in the router render a thin <KeepAliveSlot path="..." /> placeholder
 *   so React Router still "matches" the path (active nav state, no
 *   NotFound), but the real component lives in <KeepAliveHost/> outside
 *   of <Routes>, never unmounted.
 *
 * Visibility toggling
 *   Inactive slots get display:none + visibility:hidden + height:0 +
 *   overflow:hidden + pointer-events:none + aria-hidden, so they consume
 *   no visual space and receive no interaction. They are never removed
 *   from the React tree, so child state / scroll position survives.
 */

/**
 * Canonical list of paths kept alive across in-app navigation.
 * Keep this in sync with the <Route path="..."/> entries in src/App.tsx
 * and the entries map passed to <KeepAliveHost/> in src/components/Layout.tsx.
 */
export const KEEP_ALIVE_PATHS = ['/discover', '/marketplace'] as const;
export type KeepAlivePath = typeof KEEP_ALIVE_PATHS[number];

// ---------------------------------------------------------------------------
// Context
// ---------------------------------------------------------------------------

interface KeepAliveContextValue {
  /** All paths managed by the keep-alive system. */
  paths: readonly string[];
  /** Whether a given path is the active one right now. */
  isActive: (path: string) => boolean;
}

const KeepAliveContext = createContext<KeepAliveContextValue | null>(null);

// ---------------------------------------------------------------------------
// Provider
// ---------------------------------------------------------------------------

interface KeepAliveProviderProps {
  /** Children to render (typically <Routes/> plus <KeepAliveHost/>). */
  children: React.ReactNode;
  /** Paths kept alive. Must match the router's path values exactly. */
  paths: readonly string[];
}

export const KeepAliveProvider: React.FC<KeepAliveProviderProps> = ({
  children,
  paths,
}) => {
  const location = useLocation();
  const currentPath = location.pathname;

  const value = useMemo<KeepAliveContextValue>(
    () => ({
      paths,
      isActive: (p: string) => currentPath === p,
    }),
    [paths, currentPath]
  );

  return (
    <KeepAliveContext.Provider value={value}>
      {children}
    </KeepAliveContext.Provider>
  );
};

const useKeepAlive = (): KeepAliveContextValue => {
  const ctx = useContext(KeepAliveContext);
  if (!ctx) {
    throw new Error(
      'KeepAlive: component used outside <KeepAliveProvider>. Wrap your <Routes/> + <KeepAliveHost/> with <KeepAliveProvider paths={[...]}/>.'
    );
  }
  return ctx;
};

// ---------------------------------------------------------------------------
// Slot placeholder (rendered inside <Route element={...} />)
// ---------------------------------------------------------------------------

/**
 * Tiny placeholder that React Router renders in the normal <Outlet/>.
 * It produces no UI — the real component for this path lives inside
 * <KeepAliveHost/> as a persistent sibling.
 */
export const KeepAliveSlot: React.FC<{ path: string }> = ({ path }) => {
  // Touch the context so misconfiguration throws loudly during dev.
  const { paths } = useKeepAlive();
  if (!paths.includes(path)) {
    // eslint-disable-next-line no-console
    console.warn(
      `[KeepAlive] <KeepAliveSlot path="${path}"/> rendered but path is not registered in <KeepAliveProvider paths={...}/>.`
    );
  }
  return null;
};

// ---------------------------------------------------------------------------
// Host — renders every kept-alive entry once, toggles visibility
// ---------------------------------------------------------------------------

interface KeepAliveHostProps {
  /**
   * Map of path → element. Every entry is mounted exactly once for the
   * lifetime of the host and never unmounts on navigation.
   *
   * The map should be defined in a stable module scope (or memoized) so
   * the elements are referentially stable across renders.
   */
  entries: Readonly<Record<string, React.ReactNode>>;
  /** Optional className applied to the host wrapper. */
  className?: string;
}

/**
 * KeepAliveHost
 *
 * Renders every registered path once. The active one is shown; all
 * others are hidden via CSS (display:none + a11y guards) but remain
 * mounted with their state intact.
 *
 * Mounting strategy: a path is only inserted into the DOM the FIRST
 * time it becomes active. After that it stays in the DOM forever
 * (for the session). This avoids paying the mount cost for routes
 * the user never visits.
 */
export const KeepAliveHost: React.FC<KeepAliveHostProps> = ({
  entries,
  className,
}) => {
  const { isActive } = useKeepAlive();

  // Track which paths have ever been activated; only those are rendered.
  const everActivatedRef = useRef<Set<string>>(new Set());
  const [, forceRender] = useState(0);

  // Whenever the active path changes, ensure it is in the "ever activated"
  // set so it gets rendered on this pass.
  const knownPaths = Object.keys(entries);
  let dirty = false;
  for (const p of knownPaths) {
    if (isActive(p) && !everActivatedRef.current.has(p)) {
      everActivatedRef.current.add(p);
      dirty = true;
    }
  }
  // If we just added a new path, trigger a follow-up render so the new
  // entry appears in the DOM. (Ref mutation alone doesn't re-render.)
  useEffect(() => {
    if (dirty) forceRender((n) => n + 1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  });

  return (
    <div data-em-keep-alive-host="" className={className}>
      {knownPaths.map((path) => {
        const mounted = everActivatedRef.current.has(path);
        if (!mounted) return null;
        const active = isActive(path);
        return (
          <div
            key={path}
            data-em-keep-alive-slot={path}
            aria-hidden={active ? undefined : 'true'}
            style={
              active
                ? {
                    display: 'block',
                    visibility: 'visible',
                    pointerEvents: 'auto',
                  }
                : {
                    display: 'none',
                    visibility: 'hidden',
                    height: 0,
                    overflow: 'hidden',
                    pointerEvents: 'none',
                  }
            }
          >
            {entries[path]}
          </div>
        );
      })}
    </div>
  );
};

// ---------------------------------------------------------------------------
// Convenience hook (currently unused by callers, exported for completeness)
// ---------------------------------------------------------------------------

export const useIsKeepAlivePath = (path: string): boolean => {
  const ctx = useContext(KeepAliveContext);
  // Stable callback (no deps drift if caller passes a literal).
  const isActive = useCallback(
    () => (ctx ? ctx.isActive(path) : false),
    [ctx, path]
  );
  return isActive();
};
