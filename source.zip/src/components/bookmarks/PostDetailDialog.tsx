import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from '@/components/ui/drawer';
import { useIsMobile } from '@/hooks/use-mobile';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { BadgeCheck, ExternalLink } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { useNavigate } from 'react-router-dom';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  post: any | null;
}

const PostDetailDialog: React.FC<Props> = ({ open, onOpenChange, post }) => {
  const isMobile = useIsMobile();
  const navigate = useNavigate();

  if (!post) return null;

  const seller = post.seller;
  const images: string[] = Array.isArray(post.images) ? post.images : [];

  const body = (
    <div className="space-y-4">
      {/* Author */}
      <div className="flex items-center gap-3">
        <Avatar className="w-10 h-10">
          <AvatarImage src={post.business_logo_url || seller?.logo} alt={seller?.name} />
          <AvatarFallback className="bg-primary/10 text-primary">
            {seller?.name?.charAt(0)?.toUpperCase() || 'U'}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <p className="font-semibold text-sm truncate">{seller?.name || 'User'}</p>
            {seller?.isVerified && <BadgeCheck className="w-3.5 h-3.5 text-primary flex-shrink-0" />}
          </div>
          {post.created_at && (
            <p className="text-xs text-muted-foreground">
              {formatDistanceToNow(new Date(post.created_at), { addSuffix: true })}
            </p>
          )}
        </div>
      </div>

      {/* Content */}
      {post.title && (
        <h3 className="text-base font-semibold leading-snug">{post.title}</h3>
      )}
      {post.content && (
        <p className="text-sm text-foreground whitespace-pre-wrap leading-relaxed">
          {post.content}
        </p>
      )}
      {post.description && !post.content && (
        <p className="text-sm text-foreground whitespace-pre-wrap leading-relaxed">
          {post.description}
        </p>
      )}

      {/* Images */}
      {images.length > 0 && (
        <div className={`grid gap-2 ${images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'}`}>
          {images.slice(0, 4).map((src, i) => (
            <div key={i} className="relative aspect-square rounded-xl overflow-hidden bg-muted">
              <img src={src} alt="" className="w-full h-full object-cover" />
            </div>
          ))}
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-2 pt-1">
        <Button
          variant="outline"
          size="sm"
          className="flex-1 rounded-full gap-2"
          onClick={() => {
            onOpenChange(false);
            navigate('/following');
          }}
        >
          <ExternalLink className="w-3.5 h-3.5" />
          Open in feed
        </Button>
        {seller?.id && (
          <Button
            size="sm"
            className="flex-1 rounded-full"
            onClick={() => {
              onOpenChange(false);
              navigate(`/seller/${seller.id}`);
            }}
          >
            Visit author
          </Button>
        )}
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="px-4 pb-8 max-h-[85vh] overflow-y-auto">
          <DrawerHeader className="text-left px-0">
            <DrawerTitle className="sr-only">Post details</DrawerTitle>
            <DrawerDescription className="sr-only">Saved post preview</DrawerDescription>
          </DrawerHeader>
          {body}
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="sr-only">Post details</DialogTitle>
          <DialogDescription className="sr-only">Saved post preview</DialogDescription>
        </DialogHeader>
        {body}
      </DialogContent>
    </Dialog>
  );
};

export default PostDetailDialog;
