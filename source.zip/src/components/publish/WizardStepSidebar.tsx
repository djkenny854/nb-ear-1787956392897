import React from 'react';
import { Check, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface WizardStep {
  label: string;
}

interface WizardStepSidebarProps {
  steps: WizardStep[];
  currentStep: number; // 0-indexed
  title: string;
}

const WizardStepSidebar: React.FC<WizardStepSidebarProps> = ({
  steps,
  currentStep,
  title,
}) => {
  return (
    <>
      {/* Desktop Sidebar */}
      <div className="hidden lg:flex lg:w-64 flex-col fixed h-screen bg-card border-r border-border z-20">
        {/* Title */}
        <div className="px-6 pt-8 pb-6">
          <h2 className="text-lg font-semibold text-foreground leading-snug">
            {title}
          </h2>
        </div>

        {/* Steps List with vertical connector */}
        <nav className="flex-1 px-6 py-2 overflow-y-auto">
          <div className="relative">
            {steps.map((step, index) => {
              const isCompleted = index < currentStep;
              const isCurrent = index === currentStep;
              const isFuture = index > currentStep;
              const isLast = index === steps.length - 1;

              return (
                <div key={index} className="relative flex items-start">
                  {/* Vertical connector line */}
                  {!isLast && (
                    <div
                      className={cn(
                        'absolute left-[11px] top-[28px] w-[2px] h-[calc(100%-4px)]',
                        isCompleted ? 'bg-primary' : 'bg-border'
                      )}
                    />
                  )}

                  {/* Step indicator + label */}
                  <div className="flex items-center gap-3 pb-6 relative z-10">
                    {/* Circle / Check indicator */}
                    <div
                      className={cn(
                        'flex items-center justify-center w-6 h-6 rounded-full shrink-0 transition-all',
                        isCompleted && 'bg-primary',
                        isCurrent && 'border-2 border-primary bg-primary/10',
                        isFuture && 'border-2 border-border bg-background'
                      )}
                    >
                      {isCompleted ? (
                        <Check className="w-3.5 h-3.5 text-primary-foreground" />
                      ) : isCurrent ? (
                        <ChevronRight className="w-3.5 h-3.5 text-primary" />
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-muted-foreground/30" />
                      )}
                    </div>

                    {/* Label */}
                    <span
                      className={cn(
                        'text-sm transition-colors',
                        isCompleted && 'text-foreground font-medium',
                        isCurrent && 'text-primary font-semibold',
                        isFuture && 'text-muted-foreground'
                      )}
                    >
                      {step.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </nav>
      </div>

      {/* Mobile: Hidden — wizard steps not shown on small devices */}
    </>
  );
};

export default WizardStepSidebar;
