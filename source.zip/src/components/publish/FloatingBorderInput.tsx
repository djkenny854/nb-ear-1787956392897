import { useState, useId, forwardRef, ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface Props {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  autoFocus?: boolean;
  className?: string;
  inputClassName?: string;
  id?: string;
  name?: string;
  autoComplete?: string;
  minLength?: number;
  /** Left adornment rendered inside the field (e.g. flag, country code). */
  leftSlot?: ReactNode;
  /** Right adornment rendered inside the field (e.g. eye toggle). */
  rightSlot?: ReactNode;
  /** Extra left padding when leftSlot is wide. */
  leftPadding?: string;
}

/**
 * Material-style outlined input — label sits inside, then floats up and
 * notches into the top border on focus or when filled.
 */
const FloatingBorderInput = forwardRef<HTMLInputElement, Props>(function FloatingBorderInput({
  label, value, onChange, type = 'text', required, autoFocus, className, inputClassName,
  id, name, autoComplete, minLength, leftSlot, rightSlot, leftPadding,
}, ref) {
  const reactId = useId();
  const inputId = id || reactId;
  const [focused, setFocused] = useState(false);
  const floated = focused || value.length > 0;

  return (
    <div className={cn('relative', className)}>
      {leftSlot && (
        <div className="absolute left-3 top-1/2 -translate-y-1/2 z-10 flex items-center pointer-events-none">
          {leftSlot}
        </div>
      )}
      <input
        id={inputId}
        ref={ref}
        type={type}
        value={value}
        name={name}
        autoComplete={autoComplete}
        minLength={minLength}
        required={required}
        autoFocus={autoFocus}
        onChange={e => onChange(e.target.value)}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        className={cn(
          'peer w-full h-14 rounded-xl bg-background px-4 text-base text-foreground outline-none transition-all',
          'border-[1.5px]',
          focused ? 'border-primary' : 'border-border hover:border-foreground/40',
          leftPadding,
          rightSlot && 'pr-12',
          inputClassName,
        )}
      />
      <label
        htmlFor={inputId}
        className={cn(
          'pointer-events-none absolute px-1 transition-all duration-150 select-none bg-background',
          leftPadding ? 'left-12' : 'left-3',
          floated
            ? 'top-0 -translate-y-1/2 text-xs ' + (focused ? 'text-primary' : 'text-muted-foreground')
            : 'top-1/2 -translate-y-1/2 text-base text-muted-foreground',
        )}
      >
        {label}{required && <span className="text-destructive ml-0.5">*</span>}
      </label>
      {rightSlot && (
        <div className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center">
          {rightSlot}
        </div>
      )}
    </div>
  );
});

export default FloatingBorderInput;
