import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Store, ArrowLeft, Building2 } from 'lucide-react';

interface BusinessAccountGuardProps {
  children: React.ReactNode;
}

/**
 * Blocks service-workspace routes for users who don't yet have a business or
 * organization seller account. Regular users are prompted to create one first.
 */
const BusinessAccountGuard: React.FC<BusinessAccountGuardProps> = ({ children }) => {
  const navigate = useNavigate();
  const { user } = useAuth();

  const { data: profile, isLoading } = useQuery({
    queryKey: ['business-account-guard', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('seller_profiles')
        .select('account_tier')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      if (error && error.code !== 'PGRST116') throw error;
      return data;
    },
    enabled: !!user,
    staleTime: 5 * 60 * 1000,
    refetchOnWindowFocus: false,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md w-full space-y-4">
          <Skeleton className="h-8 w-3/4 mx-auto" />
          <Skeleton className="h-4 w-full" />
          <Skeleton className="h-4 w-2/3 mx-auto" />
          <Skeleton className="h-12 w-40 mx-auto mt-6" />
        </div>
      </div>
    );
  }

  const hasBusinessAccount =
    profile?.account_tier === 'business' || profile?.account_tier === 'organization';

  if (!hasBusinessAccount) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center">
          <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-primary/10 flex items-center justify-center">
            <Building2 className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-foreground mb-3">
            Create a business account first
          </h1>
          <p className="text-muted-foreground mb-8">
            Service workspaces are for businesses. Set up your free business account
            to start building a service that earns customer trust.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button variant="outline" onClick={() => navigate(-1)} className="gap-2">
              <ArrowLeft className="w-4 h-4" />
              Go Back
            </Button>
            <Button onClick={() => navigate('/create-business-account')} className="gap-2">
              <Store className="w-4 h-4" />
              Create business account
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default BusinessAccountGuard;