import { cn } from '@/lib/utils';
import AnimatedLabel from './AnimatedLabel';
import { Textarea } from '@/components/ui/textarea';

interface ModernTextareaProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  rows?: number;
  id?: string;
  className?: string;
}

export default function ModernTextarea({
  label,
  value,
  onChange,
  placeholder,
  required = false,
  rows = 6,
  id,
  className,
}: ModernTextareaProps) {
  const textareaId = id || label.toLowerCase().replace(/\s+/g, '-');

  return (
    <div className={cn("space-y-2", className)}>
      {label && (
        <AnimatedLabel htmlFor={textareaId} required={required} showSkeleton={!value && !placeholder}>
          {label}
        </AnimatedLabel>
      )}
      <Textarea
        id={textareaId}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className="resize-none bg-background border-border focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all min-h-[120px] placeholder:text-muted-foreground/50"
      />
    </div>
  );
}
