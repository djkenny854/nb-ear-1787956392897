import { Label } from '@/components/ui/label';
import { cn } from '@/lib/utils';

interface AnimatedLabelProps {
  htmlFor?: string;
  children: React.ReactNode;
  required?: boolean;
  showSkeleton?: boolean;
  className?: string;
}

export default function AnimatedLabel({
  htmlFor,
  children,
  required = false,
  showSkeleton = false,
  className
}: AnimatedLabelProps) {
  return (
    <Label htmlFor={htmlFor} className={cn("text-sm font-medium text-foreground block", className)}>
      <span className="flex items-center gap-2">
        {showSkeleton ? (
          <span className="flex-1 flex items-center gap-2">
            <span className="h-4 flex-1 max-w-[200px] rounded animate-pulse bg-gradient-to-r from-muted via-muted-foreground/20 to-muted bg-[length:200%_100%] animate-[shimmer_2s_ease-in-out_infinite]" />
            {required && <span className="text-destructive">*</span>}
          </span>
        ) : (
          <>
            {children}
            {required && <span className="text-destructive ml-1">*</span>}
          </>
        )}
      </span>
    </Label>
  );
}
