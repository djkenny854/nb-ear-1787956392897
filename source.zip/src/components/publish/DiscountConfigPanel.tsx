import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { 
  Clock, 
  Zap, 
  Calendar, 
  Tag, 
  Percent, 
  ShoppingBag, 
  Bell, 
  TrendingUp,
  Sparkles,
  Timer,
  Package,
  ChevronDown,
  ChevronUp,
  Store,
  Layers,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

export type PromotionSubType = 'standard' | 'flash_sale' | 'scheduled_drop' | 'happy_hour' | 'category_takeover' | 'seller_wide';

interface HappyHourWindow {
  id: string;
  startTime: string;
  endTime: string;
  days: string[];
}

interface SellerProduct {
  id: string;
  title: string;
  price: number;
  images: string[];
  category: string;
  has_discount?: boolean;
  original_price?: number;
}

interface DiscountMapping {
  productId: string;
  discountPercent: number;
}

export interface DiscountConfig {
  subType: PromotionSubType;
  discountPercent: number;
  isSellerWide: boolean;
  selectedProducts: string[];
  discountMapping: DiscountMapping[];
  categoryFilter: string[];
  happyHourWindows: HappyHourWindow[];
  scheduledStartTime: string;
  enableReminders: boolean;
  maxClaims?: number;
  perProductOverrides: boolean;
  existingDiscountHandling: 'unify' | 'keep_existing' | 'override';
}

interface DiscountConfigPanelProps {
  config: DiscountConfig;
  onChange: (config: DiscountConfig) => void;
}

const DAYS_OF_WEEK = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const PROMOTION_SUBTYPES = [
  {
    id: 'standard' as PromotionSubType,
    title: 'Standard Discount',
    description: 'Classic discount on selected products',
    icon: Percent,
    color: 'text-primary',
    bgColor: 'bg-primary/10',
    available: true
  },
  {
    id: 'seller_wide' as PromotionSubType,
    title: 'Store-wide Sale',
    description: 'Apply discount to all your products',
    icon: Store,
    color: 'text-orange-500',
    bgColor: 'bg-orange-500/10',
    available: true
  },
  {
    id: 'scheduled_drop' as PromotionSubType,
    title: 'Scheduled Drop',
    description: 'Build hype before discounts go live',
    icon: Calendar,
    color: 'text-purple-500',
    bgColor: 'bg-purple-500/10',
    available: false
  },
  {
    id: 'happy_hour' as PromotionSubType,
    title: 'Happy Hours',
    description: 'Short time windows with big discounts',
    icon: Timer,
    color: 'text-blue-500',
    bgColor: 'bg-blue-500/10',
    available: false
  },
  {
    id: 'category_takeover' as PromotionSubType,
    title: 'Category Takeover',
    description: 'Dominate a category with your deals',
    icon: Layers,
    color: 'text-green-500',
    bgColor: 'bg-green-500/10',
    available: false
  }
];

const CATEGORIES = [
  'Electronics', 'Fashion', 'Home & Garden', 'Sports', 'Beauty', 
  'Automotive', 'Food & Drinks', 'Services', 'Real Estate', 'Jobs'
];

export default function DiscountConfigPanel({ config, onChange }: DiscountConfigPanelProps) {
  const { user } = useAuth();
  const [products, setProducts] = useState<SellerProduct[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [expandedSections, setExpandedSections] = useState({
    products: true,
    timing: false,
    advanced: false
  });

  useEffect(() => {
    fetchSellerProducts();
  }, [user]);

  const fetchSellerProducts = async () => {
    if (!user) return;
    
    try {
      const { data: sellerProfile } = await supabase
        .from('seller_profiles')
        .select('id')
        .eq('user_id', user.id)
        .single();

      if (!sellerProfile) return;

      const { data } = await supabase
        .from('ads')
        .select('id, title, price, images, category, has_discount, original_price')
        .eq('seller_id', sellerProfile.id)
        .eq('status', 'active')
        .eq('listing_type', 'physical_products')
        .limit(50);

      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoadingProducts(false);
    }
  };

  const toggleSection = (section: keyof typeof expandedSections) => {
    setExpandedSections(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const updateConfig = (partial: Partial<DiscountConfig>) => {
    onChange({ ...config, ...partial });
  };

  const toggleProduct = (productId: string) => {
    const newSelected = config.selectedProducts.includes(productId)
      ? config.selectedProducts.filter(id => id !== productId)
      : [...config.selectedProducts, productId];
    
    // Update discount mapping for new products
    const newMapping = newSelected.map(id => {
      const existing = config.discountMapping.find(m => m.productId === id);
      return existing || { productId: id, discountPercent: config.discountPercent };
    });

    updateConfig({ selectedProducts: newSelected, discountMapping: newMapping });
  };

  const updateProductDiscount = (productId: string, percent: number) => {
    const newMapping = config.discountMapping.map(m => 
      m.productId === productId ? { ...m, discountPercent: percent } : m
    );
    updateConfig({ discountMapping: newMapping });
  };

  const addHappyHourWindow = () => {
    const newWindow: HappyHourWindow = {
      id: Date.now().toString(),
      startTime: '14:00',
      endTime: '16:00',
      days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
    };
    updateConfig({ happyHourWindows: [...config.happyHourWindows, newWindow] });
  };

  const updateHappyHourWindow = (id: string, updates: Partial<HappyHourWindow>) => {
    const newWindows = config.happyHourWindows.map(w => 
      w.id === id ? { ...w, ...updates } : w
    );
    updateConfig({ happyHourWindows: newWindows });
  };

  const removeHappyHourWindow = (id: string) => {
    updateConfig({ happyHourWindows: config.happyHourWindows.filter(w => w.id !== id) });
  };

  const selectAllProducts = () => {
    const allIds = products.map(p => p.id);
    const allMappings = allIds.map(id => ({ productId: id, discountPercent: config.discountPercent }));
    updateConfig({ selectedProducts: allIds, discountMapping: allMappings });
  };

  const selectByCategory = (category: string) => {
    const categoryProducts = products.filter(p => p.category === category);
    const ids = categoryProducts.map(p => p.id);
    const newSelected = [...new Set([...config.selectedProducts, ...ids])];
    const newMapping = newSelected.map(id => {
      const existing = config.discountMapping.find(m => m.productId === id);
      return existing || { productId: id, discountPercent: config.discountPercent };
    });
    updateConfig({ selectedProducts: newSelected, discountMapping: newMapping });
  };

  return (
    <motion.div
      initial={{ opacity: 0, height: 0 }}
      animate={{ opacity: 1, height: 'auto' }}
      exit={{ opacity: 0, height: 0 }}
      transition={{ duration: 0.3 }}
      className="space-y-6 mt-6"
    >
      {/* Promotion Sub-Type Selection */}
      <div className="space-y-3">
        <Label className="text-base font-medium flex items-center gap-2">
          <Sparkles className="h-4 w-4 text-primary" />
          Choose Promotion Style
        </Label>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {PROMOTION_SUBTYPES.map((subtype) => {
            const Icon = subtype.icon;
            const isSelected = config.subType === subtype.id;
            const isAvailable = subtype.available;
            return (
              <motion.button
                key={subtype.id}
                whileHover={isAvailable ? { scale: 1.02 } : {}}
                whileTap={isAvailable ? { scale: 0.98 } : {}}
                onClick={() => {
                  if (!isAvailable) return;
                  // FIX: Auto-set isSellerWide to true when seller_wide subType is selected
                  const updates: Partial<DiscountConfig> = { subType: subtype.id };
                  if (subtype.id === 'seller_wide') {
                    updates.isSellerWide = true;
                  } else {
                    // Reset isSellerWide when switching away from seller_wide
                    updates.isSellerWide = false;
                  }
                  updateConfig(updates);
                }}
                disabled={!isAvailable}
                className={cn(
                  "p-4 rounded-xl border-2 text-left transition-all relative",
                  isSelected 
                    ? "border-primary bg-primary/5" 
                    : "border-border",
                  isAvailable 
                    ? "hover:border-primary/50 cursor-pointer" 
                    : "opacity-60 cursor-not-allowed"
                )}
              >
                <div className="flex items-start gap-3">
                  <div className={cn("p-2 rounded-lg", subtype.bgColor)}>
                    <Icon className={cn("h-5 w-5", subtype.color)} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm flex items-center gap-2">
                      {subtype.title}
                      {!isAvailable && (
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 text-muted-foreground">
                          Coming Soon
                        </Badge>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      {subtype.description}
                    </div>
                  </div>
                  {isSelected && isAvailable && (
                    <Badge variant="default" className="shrink-0">Selected</Badge>
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Global Discount Percentage */}
      <div className="space-y-3">
        <Label className="text-base font-medium flex items-center gap-2">
          <Percent className="h-4 w-4 text-primary" />
          Discount Percentage
        </Label>
        <div className="flex items-center gap-4">
          <Input
            type="number"
            min={1}
            max={99}
            value={config.discountPercent}
            onChange={(e) => {
              const newPercent = parseInt(e.target.value) || 0;
              // Update global discount AND sync all existing discountMapping entries
              const newMapping = config.discountMapping.map(m => ({
                ...m,
                discountPercent: config.perProductOverrides ? m.discountPercent : newPercent
              }));
              updateConfig({ discountPercent: newPercent, discountMapping: newMapping });
            }}
            className="w-24 text-center text-lg font-bold"
          />
          <span className="text-lg font-bold">%</span>
          <div className="flex-1 flex gap-2">
            {[10, 20, 30, 50].map(percent => (
              <Button
                key={percent}
                size="sm"
                variant={config.discountPercent === percent ? "default" : "outline"}
                onClick={() => {
                  // Update global discount AND sync all existing discountMapping entries
                  const newMapping = config.discountMapping.map(m => ({
                    ...m,
                    discountPercent: config.perProductOverrides ? m.discountPercent : percent
                  }));
                  updateConfig({ discountPercent: percent, discountMapping: newMapping });
                }}
              >
                {percent}%
              </Button>
            ))}
          </div>
        </div>
      </div>

      {/* Seller-wide Toggle */}
      {config.subType === 'seller_wide' && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between p-4 rounded-xl bg-orange-500/10 border border-orange-500/20"
        >
          <div className="flex items-center gap-3">
            <Store className="h-5 w-5 text-orange-500" />
            <div>
              <div className="font-medium">Apply to All Products</div>
              <div className="text-xs text-muted-foreground">
                This discount will apply to all your active listings
              </div>
            </div>
          </div>
          <Switch
            checked={config.isSellerWide}
            onCheckedChange={(checked) => updateConfig({ isSellerWide: checked })}
          />
        </motion.div>
      )}

      {/* Category Filter for Category Takeover */}
      {config.subType === 'category_takeover' && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-3"
        >
          <Label className="text-base font-medium flex items-center gap-2">
            <Layers className="h-4 w-4 text-green-500" />
            Select Categories
          </Label>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map(category => (
              <Badge
                key={category}
                variant={config.categoryFilter.includes(category) ? "default" : "outline"}
                className="cursor-pointer"
                onClick={() => {
                  const newCategories = config.categoryFilter.includes(category)
                    ? config.categoryFilter.filter(c => c !== category)
                    : [...config.categoryFilter, category];
                  updateConfig({ categoryFilter: newCategories });
                  if (!config.categoryFilter.includes(category)) {
                    selectByCategory(category);
                  }
                }}
              >
                {category}
              </Badge>
            ))}
          </div>
        </motion.div>
      )}

      {/* Happy Hour Windows */}
      {config.subType === 'happy_hour' && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="flex items-center justify-between">
            <Label className="text-base font-medium flex items-center gap-2">
              <Timer className="h-4 w-4 text-blue-500" />
              Happy Hour Windows
            </Label>
            <Button size="sm" variant="outline" onClick={addHappyHourWindow}>
              <Zap className="h-4 w-4 mr-1" />
              Add Window
            </Button>
          </div>

          <AnimatePresence>
            {config.happyHourWindows.map((window) => (
              <motion.div
                key={window.id}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="p-4 rounded-xl border border-border bg-card space-y-3"
              >
                <div className="flex items-center gap-4">
                  <div className="flex-1 grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs text-muted-foreground">Start Time</Label>
                      <Input
                        type="time"
                        value={window.startTime}
                        onChange={(e) => updateHappyHourWindow(window.id, { startTime: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label className="text-xs text-muted-foreground">End Time</Label>
                      <Input
                        type="time"
                        value={window.endTime}
                        onChange={(e) => updateHappyHourWindow(window.id, { endTime: e.target.value })}
                      />
                    </div>
                  </div>
                  <Button 
                    size="sm" 
                    variant="ghost"
                    className="text-destructive"
                    onClick={() => removeHappyHourWindow(window.id)}
                  >
                    Remove
                  </Button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {DAYS_OF_WEEK.map(day => (
                    <Badge
                      key={day}
                      variant={window.days.includes(day) ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => {
                        const newDays = window.days.includes(day)
                          ? window.days.filter(d => d !== day)
                          : [...window.days, day];
                        updateHappyHourWindow(window.id, { days: newDays });
                      }}
                    >
                      {day}
                    </Badge>
                  ))}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {config.happyHourWindows.length === 0 && (
            <div className="p-8 text-center rounded-xl border border-dashed border-border">
              <Timer className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">
                Add time windows for your happy hour deals
              </p>
            </div>
          )}
        </motion.div>
      )}

      {/* Scheduled Drop Settings */}
      {config.subType === 'scheduled_drop' && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <div className="p-4 rounded-xl bg-purple-500/10 border border-purple-500/20 space-y-4">
            <div className="flex items-start gap-3">
              <Calendar className="h-5 w-5 text-purple-500 mt-0.5" />
              <div className="flex-1">
                <div className="font-medium">Schedule Your Drop</div>
                <div className="text-xs text-muted-foreground mt-1">
                  Build anticipation - your promotion will show as "Starting Soon" with a countdown
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs text-muted-foreground">Drop Date & Time</Label>
                <Input
                  type="datetime-local"
                  value={config.scheduledStartTime}
                  onChange={(e) => updateConfig({ scheduledStartTime: e.target.value })}
                />
              </div>
            </div>
            <div className="flex items-center gap-3 pt-2">
              <Switch
                checked={config.enableReminders}
                onCheckedChange={(checked) => updateConfig({ enableReminders: checked })}
              />
              <div className="flex items-center gap-2">
                <Bell className="h-4 w-4 text-purple-500" />
                <span className="text-sm">Allow users to set reminders</span>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Product Selection (if not seller-wide) */}
      {!config.isSellerWide && config.subType !== 'seller_wide' && (
        <div className="space-y-3">
          <button
            onClick={() => toggleSection('products')}
            className="w-full flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition"
          >
            <div className="flex items-center gap-2">
              <Package className="h-4 w-4 text-primary" />
              <span className="font-medium">Select Products</span>
              <Badge variant="secondary">{config.selectedProducts.length} selected</Badge>
            </div>
            {expandedSections.products ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </button>

          <AnimatePresence>
            {expandedSections.products && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-3"
              >
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline" onClick={selectAllProducts}>
                    Select All
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    onClick={() => updateConfig({ selectedProducts: [], discountMapping: [] })}
                  >
                    Clear All
                  </Button>
                </div>

                {loadingProducts ? (
                  <div className="grid grid-cols-2 gap-3">
                    {[1, 2, 3, 4].map(i => (
                      <div key={i} className="p-3 rounded-lg border border-border">
                        <Skeleton className="h-12 w-12 rounded mb-2" />
                        <Skeleton className="h-4 w-full mb-1" />
                        <Skeleton className="h-3 w-1/2" />
                      </div>
                    ))}
                  </div>
                ) : products.length === 0 ? (
                  <div className="p-8 text-center rounded-xl border border-dashed border-border">
                    <ShoppingBag className="h-8 w-8 text-muted-foreground mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">
                      You don't have any active products yet
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[400px] overflow-y-auto">
                    {products.map(product => {
                      const isSelected = config.selectedProducts.includes(product.id);
                      const mapping = config.discountMapping.find(m => m.productId === product.id);
                      return (
                        <motion.div
                          key={product.id}
                          whileHover={{ scale: 1.01 }}
                          className={cn(
                            "p-3 rounded-xl border-2 cursor-pointer transition-all",
                            isSelected 
                              ? "border-primary bg-primary/5" 
                              : "border-border hover:border-primary/30"
                          )}
                          onClick={() => toggleProduct(product.id)}
                        >
                          <div className="flex items-start gap-3">
                            <div className="relative">
                              <img 
                                src={product.images?.[0] || '/placeholder.svg'} 
                                alt={product.title}
                                className="w-14 h-14 rounded-lg object-cover"
                              />
                              {isSelected && (
                                <div className="absolute -top-1 -right-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                                  <Checkbox checked className="border-0" />
                                </div>
                              )}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="font-medium text-sm line-clamp-1">{product.title}</div>
                              <div className="text-xs text-muted-foreground">{product.category}</div>
                              <div className="flex items-center gap-2 mt-1">
                                <span className="text-xs line-through text-muted-foreground">
                                  UGX {product.price?.toLocaleString()}
                                </span>
                                {isSelected && (
                                  <span className="text-xs font-bold text-primary">
                                    UGX {Math.round(product.price * (1 - (config.perProductOverrides && mapping ? mapping.discountPercent : config.discountPercent) / 100)).toLocaleString()}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          {/* Per-product discount override */}
                          {isSelected && config.perProductOverrides && (
                            <motion.div
                              initial={{ opacity: 0, height: 0 }}
                              animate={{ opacity: 1, height: 'auto' }}
                              className="mt-3 pt-3 border-t border-border"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <div className="flex items-center gap-2">
                                <Label className="text-xs">Custom %</Label>
                                <Input
                                  type="number"
                                  min={1}
                                  max={99}
                                  value={mapping?.discountPercent || config.discountPercent}
                                  onChange={(e) => updateProductDiscount(product.id, parseInt(e.target.value) || 0)}
                                  className="w-16 h-8 text-sm"
                                />
                              </div>
                            </motion.div>
                          )}
                        </motion.div>
                      );
                    })}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      {/* Advanced Options */}
      <div className="space-y-3">
        <button
          onClick={() => toggleSection('advanced')}
          className="w-full flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition"
        >
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-primary" />
            <span className="font-medium">Advanced Options</span>
          </div>
          {expandedSections.advanced ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>

        <AnimatePresence>
          {expandedSections.advanced && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-4 p-4 rounded-xl border border-border"
            >
              {/* Existing Discount Handling */}
              {(() => {
                const discountedProducts = products.filter(p => p.has_discount);
                if (discountedProducts.length === 0) return null;
                
                return (
                  <div className="space-y-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/20">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="h-4 w-4 text-amber-500 mt-0.5" />
                      <div className="flex-1">
                        <span className="text-sm font-medium">
                          {discountedProducts.length} product{discountedProducts.length > 1 ? 's' : ''} already {discountedProducts.length > 1 ? 'have' : 'has'} discounts
                        </span>
                        <div className="text-xs text-muted-foreground mt-1">
                          {discountedProducts.slice(0, 3).map(p => p.title).join(', ')}
                          {discountedProducts.length > 3 && ` and ${discountedProducts.length - 3} more`}
                        </div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="existingDiscountHandling"
                          checked={config.existingDiscountHandling === 'unify'}
                          onChange={() => updateConfig({ existingDiscountHandling: 'unify' })}
                          className="accent-primary"
                        />
                        <span className="text-sm">Apply uniform discount to all (replaces existing)</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="existingDiscountHandling"
                          checked={config.existingDiscountHandling === 'keep_existing'}
                          onChange={() => updateConfig({ existingDiscountHandling: 'keep_existing' })}
                          className="accent-primary"
                        />
                        <span className="text-sm">Keep existing discounts (skip already discounted)</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="existingDiscountHandling"
                          checked={config.existingDiscountHandling === 'override'}
                          onChange={() => updateConfig({ existingDiscountHandling: 'override' })}
                          className="accent-primary"
                        />
                        <span className="text-sm">Stack discounts (additional % on top)</span>
                      </label>
                    </div>
                  </div>
                );
              })()}

              {/* Per-product overrides toggle */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Tag className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-sm font-medium">Per-product discount overrides</div>
                    <div className="text-xs text-muted-foreground">
                      Set different discounts for each product
                    </div>
                  </div>
                </div>
                <Switch
                  checked={config.perProductOverrides}
                  onCheckedChange={(checked) => updateConfig({ perProductOverrides: checked })}
                />
              </div>

              {/* Max claims */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <AlertCircle className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <div className="text-sm font-medium">Limit total claims</div>
                    <div className="text-xs text-muted-foreground">
                      Set a maximum number of times this can be claimed
                    </div>
                  </div>
                </div>
                <Input
                  type="number"
                  min={0}
                  placeholder="Unlimited"
                  value={config.maxClaims || ''}
                  onChange={(e) => updateConfig({ maxClaims: parseInt(e.target.value) || undefined })}
                  className="w-24"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Live Preview Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-4 rounded-xl bg-gradient-to-r from-primary/10 via-primary/5 to-transparent border border-primary/20"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-full bg-primary/20">
            <Sparkles className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <div className="font-medium text-sm">
              {config.subType === 'scheduled_drop' && "🔔 Users will see 'Starting Soon' countdown"}
              {config.subType === 'happy_hour' && "⚡ Deals will flash during your time windows"}
              {config.subType === 'category_takeover' && "🎯 Your deals will dominate selected categories"}
              {config.subType === 'seller_wide' && "🏪 All your products will show discount badges"}
              {config.subType === 'standard' && "🏷️ Selected products will display discount pricing"}
            </div>
            <div className="text-xs text-muted-foreground mt-0.5">
              {config.selectedProducts.length > 0 || config.isSellerWide
                ? `${config.discountPercent}% off ${config.isSellerWide ? 'all products' : `${config.selectedProducts.length} products`}`
                : 'Select products to apply discount'}
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
