import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { Copy, ExternalLink, ArrowRight, Briefcase, Wrench, Package, Calendar, Tag, Megaphone, FileText } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { getShareableUrl } from '@/utils/getAppUrl';
import { useIsMobile } from '@/hooks/use-mobile';

interface PublishSuccessDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  imageUrl?: string;
  listingId?: string;
  listingType: string;
  onViewListing?: () => void;
  onGoToProfile?: () => void;
  onPostAnother?: () => void;
}

/**
 * Build the listing path based on listing_type so links route to the
 * correct detail page in both web and native (Capacitor) modes.
 */
const getListingPath = (listingType: string, listingId: string): string => {
  const lt = (listingType || '').toLowerCase();
  switch (lt) {
    case 'jobs':
    case 'job':
      return `/job/${listingId}`;
    case 'services':
    case 'service':
      return `/service/${listingId}`;
    case 'events':
    case 'event':
      return `/event/${listingId}`;
    case 'promotions':
    case 'promotion':
      return `/promotion/${listingId}`;
    case 'digital_products':
      return `/digital/${listingId}`;
    default:
      return `/ad/${listingId}`;
  }
};

const getListingMeta = (listingType: string) => {
  const lt = (listingType || '').toLowerCase();
  switch (lt) {
    case 'jobs':
    case 'job':
      return { label: 'Job', Icon: Briefcase, color: 'bg-blue-500/10 text-blue-600' };
    case 'services':
    case 'service':
      return { label: 'Service', Icon: Wrench, color: 'bg-green-500/10 text-green-600' };
    case 'events':
    case 'event':
      return { label: 'Event', Icon: Calendar, color: 'bg-purple-500/10 text-purple-600' };
    case 'promotions':
    case 'promotion':
      return { label: 'Promotion', Icon: Tag, color: 'bg-orange-500/10 text-orange-600' };
    case 'announcements':
    case 'announcement':
      return { label: 'Announcement', Icon: Megaphone, color: 'bg-amber-500/10 text-amber-600' };
    case 'posts':
    case 'post':
      return { label: 'Post', Icon: FileText, color: 'bg-pink-500/10 text-pink-600' };
    default:
      return { label: 'Listing', Icon: Package, color: 'bg-primary/10 text-primary' };
  }
};

export default function PublishSuccessDialog({
  open,
  onOpenChange,
  title,
  description,
  imageUrl,
  listingId,
  listingType,
  onViewListing,
  onGoToProfile,
  onPostAnother,
}: PublishSuccessDialogProps) {
  const navigate = useNavigate();
  const isMobile = useIsMobile();

  const listingPath = listingId ? getListingPath(listingType, listingId) : '/';
  // Always use the production domain for shareable URLs (works on native + web)
  const listingUrl = getShareableUrl(listingPath);
  const { label, Icon, color } = getListingMeta(listingType);

  const shareText = `Check out "${title}" on EarlyMarket!`;

  const handleClose = (isOpen: boolean) => {
    onOpenChange(isOpen);
    if (!isOpen) {
      navigate('/post-ad');
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(listingUrl);
      toast({ title: 'Link copied!', description: listingUrl });
    } catch {
      toast({ title: 'Failed to copy', variant: 'destructive' });
    }
  };

  const handleWhatsAppShare = () => {
    window.open(`https://wa.me/?text=${encodeURIComponent(`${shareText}\n\n${listingUrl}`)}`, '_blank');
  };

  const handleFacebookShare = () => {
    window.open(
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(listingUrl)}&quote=${encodeURIComponent(shareText)}`,
      '_blank'
    );
  };

  const handleXShare = () => {
    window.open(
      `https://x.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(listingUrl)}`,
      '_blank'
    );
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title, text: shareText, url: listingUrl });
        return;
      } catch {
        // user cancelled — fall through
      }
    }
    handleCopyLink();
  };

  const body = (
    <div className="space-y-4">
      {/* Listing type chip */}
      <div className="flex justify-center">
        <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[11px] font-semibold ${color}`}>
          <Icon className="w-3.5 h-3.5" />
          {label} Published
        </span>
      </div>

      {/* Share section */}
      <div>
        <p className="text-xs text-muted-foreground mb-2.5 text-center">Share "{title}"</p>
        <div className="flex justify-center gap-3 flex-wrap">
          {/* WhatsApp */}
          <button
            onClick={handleWhatsAppShare}
            className="w-11 h-11 rounded-full flex items-center justify-center transition-transform hover:scale-110"
            style={{ backgroundColor: '#25D366' }}
            aria-label="Share on WhatsApp"
          >
            <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
          </button>
          {/* Facebook */}
          <button
            onClick={handleFacebookShare}
            className="w-11 h-11 rounded-full flex items-center justify-center transition-transform hover:scale-110"
            style={{ backgroundColor: '#1877F2' }}
            aria-label="Share on Facebook"
          >
            <svg viewBox="0 0 24 24" className="w-5 h-5 fill-white">
              <path d="M9.101 23.691v-7.98H6.627v-3.667h2.474v-1.58c0-4.085 1.848-5.978 5.858-5.978.401 0 .955.042 1.468.103a8.68 8.68 0 0 1 1.141.195v3.325a8.623 8.623 0 0 0-.653-.036 26.805 26.805 0 0 0-.733-.009c-.707 0-1.259.096-1.675.309a1.686 1.686 0 0 0-.679.622c-.258.42-.374.995-.374 1.752v1.297h3.919l-.386 2.103-.287 1.564h-3.246v8.245C19.396 23.238 24 18.179 24 12.044c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.628 3.874 10.35 9.101 11.647Z" />
            </svg>
          </button>
          {/* X */}
          <button
            onClick={handleXShare}
            className="w-11 h-11 rounded-full bg-black dark:bg-white flex items-center justify-center transition-transform hover:scale-110"
            aria-label="Share on X"
          >
            <svg viewBox="0 0 24 24" className="w-4 h-4 fill-white dark:fill-black">
              <path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z" />
            </svg>
          </button>
          {/* Native share (mobile / capacitor) */}
          {isMobile && (
            <button
              onClick={handleNativeShare}
              className="w-11 h-11 rounded-full bg-primary flex items-center justify-center transition-transform hover:scale-110 text-primary-foreground"
              aria-label="More share options"
            >
              <ExternalLink className="w-4.5 h-4.5" />
            </button>
          )}
          {/* Copy */}
          <button
            onClick={handleCopyLink}
            className="w-11 h-11 rounded-full bg-muted flex items-center justify-center transition-transform hover:scale-110"
            aria-label="Copy link"
          >
            <Copy className="w-4.5 h-4.5 text-muted-foreground" />
          </button>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-2 pt-1">
        {onViewListing && (
          <Button onClick={onViewListing} size="sm" className="flex-1 gap-1.5">
            <ExternalLink className="w-3.5 h-3.5" />
            View {label}
          </Button>
        )}
        {onPostAnother && (
          <Button variant="outline" size="sm" onClick={onPostAnother} className="flex-1 gap-1.5">
            Post Another <ArrowRight className="w-3.5 h-3.5" />
          </Button>
        )}
      </div>
    </div>
  );

  const header = (
    <div className="pt-2 pb-3 text-center">
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', stiffness: 200, delay: 0.1 }}
        className="text-4xl mb-2"
      >
        🎉
      </motion.div>
      <p className="text-base font-semibold">Published!</p>
    </div>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={handleClose}>
        <DrawerContent className="px-5 pb-8">
          <DrawerHeader className="text-center px-0">
            <DrawerTitle className="sr-only">Published</DrawerTitle>
            <DrawerDescription className="sr-only">Share your published listing</DrawerDescription>
            {header}
          </DrawerHeader>
          {body}
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-sm p-0 overflow-hidden">
        <DialogHeader className="pt-2">
          <DialogTitle className="sr-only">Published</DialogTitle>
          <DialogDescription className="sr-only">Share your published listing</DialogDescription>
          {header}
        </DialogHeader>
        <div className="px-5 pb-5">{body}</div>
      </DialogContent>
    </Dialog>
  );
}
