import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Sparkles, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { addWatermarkToImage } from '@/utils/watermark';
import { saveAiImage } from '@/utils/saveAiImage';

interface FormDataLike {
  title: string;
  promotionType: string;
  description: string;
  businessName: string;
  location: string;
  discountConfig: { discountPercent: number };
}

interface GeneratedImage {
  id: string;
  file: File;
  url: string;
  isHighQuality: boolean;
  qualityScore: number;
  type?: 'image' | 'video';
}

interface Props {
  formData: FormDataLike;
  onGenerated: (img: GeneratedImage) => void;
  disabled?: boolean;
}

async function dataUrlToFile(dataUrl: string, filename: string): Promise<File> {
  const res = await fetch(dataUrl);
  const blob = await res.blob();
  return new File([blob], filename, { type: blob.type || 'image/png' });
}

export default function NanoBananaGenerateButton({ formData, onGenerated, disabled }: Props) {
  const [loading, setLoading] = useState(false);
  const flaggedCountRef = useRef(0);
  const cooldownUntilRef = useRef<number>(0);

  const handleClick = async () => {
    if (loading) return;
    const now = Date.now();
    if (now < cooldownUntilRef.current) {
      const secs = Math.ceil((cooldownUntilRef.current - now) / 1000);
      toast({ title: 'Please wait', description: `Try again in ${secs}s.`, variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('generate-promotion-image', {
        body: {
          title: formData.title,
          promotionType: formData.promotionType,
          description: formData.description,
          businessName: formData.businessName,
          location: formData.location,
          discountPercent: formData.discountConfig?.discountPercent ?? 0,
        },
      });

      if (error) {
        const ctx: any = (error as any).context;
        const status = ctx?.status;
        let msg = error.message || 'Failed to generate image';
        try {
          const body = ctx ? await ctx.json() : null;
          if (body?.error) msg = body.error;
          if (body?.reason) msg = body.reason;
        } catch { /* ignore */ }
        if (status === 429) {
          cooldownUntilRef.current = Date.now() + 60_000;
        }
        toast({ title: 'AI generation blocked', description: msg, variant: 'destructive' });
        return;
      }

      if (data?.flagged) {
        flaggedCountRef.current += 1;
        cooldownUntilRef.current = Date.now() + (flaggedCountRef.current >= 3 ? 5 * 60_000 : 30_000);
        toast({
          title: 'Content blocked',
          description: data.reason || 'The AI refused this prompt. Try different wording.',
          variant: 'destructive',
        });
        return;
      }

      if (!data?.imageDataUrl) {
        toast({ title: 'No image returned', description: 'Please try again.', variant: 'destructive' });
        return;
      }

      flaggedCountRef.current = 0;
      const rawFile = await dataUrlToFile(data.imageDataUrl, `promo-${Date.now()}.png`);
      let file = rawFile;
      try { file = await addWatermarkToImage(rawFile); } catch (e) { console.warn('Watermark failed', e); }
      saveAiImage({
        file,
        source: 'promotion',
        prompt: formData.title,
        context: {
          promotionType: formData.promotionType,
          businessName: formData.businessName,
          location: formData.location,
          discountPercent: formData.discountConfig?.discountPercent ?? 0,
        },
      }).catch((e) => console.warn('saveAiImage', e));
      const objectUrl = URL.createObjectURL(file);
      onGenerated({
        id: crypto.randomUUID(),
        file,
        url: objectUrl,
        isHighQuality: true,
        qualityScore: 90,
        type: 'image',
      });
      toast({ title: '✨ Image generated', description: 'AI-generated promotional image is ready. Saved to your Media tab.' });
    } catch (e: any) {
      toast({ title: 'Generation failed', description: e?.message || 'Please try again.', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      type="button"
      variant="outline"
      onClick={handleClick}
      disabled={disabled || loading}
      className="w-full gap-2 border-yellow-400/60 bg-gradient-to-r from-yellow-50 to-amber-50 hover:from-yellow-100 hover:to-amber-100 dark:from-yellow-950/30 dark:to-amber-950/30"
    >
      {loading ? (
        <>
          <Loader2 className="h-4 w-4 animate-spin" />
          Generating with Nano Banana…
        </>
      ) : (
        <>
          <span className="text-base">🍌</span>
          <Sparkles className="h-4 w-4 text-amber-500" />
          Generate image with Nano Banana AI
        </>
      )}
    </Button>
  );
}
