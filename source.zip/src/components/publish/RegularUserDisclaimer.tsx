import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { Info, Sparkles, Crown } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface RegularUserDisclaimerProps {
  currentAdCount: number;
  maxAds: number;
  variant?: 'info' | 'limit';
}

export const RegularUserDisclaimer: React.FC<RegularUserDisclaimerProps> = ({
  currentAdCount,
  maxAds,
  variant = 'info',
}) => {
  const navigate = useNavigate();

  if (variant === 'limit') {
    return (
      <Alert className="border-orange-500/50 bg-orange-500/5">
        <Info className="h-5 w-5 text-orange-500" />
        <AlertTitle className="text-orange-500 font-semibold">
          Listing Limit Reached
        </AlertTitle>
        <AlertDescription className="space-y-3">
          <p className="text-sm text-muted-foreground">
            You've reached your limit of {maxAds} active listings as a regular user. 
            Your listings expire after 2 months.
          </p>
        <Button
          onClick={() => navigate('/create-business-account')}
          className="w-full sm:w-auto bg-gradient-to-r from-orange-500 to-pink-500 hover:from-orange-600 hover:to-pink-600"
        >
          <Crown className="mr-2 h-4 w-4" />
          Upgrade to Business
        </Button>
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Alert className="border-primary/50 bg-primary/5">
      <Sparkles className="h-5 w-5 text-primary" />
      <AlertTitle className="text-primary font-semibold">
        Regular Account Limitations
      </AlertTitle>
      <AlertDescription className="space-y-3">
        <div className="text-sm text-muted-foreground space-y-2">
          <p>
            You're posting as a regular user ({currentAdCount}/{maxAds} listings used). Your listings will:
          </p>
          <ul className="list-disc list-inside space-y-1 ml-2">
            <li>Expire automatically after 2 months</li>
            <li>Limited to products only (no jobs, services, events, posts, or promotions)</li>
            <li>Maximum of {maxAds} active listings at a time</li>
          </ul>
        </div>
        <Button
          onClick={() => navigate('/create-business-account')}
          variant="outline"
          className="w-full sm:w-auto border-primary/50 hover:bg-primary/10"
        >
          <Crown className="mr-2 h-4 w-4" />
          Upgrade to Business
        </Button>
      </AlertDescription>
    </Alert>
  );
};
