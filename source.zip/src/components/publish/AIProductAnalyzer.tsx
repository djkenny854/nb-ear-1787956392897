import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Wand2, Upload, Loader2, CheckCircle, AlertCircle, X, ImagePlus, Camera, ShieldCheck, Info } from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { toast } from '@/hooks/use-toast';
import { motion, AnimatePresence } from 'framer-motion';

export interface AIAnalyzedImage {
  file: File;
  preview: string;
}

interface AIProductAnalyzerProps {
  availableCategories: { id: string; name: string }[];
  availableSubcategories?: { id: string; name: string; category_id: string }[];
  onAnalysisComplete: (result: AnalysisResult, images: AIAnalyzedImage[]) => void;
  disabled?: boolean;
}

export interface AnalysisResult {
  productName: string;
  category: string;
  subcategory?: string;
  description: string | null;
  tags: string[];
  confidence: 'high' | 'medium' | 'low';
  additionalFields?: {
    brand?: string;
    model?: string;
    color?: string;
    condition?: string;
    priceEstimate?: number;
    specs?: string;
  };
}

// Changing assurance texts shown during AI analysis
const ASSURANCE_TEXTS = [
  { icon: '🔍', text: 'Analyzing your product images...' },
  { icon: '🧠', text: 'Identifying brand, model & specs...' },
  { icon: '📋', text: 'Generating optimized title with key specs...' },
  { icon: '🏷️', text: 'Selecting the best category match...' },
  { icon: '✍️', text: 'Crafting a compelling description...' },
  { icon: '🎯', text: 'Detecting condition & features...' },
  { icon: '💰', text: 'Estimating fair market price...' },
  { icon: '✨', text: 'Finalizing details for your listing...' },
];

const AssuranceText: React.FC<{ isActive: boolean }> = ({ isActive }) => {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (!isActive) return;
    const interval = setInterval(() => {
      setIndex(prev => (prev + 1) % ASSURANCE_TEXTS.length);
    }, 2500);
    return () => clearInterval(interval);
  }, [isActive]);

  const current = ASSURANCE_TEXTS[index];

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={index}
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -10 }}
        transition={{ duration: 0.3 }}
        className="flex items-center justify-center gap-2.5 py-3"
      >
        <span className="text-xl">{current.icon}</span>
        <span className="text-sm font-medium text-foreground">{current.text}</span>
      </motion.div>
    </AnimatePresence>
  );
};

// Shimmer loading skeleton
const AnalysisSkeleton: React.FC = () => (
  <div className="space-y-3">
    {[...Array(4)].map((_, i) => (
      <div key={i} className="space-y-1.5">
        <div className="h-3 w-20 rounded bg-muted animate-pulse" />
        <div className={cn("h-5 rounded bg-muted animate-pulse", i === 2 ? "w-full" : "w-3/4")} 
          style={{ animationDelay: `${i * 150}ms` }} />
      </div>
    ))}
    <div className="flex gap-2 pt-1">
      {[...Array(3)].map((_, i) => (
        <div key={i} className="h-6 w-16 rounded-full bg-muted animate-pulse" 
          style={{ animationDelay: `${i * 100}ms` }} />
      ))}
    </div>
  </div>
);

export const AIProductAnalyzer: React.FC<AIProductAnalyzerProps> = ({
  availableCategories,
  availableSubcategories = [],
  onAnalysisComplete,
  disabled = false,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [images, setImages] = useState<{ file: File; preview: string }[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Attention hint: the button opens up with an explainer label, then folds
  // back to the compact pill — a couple of gentle cycles on entry.
  const [hintOpen, setHintOpen] = useState(false);
  useEffect(() => {
    const timers: ReturnType<typeof setTimeout>[] = [];
    const CYCLES = 3;
    for (let i = 0; i < CYCLES; i++) {
      const base = 600 + i * 4000;
      timers.push(setTimeout(() => setHintOpen(true), base));
      timers.push(setTimeout(() => setHintOpen(false), base + 2000));
    }
    return () => timers.forEach(clearTimeout);
  }, []);

  const handleOpenModal = () => {
    setIsOpen(true);
    setImages([]);
    setResult(null);
    setError(null);
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    const remainingSlots = 4 - images.length;
    const filesToAdd = files.slice(0, remainingSlots);
    const newImages = filesToAdd.map(file => ({
      file,
      preview: URL.createObjectURL(file),
    }));
    setImages(prev => [...prev, ...newImages]);
    setError(null);
  };

  const removeImage = (index: number) => {
    setImages(prev => {
      const updated = [...prev];
      URL.revokeObjectURL(updated[index].preview);
      updated.splice(index, 1);
      return updated;
    });
  };

  const fileToBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

  const handleAnalyze = async () => {
    if (images.length < 1) {
      setError('Please upload at least 1 image');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      const base64Images = await Promise.all(images.map(img => fileToBase64(img.file)));

      const { data, error: fnError } = await supabase.functions.invoke('analyze-product-images', {
        body: {
          images: base64Images,
          availableCategories: availableCategories.map(c => c.name),
          availableSubcategories: availableSubcategories.map(s => ({ id: s.id, name: s.name, category_id: s.category_id })),
        },
      });

      // Surface typed prohibited-content errors with the backend's message
      const fnContext = (fnError as any)?.context;
      if (fnError && fnContext) {
        try {
          const body = await fnContext.json();
          if (body?.message) throw new Error(body.message);
          if (body?.error) throw new Error(body.error);
        } catch (parseErr) {
          // fall through to generic error
        }
        throw new Error(fnError.message || 'Analysis failed');
      }
      if (fnError) throw fnError;
      if (data?.error) {
        throw new Error(data.message || data.error);
      }

      // Find matching subcategory
      let suggestedSubcategory: string | undefined;
      const matchedCategory = availableCategories.find(
        c => c.name.toLowerCase() === data.category?.toLowerCase()
      );
      
      if (matchedCategory && availableSubcategories.length > 0) {
        const categorySubcats = availableSubcategories.filter(s => s.category_id === matchedCategory.id);
        if (data.suggestedSubcategory) {
          const matchingSub = categorySubcats.find(s => 
            s.name.toLowerCase() === data.suggestedSubcategory?.toLowerCase() ||
            s.name.toLowerCase().includes(data.suggestedSubcategory?.toLowerCase()) ||
            data.suggestedSubcategory?.toLowerCase().includes(s.name.toLowerCase())
          );
          suggestedSubcategory = matchingSub?.id;
        }
        if (!suggestedSubcategory && categorySubcats.length > 0) {
          const productNameLower = data.productName?.toLowerCase() || '';
          const matchingSub = categorySubcats.find(s => 
            productNameLower.includes(s.name.toLowerCase()) ||
            s.name.toLowerCase().includes(productNameLower.split(' ')[0])
          );
          suggestedSubcategory = matchingSub?.id || categorySubcats[0]?.id;
        }
      }

      const resultWithSubcategory = { ...data, subcategory: suggestedSubcategory };
      setResult(resultWithSubcategory);

      // Auto-apply for high confidence
      if (data.confidence === 'high') {
        toast({ title: '✨ AI Analysis Complete', description: 'Product details have been auto-filled.' });
        onAnalysisComplete(resultWithSubcategory, images);
        setIsOpen(false);
      }
    } catch (err) {
      console.error('Analysis error:', err);
      setError(err instanceof Error ? err.message : 'Failed to analyze images');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleAccept = () => {
    if (result) {
      onAnalysisComplete(result, images);
      toast({ title: '✨ Applied AI Suggestions', description: 'Product details have been filled.' });
      setIsOpen(false);
    }
  };

  const getConfidenceBadge = (confidence: string) => {
    switch (confidence) {
      case 'high': return { color: 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/20', label: 'High Confidence', icon: <ShieldCheck className="w-3.5 h-3.5" /> };
      case 'medium': return { color: 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/20', label: 'Medium Confidence', icon: <Info className="w-3.5 h-3.5" /> };
      case 'low': return { color: 'bg-red-500/15 text-red-600 dark:text-red-400 border-red-500/20', label: 'Low Confidence', icon: <AlertCircle className="w-3.5 h-3.5" /> };
      default: return { color: 'bg-muted text-muted-foreground', label: 'Unknown', icon: null };
    }
  };

  return (
    <>
      <Button
        type="button"
        variant="outline"
        size="sm"
        onClick={handleOpenModal}
        disabled={disabled}
        className="gap-2 border-primary/30 hover:border-primary text-primary hover:bg-primary/10 overflow-hidden"
      >
        <Wand2 className="w-4 h-4 flex-shrink-0" />
        <span className="hidden sm:inline">AI Assist</span>
        <AnimatePresence initial={false}>
          {hintOpen && (
            <motion.span
              key="hint"
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 'auto', opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.35, ease: 'easeOut' }}
              className="whitespace-nowrap text-xs font-medium overflow-hidden"
            >
              <span className="pl-1">Snap your product — we fill the details</span>
            </motion.span>
          )}
        </AnimatePresence>
      </Button>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-md mx-auto max-h-[85vh] overflow-y-auto rounded-2xl border-border/50 shadow-2xl">
          <DialogHeader className="text-center pb-2">
            <div className="mx-auto w-14 h-14 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center mb-3">
              <Camera className="w-7 h-7 text-primary" />
            </div>
            <DialogTitle className="text-xl font-bold">Show us what you're listing</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Upload photos and we'll help fill in the details for you
            </DialogDescription>
          </DialogHeader>

          <AnimatePresence mode="wait">
            {isAnalyzing ? (
              <motion.div
                key="loading"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="py-6 space-y-6"
              >
                {/* Pulsing AI icon */}
                <div className="flex justify-center">
                  <div className="relative">
                    <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center animate-pulse">
                      <Wand2 className="w-8 h-8 text-primary" />
                    </div>
                    <div className="absolute inset-0 rounded-full border-2 border-primary/30 animate-ping" />
                  </div>
                </div>

                {/* Changing assurance text */}
                <AssuranceText isActive={true} />

                {/* Skeleton preview */}
                <div className="bg-muted/20 rounded-xl p-4 border border-border/30">
                  <AnalysisSkeleton />
                </div>

                {/* Image thumbnails */}
                <div className="flex justify-center gap-2">
                  {images.map((img, idx) => (
                    <div key={idx} className="w-12 h-12 rounded-lg overflow-hidden border-2 border-primary/20 opacity-60">
                      <img src={img.preview} alt="" className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              </motion.div>
            ) : !result ? (
              <motion.div
                key="upload"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="space-y-4"
              >
                {/* Disclaimer */}
                <div className="rounded-xl border border-border/60 bg-muted/30 p-3 space-y-2 text-xs leading-relaxed">
                  <p>
                    <span className="font-semibold text-foreground">What the AI will do:</span>{' '}
                    <span className="text-muted-foreground">suggest a title, category, description, brand/model, condition, and tags from your photos.</span>
                  </p>
                  <p>
                    <span className="font-semibold text-amber-600 dark:text-amber-400">What you must double-check:</span>{' '}
                    <span className="text-muted-foreground">Price (never set by AI), Condition, Description accuracy, Brand/Model, and Quantity. These are your responsibility.</span>
                  </p>
                  <p>
                    <span className="font-semibold text-destructive">Not allowed:</span>{' '}
                    <span className="text-muted-foreground">weapons, drugs, sexual content, counterfeit goods, certain live animals, stolen items. Uploading prohibited content is logged and may result in account suspension.</span>
                  </p>
                </div>

                {/* Upload area */}
                <div 
                  onClick={() => images.length < 4 && fileInputRef.current?.click()}
                  className={cn(
                    "border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer",
                    images.length >= 4 
                      ? "border-muted cursor-not-allowed opacity-50" 
                      : "border-primary/30 hover:border-primary hover:bg-primary/5 active:scale-[0.99]"
                  )}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleImageSelect}
                    className="hidden"
                  />
                  <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-primary/10 flex items-center justify-center">
                    <ImagePlus className="w-8 h-8 text-primary" />
                  </div>
                  <p className="text-sm font-semibold text-foreground">
                    {images.length >= 4 ? 'Maximum 4 images reached' : 'Tap to add product photos'}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1.5">
                    1–4 clear photos • AI fills title, category, price & more
                  </p>
                </div>

                {/* Image previews */}
                {images.length > 0 && (
                  <div className="grid grid-cols-4 gap-2.5">
                    {images.map((img, idx) => (
                      <div key={idx} className="relative aspect-square rounded-xl overflow-hidden border border-border group shadow-sm">
                        <img src={img.preview} alt={`Preview ${idx + 1}`} className="w-full h-full object-cover" />
                        <button
                          onClick={(e) => { e.stopPropagation(); removeImage(idx); }}
                          className="absolute top-1 right-1 p-1 bg-black/60 rounded-full text-white hover:bg-black/80 opacity-0 group-hover:opacity-100 transition-all"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {error && (
                  <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 p-3 rounded-xl">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                <div className="flex gap-2 pt-2">
                  <Button variant="ghost" onClick={() => setIsOpen(false)} className="flex-1">
                    Cancel
                  </Button>
                  <Button 
                    onClick={handleAnalyze}
                    disabled={images.length === 0}
                    className="flex-1 gap-2 bg-primary hover:bg-primary/90"
                  >
                    <Wand2 className="w-4 h-4" />
                    Analyze
                  </Button>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="results"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="space-y-4"
              >
                {/* Confidence badge */}
                {(() => {
                  const badge = getConfidenceBadge(result.confidence);
                  return (
                    <div className={cn("inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border", badge.color)}>
                      {badge.icon}
                      {badge.label}
                      {result.confidence !== 'high' && (
                        <span className="text-[10px] opacity-70 ml-1">• Review suggested</span>
                      )}
                    </div>
                  );
                })()}

                {/* Results card */}
                <div className="bg-muted/20 rounded-xl p-4 border border-border/30 space-y-3">
                  <div>
                    <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Product Title</label>
                    <p className="font-semibold text-foreground text-sm mt-0.5">{result.productName}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Category</label>
                      <p className="text-sm font-medium text-foreground mt-0.5">{result.category}</p>
                    </div>
                    {result.additionalFields?.condition && (
                      <div>
                        <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Condition</label>
                        <p className="text-sm font-medium text-foreground mt-0.5">{result.additionalFields.condition}</p>
                      </div>
                    )}
                  </div>

                  {result.description && (
                    <div>
                      <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Description</label>
                      <p className="text-xs text-foreground/80 mt-0.5 leading-relaxed">{result.description}</p>
                    </div>
                  )}

                  {result.tags.length > 0 && (
                    <div>
                      <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Tags</label>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {result.tags.map((tag, idx) => (
                          <span key={idx} className="px-2 py-0.5 bg-primary/10 text-primary text-[11px] rounded-full font-medium">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Additional fields */}
                  {result.additionalFields && (
                    <div className="grid grid-cols-2 gap-2 pt-2 border-t border-border/30">
                      {result.additionalFields.brand && (
                        <div>
                          <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Brand</label>
                          <p className="text-xs font-medium mt-0.5">{result.additionalFields.brand}</p>
                        </div>
                      )}
                      {result.additionalFields.model && (
                        <div>
                          <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Model</label>
                          <p className="text-xs font-medium mt-0.5">{result.additionalFields.model}</p>
                        </div>
                      )}
                      {result.additionalFields.color && (
                        <div>
                          <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Color</label>
                          <p className="text-xs font-medium mt-0.5">{result.additionalFields.color}</p>
                        </div>
                      )}
                      {result.additionalFields.priceEstimate && (
                        <div>
                          <label className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Est. Price</label>
                          <p className="text-xs font-medium mt-0.5">UGX {result.additionalFields.priceEstimate.toLocaleString()}</p>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Image thumbnails */}
                <div className="flex gap-2">
                  {images.map((img, idx) => (
                    <div key={idx} className="w-14 h-14 rounded-lg overflow-hidden border border-border">
                      <img src={img.preview} alt="" className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>

                <div className="flex gap-2 pt-1">
                  <Button variant="outline" onClick={() => { setResult(null); setError(null); }} className="flex-1">
                    Try Again
                  </Button>
                  <Button onClick={handleAccept} className="flex-1 gap-2">
                    <CheckCircle className="w-4 h-4" />
                    Accept & Apply
                  </Button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default AIProductAnalyzer;
