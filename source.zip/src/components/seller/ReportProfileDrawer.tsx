import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerFooter } from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { AlertTriangle, Flag } from 'lucide-react';
import { toast } from 'sonner';
import { useIsMobile } from '@/hooks/use-mobile';
import { cn } from '@/lib/utils';

interface ReportProfileDrawerProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  profileName: string;
  profileId: string;
}

const reportReasons = [
  { id: 'fake', label: 'Fake or misleading profile', description: 'Impersonation or false information' },
  { id: 'scam', label: 'Scam or fraud', description: 'Suspicious activity or fraudulent behavior' },
  { id: 'inappropriate', label: 'Inappropriate content', description: 'Offensive images or descriptions' },
  { id: 'harassment', label: 'Harassment or threats', description: 'Abusive behavior or messages' },
  { id: 'spam', label: 'Spam', description: 'Excessive or unwanted content' },
  { id: 'other', label: 'Other', description: 'Something else not listed above' },
];

const ReportProfileDrawer: React.FC<ReportProfileDrawerProps> = ({
  open,
  onOpenChange,
  profileName,
  profileId,
}) => {
  const isMobile = useIsMobile();
  const [selectedReason, setSelectedReason] = useState<string>('');
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!selectedReason) {
      toast.error('Please select a reason');
      return;
    }

    setSubmitting(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    toast.success('Report submitted', {
      description: 'Thank you for reporting. We will review this profile.',
    });
    
    setSubmitting(false);
    setSelectedReason('');
    setAdditionalInfo('');
    onOpenChange(false);
  };

  const content = (
    <div className="space-y-4">
      <div className="flex items-center gap-3 p-3 rounded-lg bg-destructive/10 text-destructive">
        <AlertTriangle className="w-5 h-5 flex-shrink-0" />
        <p className="text-sm">
          Help us keep EarlyMarket safe by reporting profiles that violate our guidelines.
        </p>
      </div>

      <div className="space-y-2">
        <Label className="text-sm font-medium">Why are you reporting this profile?</Label>
        <RadioGroup value={selectedReason} onValueChange={setSelectedReason} className="space-y-2">
          {reportReasons.map((reason) => (
            <label
              key={reason.id}
              className={cn(
                "flex items-start gap-3 p-3 rounded-lg border cursor-pointer transition-colors",
                selectedReason === reason.id
                  ? "border-primary bg-primary/5"
                  : "border-border hover:bg-muted/50"
              )}
            >
              <RadioGroupItem value={reason.id} id={reason.id} className="mt-0.5" />
              <div className="flex-1 min-w-0">
                <span className="text-sm font-medium block">{reason.label}</span>
                <span className="text-xs text-muted-foreground">{reason.description}</span>
              </div>
            </label>
          ))}
        </RadioGroup>
      </div>

      <div className="space-y-2">
        <Label htmlFor="additional-info" className="text-sm font-medium">
          Additional details (optional)
        </Label>
        <Textarea
          id="additional-info"
          placeholder="Provide any additional information that might help us investigate..."
          value={additionalInfo}
          onChange={(e) => setAdditionalInfo(e.target.value)}
          className="min-h-[100px] resize-none"
        />
      </div>
    </div>
  );

  const footer = (
    <div className="flex gap-2 w-full">
      <Button
        variant="outline"
        onClick={() => onOpenChange(false)}
        className="flex-1"
        disabled={submitting}
      >
        Cancel
      </Button>
      <Button
        onClick={handleSubmit}
        disabled={!selectedReason || submitting}
        className="flex-1 bg-destructive hover:bg-destructive/90"
      >
        <Flag className="w-4 h-4 mr-2" />
        {submitting ? 'Submitting...' : 'Submit Report'}
      </Button>
    </div>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent className="px-4 pb-8 max-h-[90vh]">
          <DrawerHeader className="text-left">
            <DrawerTitle>Report {profileName}</DrawerTitle>
          </DrawerHeader>
          <div className="overflow-y-auto flex-1 pb-4">
            {content}
          </div>
          <DrawerFooter className="px-0">
            {footer}
          </DrawerFooter>
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Report {profileName}</DialogTitle>
        </DialogHeader>
        {content}
        <DialogFooter>
          {footer}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ReportProfileDrawer;
