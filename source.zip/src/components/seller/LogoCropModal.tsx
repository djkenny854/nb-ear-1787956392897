import React, { useState, useRef, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { RotateCw, ArrowLeft, Check, ZoomIn, ZoomOut } from 'lucide-react';
import { Spinner } from '@/components/ui/spinner';
import { Slider } from '@/components/ui/slider';

interface LogoCropModalProps {
  isOpen: boolean;
  onClose: () => void;
  imageFile: File | null;
  onSave: (croppedBlob: Blob) => void;
  aspectRatio?: 'square' | 'cover'; // square for logo, cover for banner
  title?: string;
}

const LogoCropModal: React.FC<LogoCropModalProps> = ({
  isOpen,
  onClose,
  imageFile,
  onSave,
  aspectRatio = 'square',
  title = 'Crop and rotate'
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const previewRef = useRef<HTMLCanvasElement>(null);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [imageData, setImageData] = useState<HTMLImageElement | null>(null);
  const [cropBox, setCropBox] = useState({ x: 0, y: 0, width: 200, height: 200 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [isResizing, setIsResizing] = useState(false);
  const [zoom, setZoom] = useState(100);

  // Larger canvas for better quality
  const CANVAS_WIDTH = 500;
  const CANVAS_HEIGHT = aspectRatio === 'cover' ? 280 : 500;
  
  // Output sizes
  const OUTPUT_WIDTH = aspectRatio === 'cover' ? 1200 : 500;
  const OUTPUT_HEIGHT = aspectRatio === 'cover' ? 400 : 500;

  const loadImage = useCallback(() => {
    if (!imageFile) return;
    
    const img = new Image();
    img.onload = () => {
      setImageData(img);
      setImageLoaded(true);
      
      // Calculate initial crop box (centered)
      if (aspectRatio === 'cover') {
        // 3:1 aspect ratio for cover
        const cropWidth = Math.min(CANVAS_WIDTH * 0.9, img.width);
        const cropHeight = cropWidth / 3;
        setCropBox({
          x: (CANVAS_WIDTH - cropWidth) / 2,
          y: (CANVAS_HEIGHT - cropHeight) / 2,
          width: cropWidth,
          height: cropHeight
        });
      } else {
        // Square for logo
        const minDim = Math.min(img.width, img.height);
        const scale = CANVAS_WIDTH / Math.max(img.width, img.height);
        const scaledMin = minDim * scale;
        const initialSize = Math.min(scaledMin * 0.9, CANVAS_WIDTH * 0.85);
        
        setCropBox({
          x: (CANVAS_WIDTH - initialSize) / 2,
          y: (CANVAS_HEIGHT - initialSize) / 2,
          width: initialSize,
          height: initialSize
        });
      }
      setRotation(0);
      setZoom(100);
    };
    
    img.src = URL.createObjectURL(imageFile);
  }, [imageFile, aspectRatio]);

  useEffect(() => {
    if (isOpen && imageFile) {
      setImageLoaded(false);
      loadImage();
    }
  }, [isOpen, imageFile, loadImage]);

  const drawCanvas = useCallback(() => {
    if (!canvasRef.current || !imageData || !imageLoaded) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = CANVAS_WIDTH;
    canvas.height = CANVAS_HEIGHT;

    // Clear canvas with dark background
    ctx.fillStyle = '#1a1a1a';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // Calculate scaling to fit image with zoom
    const zoomFactor = zoom / 100;
    const baseScale = Math.min(CANVAS_WIDTH / imageData.width, CANVAS_HEIGHT / imageData.height);
    const scale = baseScale * zoomFactor;
    const scaledWidth = imageData.width * scale;
    const scaledHeight = imageData.height * scale;
    const offsetX = (CANVAS_WIDTH - scaledWidth) / 2;
    const offsetY = (CANVAS_HEIGHT - scaledHeight) / 2;

    // Save context and apply rotation
    ctx.save();
    ctx.translate(CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
    ctx.rotate((rotation * Math.PI) / 180);
    ctx.translate(-CANVAS_WIDTH / 2, -CANVAS_HEIGHT / 2);
    
    // Draw the image
    ctx.drawImage(imageData, offsetX, offsetY, scaledWidth, scaledHeight);
    ctx.restore();

    // Draw semi-transparent overlay outside crop area
    ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
    ctx.fillRect(0, 0, CANVAS_WIDTH, cropBox.y); // Top
    ctx.fillRect(0, cropBox.y + cropBox.height, CANVAS_WIDTH, CANVAS_HEIGHT - cropBox.y - cropBox.height); // Bottom
    ctx.fillRect(0, cropBox.y, cropBox.x, cropBox.height); // Left
    ctx.fillRect(cropBox.x + cropBox.width, cropBox.y, CANVAS_WIDTH - cropBox.x - cropBox.width, cropBox.height); // Right

    // Draw crop box border
    ctx.strokeStyle = '#6366f1';
    ctx.lineWidth = 2;
    ctx.strokeRect(cropBox.x, cropBox.y, cropBox.width, cropBox.height);

    // Circular guide for logos so users see the final round crop
    if (aspectRatio === 'square') {
      ctx.save();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.setLineDash([6, 6]);
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(
        cropBox.x + cropBox.width / 2,
        cropBox.y + cropBox.height / 2,
        cropBox.width / 2,
        0,
        Math.PI * 2,
      );
      ctx.stroke();
      ctx.restore();
    }

    // Draw corner handles
    const handleSize = 14;
    ctx.fillStyle = '#6366f1';
    
    // Corner handles
    ctx.fillRect(cropBox.x - handleSize/2, cropBox.y - handleSize/2, handleSize, handleSize);
    ctx.fillRect(cropBox.x + cropBox.width - handleSize/2, cropBox.y - handleSize/2, handleSize, handleSize);
    ctx.fillRect(cropBox.x - handleSize/2, cropBox.y + cropBox.height - handleSize/2, handleSize, handleSize);
    ctx.fillRect(cropBox.x + cropBox.width - handleSize/2, cropBox.y + cropBox.height - handleSize/2, handleSize, handleSize);

    // Draw grid lines (rule of thirds)
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
    ctx.lineWidth = 1;
    const thirdW = cropBox.width / 3;
    const thirdH = cropBox.height / 3;
    
    // Vertical lines
    ctx.beginPath();
    ctx.moveTo(cropBox.x + thirdW, cropBox.y);
    ctx.lineTo(cropBox.x + thirdW, cropBox.y + cropBox.height);
    ctx.moveTo(cropBox.x + thirdW * 2, cropBox.y);
    ctx.lineTo(cropBox.x + thirdW * 2, cropBox.y + cropBox.height);
    
    // Horizontal lines
    ctx.moveTo(cropBox.x, cropBox.y + thirdH);
    ctx.lineTo(cropBox.x + cropBox.width, cropBox.y + thirdH);
    ctx.moveTo(cropBox.x, cropBox.y + thirdH * 2);
    ctx.lineTo(cropBox.x + cropBox.width, cropBox.y + thirdH * 2);
    ctx.stroke();

  }, [imageData, imageLoaded, rotation, cropBox, zoom, aspectRatio, CANVAS_WIDTH, CANVAS_HEIGHT]);

  useEffect(() => {
    drawCanvas();
  }, [drawCanvas]);

  // Live preview of exactly what will be saved (circular for logo, wide for cover).
  const drawPreview = useCallback(() => {
    if (!previewRef.current || !imageData || !imageLoaded) return;
    const pc = previewRef.current;
    const pctx = pc.getContext('2d');
    if (!pctx) return;
    pctx.clearRect(0, 0, pc.width, pc.height);

    const zoomFactor = zoom / 100;
    const baseScale = Math.min(CANVAS_WIDTH / imageData.width, CANVAS_HEIGHT / imageData.height);
    const scale = baseScale * zoomFactor;
    const scaledWidth = imageData.width * scale;
    const scaledHeight = imageData.height * scale;
    const offsetX = (CANVAS_WIDTH - scaledWidth) / 2;
    const offsetY = (CANVAS_HEIGHT - scaledHeight) / 2;

    const temp = document.createElement('canvas');
    temp.width = CANVAS_WIDTH;
    temp.height = CANVAS_HEIGHT;
    const tctx = temp.getContext('2d');
    if (!tctx) return;
    tctx.fillStyle = '#ffffff';
    tctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    tctx.save();
    tctx.translate(CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
    tctx.rotate((rotation * Math.PI) / 180);
    tctx.translate(-CANVAS_WIDTH / 2, -CANVAS_HEIGHT / 2);
    tctx.drawImage(imageData, offsetX, offsetY, scaledWidth, scaledHeight);
    tctx.restore();

    pctx.save();
    if (aspectRatio === 'square') {
      pctx.beginPath();
      pctx.arc(pc.width / 2, pc.height / 2, pc.width / 2, 0, Math.PI * 2);
      pctx.clip();
    }
    pctx.drawImage(
      temp,
      cropBox.x, cropBox.y, cropBox.width, cropBox.height,
      0, 0, pc.width, pc.height,
    );
    pctx.restore();
  }, [imageData, imageLoaded, rotation, cropBox, zoom, aspectRatio, CANVAS_WIDTH, CANVAS_HEIGHT]);

  useEffect(() => {
    drawPreview();
  }, [drawPreview]);

  const handleRotate = () => {
    setRotation((prev) => (prev + 90) % 360);
  };

  const getMousePos = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    
    const rect = canvas.getBoundingClientRect();
    const scaleX = CANVAS_WIDTH / rect.width;
    const scaleY = CANVAS_HEIGHT / rect.height;
    
    if ('touches' in e) {
      const touch = e.touches[0] || e.changedTouches[0];
      return {
        x: (touch.clientX - rect.left) * scaleX,
        y: (touch.clientY - rect.top) * scaleY
      };
    }
    
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top) * scaleY
    };
  };

  const isNearCorner = (pos: { x: number; y: number }) => {
    const handleSize = 24;
    const corners = [
      { x: cropBox.x, y: cropBox.y },
      { x: cropBox.x + cropBox.width, y: cropBox.y },
      { x: cropBox.x, y: cropBox.y + cropBox.height },
      { x: cropBox.x + cropBox.width, y: cropBox.y + cropBox.height }
    ];
    
    return corners.some(corner => 
      Math.abs(pos.x - corner.x) < handleSize && Math.abs(pos.y - corner.y) < handleSize
    );
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pos = getMousePos(e);
    
    if (isNearCorner(pos)) {
      setIsResizing(true);
    } else if (
      pos.x >= cropBox.x && pos.x <= cropBox.x + cropBox.width &&
      pos.y >= cropBox.y && pos.y <= cropBox.y + cropBox.height
    ) {
      setIsDragging(true);
      setDragStart({ x: pos.x - cropBox.x, y: pos.y - cropBox.y });
    }
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const pos = getMousePos(e);
    
    if (isNearCorner(pos)) {
      setIsResizing(true);
    } else if (
      pos.x >= cropBox.x && pos.x <= cropBox.x + cropBox.width &&
      pos.y >= cropBox.y && pos.y <= cropBox.y + cropBox.height
    ) {
      setIsDragging(true);
      setDragStart({ x: pos.x - cropBox.x, y: pos.y - cropBox.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pos = getMousePos(e);
    handleMove(pos);
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const pos = getMousePos(e);
    handleMove(pos);
  };

  const handleMove = (pos: { x: number; y: number }) => {
    if (isDragging) {
      const newX = Math.max(0, Math.min(CANVAS_WIDTH - cropBox.width, pos.x - dragStart.x));
      const newY = Math.max(0, Math.min(CANVAS_HEIGHT - cropBox.height, pos.y - dragStart.y));
      setCropBox(prev => ({ ...prev, x: newX, y: newY }));
    } else if (isResizing) {
      // Calculate new size based on mouse position while maintaining aspect ratio
      const centerX = cropBox.x + cropBox.width / 2;
      const centerY = cropBox.y + cropBox.height / 2;
      const distX = Math.abs(pos.x - centerX);
      const distY = Math.abs(pos.y - centerY);
      
      if (aspectRatio === 'cover') {
        // Maintain 3:1 aspect ratio
        const newWidth = Math.max(100, Math.min(CANVAS_WIDTH - 20, distX * 2));
        const newHeight = newWidth / 3;
        const newX = Math.max(0, Math.min(CANVAS_WIDTH - newWidth, centerX - newWidth / 2));
        const newY = Math.max(0, Math.min(CANVAS_HEIGHT - newHeight, centerY - newHeight / 2));
        setCropBox({ x: newX, y: newY, width: newWidth, height: newHeight });
      } else {
        // Square aspect ratio
        const newSize = Math.max(100, Math.min(CANVAS_WIDTH - 20, Math.max(distX, distY) * 2));
        const newX = Math.max(0, Math.min(CANVAS_WIDTH - newSize, centerX - newSize / 2));
        const newY = Math.max(0, Math.min(CANVAS_HEIGHT - newSize, centerY - newSize / 2));
        setCropBox({ x: newX, y: newY, width: newSize, height: newSize });
      }
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setIsResizing(false);
  };

  const handleSave = () => {
    if (!canvasRef.current || !imageData) return;

    // Create a new canvas for the cropped output
    const outputCanvas = document.createElement('canvas');
    outputCanvas.width = OUTPUT_WIDTH;
    outputCanvas.height = OUTPUT_HEIGHT;
    const outputCtx = outputCanvas.getContext('2d');
    
    if (!outputCtx) return;

    // Calculate the actual crop coordinates on the original image
    const zoomFactor = zoom / 100;
    const baseScale = Math.min(CANVAS_WIDTH / imageData.width, CANVAS_HEIGHT / imageData.height);
    const scale = baseScale * zoomFactor;
    const scaledWidth = imageData.width * scale;
    const scaledHeight = imageData.height * scale;
    const offsetX = (CANVAS_WIDTH - scaledWidth) / 2;
    const offsetY = (CANVAS_HEIGHT - scaledHeight) / 2;

    // Create a temporary canvas for rotation
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = CANVAS_WIDTH;
    tempCanvas.height = CANVAS_HEIGHT;
    const tempCtx = tempCanvas.getContext('2d');
    
    if (!tempCtx) return;

    // Draw rotated image on temp canvas
    tempCtx.fillStyle = '#ffffff';
    tempCtx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);
    tempCtx.save();
    tempCtx.translate(CANVAS_WIDTH / 2, CANVAS_HEIGHT / 2);
    tempCtx.rotate((rotation * Math.PI) / 180);
    tempCtx.translate(-CANVAS_WIDTH / 2, -CANVAS_HEIGHT / 2);
    tempCtx.drawImage(imageData, offsetX, offsetY, scaledWidth, scaledHeight);
    tempCtx.restore();

    // Draw the cropped area to output canvas
    outputCtx.drawImage(
      tempCanvas,
      cropBox.x, cropBox.y, cropBox.width, cropBox.height,
      0, 0, OUTPUT_WIDTH, OUTPUT_HEIGHT
    );

    outputCanvas.toBlob((blob) => {
      if (blob) {
        onSave(blob);
        onClose();
      }
    }, 'image/jpeg', 0.92);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-background">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Button variant="ghost" size="icon" onClick={onClose}>
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <span>{title}</span>
          </DialogTitle>
          <p className="pl-11 -mt-1 text-sm text-muted-foreground">
            {aspectRatio === 'square'
              ? 'Drag to reposition and zoom so your logo sits neatly inside the circle. Square images look best.'
              : 'Frame your cover image. A wide banner (3:1) works best across your store.'}
          </p>
        </DialogHeader>

        <div className="grid gap-6 md:grid-cols-[1fr_auto]">
          <div className="flex flex-col items-center gap-4">
          {!imageLoaded && (
            <div 
              className="flex items-center justify-center bg-muted rounded-lg"
              style={{ width: '100%', maxWidth: `${CANVAS_WIDTH}px`, aspectRatio: `${CANVAS_WIDTH}/${CANVAS_HEIGHT}` }}
            >
              <Spinner size="lg" className="text-primary" />
            </div>
          )}
          
          <canvas
            ref={canvasRef}
            className={`max-w-full rounded-lg cursor-move touch-none ${imageLoaded ? 'block' : 'hidden'}`}
            style={{ width: '100%', maxWidth: `${CANVAS_WIDTH}px`, aspectRatio: `${CANVAS_WIDTH}/${CANVAS_HEIGHT}` }}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleMouseUp}
          />

          {/* Zoom slider */}
          <div className="flex items-center gap-3 w-full max-w-[300px]">
            <ZoomOut className="w-4 h-4 text-muted-foreground" />
            <Slider
              value={[zoom]}
              onValueChange={(values) => setZoom(values[0])}
              min={50}
              max={200}
              step={5}
              className="flex-1"
            />
            <ZoomIn className="w-4 h-4 text-muted-foreground" />
            <span className="text-xs text-muted-foreground w-10">{zoom}%</span>
          </div>

          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={handleRotate}
              className="flex flex-col items-center gap-1 h-auto py-2"
            >
              <RotateCw className="w-5 h-5" />
              <span className="text-xs">Rotate</span>
            </Button>
          </div>
          </div>

          {/* Live preview */}
          {imageLoaded && (
            <div className="hidden md:flex flex-col items-center gap-3 pt-2">
              <span className="text-xs font-medium text-muted-foreground">Preview</span>
              <canvas
                ref={previewRef}
                width={aspectRatio === 'square' ? 128 : 210}
                height={aspectRatio === 'square' ? 128 : 70}
                className={aspectRatio === 'square'
                  ? 'rounded-full border border-border shadow-sm'
                  : 'rounded-lg border border-border shadow-sm'}
              />
              <span className="text-[11px] text-muted-foreground text-center max-w-[160px]">
                {aspectRatio === 'square'
                  ? 'How your logo appears across EarlyMarket'
                  : 'How your cover appears on your store'}
              </span>
            </div>
          )}
        </div>

        <Button
          onClick={handleSave}
          className="w-full"
          disabled={!imageLoaded}
        >
          <Check className="w-4 h-4 mr-2" />
          Apply
        </Button>
      </DialogContent>
    </Dialog>
  );
};

export default LogoCropModal;
