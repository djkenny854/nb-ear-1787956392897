import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { ChevronRight, Star, Shield, Zap, Users } from 'lucide-react';
const banner1 = '';
const banner2 = '';
const banner3 = '';
const banner4 = '';

interface Banner {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  buttonText: string;
  buttonAction: () => void;
  gradientColors: { from: string; to: string };
  backgroundImage: string;
}

const RotatingBanner: React.FC = () => {
  const [currentBanner, setCurrentBanner] = useState(0);
  const [isTextBlurred, setIsTextBlurred] = useState(false);
  const [displayedText, setDisplayedText] = useState({ title: '', description: '', buttonText: '' });
  const [displayedGradient, setDisplayedGradient] = useState({ from: '', to: '' });
  const [displayedImage, setDisplayedImage] = useState('');
  const [displayedIcon, setDisplayedIcon] = useState<React.ComponentType<{ className?: string }> | null>(null);

  // Touch swipe state
  const touchStartX = useRef(0);
  const touchEndX = useRef(0);
  const isSwiping = useRef(false);
  const autoRotateTimer = useRef<number | undefined>();

  const banners: Banner[] = [
    {
      id: 1,
      title: "Discover Amazing Deals",
      subtitle: "Shop Smart, Save More",
      description: "Find incredible products from verified sellers across Uganda",
      icon: Star,
      buttonText: "Start Shopping",
      buttonAction: () => window.scrollTo({ top: 800, behavior: 'smooth' }),
      gradientColors: { from: 'hsl(221, 83%, 53%)', to: 'hsl(271, 81%, 56%)' },
      backgroundImage: banner1
    },
    {
      id: 2,
      title: "Sell with Confidence",
      subtitle: "Your Business, Our Platform",
      description: "Join thousands of successful sellers and grow your business",
      icon: Shield,
      buttonText: "Start Selling",
      buttonAction: () => window.location.href = '/post-ad',
      gradientColors: { from: 'hsl(142, 71%, 45%)', to: 'hsl(168, 76%, 42%)' },
      backgroundImage: banner2
    },
    {
      id: 3,
      title: "Fast & Secure",
      subtitle: "Trade with Peace of Mind",
      description: "Verified sellers, secure payments, and reliable delivery",
      icon: Zap,
      buttonText: "Learn More",
      buttonAction: () => window.scrollTo({ top: 1200, behavior: 'smooth' }),
      gradientColors: { from: 'hsl(24, 95%, 53%)', to: 'hsl(0, 84%, 60%)' },
      backgroundImage: banner3
    },
    {
      id: 4,
      title: "Join Our Community",
      subtitle: "Connect & Grow",
      description: "Be part of Uganda's fastest-growing marketplace community",
      icon: Users,
      buttonText: "Join Now",
      buttonAction: () => window.location.href = '/auth',
      gradientColors: { from: 'hsl(271, 81%, 56%)', to: 'hsl(330, 81%, 60%)' },
      backgroundImage: banner4
    }
  ];

  const goToBanner = useCallback((index: number) => {
    if (index === currentBanner) return;
    const targetBanner = banners[index];

    setIsTextBlurred(true);

    setTimeout(() => {
      setDisplayedText({
        title: targetBanner.title,
        description: targetBanner.description,
        buttonText: targetBanner.buttonText
      });
      setDisplayedIcon(() => targetBanner.icon);
      setCurrentBanner(index);
      setTimeout(() => setIsTextBlurred(false), 50);
    }, 150);

    setTimeout(() => {
      setDisplayedGradient(targetBanner.gradientColors);
    }, 300);

    setTimeout(() => {
      setDisplayedImage(targetBanner.backgroundImage);
    }, 450);
  }, [currentBanner, banners]);

  // Initialize displayed states
  useEffect(() => {
    const initial = banners[0];
    setDisplayedText({ title: initial.title, description: initial.description, buttonText: initial.buttonText });
    setDisplayedGradient(initial.gradientColors);
    setDisplayedImage(initial.backgroundImage);
    setDisplayedIcon(() => initial.icon);
  }, []);

  // Auto-rotate
  useEffect(() => {
    autoRotateTimer.current = window.setInterval(() => {
      const nextIndex = (currentBanner + 1) % banners.length;
      goToBanner(nextIndex);
    }, 4000);

    return () => {
      if (autoRotateTimer.current) window.clearInterval(autoRotateTimer.current);
    };
  }, [currentBanner, goToBanner]);

  // Touch handlers for swipe
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchEndX.current = e.touches[0].clientX;
    isSwiping.current = true;
    // Pause auto-rotate during swipe
    if (autoRotateTimer.current) window.clearInterval(autoRotateTimer.current);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isSwiping.current) return;
    touchEndX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!isSwiping.current) return;
    isSwiping.current = false;

    const swipeDistance = touchStartX.current - touchEndX.current;
    const minSwipe = 50;

    if (Math.abs(swipeDistance) >= minSwipe) {
      if (swipeDistance > 0) {
        // Swipe left → next
        goToBanner((currentBanner + 1) % banners.length);
      } else {
        // Swipe right → prev
        goToBanner((currentBanner - 1 + banners.length) % banners.length);
      }
    }
  };

  const current = banners[currentBanner];
  const IconComponent = displayedIcon || current.icon;

  return (
    <div 
      className="relative overflow-hidden rounded-2xl text-white h-24 md:h-28 lg:h-32 group hover:h-28 md:hover:h-32 lg:hover:h-36 hover:shadow-2xl hover:shadow-primary/20 transition-all duration-500"
      style={{ touchAction: 'pan-y' }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {/* Background Image Layer */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-all duration-700 ease-in-out"
        style={{ 
          backgroundImage: displayedImage ? `url(${displayedImage})` : 'none',
          opacity: 0.3
        }}
      />
      
      {/* Gradient Overlay - smooth transition */}
      <div 
        className="absolute inset-0 transition-all duration-700 ease-in-out"
        style={{
          background: `linear-gradient(135deg, ${displayedGradient.from || 'hsl(221, 83%, 53%)'} 0%, ${displayedGradient.to || 'hsl(271, 81%, 56%)'} 100%)`
        }}
      />

      {/* Animated Background Pattern */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-white/30 to-transparent rounded-full animate-pulse"></div>
        <div className="absolute bottom-0 right-0 w-24 h-24 bg-gradient-to-tl from-white/20 to-transparent rounded-full animate-bounce"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 h-full flex items-center justify-between p-6">
        <div className="flex items-center gap-4 flex-1">
          {/* Animated Icon with blur */}
          <div 
            className="p-2 bg-white/20 rounded-xl group-hover:scale-110 transition-all duration-300"
            style={{
              filter: isTextBlurred ? 'blur(6px)' : 'blur(0px)',
              opacity: isTextBlurred ? 0.5 : 1,
            }}
          >
            <IconComponent className="w-6 h-6" />
          </div>
          
          {/* Content with blur animation */}
          <div className="flex-1 min-w-0">
            <h3 
              className="text-lg font-bold mb-1 truncate transition-all duration-300"
              style={{
                filter: isTextBlurred ? 'blur(8px)' : 'blur(0px)',
                opacity: isTextBlurred ? 0.5 : 1,
                transform: isTextBlurred ? 'scale(0.98)' : 'scale(1)'
              }}
            >
              {displayedText.title}
            </h3>
            <p 
              className="text-sm text-white/80 truncate transition-all duration-300"
              style={{
                filter: isTextBlurred ? 'blur(8px)' : 'blur(0px)',
                opacity: isTextBlurred ? 0.5 : 1,
                transform: isTextBlurred ? 'scale(0.98)' : 'scale(1)',
                transitionDelay: '50ms'
              }}
            >
              {displayedText.description}
            </p>
          </div>
        </div>

        {/* CTA Button */}
        <div className="flex items-center gap-3">
          <Button
            onClick={current.buttonAction}
            size="sm"
            className="bg-white/20 backdrop-blur-sm text-white hover:bg-white hover:text-gray-900 font-medium px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105 hover:shadow-lg border border-white/30"
            style={{
              filter: isTextBlurred ? 'blur(4px)' : 'blur(0px)',
              opacity: isTextBlurred ? 0.7 : 1,
            }}
          >
            <span 
              className="transition-all duration-300"
              style={{
                filter: isTextBlurred ? 'blur(6px)' : 'blur(0px)',
              }}
            >
              {displayedText.buttonText}
            </span>
            <ChevronRight className="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform duration-300" />
          </Button>
          
          {/* Banner Indicators */}
          <div className="flex gap-1">
            {banners.map((_, index) => (
              <button
                key={index}
                onClick={() => goToBanner(index)}
                className={`w-2 h-2 rounded-full transition-all duration-300 hover:scale-125 ${
                  index === currentBanner 
                    ? 'bg-white' 
                    : 'bg-white/40 hover:bg-white/70'
                }`}
              />
            ))}
          </div>
        </div>
      </div>

      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-10 translate-x-10"></div>
      <div className="absolute bottom-0 left-0 w-16 h-16 bg-white/10 rounded-full translate-y-8 -translate-x-8"></div>
      
      {/* Hover gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
    </div>
  );
};

export default RotatingBanner;
