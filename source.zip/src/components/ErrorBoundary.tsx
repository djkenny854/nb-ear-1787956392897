import React from 'react';

interface State {
  hasError: boolean;
  error?: Error;
  recoverCount: number;
}

/**
 * Global error boundary so a render error in any page never leaves a blank
 * white screen.
 *
 * For transient render errors (e.g. context churn during auth callback /
 * HMR) we silently auto-recover after a short tick. The visible
 * "Something went wrong" fallback only appears if the error keeps
 * repeating, so users never see it during a normal sign-in or callback.
 */
export default class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  state: State = { hasError: false, recoverCount: 0 };
  private recoverTimer?: ReturnType<typeof setTimeout>;

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error, recoverCount: 0 };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // eslint-disable-next-line no-console
    console.error('App error boundary caught', error, info);
    // Auto-recover for the first 2 hits in a row, so a transient provider
    // error during sign-in / callback never surfaces "Something went wrong".
    this.setState((prev) => {
      if (prev.recoverCount < 2) {
        clearTimeout(this.recoverTimer);
        this.recoverTimer = setTimeout(() => {
          this.setState((s) => ({ hasError: false, error: undefined, recoverCount: s.recoverCount + 1 }));
        }, 150);
      }
      return prev;
    });
  }

  componentWillUnmount() {
    clearTimeout(this.recoverTimer);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: undefined, recoverCount: 0 });
  };

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (!this.state.hasError) return this.props.children;
    // While auto-recovery is pending, render nothing — avoids the visible
    // "Something went wrong" flash for transient errors.
    if (this.state.recoverCount < 2) {
      return <div className="min-h-screen bg-background" />;
    }
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-6">
        <div className="max-w-md w-full text-center space-y-4">
          <div className="text-5xl">⚠️</div>
          <h1 className="text-xl font-semibold">Something went wrong</h1>
          <p className="text-sm text-muted-foreground">
            This page hit an unexpected error. Try again, and if it keeps happening reload the app.
          </p>
          {this.state.error?.message && (
            <p className="text-xs text-muted-foreground/70 break-words">{this.state.error.message}</p>
          )}
          <div className="flex gap-2 justify-center pt-2">
            <button
              onClick={this.handleReset}
              className="px-4 py-2 rounded-full border border-border text-sm hover:bg-accent"
            >
              Try again
            </button>
            <button
              onClick={this.handleReload}
              className="px-4 py-2 rounded-full bg-primary text-primary-foreground text-sm hover:bg-primary/90"
            >
              Reload
            </button>
          </div>
        </div>
      </div>
    );
  }
}
