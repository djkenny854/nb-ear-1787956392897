import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, Loader2, RotateCcw, X, AlertTriangle } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import type { UploadJob } from '@/contexts/BackgroundUploadContext';

interface Props {
  jobs: UploadJob[];
  onRetry: (id: string) => void;
  onDismiss: (id: string) => void;
}

const BackgroundUploadDock: React.FC<Props> = ({ jobs, onRetry, onDismiss }) => {
  if (jobs.length === 0) return null;

  return (
    <div className="fixed z-[60] right-3 left-3 sm:left-auto sm:right-4 bottom-20 sm:bottom-4 flex flex-col gap-2 pointer-events-none">
      <AnimatePresence>
        {jobs.map((job) => (
          <motion.div
            key={job.id}
            layout
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="pointer-events-auto w-full sm:w-80 rounded-2xl border bg-card/95 backdrop-blur shadow-lg p-3"
          >
            <div className="flex items-center gap-2.5">
              <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                {job.status === 'running' && <Loader2 className="h-4 w-4 animate-spin text-primary" />}
                {job.status === 'success' && <CheckCircle2 className="h-4 w-4 text-green-500" />}
                {job.status === 'error' && <AlertTriangle className="h-4 w-4 text-destructive" />}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">
                  {job.status === 'error' ? 'Upload failed' : job.label}
                </p>
                {job.status === 'running' && (
                  <Progress value={job.progress} className="h-1 mt-1.5" />
                )}
                {job.status === 'error' && job.error && (
                  <p className="text-xs text-muted-foreground truncate mt-0.5">{job.error}</p>
                )}
              </div>
              <div className="flex items-center gap-1">
                {job.status === 'error' && (
                  <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => onRetry(job.id)}>
                    <RotateCcw className="h-4 w-4" />
                  </Button>
                )}
                {job.status !== 'running' && (
                  <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => onDismiss(job.id)}>
                    <X className="h-4 w-4" />
                  </Button>
                )}
                {job.status === 'running' && (
                  <span className="text-xs font-semibold text-muted-foreground tabular-nums w-9 text-right">
                    {Math.round(job.progress)}%
                  </span>
                )}
              </div>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};

export default BackgroundUploadDock;