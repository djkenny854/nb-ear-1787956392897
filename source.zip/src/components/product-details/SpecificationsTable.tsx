import React from 'react';

interface Specification {
  label: string;
  value: string | number | null | undefined;
}

interface SpecificationsTableProps {
  brand?: string | null;
  model?: string | null;
  condition?: string | null;
  color?: string | null;
  size?: string | null;
  weight?: string | null;
  dimensions?: string | null;
  warranty?: string | null;
  yearManufactured?: number | null;
  features?: string | null;
}

// Map common product color names to hex values
const colorNameToHex = (name: string): string | null => {
  const map: Record<string, string> = {
    'black': '#000000', 'white': '#FFFFFF', 'red': '#EF4444', 'blue': '#3B82F6',
    'green': '#22C55E', 'yellow': '#EAB308', 'orange': '#F97316', 'purple': '#A855F7',
    'pink': '#EC4899', 'gray': '#6B7280', 'grey': '#6B7280', 'brown': '#92400E',
    'navy': '#1E3A5F', 'navy blue': '#1E3A5F', 'teal': '#14B8A6', 'cyan': '#06B6D4',
    'gold': '#D4A017', 'silver': '#C0C0C0', 'beige': '#F5F5DC', 'ivory': '#FFFFF0',
    'maroon': '#800000', 'olive': '#808000', 'coral': '#FF7F50', 'salmon': '#FA8072',
    'turquoise': '#40E0D0', 'lavender': '#E6E6FA', 'indigo': '#4B0082', 'violet': '#8B5CF6',
    'magenta': '#FF00FF', 'crimson': '#DC143C', 'charcoal': '#36454F', 'khaki': '#C3B091',
    'burgundy': '#800020', 'tan': '#D2B48C', 'cream': '#FFFDD0', 'mint': '#98FB98',
    'midnight blue': '#191970', 'rose gold': '#B76E79', 'space gray': '#717378',
    'space grey': '#717378', 'sky blue': '#87CEEB', 'royal blue': '#4169E1',
    'forest green': '#228B22', 'lime green': '#32CD32', 'hot pink': '#FF69B4',
    'deep purple': '#673AB7', 'dark blue': '#00008B', 'dark green': '#006400',
    'dark red': '#8B0000', 'light blue': '#ADD8E6', 'light green': '#90EE90',
    'light pink': '#FFB6C1', 'light gray': '#D3D3D3', 'light grey': '#D3D3D3',
    'pearl white': '#F0EAD6', 'jet black': '#0A0A0A', 'matte black': '#28282B',
    'graphite': '#53565A', 'titanium': '#878681', 'champagne': '#F7E7CE',
    'rose': '#FF007F', 'aqua': '#00FFFF', 'amber': '#FFBF00', 'bronze': '#CD7F32',
    'copper': '#B87333', 'slate': '#708090', 'pewter': '#96A8A1', 'cobalt': '#0047AB',
    'emerald': '#50C878', 'ruby': '#E0115F', 'sapphire': '#0F52BA',
    'arctic white': '#F4F4F4', 'ocean blue': '#0077B6', 'sunset orange': '#FA5F55',
    'starlight': '#F8F0E3', 'alpine green': '#505D4E', 'sierra blue': '#69ABCE',
    'product red': '#BF0013', 'phantom black': '#1C1C1C', 'mystic bronze': '#C79A6E',
  };
  const lower = name.toLowerCase().trim();
  if (map[lower]) return map[lower];
  
  // Try CSS named colors by creating a canvas test
  const cssColors = ['aliceblue','antiquewhite','aquamarine','azure','bisque','blanchedalmond',
    'blueviolet','burlywood','cadetblue','chartreuse','chocolate','cornflowerblue','cornsilk',
    'darkgoldenrod','darkkhaki','darkolivegreen','darkorange','darkorchid','darksalmon',
    'darkseagreen','darkslateblue','darkslategray','darkturquoise','darkviolet','deeppink',
    'deepskyblue','dimgray','dodgerblue','firebrick','floralwhite','gainsboro','ghostwhite',
    'goldenrod','greenyellow','honeydew','indianred','lawngreen','lemonchiffon','lightcoral',
    'lightcyan','lightgoldenrodyellow','lightsalmon','lightseagreen','lightskyblue',
    'lightslategray','lightsteelblue','lightyellow','limegreen','linen','mediumaquamarine',
    'mediumblue','mediumorchid','mediumpurple','mediumseagreen','mediumslateblue',
    'mediumspringgreen','mediumturquoise','mediumvioletred','midnightblue','mintcream',
    'mistyrose','moccasin','navajowhite','oldlace','olivedrab','orangered','orchid',
    'palegoldenrod','palegreen','paleturquoise','palevioletred','papayawhip','peachpuff',
    'peru','plum','powderblue','rosybrown','royalblue','saddlebrown','sandybrown','seagreen',
    'seashell','sienna','skyblue','slateblue','slategray','snow','springgreen','steelblue',
    'thistle','tomato','wheat','whitesmoke','yellowgreen'];
  if (cssColors.includes(lower)) return lower;
  
  return null;
};

const ColorSwatch: React.FC<{ colorName: string }> = ({ colorName }) => {
  const hex = colorNameToHex(colorName);
  if (!hex) return <span className="text-foreground">{colorName}</span>;
  
  return (
    <div className="flex items-center gap-3">
      <div 
        className="w-8 h-8 rounded-full border-2 border-border shadow-sm flex-shrink-0"
        style={{ backgroundColor: hex }}
      />
      <span className="text-foreground capitalize">{colorName}</span>
    </div>
  );
};

const SizeBadge: React.FC<{ size: string }> = ({ size }) => (
  <span className="inline-flex items-center justify-center min-w-[40px] h-9 px-4 rounded-lg bg-primary/10 text-primary font-semibold text-sm border border-primary/20">
    {size}
  </span>
);

const SpecificationsTable: React.FC<SpecificationsTableProps> = ({
  brand, model, condition, color, size, weight, dimensions, warranty, yearManufactured, features
}) => {
  // Parse features
  const parseFeatures = (featuresInput: string | null | undefined): Specification[] => {
    if (!featuresInput) return [];
    try {
      const parsed = JSON.parse(featuresInput);
      if (typeof parsed === 'object' && parsed !== null && !Array.isArray(parsed)) {
        return Object.entries(parsed).map(([key, value]) => ({
          label: key.charAt(0).toUpperCase() + key.slice(1).replace(/_/g, ' '),
          value: String(value)
        }));
      } else if (Array.isArray(parsed)) {
        return parsed.map((item, index) => ({
          label: index === 0 ? 'Features' : '',
          value: String(item)
        }));
      }
    } catch { /* not JSON */ }
    
    const featureList = featuresInput.split(/[,\n]/).map(f => f.trim()).filter(Boolean);
    return featureList.map((feature, index) => ({
      label: index === 0 ? 'Features' : '',
      value: feature
    }));
  };

  const parsedFeatures = parseFeatures(features);

  const baseSpecs: Specification[] = [
    { label: 'Brand', value: brand },
    { label: 'Model', value: model },
    { label: 'Condition', value: condition },
    { label: 'Color', value: color },
    { label: 'Size', value: size },
    { label: 'Weight', value: weight },
    { label: 'Dimensions', value: dimensions },
    { label: 'Year', value: yearManufactured },
    { label: 'Warranty', value: warranty },
  ].filter(spec => spec.value != null && spec.value !== '');

  const baseLabelLower = baseSpecs.map(s => s.label.toLowerCase());
  const filteredFeatures = parsedFeatures.filter(f => 
    !baseLabelLower.includes(f.label.toLowerCase()) || f.label === '' || f.label === 'Features'
  );

  const allSpecs = [...baseSpecs, ...filteredFeatures];

  if (allSpecs.length === 0) return null;

  const renderValue = (spec: Specification) => {
    if (spec.label === 'Color' && typeof spec.value === 'string') {
      return <ColorSwatch colorName={spec.value} />;
    }
    if (spec.label === 'Size' && typeof spec.value === 'string') {
      return <SizeBadge size={spec.value} />;
    }
    return <span className="text-foreground">{spec.value}</span>;
  };

  return (
    <div className="space-y-3">
      <h3 className="text-lg font-semibold">Specifications</h3>
      <div className="relative p-[2px] rounded-xl bg-gradient-to-r from-blue-500 via-red-500 via-yellow-500 to-green-500">
        <div className="bg-card rounded-xl overflow-hidden">
          <table className="w-full text-sm">
            <tbody>
              {allSpecs.map((spec, index) => (
                <tr 
                  key={`${spec.label}-${index}`}
                  className={index % 2 === 0 ? 'bg-muted/30' : 'bg-background'}
                >
                  <td className="px-4 py-3 font-medium text-muted-foreground w-1/3">
                    {spec.label}
                  </td>
                  <td className="px-4 py-3">
                    {renderValue(spec)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default SpecificationsTable;
