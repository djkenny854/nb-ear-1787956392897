import React from 'react';
import { Check } from 'lucide-react';

interface ProductHighlightsProps {
  features?: string | null;
  brand?: string | null;
  model?: string | null;
  condition?: string | null;
  warranty?: string | null;
}

const ProductHighlights: React.FC<ProductHighlightsProps> = ({
  features,
  brand,
  model,
  condition,
  warranty
}) => {
  // Parse features (could be comma-separated or newline-separated)
  const featureList = features
    ? features.split(/[,\n]/).map(f => f.trim()).filter(Boolean)
    : [];

  // Build highlights from available data
  const highlights: string[] = [];
  
  if (brand) highlights.push(`Brand: ${brand}`);
  if (model) highlights.push(`Model: ${model}`);
  if (condition) highlights.push(`Condition: ${condition}`);
  if (warranty) highlights.push(`${warranty} warranty included`);

  const allHighlights = [...highlights, ...featureList].slice(0, 6);

  if (allHighlights.length === 0) return null;

  return (
    <div className="space-y-3 overflow-hidden">
      <h3 className="text-lg font-semibold">Quick Highlights</h3>
      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        {allHighlights.map((highlight, index) => (
          <li 
            key={index} 
            className="flex items-start gap-2 text-sm text-muted-foreground min-w-0"
          >
            <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
            <span className="break-words overflow-hidden">{highlight}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ProductHighlights;
