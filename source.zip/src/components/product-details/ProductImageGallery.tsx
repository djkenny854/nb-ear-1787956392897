import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronLeft, ChevronRight, ZoomIn, Play, X, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { toast } from 'sonner';
import { addWatermarkToImage } from '@/utils/watermark';
import AdaptiveMedia from '@/components/media/AdaptiveMedia';
import { cn } from '@/lib/utils';
import SmartVideo from '@/components/media/SmartVideo';
import { imageCdnUrl, videoCdnUrl } from '@/utils/cdnUrl';
import { onImageError } from '@/utils/fallbackImage';

interface ProductImageGalleryProps {
  images: string[];
  title: string;
  videoUrl?: string | null;
  mediaDimensions?: { w: number; h: number }[] | null;
  videoWidth?: number | null;
  videoHeight?: number | null;
}

// Helper to detect video URLs
const isVideoUrl = (url: string) => url?.match(/\.(mp4|webm|mov|avi)$/i) || url?.includes('.mp4') || url?.includes('.webm');

const ProductImageGallery: React.FC<ProductImageGalleryProps> = ({ 
  images, 
  title, 
  videoUrl,
  mediaDimensions,
  videoWidth,
  videoHeight,
}) => {
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [videoPlaying, setVideoPlaying] = useState(false);
  const videoElRef = useRef<HTMLVideoElement>(null);
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);

  // Build media list: images (including inline videos) + dedicated video
  const allMedia = [
    ...(images || []),
    ...(videoUrl ? ['video:' + videoUrl] : [])
  ];
  const hasMultipleMedia = allMedia.length > 1;

  const currentMedia = allMedia[selectedIndex];
  const isDedicatedVideo = currentMedia?.startsWith('video:');
  const isInlineVideo = !isDedicatedVideo && isVideoUrl(currentMedia);
  const isCurrentVideo = isDedicatedVideo || isInlineVideo;
  const currentVideoSrc = isDedicatedVideo ? currentMedia.replace('video:', '') : currentMedia;

  // Index of the first video tile in the gallery (for the play-button jump).
  const videoTileIndex = allMedia.findIndex(
    (m) => m.startsWith('video:') || isVideoUrl(m),
  );
  const hasAnyVideo = videoTileIndex !== -1;

  const currentDims = isDedicatedVideo
    ? { w: videoWidth, h: videoHeight }
    : { w: mediaDimensions?.[selectedIndex]?.w, h: mediaDimensions?.[selectedIndex]?.h };

  const handleNext = () => {
    setVideoPlaying(false);
    setSelectedIndex((prev) => (prev + 1) % allMedia.length);
  };

  const handlePrev = () => {
    setVideoPlaying(false);
    setSelectedIndex((prev) => (prev - 1 + allMedia.length) % allMedia.length);
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current === null || touchStartY.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    const dy = e.changedTouches[0].clientY - touchStartY.current;
    // Only treat as swipe if horizontal movement dominates and exceeds threshold
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) && hasMultipleMedia) {
      if (dx < 0) handleNext();
      else handlePrev();
    }
    touchStartX.current = null;
    touchStartY.current = null;
  };

  return (
    <div className="space-y-4">
      {/* Main Image/Video */}
      <div
        className="relative bg-muted rounded-xl overflow-hidden group touch-pan-y"
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        <AnimatePresence mode="wait">
          {isCurrentVideo ? (
            <motion.div
              key={`video-${selectedIndex}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="relative w-full h-full"
            >
              <SmartVideo
                ref={videoElRef}
                src={videoCdnUrl(currentVideoSrc) || currentVideoSrc}
                poster={images?.[0] ? imageCdnUrl(images[0], { width: 1080, quality: 72 }) : undefined}
                controls
                playsInline
                onPlay={() => setVideoPlaying(true)}
                onPause={() => setVideoPlaying(false)}
                className="w-full max-h-[640px] bg-black"
                style={{
                  aspectRatio: currentDims.w && currentDims.h ? `${currentDims.w} / ${currentDims.h}` : '16 / 9',
                }}
              />
              {!videoPlaying && (
                <button
                  type="button"
                  aria-label="Play video"
                  onClick={(e) => {
                    e.stopPropagation();
                    const v = videoElRef.current;
                    if (v) {
                      v.play().then(() => setVideoPlaying(true)).catch(() => {});
                    }
                  }}
                  className="absolute inset-0 flex items-center justify-center z-10 group/play"
                >
                  <span className="w-16 h-16 rounded-full bg-black/55 backdrop-blur-sm flex items-center justify-center transition-transform group-hover/play:scale-110">
                    <Play className="w-8 h-8 text-white fill-white ml-1" />
                  </span>
                </button>
              )}
            </motion.div>
          ) : (
            <motion.div
              key={selectedIndex}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="w-full cursor-zoom-in"
            >
              <AdaptiveMedia
                url={currentMedia || '/placeholder.svg'}
                type="image"
                context="detail"
                alt={`${title} - ${selectedIndex + 1}`}
                originalWidth={currentDims.w}
                originalHeight={currentDims.h}
                onClick={() => setIsZoomed(true)}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Zoom indicator */}
        {!isCurrentVideo && (
          <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
            <Button
              size="sm"
              variant="secondary"
              className="bg-background/80 backdrop-blur-sm"
              onClick={() => setIsZoomed(true)}
            >
              <ZoomIn className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Navigation arrows */}
        {hasMultipleMedia && (
          <>
            <Button
              size="icon"
              variant="secondary"
              className="absolute left-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={handlePrev}
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            <Button
              size="icon"
              variant="secondary"
              className="absolute right-2 top-1/2 -translate-y-1/2 bg-background/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity"
              onClick={handleNext}
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </>
        )}

        {/* Image counter */}
        {hasMultipleMedia && (
          <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-background/80 backdrop-blur-sm px-3 py-1 rounded-full text-sm font-medium">
            {selectedIndex + 1} / {allMedia.length}
          </div>
        )}
      </div>

      {/* Thumbnails */}
      {hasMultipleMedia && (
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {allMedia.map((media, index) => {
            const isThumbnailDedicatedVideo = media.startsWith('video:');
            const isThumbnailInlineVideo = !isThumbnailDedicatedVideo && isVideoUrl(media);
            const isThumbnailVideo = isThumbnailDedicatedVideo || isThumbnailInlineVideo;
            
            return (
              <button
                key={index}
                onClick={() => setSelectedIndex(index)}
                className={cn(
                  "relative flex-shrink-0 w-16 h-16 md:w-20 md:h-20 rounded-lg overflow-hidden border-2 transition-all",
                  selectedIndex === index 
                    ? 'border-primary ring-2 ring-primary/20' 
                    : 'border-transparent hover:border-muted-foreground/30'
                )}
              >
                {isThumbnailVideo ? (
                  <div className="w-full h-full bg-muted flex items-center justify-center relative">
                    {/* Use first image as poster for video thumbnails */}
                    {images?.[0] ? (
                      <>
                        <img
                          src={imageCdnUrl(images[0], { width: 160, quality: 70 })}
                          alt="Video"
                          className="w-full h-full object-cover"
                          onError={(event) => {
                            if (event.currentTarget.dataset.originalRetried !== '1') {
                              event.currentTarget.dataset.originalRetried = '1';
                              event.currentTarget.src = images[0];
                              return;
                            }
                            onImageError(event);
                          }}
                        />
                        <Play className="w-4 h-4 text-white absolute" />
                      </>
                    ) : (
                      <Play className="w-6 h-6 text-muted-foreground" />
                    )}
                  </div>
                ) : (
                  <img
                    src={imageCdnUrl(media, { width: 160, quality: 70 })}
                    alt={`${title} thumbnail ${index + 1}`}
                    className="w-full h-full object-cover select-none"
                    onContextMenu={(e) => e.preventDefault()}
                    draggable={false}
                    onError={(event) => {
                      if (event.currentTarget.src !== media && event.currentTarget.dataset.originalRetried !== '1') {
                        event.currentTarget.dataset.originalRetried = '1';
                        event.currentTarget.src = media;
                        return;
                      }
                      onImageError(event);
                    }}
                  />
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Zoom Dialog */}
      <Dialog open={isZoomed && !isCurrentVideo} onOpenChange={setIsZoomed}>
        <DialogContent
          className="max-w-[95vw] w-[95vw] sm:max-w-5xl p-0 bg-background/95 backdrop-blur-xl border-border overflow-hidden"
        >
          <div className="relative w-full h-[85vh] flex items-center justify-center">
            <img
              src={currentMedia}
              alt={title}
              className="max-w-full max-h-full object-contain select-none"
              onContextMenu={(e) => e.preventDefault()}
              draggable={false}
            />
            <div className="absolute top-3 right-3 flex gap-2">
              <Button
                size="icon"
                variant="secondary"
                className="rounded-full bg-background/80 backdrop-blur-sm hover:bg-background"
                onClick={async () => {
                  try {
                    toast.loading('Preparing download...', { id: 'dl' });
                    const res = await fetch(currentMedia);
                    const blob = await res.blob();
                    const file = new File([blob], `${title || 'image'}.jpg`, { type: blob.type || 'image/jpeg' });
                    const watermarked = await addWatermarkToImage(file);
                    const url = URL.createObjectURL(watermarked);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `earlymarket-${title || 'image'}.jpg`;
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    URL.revokeObjectURL(url);
                    toast.success('Image downloaded', { id: 'dl' });
                  } catch (err) {
                    console.error(err);
                    toast.error('Failed to download', { id: 'dl' });
                  }
                }}
              >
                <Download className="w-5 h-5" />
              </Button>
              <Button
                size="icon"
                variant="secondary"
                className="rounded-full bg-background/80 backdrop-blur-sm hover:bg-background"
                onClick={() => setIsZoomed(false)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
            {hasMultipleMedia && (
              <>
                <Button
                  size="icon"
                  variant="secondary"
                  className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur-sm"
                  onClick={handlePrev}
                >
                  <ChevronLeft className="w-5 h-5" />
                </Button>
                <Button
                  size="icon"
                  variant="secondary"
                  className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-background/80 backdrop-blur-sm"
                  onClick={handleNext}
                >
                  <ChevronRight className="w-5 h-5" />
                </Button>
              </>
            )}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 text-xs text-foreground/80 bg-background/70 backdrop-blur-sm px-3 py-1 rounded-full">
              Downloaded images include an EarlyMarket watermark
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProductImageGallery;
