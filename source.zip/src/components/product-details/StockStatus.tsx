import React from 'react';
import { Package, AlertTriangle, Bell } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface StockStatusProps {
  inventoryCount?: number | null;
}

const StockStatus: React.FC<StockStatusProps> = ({ inventoryCount }) => {
  const isLowStock = inventoryCount !== null && inventoryCount !== undefined && inventoryCount <= 5 && inventoryCount > 0;
  const isOutOfStock = inventoryCount === 0;
  const isInStock = inventoryCount === null || inventoryCount === undefined || inventoryCount > 5;

  const handleNotifyMe = () => {
    toast.success('We\'ll notify you when this item is back in stock!');
  };

  return (
    <div className={cn(
      "flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium",
      isOutOfStock && "bg-red-50 text-red-600",
      isLowStock && "bg-amber-50 text-amber-600",
      isInStock && "bg-green-50 text-green-600"
    )}>
      {isOutOfStock ? (
        <>
          <AlertTriangle className="w-4 h-4" />
          <span>Out of Stock</span>
          <Button
            variant="ghost"
            size="sm"
            className="ml-auto text-red-600 hover:text-red-700 hover:bg-red-100 h-7 px-2"
            onClick={handleNotifyMe}
          >
            <Bell className="w-3 h-3 mr-1" />
            Notify me
          </Button>
        </>
      ) : isLowStock ? (
        <>
          <AlertTriangle className="w-4 h-4" />
          <span>Limited stock – selling fast!</span>
        </>
      ) : (
        <>
          <Package className="w-4 h-4" />
          <span>In Stock</span>
        </>
      )}
    </div>
  );
};

export default StockStatus;
