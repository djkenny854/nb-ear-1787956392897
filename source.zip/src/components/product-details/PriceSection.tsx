import React from 'react';
import { Badge } from '@/components/ui/badge';
import { Percent, Bell, BellRing } from 'lucide-react';
import { useCurrency } from '@/contexts/CurrencyContext';
import { cn } from '@/lib/utils';

interface PriceSectionProps {
  price: number | null;
  originalPrice?: number | null;
  currency?: string;
  hasDiscount?: boolean;
  isNegotiable?: boolean;
  notifyEnabled?: boolean;
  onNotifyClick?: () => void;
}

const PriceSection: React.FC<PriceSectionProps> = ({
  price,
  originalPrice,
  currency: _currency = 'UGX',
  hasDiscount,
  isNegotiable,
  notifyEnabled = false,
  onNotifyClick
}) => {
  const { formatPrice } = useCurrency();
  
  const discountPercent = hasDiscount && originalPrice && price
    ? Math.round(((originalPrice - price) / originalPrice) * 100)
    : 0;

  const savings = hasDiscount && originalPrice && price
    ? originalPrice - price
    : 0;

  return (
    <div className="space-y-3">
      <div className="flex items-baseline gap-3 flex-wrap">
        <span className="text-3xl md:text-4xl font-bold text-primary">
          {price ? formatPrice(price) : 'Contact for price'}
        </span>
        {isNegotiable && (
          <Badge variant="outline" className="text-green-600 border-green-200 bg-green-50 dark:bg-green-950 dark:border-green-800">
            Negotiable
          </Badge>
        )}
      </div>

      {hasDiscount && originalPrice && (
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-lg text-muted-foreground line-through">
            {formatPrice(originalPrice)}
          </span>
          <Badge variant="destructive" className="flex items-center gap-1">
            <Percent className="w-3 h-3" />
            {discountPercent}% OFF
          </Badge>
          <span className="text-sm text-green-600 font-medium">
            Save {formatPrice(savings)}
          </span>
        </div>
      )}

      {/* Price Drop Alert - big prominent CTA */}
      {onNotifyClick && (
        <button
          onClick={onNotifyClick}
          className={cn(
            "w-full h-12 rounded-full flex items-center justify-center gap-2 text-sm font-semibold border-2 transition-colors",
            notifyEnabled
              ? "bg-primary text-primary-foreground border-primary"
              : "border-primary/40 text-primary hover:bg-primary/10"
          )}
        >
          {notifyEnabled ? <BellRing className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
          {notifyEnabled ? 'Price alert enabled' : 'Notify me when price drops'}
        </button>
      )}
    </div>
  );
};

export default PriceSection;
