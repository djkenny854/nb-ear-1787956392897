import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Star, 
  ThumbsUp, 
  MessageSquare, 
  User,
  Image as ImageIcon,
  Filter,
  CheckCircle2
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

interface ReviewsSectionProps {
  sellerId: string;
  adId: string;
}

const ReviewsSection: React.FC<ReviewsSectionProps> = ({ sellerId, adId }) => {
  const [sortBy, setSortBy] = useState<'latest' | 'top' | 'photos'>('latest');
  const queryClient = useQueryClient();

  const { data: reviews, isLoading } = useQuery({
    queryKey: ['product-reviews', sellerId, sortBy],
    queryFn: async () => {
      let query = supabase
        .from('reviews')
        .select('*')
        .eq('reviewed_user_id', sellerId);

      if (sortBy === 'latest') {
        query = query.order('created_at', { ascending: false });
      } else if (sortBy === 'top') {
        query = query.order('helpful_count', { ascending: false });
      } else if (sortBy === 'photos') {
        query = query.not('review_images', 'is', null);
      }

      const { data, error } = await query.limit(10);
      if (error) throw error;
      return data || [];
    },
    enabled: !!sellerId
  });

  // Calculate rating breakdown
  const ratingBreakdown = reviews?.reduce((acc, review) => {
    acc[review.rating] = (acc[review.rating] || 0) + 1;
    return acc;
  }, {} as Record<number, number>) || {};

  const totalReviews = reviews?.length || 0;
  const avgRating = totalReviews > 0
    ? reviews!.reduce((acc, r) => acc + r.rating, 0) / totalReviews
    : 0;

  const handleHelpful = async (reviewId: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      toast.error('Please sign in to mark reviews as helpful');
      return;
    }

    // Check if already voted
    const { data: existing } = await supabase
      .from('review_helpful_votes')
      .select('id')
      .eq('review_id', reviewId)
      .eq('user_id', user.id)
      .single();

    if (existing) {
      toast.info('You already marked this review as helpful');
      return;
    }

    // Add vote
    await supabase.from('review_helpful_votes').insert({
      review_id: reviewId,
      user_id: user.id
    });

    // Update count manually
    const { data: review } = await supabase
      .from('reviews')
      .select('helpful_count')
      .eq('id', reviewId)
      .single();
    
    await supabase
      .from('reviews')
      .update({ helpful_count: (review?.helpful_count || 0) + 1 })
      .eq('id', reviewId);

    queryClient.invalidateQueries({ queryKey: ['product-reviews', sellerId] });
    toast.success('Marked as helpful');
  };

  if (isLoading) {
    return (
      <Card className="p-6 space-y-6">
        <Skeleton className="h-6 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Skeleton className="h-40" />
          <div className="space-y-2">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-4" />
            ))}
          </div>
        </div>
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32" />
          ))}
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-6 space-y-6">
      <h3 className="text-xl font-semibold flex items-center gap-2">
        <Star className="w-5 h-5 text-yellow-500" />
        Customer Reviews
      </h3>

      {/* Rating Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Average Rating */}
        <div className="text-center p-6 bg-muted/30 rounded-xl">
          <div className="text-5xl font-bold text-foreground mb-2">
            {avgRating.toFixed(1)}
          </div>
          <div className="flex justify-center mb-2">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={cn(
                  "w-5 h-5",
                  i < Math.round(avgRating)
                    ? 'text-yellow-400 fill-yellow-400'
                    : 'text-gray-300'
                )}
              />
            ))}
          </div>
          <p className="text-sm text-muted-foreground">
            Based on {totalReviews} reviews
          </p>
        </div>

        {/* Rating Breakdown */}
        <div className="space-y-2">
          {[5, 4, 3, 2, 1].map((rating) => {
            const count = ratingBreakdown[rating] || 0;
            const percentage = totalReviews > 0 ? (count / totalReviews) * 100 : 0;
            return (
              <div key={rating} className="flex items-center gap-2 text-sm">
                <span className="w-8">{rating}★</span>
                <Progress value={percentage} className="flex-1 h-2" />
                <span className="w-8 text-muted-foreground">{count}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Sort Options */}
      <div className="flex items-center gap-2 border-t pt-4">
        <Filter className="w-4 h-4 text-muted-foreground" />
        <span className="text-sm text-muted-foreground">Sort by:</span>
        <div className="flex gap-2">
          {(['latest', 'top', 'photos'] as const).map((option) => (
            <Button
              key={option}
              variant={sortBy === option ? 'default' : 'outline'}
              size="sm"
              onClick={() => setSortBy(option)}
            >
              {option === 'latest' && 'Latest'}
              {option === 'top' && 'Most Helpful'}
              {option === 'photos' && (
                <>
                  <ImageIcon className="w-3 h-3 mr-1" />
                  With Photos
                </>
              )}
            </Button>
          ))}
        </div>
      </div>

      {/* Reviews List */}
      <div className="space-y-4">
        {reviews?.length === 0 ? (
          <div className="text-center py-8">
            <MessageSquare className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
            <h4 className="font-semibold text-foreground mb-2">No reviews yet</h4>
            <p className="text-sm text-muted-foreground">
              Be the first to review this seller's products
            </p>
          </div>
        ) : (
          reviews?.map((review) => (
            <div 
              key={review.id} 
              className="p-4 border rounded-lg space-y-3"
            >
              {/* Review Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                    <User className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">Buyer</span>
                      {review.is_verified && (
                        <Badge variant="secondary" className="text-xs">
                          <CheckCircle2 className="w-3 h-3 mr-1" />
                          Verified Purchase
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={cn(
                              "w-3 h-3",
                              i < review.rating
                                ? 'text-yellow-400 fill-yellow-400'
                                : 'text-gray-300'
                            )}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">
                        {formatDistanceToNow(new Date(review.created_at), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Review Content */}
              {review.comment && (
                <p className="text-sm text-foreground">{review.comment}</p>
              )}

              {/* Review Images */}
              {review.review_images && review.review_images.length > 0 && (
                <div className="flex gap-2 overflow-x-auto">
                  {review.review_images.map((img: string, index: number) => (
                    <img
                      key={index}
                      src={img}
                      alt={`Review image ${index + 1}`}
                      className="w-20 h-20 rounded-lg object-cover"
                    />
                  ))}
                </div>
              )}

              {/* Helpful Button */}
              <div className="flex items-center gap-4">
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-muted-foreground hover:text-foreground"
                  onClick={() => handleHelpful(review.id)}
                >
                  <ThumbsUp className="w-4 h-4 mr-1" />
                  Helpful ({review.helpful_count || 0})
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </Card>
  );
};

export default ReviewsSection;
