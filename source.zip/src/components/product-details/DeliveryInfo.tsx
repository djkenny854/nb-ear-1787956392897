import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Truck, 
  MapPin, 
  Clock, 
  CreditCard,
  Package,
  ChevronRight
} from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ugandaDistricts } from '@/data/ugandaDistricts';

interface DeliveryInfoProps {
  location: string;
  pickupAvailable?: boolean;
  shippingOptions?: any;
}

const DeliveryInfo: React.FC<DeliveryInfoProps> = ({
  location,
  pickupAvailable = true,
  shippingOptions
}) => {
  const [selectedDistrict, setSelectedDistrict] = useState<string>('');

  const getDeliveryEstimate = (district: string) => {
    const kampalaDistricts = ['Kampala', 'Wakiso', 'Mukono'];
    if (kampalaDistricts.includes(district)) {
      return { days: '1-2 days', fee: 5000 };
    }
    return { days: '3-5 days', fee: 15000 };
  };

  const deliveryEstimate = selectedDistrict 
    ? getDeliveryEstimate(selectedDistrict)
    : null;

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
          <Truck className="w-4 h-4 text-primary" />
        </div>
        <h3 className="font-semibold text-foreground">Delivery</h3>
      </div>

      {/* Location Selector */}
      <div className="space-y-2">
        <Select value={selectedDistrict} onValueChange={setSelectedDistrict}>
          <SelectTrigger className="bg-muted/30 border-border/50 h-10">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-muted-foreground" />
              <SelectValue placeholder="Select delivery location" />
            </div>
          </SelectTrigger>
          <SelectContent className="max-h-60">
            {ugandaDistricts.map((district) => (
              <SelectItem key={district.name} value={district.name}>
                {district.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Delivery Estimate */}
      {deliveryEstimate && (
        <div className="rounded-xl bg-gradient-to-r from-green-500/10 to-emerald-500/10 p-3 space-y-2 border border-green-500/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Clock className="w-4 h-4" />
              <span>Delivery time</span>
            </div>
            <span className="font-semibold text-green-600">
              {deliveryEstimate.days}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <CreditCard className="w-4 h-4" />
              <span>Delivery fee</span>
            </div>
            <span className="font-medium text-foreground">
              UGX {deliveryEstimate.fee.toLocaleString()}
            </span>
          </div>
        </div>
      )}

      {/* Options List */}
      <div className="space-y-2">
        {pickupAvailable && (
          <div className="flex items-center justify-between p-3 rounded-xl bg-muted/20 hover:bg-muted/30 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center">
                <Package className="w-4 h-4 text-blue-500" />
              </div>
              <div>
                <p className="font-medium text-sm text-foreground">Pickup Available</p>
                <p className="text-xs text-muted-foreground">{location || 'Seller location'}</p>
              </div>
            </div>
            <span className="text-xs font-medium text-green-600">FREE</span>
          </div>
        )}

        <div className="flex items-center justify-between p-3 rounded-xl bg-muted/20 hover:bg-muted/30 transition-colors">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-amber-500/10 flex items-center justify-center">
              <CreditCard className="w-4 h-4 text-amber-500" />
            </div>
            <div>
              <p className="font-medium text-sm text-foreground">Cash on Delivery</p>
              <p className="text-xs text-muted-foreground">Pay when you receive</p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </div>
      </div>
    </div>
  );
};

export default DeliveryInfo;
