import React from 'react';
import { Star } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Skeleton } from '@/components/ui/skeleton';

interface ProductRatingSummaryProps {
  adId: string;
  sellerId: string;
}

const ProductRatingSummary: React.FC<ProductRatingSummaryProps> = ({ adId, sellerId }) => {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['seller-rating-summary', sellerId],
    queryFn: async () => {
      // First get the user_id from seller_profiles
      const { data: sellerData } = await supabase
        .from('seller_profiles')
        .select('user_id')
        .eq('id', sellerId)
        .single();

      if (!sellerData?.user_id) {
        return { avgRating: '0.0', totalReviews: 0 };
      }

      // Get reviews for the seller's user_id
      const { data: reviews, error: reviewsError } = await supabase
        .from('reviews')
        .select('rating')
        .eq('reviewed_user_id', sellerData.user_id);

      if (reviewsError) throw reviewsError;

      const totalReviews = reviews?.length || 0;
      const avgRating = totalReviews > 0 
        ? reviews.reduce((acc, r) => acc + r.rating, 0) / totalReviews 
        : 0;

      return {
        avgRating: avgRating.toFixed(1),
        totalReviews
      };
    },
    enabled: !!sellerId
  });

  if (isLoading) {
    return (
      <div className="flex items-center gap-2">
        <Skeleton className="h-5 w-24" />
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2 text-sm">
      <div className="flex items-center gap-1">
        <div className="flex items-center">
          {[...Array(5)].map((_, i) => (
            <Star
              key={i}
              className={`w-4 h-4 ${
                i < Math.round(Number(stats?.avgRating || 0))
                  ? 'text-yellow-400 fill-yellow-400'
                  : 'text-gray-300'
              }`}
            />
          ))}
        </div>
        <span className="font-medium">{stats?.avgRating || '0.0'}</span>
        <span className="text-muted-foreground">({stats?.totalReviews || 0} reviews)</span>
      </div>
    </div>
  );
};

export default ProductRatingSummary;
