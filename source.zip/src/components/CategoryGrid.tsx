
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ChevronRight } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { icons } from 'lucide-react';

interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

interface CategoryGridProps {
  categories: Category[];
  onCategorySelect: (category: string, subcategory?: string) => void;
}

const CategoryGrid = ({ categories, onCategorySelect }: CategoryGridProps) => {
  const navigate = useNavigate();

  const { data: subcategories = [] } = useQuery({
    queryKey: ['all-subcategories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('subcategories')
        .select('*')
        .eq('is_active', true)
        .order('name');
      
      if (error) throw error;
      return data || [];
    },
  });

  // Fetch ad counts for categories
  const { data: adCounts = {} } = useQuery({
    queryKey: ['category-ad-counts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('ads')
        .select('category')
        .eq('status', 'active');
      
      if (error) throw error;
      
      const counts: { [key: string]: number } = {};
      data.forEach(ad => {
        counts[ad.category] = (counts[ad.category] || 0) + 1;
      });
      
      return counts;
    },
  });

  const getIconComponent = (iconName: string) => {
    if (!iconName) return icons.Package;
    
    // Convert icon name to PascalCase for lucide-react
    const pascalCaseIcon = iconName
      .split(/[-_\s]/)
      .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join('');
    
    const IconComponent = icons[pascalCaseIcon as keyof typeof icons] || icons.Package;
    return IconComponent;
  };

  const getCategorySubcategories = (categoryId: string) => {
    return subcategories.filter(sub => sub.category_id === categoryId);
  };

  const handleCategoryClick = (categoryName: string) => {
    onCategorySelect(categoryName);
  };

  return (
    <div className="py-8 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-foreground">Browse Categories</h2>
          <Button variant="outline" onClick={() => navigate('/search')}>
            View All Categories
            <ChevronRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          {categories.map((category) => {
            const IconComponent = getIconComponent(category.icon);
            const categorySubcategories = getCategorySubcategories(category.id);
            const categoryAdCount = adCounts[category.name] || 0;
            
            return (
              <Card
                key={category.id}
                className="hover:shadow-lg transition-all duration-300 cursor-pointer group border-2 hover:border-primary/20 bg-card hover:scale-105"
                onClick={() => handleCategoryClick(category.name)}
              >
                <CardContent className="p-4 text-center">
                  <div className="flex flex-col items-center space-y-3">
                    <div className="w-16 h-16 bg-gradient-to-r from-primary to-orange-600 dark:from-foreground dark:to-muted-foreground rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg">
                      <IconComponent className="w-8 h-8 text-primary-foreground dark:text-background" />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-center gap-2">
                        <h3 className="font-semibold text-sm text-foreground group-hover:text-primary transition-colors">
                          {category.name}
                        </h3>
                        {categoryAdCount > 0 && (
                          <Badge variant="secondary" className="text-xs px-1.5 py-0.5 h-5">
                            {categoryAdCount}
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed line-clamp-2">
                        {category.description}
                      </p>
                    </div>

                    <Badge variant="outline" className="text-xs">
                      {categorySubcategories.length} subcategories
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default CategoryGrid;
