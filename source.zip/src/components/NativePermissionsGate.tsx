import React, { useEffect, useRef } from 'react';
import { isRealNativeRuntime } from '@/hooks/useCapacitor';

// v4: removed automatic notification permission requests (caused Android crash on some devices).
// Camera, microphone, photos/files, and location are requested ON DEMAND by the features that need them.
const PERMISSIONS_VERSION = 'v4';
const PERMISSIONS_REQUESTED_KEY = `native_permissions_${PERMISSIONS_VERSION}`;

export const NativePermissionsGate: React.FC = () => {
  const hasRun = useRef(false);

  useEffect(() => {
    if (!isRealNativeRuntime() || hasRun.current) return;
    if (localStorage.getItem(PERMISSIONS_REQUESTED_KEY)) return;
    hasRun.current = true;

    // No automatic permission requests at startup.
    // Notification permission auto-prompt was crashing Android — removed entirely.
    // Camera/Microphone/Photos/Files/Location are requested lazily by feature code
    // (e.g., voice messages request mic, image picker requests photos, location picker requests GPS).
    localStorage.setItem(PERMISSIONS_REQUESTED_KEY, 'true');
  }, []);

  return null;
};

export default NativePermissionsGate;
