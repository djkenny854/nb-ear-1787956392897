import React, { useState, useEffect, useRef, useCallback } from 'react';
import { cn } from '@/lib/utils';
const banner1 = '';
const banner2 = '';
const banner3 = '';
const banner4 = '';

interface BannerSlide {
  image: string;
  title: string;
  subtitle: string;
  gradientColor: string; // HSL color for the gradient
}

const bannerSlides: BannerSlide[] = [
  {
    image: banner1,
    title: "Boost Sales with Video Ads",
    subtitle: "Add videos to your products and get 3x more views",
    gradientColor: "280, 80%, 55%" // Purple
  },
  {
    image: banner2,
    title: "Sell Smarter, Not Harder",
    subtitle: "Pro tips to maximize your seller potential",
    gradientColor: "210, 100%, 50%" // Blue
  },
  {
    image: banner3,
    title: "Shop Local in Kampala",
    subtitle: "Discover amazing deals right in your city",
    gradientColor: "25, 95%, 55%" // Orange
  },
  {
    image: banner4,
    title: "Instant Buyer Connections",
    subtitle: "Real-time chat brings customers to you faster",
    gradientColor: "160, 70%, 45%" // Teal
  },
  {
    image: banner1,
    title: "AI-Powered Recommendations",
    subtitle: "Smart search helps buyers find your products",
    gradientColor: "340, 80%, 55%" // Pink
  },
  {
    image: banner2,
    title: "Verified Seller Badge",
    subtitle: "Build trust and stand out from the crowd",
    gradientColor: "45, 90%, 50%" // Gold
  },
];

const ModernHeroBanner = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  
  // Transition states for layered animations
  const [isTextBlurring, setIsTextBlurring] = useState(false);
  const [displayedTextIndex, setDisplayedTextIndex] = useState(0);
  const [displayedGradientIndex, setDisplayedGradientIndex] = useState(0);
  const [displayedImageIndex, setDisplayedImageIndex] = useState(0);
  
  const bannerRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Intersection observer for visibility
  useEffect(() => {
    const observer = new IntersectionObserver(([entry]) => {
      setIsVisible(entry.isIntersecting);
    }, {
      threshold: 0.3,
      rootMargin: '50px'
    });
    
    if (bannerRef.current) {
      observer.observe(bannerRef.current);
    }
    
    return () => {
      if (bannerRef.current) {
        observer.unobserve(bannerRef.current);
      }
    };
  }, []);

  // Trigger transition function
  const triggerTransition = useCallback((nextIndex: number) => {
    // Step 1: Start text blur immediately (0ms)
    setIsTextBlurring(true);
    
    // Step 2: Change text while blurred (300ms into blur)
    setTimeout(() => {
      setDisplayedTextIndex(nextIndex);
      // Unblur text after changing
      setTimeout(() => {
        setIsTextBlurring(false);
      }, 300);
    }, 300);
    
    // Step 3: Change gradient color (500ms delay)
    setTimeout(() => {
      setDisplayedGradientIndex(nextIndex);
    }, 500);
    
    // Step 4: Change background image (1000ms delay, smooth 700ms transition)
    setTimeout(() => {
      setDisplayedImageIndex(nextIndex);
    }, 1000);
  }, []);

  // Auto-advance with layered transitions - runs continuously
  useEffect(() => {
    if (!isVisible || isPaused || bannerSlides.length <= 1) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }
    
    // Clear any existing interval first
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    
    // Start new interval - 5 seconds total cycle
    intervalRef.current = setInterval(() => {
      setCurrentIndex(prevIndex => {
        const nextIndex = prevIndex === bannerSlides.length - 1 ? 0 : prevIndex + 1;
        triggerTransition(nextIndex);
        return nextIndex;
      });
    }, 5000);
    
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    };
  }, [isVisible, isPaused, triggerTransition]);

  const goToSlide = (index: number) => {
    if (index !== currentIndex) {
      setCurrentIndex(index);
      triggerTransition(index);
    }
  };

  const currentSlide = bannerSlides[displayedTextIndex];
  const currentGradient = bannerSlides[displayedGradientIndex];
  const currentImage = bannerSlides[displayedImageIndex];

  return (
    <div 
      ref={bannerRef} 
      className="relative w-screen overflow-hidden bg-muted/30" 
      onMouseEnter={() => setIsPaused(true)} 
      onMouseLeave={() => setIsPaused(false)} 
      style={{
        height: window.innerWidth < 768 ? '200px' : '350px',
        marginLeft: 'calc(-50vw + 50%)',
        marginRight: 'calc(-50vw + 50%)',
        width: '100vw',
        maxWidth: 'none',
        zIndex: 0
      }}
    >
      {/* Background Images - Fixed position, smooth opacity transition */}
      <div className="absolute inset-0 w-full h-full">
        {bannerSlides.map((slide, index) => (
          <div 
            key={index} 
            className="absolute inset-0 w-full h-full flex items-center justify-center"
            style={{
              opacity: index === displayedImageIndex ? 1 : 0,
              transition: 'opacity 700ms ease-in-out',
            }}
          >
            <img 
              src={slide.image} 
              className="max-w-full max-h-full object-contain" 
              alt={`Banner ${index + 1}`} 
            />
          </div>
        ))}
      </div>

      {/* Gradient Overlay - Fades from middle to right */}
      <div 
        className="absolute inset-0 z-10 pointer-events-none"
        style={{
          background: `linear-gradient(90deg, 
            hsla(${currentGradient.gradientColor}, 0.85) 0%, 
            hsla(${currentGradient.gradientColor}, 0.7) 25%,
            hsla(${currentGradient.gradientColor}, 0.4) 50%, 
            hsla(${currentGradient.gradientColor}, 0.1) 75%,
            transparent 100%)`,
          transition: 'background 800ms ease-in-out',
        }}
      />

      {/* Text Content with Blur Transition */}
      <div className="absolute inset-0 z-20 flex items-center">
        <div className="max-w-6xl mx-auto px-6 sm:px-8 lg:px-12 w-full">
          <div 
            className="max-w-md space-y-2 md:space-y-4"
            style={{
              filter: isTextBlurring ? 'blur(8px)' : 'blur(0px)',
              opacity: isTextBlurring ? 0.6 : 1,
              transform: isTextBlurring ? 'scale(0.98)' : 'scale(1)',
              transition: 'filter 300ms ease-out, opacity 300ms ease-out, transform 300ms ease-out',
            }}
          >
            <h1 className="text-2xl md:text-4xl lg:text-5xl font-bold text-white drop-shadow-lg">
              {currentSlide.title}
            </h1>
            <p className="text-sm md:text-lg lg:text-xl text-white/90 drop-shadow-md">
              {currentSlide.subtitle}
            </p>
          </div>
        </div>
      </div>

      {/* Dots Indicator */}
      <div className="absolute bottom-4 md:bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2 md:space-x-3 z-30">
        {bannerSlides.map((_, index) => (
          <button 
            key={index} 
            onClick={() => goToSlide(index)} 
            className={cn(
              "w-2 h-2 md:w-3 md:h-3 rounded-full transition-all duration-300",
              index === currentIndex 
                ? "bg-white scale-125 shadow-lg" 
                : "bg-white/50 hover:bg-white/70"
            )} 
            aria-label={`Go to slide ${index + 1}`} 
          />
        ))}
      </div>

      {/* Progress Bar */}
      {isVisible && !isPaused && (
        <div className="absolute bottom-0 left-0 w-full h-1 bg-black/20 z-30 overflow-hidden">
          <div 
            className="h-full bg-white/80 transition-all duration-100 ease-linear" 
            style={{
              width: `${((currentIndex + 1) / bannerSlides.length) * 100}%`
            }} 
          />
        </div>
      )}
    </div>
  );
};

export default ModernHeroBanner;
