import React, { useEffect, useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Bookmark,
  ChevronRight,
  Clock,
  Copy,
  Gift,
  Percent,
  Sparkles,
  Tag,
  Zap,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface DatabasePromotion {
  id: string;
  title: string;
  description: string;
  images: string[];
  brand_name: string;
  offer_type: string;
  discount_percentage?: number | null;
  discount_amount?: number | null;
  original_price?: number | null;
  valid_until?: string | null;
  start_at?: string | null;
  state?: string | null;
  promo_code?: string | null;
  current_claims: number;
  max_claims?: number | null;
  terms_conditions?: string | null;
  seller?: {
    id: string;
    business_name: string;
    business_logo_url?: string;
    is_verified?: boolean;
  } | null;
}

interface DatabasePromotionCardProps {
  promotion: DatabasePromotion;
  onClick?: () => void;
}

const offerTypeStyles: Record<string, { icon: React.ReactNode; color: string }> = {
  'Discount': {
    icon: <Percent className="w-3 h-3" />,
    color: 'rose',
  },
  'Flash Sale': {
    icon: <Zap className="w-3 h-3" />,
    color: 'amber',
  },
  'Bundle': {
    icon: <Gift className="w-3 h-3" />,
    color: 'emerald',
  },
  'Offer': {
    icon: <Tag className="w-3 h-3" />,
    color: 'blue',
  },
  'Event': {
    icon: <Sparkles className="w-3 h-3" />,
    color: 'purple',
  },
};

const DatabasePromotionCard: React.FC<DatabasePromotionCardProps> = ({ promotion, onClick }) => {
  const navigate = useNavigate();
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Fetch linked promotion products
  const { data: linkedProducts } = useQuery({
    queryKey: ['promo-linked-products', promotion.id],
    queryFn: async () => {
      // First get the promotion_details ID
      const { data: promoDetails } = await supabase
        .from('promotion_details')
        .select('id, is_seller_wide')
        .eq('ad_id', promotion.id)
        .single();

      if (!promoDetails) return [];

      // Get linked products
      const { data: linked } = await supabase
        .from('promotion_products')
        .select('ad_id, discount_percentage')
        .eq('promotion_id', promoDetails.id);

      if (linked && linked.length > 0) {
        const productIds = linked.slice(0, 4).map(p => p.ad_id);
        const { data: products } = await supabase
          .from('ads')
          .select('id, title, images, price')
          .in('id', productIds);
        return products || [];
      }

      // Fallback for seller-wide: get seller products
      if (promoDetails.is_seller_wide && promotion.seller?.id) {
        const { data: sellerProducts } = await supabase
          .from('ads')
          .select('id, title, images, price')
          .eq('seller_id', promotion.seller.id)
          .eq('status', 'active')
          .in('listing_type', ['physical_products', 'digital_products'])
          .limit(4);
        return sellerProducts || [];
      }

      return [];
    },
    staleTime: 1000 * 60 * 5,
  });

  useEffect(() => {
    if (!promotion.images || promotion.images.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % promotion.images.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [promotion.images?.length]);

  // Calculate countdown status (upcoming → ends in)
  const countdownInfo = useMemo(() => {
    const now = Date.now();
    const startMs = promotion.start_at ? new Date(promotion.start_at).getTime() : 0;
    const isUpcoming = (promotion.state === 'upcoming') || (startMs && startMs > now);

    if (isUpcoming) {
      const diff = startMs - now;
      const hours = Math.floor(diff / 3600000);
      const days = Math.floor(hours / 24);
      const remHours = hours % 24;
      const mins = Math.floor((diff % 3600000) / 60000);
      const label = days > 0 ? `Starts in ${days}d ${remHours}h`
        : hours > 0 ? `Starts in ${hours}h ${mins}m`
        : `Starts in ${Math.max(mins, 1)}m`;
      return { label, status: 'upcoming' as const };
    }

    if (!promotion.valid_until) return { label: 'No expiry', status: 'ongoing' as const };
    const endDate = new Date(promotion.valid_until).getTime();
    const diff = endDate - now;
    if (diff <= 0) return { label: 'Expired', status: 'expired' as const };
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(hours / 24);
    const remainingHours = hours % 24;
    const minutes = Math.floor((diff % 3600000) / 60000);
    if (days > 0) return { label: `Ends in ${days}d ${remainingHours}h`, status: 'ending' as const };
    if (hours > 0) return { label: `Ends in ${hours}h ${minutes}m`, status: 'ending' as const };
    return { label: `Ends in ${Math.max(minutes, 1)}m`, status: 'urgent' as const };
  }, [promotion.valid_until, promotion.start_at, promotion.state]);

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!promotion.promo_code) return;
    navigator.clipboard.writeText(promotion.promo_code);
    toast.success("Promo code copied");
  };

  const handleClick = () => {
    if (onClick) {
      onClick();
    } else {
      navigate(`/promotion/${promotion.id}`);
    }
  };

  const isExpired = countdownInfo.status === 'expired';
  const style = offerTypeStyles[promotion.offer_type] || offerTypeStyles['Discount'];
  const hasLinkedProducts = linkedProducts && linkedProducts.length > 0;

  return (
    <motion.article
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.99 }}
      transition={{ duration: 0.2 }}
      onClick={handleClick}
      className={cn(
        "group cursor-pointer col-span-2 bg-card rounded-2xl overflow-hidden border border-border hover:shadow-lg transition-all w-full",
        isExpired && "opacity-70"
      )}
      aria-label={`Promotion: ${promotion.title}`}
    >
      <div className="flex min-h-[140px]">
        {/* Media */}
        <div className="relative w-[42%] min-w-[140px] max-w-[260px] overflow-hidden">
          {hasLinkedProducts ? (
            // Show product grid when linked products exist
            <div className="grid grid-cols-2 gap-0.5 h-full bg-muted">
              {linkedProducts.slice(0, 4).map((product: any) => (
                <div key={product.id} className="overflow-hidden">
                  {product.images?.[0] ? (
                    <img 
                      src={product.images[0]} 
                      alt={product.title}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-muted">
                      <Percent className="w-4 h-4 text-muted-foreground" />
                    </div>
                  )}
                </div>
              ))}
              {linkedProducts.length < 4 && Array.from({ length: 4 - linkedProducts.length }).map((_, i) => (
                <div key={`empty-${i}`} className="bg-muted/50" />
              ))}
            </div>
          ) : (
            // Fallback to promotion images
            <AnimatePresence mode="wait">
              <motion.img
                key={currentImageIndex}
                src={promotion.images?.[currentImageIndex] || "/placeholder.svg"}
                alt={promotion.title}
                className="h-full w-full object-cover"
                loading="lazy"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.35 }}
              />
            </AnimatePresence>
          )}

          {/* Fade to right */}
          <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-card to-transparent" />

          <div className="absolute left-3 top-3 flex items-center gap-2">
            <Badge className="bg-primary text-primary-foreground text-[10px]">
              {style.icon}
              <span className="ml-1">{promotion.offer_type}</span>
            </Badge>
            {promotion.discount_percentage && (
              <div className="inline-flex items-center gap-1 rounded-full bg-destructive text-white px-2.5 py-1 text-[11px] font-bold shadow-lg">
                <Percent className="h-3 w-3" />
                {promotion.discount_percentage}% OFF
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsBookmarked((v) => !v);
            }}
            className="absolute right-3 top-3 rounded-full bg-background/70 backdrop-blur px-2.5 py-2 border border-border hover:bg-background transition"
            aria-label={isBookmarked ? "Remove bookmark" : "Bookmark"}
          >
            <Bookmark className={cn("h-4 w-4", isBookmarked && "fill-primary text-primary")} />
          </button>

          {/* Countdown Badge */}
          <div className={cn(
            "absolute left-3 bottom-3 inline-flex items-center gap-1 rounded-full backdrop-blur border px-2.5 py-1 text-[11px] font-medium",
            countdownInfo.status === 'expired' && "bg-destructive/20 border-destructive/30 text-destructive",
            countdownInfo.status === 'urgent' && "bg-orange-500/20 border-orange-500/30 text-orange-600",
            countdownInfo.status === 'ending' && "bg-background/70 border-border text-foreground",
            countdownInfo.status === 'ongoing' && "bg-emerald-500/20 border-emerald-500/30 text-emerald-600",
            countdownInfo.status === 'upcoming' && "bg-purple-500/20 border-purple-500/30 text-purple-600"
          )}>
            <Clock className="h-3 w-3" />
            {countdownInfo.label}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 p-4 flex flex-col gap-2">
          <header className="min-w-0">
            <div className="flex items-center gap-2 mb-1">
              {promotion.seller?.business_logo_url && (
                <img 
                  src={promotion.seller.business_logo_url} 
                  alt={promotion.seller.business_name}
                  className="w-5 h-5 rounded-full object-cover"
                />
              )}
              <p className="text-xs text-muted-foreground line-clamp-1">
                {promotion.brand_name || promotion.seller?.business_name || 'Brand'}
              </p>
            </div>
            <h3 className="font-semibold text-sm text-foreground line-clamp-2 group-hover:text-primary transition-colors">
              {promotion.title}
            </h3>
          </header>

          <p className="text-xs text-muted-foreground line-clamp-2">
            {promotion.description}
          </p>

          {/* Linked Products Avatars */}
          {hasLinkedProducts && (
            <div className="flex items-center gap-1">
              <div className="flex -space-x-2">
                {linkedProducts.slice(0, 4).map((product: any) => (
                  <Avatar key={product.id} className="w-6 h-6 border-2 border-background">
                    <AvatarImage src={product.images?.[0]} />
                    <AvatarFallback className="text-[8px] bg-muted">
                      {product.title?.charAt(0) || '?'}
                    </AvatarFallback>
                  </Avatar>
                ))}
              </div>
              <span className="text-[10px] text-muted-foreground ml-1">
                {linkedProducts.length} product{linkedProducts.length > 1 ? 's' : ''} included
              </span>
            </div>
          )}

          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              {promotion.discount_percentage ? (
                <>
                  <div className="text-[11px] text-muted-foreground">Save</div>
                  <div className="font-bold text-sm text-destructive truncate">
                    {promotion.discount_percentage}% off
                  </div>
                </>
              ) : promotion.discount_amount ? (
                <>
                  <div className="text-[11px] text-muted-foreground">Save</div>
                  <div className="font-bold text-sm text-foreground truncate">
                    UGX {promotion.discount_amount.toLocaleString()}
                  </div>
                </>
              ) : null}
            </div>

            {promotion.promo_code && (
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-2 rounded-full border border-border bg-background px-3 py-1.5 text-xs font-semibold hover:bg-muted transition"
              >
                <span className="font-mono tracking-wider">{promotion.promo_code}</span>
                <Copy className="h-3 w-3 text-muted-foreground" />
              </button>
            )}
          </div>

          <div className="mt-auto flex items-center justify-between gap-3">
            <div className="text-[11px] text-muted-foreground">
              {promotion.current_claims} claimed
              {promotion.max_claims ? ` • ${Math.max(promotion.max_claims - promotion.current_claims, 0)} left` : ""}
            </div>
            <Button
              size="sm"
              className="rounded-full text-xs"
              onClick={(e) => {
                e.stopPropagation();
                handleClick();
              }}
              disabled={isExpired}
            >
              <Sparkles className="h-3 w-3" />
              View Deal
              <ChevronRight className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </div>
    </motion.article>
  );
};

export default DatabasePromotionCard;