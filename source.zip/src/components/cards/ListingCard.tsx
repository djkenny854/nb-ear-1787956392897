import React from 'react';
import { Heart, Eye, MapPin, CheckCircle } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';
import ImageCarousel from './ImageCarousel';
import { useCurrency } from '@/contexts/CurrencyContext';
import type { Listing } from '@/data/mockData';

interface ListingCardProps {
  listing: Listing;
  onClick?: () => void;
}

const ListingCard: React.FC<ListingCardProps> = ({ listing, onClick }) => {
  const { formatPriceCompact } = useCurrency();

  // Get images array - support both single image and array
  const images = listing.images?.length ? listing.images : [listing.image];

  return (
    <motion.div
      whileHover={{ y: -4, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className="group cursor-pointer bg-card/60 backdrop-blur-sm rounded-xl overflow-hidden border border-border/50 hover:border-primary/30 hover:shadow-lg transition-all duration-300 min-w-[180px] max-w-[220px]"
    >
      {/* Image Container with Carousel */}
      <div className="relative aspect-square overflow-hidden">
        {images.length > 1 ? (
          <ImageCarousel
            images={images}
            interval={6000}
            aspectRatio="square"
            showIndicators={true}
            pauseOnHover={true}
          />
        ) : (
          <img
            src={listing.image}
            alt={listing.title}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          />
        )}
        
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {listing.isNew && (
            <Badge className="bg-primary text-primary-foreground text-[10px] px-2 py-0.5">
              NEW
            </Badge>
          )}
          {listing.isHot && (
            <Badge className="bg-orange-500 text-white text-[10px] px-2 py-0.5">
              🔥 HOT
            </Badge>
          )}
          {listing.discount && (
            <Badge className="bg-destructive text-destructive-foreground text-[10px] px-2 py-0.5">
              -{listing.discount}%
            </Badge>
          )}
        </div>

        {/* Wishlist Button */}
        <button className="absolute top-2 right-2 w-8 h-8 rounded-full bg-background/80 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
          <Heart className="w-4 h-4 text-foreground" />
        </button>

        {/* Views */}
        <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-background/80 backdrop-blur-sm rounded-full px-2 py-1">
          <Eye className="w-3 h-3 text-muted-foreground" />
          <span className="text-[10px] text-muted-foreground">{listing.views}</span>
        </div>
      </div>

      {/* Content */}
      <div className="p-3 space-y-2">
        <h3 className="font-semibold text-sm text-foreground line-clamp-2 leading-tight">
          {listing.title}
        </h3>

        {/* Price */}
        <div className="flex items-center gap-2">
          <span className="font-bold text-base text-primary">
            {formatPriceCompact(listing.price)}
          </span>
          {listing.originalPrice && (
            <span className="text-xs text-muted-foreground line-through">
              {formatPriceCompact(listing.originalPrice)}
            </span>
          )}
        </div>

        {/* Location */}
        <div className="flex items-center gap-1 text-muted-foreground">
          <MapPin className="w-3 h-3" />
          <span className="text-xs">{listing.location}</span>
        </div>

        {/* Seller */}
        <div className="flex items-center gap-2 pt-1 border-t border-border/50">
          <img
            src={listing.seller.avatar}
            alt={listing.seller.name}
            className="w-5 h-5 rounded-full object-cover"
          />
          <span className="text-xs text-muted-foreground truncate flex-1">
            {listing.seller.name}
          </span>
          {listing.seller.isVerified && (
            <CheckCircle className="w-3 h-3 text-primary fill-primary" />
          )}
        </div>
      </div>
    </motion.div>
  );
};

export default ListingCard;
