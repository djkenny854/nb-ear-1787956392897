import SmartVideo from '@/components/media/SmartVideo';
import React, { useState, useEffect, useRef } from 'react';
import { Bookmark, MapPin, Play } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { motion, AnimatePresence } from 'framer-motion';
import { formatDistanceToNow } from 'date-fns';
import { useViewTracking } from '@/hooks/useViewTracking';
import { useEngagement } from '@/hooks/useEngagement';
import { useBookmarks } from '@/hooks/useBookmarks';
import { useCurrency } from '@/contexts/CurrencyContext';
import { useGlobalSettings } from '@/contexts/AppSettingsContext';
import { videoCdnUrl, imageCdnUrl } from '@/utils/cdnUrl';
import { toast } from 'sonner';
import { YouTubeIcon, TikTokIcon } from '@/components/icons/SocialIcons';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';
import EmbedVideoModal from '@/components/feed/EmbedVideoModal';
import { onImageError } from '@/utils/fallbackImage';
import { warmImage } from '@/utils/imageDecode';

interface HomeProductCardProps {
  id: string;
  title: string;
  price: number;
  originalPrice?: number | null;
  images: string[];
  videoUrl?: string | null;
  youtubeUrl?: string | null;
  tiktokUrl?: string | null;
  location: string;
  viewCount?: number;
  isBoosted?: boolean;
  isSponsored?: boolean;
  hasDiscount?: boolean;
  createdAt?: string;
  inventoryCount?: number;
  isPriceNegotiable?: boolean;
  warranty?: string | null;
  seller?: {
    business_name?: string | null;
    business_logo_url?: string | null;
    is_verified?: boolean;
    verification_badge_color?: BadgeColor;
    district?: string | null;
    sub_county?: string | null;
  } | null;
  onClick?: () => void;
  isBookmarked?: boolean;
  onBookmarkToggle?: (e: React.MouseEvent) => void;
  sourcePage?: 'feed' | 'search' | 'details' | 'profile';
}

// Assurance texts are now dynamically generated per card

const HomeProductCard: React.FC<HomeProductCardProps> = ({
  id,
  title,
  price,
  originalPrice,
  images,
  videoUrl,
  youtubeUrl,
  tiktokUrl,
  location,
  isBoosted,
  isSponsored,
  hasDiscount,
  createdAt,
  inventoryCount,
  isPriceNegotiable,
  warranty,
  seller,
  onClick,
  isBookmarked: externalIsBookmarked,
  onBookmarkToggle,
  sourcePage = 'feed',
}) => {
  const { trackClick } = useEngagement();
  const { isBookmarked: hookIsBookmarked, toggleBookmark } = useBookmarks();
  const { formatPriceCompact } = useCurrency();
  const { settings } = useGlobalSettings();
  const dataSaver = settings.data_saver;
  const autoplayProductCards = settings.autoplay_product_cards && !dataSaver;
  
  // Use external bookmark state if provided, otherwise use hook
  const isBookmarked = externalIsBookmarked !== undefined ? externalIsBookmarked : hookIsBookmarked(id, 'product');
  
  // View tracking - fires after 4 seconds in viewport (silent readers count too)
  const viewTrackingRef = useViewTracking({
    contentId: id,
    contentType: 'ad',
    sourcePage: sourcePage,
    threshold: 0.5,
    viewDuration: 4000,
  });
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [assuranceIndex, setAssuranceIndex] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [hasEnteredViewport, setHasEnteredViewport] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [readyIndexes, setReadyIndexes] = useState<number[]>([]);
  const [firstImageTimedOut, setFirstImageTimedOut] = useState(false);
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [videoFinished, setVideoFinished] = useState(false);
  const [embedVideoUrl, setEmbedVideoUrl] = useState<string | null>(null);
  const [embedVideoType, setEmbedVideoType] = useState<'youtube' | 'tiktok'>('youtube');
  const cardRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const videoPreviewTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Cap the video preview at 10s, then swap to images
  const startVideoPreviewTimer = () => {
    if (videoPreviewTimerRef.current) return;
    videoPreviewTimerRef.current = setTimeout(() => {
      if (hasActualImages) setVideoFinished(true);
      videoPreviewTimerRef.current = null;
    }, 10_000);
  };
  const clearVideoPreviewTimer = () => {
    if (videoPreviewTimerRef.current) {
      clearTimeout(videoPreviewTimerRef.current);
      videoPreviewTimerRef.current = null;
    }
  };
  useEffect(() => () => clearVideoPreviewTimer(), []);

  // Check if images array contains video URLs
  const isVideoUrl = (url: string) => {
    return url?.match(/\.(mp4|webm|mov|avi)$/i) || url?.includes('.mp4') || url?.includes('.webm');
  };

  // Filter actual images from video URLs in images array, and request a
  // downscaled variant from Supabase's image CDN so cards load fast and the
  // feed downloads far less data.
  const originalActualImages = images?.filter(img => !isVideoUrl(img)) || [];
  const allActualImages = originalActualImages.map(
    (img) => imageCdnUrl(img, { width: 600, quality: 70 }),
  );
  // Data saver: only ever load the first image and never rotate.
  const actualImages = dataSaver ? allActualImages.slice(0, 1) : allActualImages;
  const videoFromImages = images?.find(img => isVideoUrl(img));
  // Rewrite raw Backblaze B2 URLs to the CDN subdomain so they actually load.
  const rawVideoUrl = videoUrl || videoFromImages;
  const effectiveVideoUrl = autoplayProductCards && rawVideoUrl ? videoCdnUrl(rawVideoUrl) : undefined;
  
  // Determine what media to show - prioritize video over images, unless video finished one loop
  const hasActualImages = actualImages.length > 0;
  const hasVideo = !!effectiveVideoUrl;
  
  const mainImage = actualImages?.[currentImageIndex] || actualImages?.[0];
  // Show video if available, setting is on, and hasn't finished its single play
  const showVideo = hasVideo && !videoFinished;

  const discount = originalPrice && price 
    ? Math.round(((originalPrice - price) / originalPrice) * 100) 
    : 0;

  // Get display location - prefer seller's specific location
  const getDisplayLocation = () => {
    if (seller?.sub_county && seller?.district) {
      return `${seller.sub_county}, ${seller.district}`;
    }
    if (seller?.district) {
      return seller.district;
    }
    if (seller?.sub_county) {
      return seller.sub_county;
    }
    // Parse location string to get meaningful part (not just "Uganda")
    if (location && location.toLowerCase() !== 'uganda') {
      const parts = location.split(',');
      return parts[0].trim();
    }
    return location || 'Uganda';
  };

  // Get dynamic assurance based on actual product/seller data
  const getDynamicAssurance = () => {
    const assurances: Array<{ text: string; color: string }> = [];
    
    // Negotiable status
    if (isPriceNegotiable) {
      assurances.push({ text: 'Negotiable', color: 'text-blue-500' });
    }
    
    // Stock status
    if (inventoryCount !== undefined && inventoryCount !== null) {
      if (inventoryCount === 0) {
        assurances.push({ text: 'Out of Stock', color: 'text-red-500' });
      } else if (inventoryCount <= 5) {
        assurances.push({ text: 'Limited stock', color: 'text-amber-500' });
      } else {
        assurances.push({ text: 'In Stock', color: 'text-green-500' });
      }
    }
    
    // Verified seller
    if (seller?.is_verified) {
      assurances.push({ text: 'Verified Seller', color: 'text-primary' });
    }

    // Warranty
    if (warranty) {
      assurances.push({ text: warranty, color: 'text-green-600' });
    }

    // Discount info
    if (discount > 0) {
      assurances.push({ text: `${discount}% off`, color: 'text-red-500' });
    }
    
    // Sponsored status
    if (isSponsored) {
      assurances.push({ text: 'Sponsored', color: 'text-amber-500' });
    }

    // Fallback if nothing available
    if (assurances.length === 0) {
      assurances.push({ text: 'Available', color: 'text-muted-foreground' });
    }
    
    return assurances;
  };

  const dynamicAssurances = getDynamicAssurance();

  // Intersection Observer for visibility & video autoplay
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        setIsVisible(entry.isIntersecting);
        if (entry.isIntersecting) setHasEnteredViewport(true);
        // Control video autoplay based on visibility
        if (videoRef.current && showVideo) {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
            videoRef.current.play().catch(() => {});
          } else {
            videoRef.current.pause();
          }
        }
      },
      // ~2 rows of cards ahead of the viewport start warming their first
      // image, so by the time the user scrolls there the photo is decoded.
      { threshold: [0.3, 0.5], rootMargin: '900px 0px' }
    );

    if (cardRef.current) {
      observer.observe(cardRef.current);
    }

    return () => observer.disconnect();
  }, [showVideo]);

  // Preload media before enabling rotation. The first image is fetched first
  // (fast) so it can paint immediately; the remaining images are decoded in
  // the background afterwards. Each image marks *its own* index ready, and
  // rotation only ever cycles through indexes that are fully decoded — so a
  // card can never flip to a blank frame.
  const imagesKey = actualImages.join('|');
  useEffect(() => {
    setReadyIndexes([]);
    setFirstImageTimedOut(false);
    setCurrentImageIndex(0);
  }, [imagesKey]);

  // PHASE 1 — the card is visible: fetch + off-thread-decode ONLY the first
  // image. Nothing else on this card touches the network yet, so the visible
  // row of cards owns the whole connection budget.
  useEffect(() => {
    if (!isVisible || !hasActualImages) return;
    if (readyIndexes.includes(0)) return;
    let cancelled = false;

    warmImage(actualImages[0]).then((ok) => {
      if (cancelled || !ok) return;
      setReadyIndexes((prev) => (prev.includes(0) ? prev : [0, ...prev]));
    });

    // Failsafe so a stuck request can never freeze the card on its placeholder.
    const failsafe = setTimeout(() => {
      if (!cancelled) setFirstImageTimedOut(true);
    }, 8000);

    return () => {
      cancelled = true;
      clearTimeout(failsafe);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isVisible, hasActualImages, imagesKey, readyIndexes.includes(0)]);

  // PHASE 2 — the first image is painted and the card is still on screen:
  // walk the remaining images one at a time in the background. Each one only
  // joins the rotation set after its bitmap is fully decoded, so the card can
  // never flip to a frame that has not arrived yet.
  useEffect(() => {
    if (dataSaver) return;
    if (!readyIndexes.includes(0)) return;
    if (!isVisible) return;
    if (actualImages.length <= 1) return;
    let cancelled = false;

    (async () => {
      for (let i = 1; i < actualImages.length; i++) {
        if (cancelled) return;
        // eslint-disable-next-line no-await-in-loop
        const ok = await warmImage(actualImages[i]);
        if (cancelled || !ok) continue;
        setReadyIndexes((prev) =>
          prev.includes(i) ? prev : [...prev, i].sort((a, b) => a - b),
        );
      }
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [readyIndexes.includes(0), isVisible, imagesKey, dataSaver]);

  const firstImageLoaded = readyIndexes.includes(0) || firstImageTimedOut;
  // Only indexes whose bitmaps are decoded may be shown by the rotation.
  const rotatableIndexes = readyIndexes.length ? readyIndexes : [0];
  const rotatableKey = rotatableIndexes.join('|');

  // Auto-rotate only through images that are fully decoded, and only while
  // the card is actually in the viewport.
  useEffect(() => {
    if (!isVisible || rotatableIndexes.length <= 1) return;

    // Stagger start so not every card flips at the same moment.
    const staggerOffset = id ? parseInt(id.replace(/-/g, '').slice(0, 4), 16) % 2000 : 0;

    let interval: ReturnType<typeof setInterval> | null = null;
    const timeout = setTimeout(() => {
      interval = setInterval(() => {
        setCurrentImageIndex((prev) => {
          const pos = rotatableIndexes.indexOf(prev);
          return rotatableIndexes[(pos + 1) % rotatableIndexes.length];
        });
      }, 7000);
    }, staggerOffset);

    return () => {
      clearTimeout(timeout);
      if (interval) clearInterval(interval);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isVisible, rotatableKey, id]);


  // Rotate assurance text
  useEffect(() => {
    const interval = setInterval(() => {
      setAssuranceIndex((prev) => (prev + 1) % dynamicAssurances.length);
    }, 3000);

    return () => clearInterval(interval);
  }, [dynamicAssurances.length]);

  const handleBookmark = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onBookmarkToggle) {
      onBookmarkToggle(e);
    } else {
      // Use internal bookmark functionality
      await toggleBookmark(id, 'product');
    }
  };

  const postTime = createdAt 
    ? formatDistanceToNow(new Date(createdAt), { addSuffix: true })
    : null;

  const handleCardClick = () => {
    trackClick(id, 'ad', 'item', sourcePage);
    onClick?.();
  };

  return (
    <motion.div
      ref={(el) => {
        // Combine refs
        (cardRef as React.MutableRefObject<HTMLDivElement | null>).current = el;
        (viewTrackingRef as React.MutableRefObject<HTMLDivElement | null>).current = el;
      }}
      whileHover={{ y: -4, scale: 1.02 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.2 }}
      onClick={handleCardClick}
      className="group cursor-pointer bg-transparent rounded-xl overflow-hidden min-w-[160px] max-w-[200px] flex-shrink-0"
    >
      {/* Media Container */}
      <div className="relative aspect-square overflow-hidden rounded-xl bg-muted">
        {/* Poster image behind video for instant visual */}
        {showVideo && mainImage && !videoLoaded && (
          <img 
            src={mainImage} 
            alt="" 
            className="absolute inset-0 w-full h-full object-cover z-[1]" 
          />
        )}

        {/* No spinner: the poster/blur stays until the video can play. */}

        {/* BlurHash-style placeholder: a ~24px CDN variant of the same image,
            under 1KB, blurred and upscaled. It paints almost instantly and the
            full-resolution image cross-fades over it once decoded. */}
        {!showVideo && hasActualImages && !firstImageLoaded && (
          <img
            src={imageCdnUrl(originalActualImages[0], { width: 24, quality: 20 })}
            alt=""
            aria-hidden
            draggable={false}
            decoding="async"
            className="absolute inset-0 w-full h-full object-cover scale-110 blur-xl z-[1]"
          />
        )}

        {showVideo ? (
          <SmartVideo
            ref={videoRef}
            src={hasEnteredViewport ? effectiveVideoUrl! : undefined}
            className={`w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 select-none ${!videoLoaded ? 'opacity-0' : 'opacity-100'}`}
            style={{ WebkitUserSelect: 'none', userSelect: 'none' }}
            muted
            playsInline
            poster={mainImage}
            controlsList="nodownload nofullscreen noremoteplayback noplaybackrate"
            disablePictureInPicture
            onContextMenu={(e) => e.preventDefault()}
            onLoadedData={() => setVideoLoaded(true)}
            onReady={() => setVideoLoaded(true)}
            onPlaying={startVideoPreviewTimer}
            onPause={clearVideoPreviewTimer}
            onEnded={() => {
              // Video ended naturally before the 10s cap — swap to images
              clearVideoPreviewTimer();
              if (hasActualImages) {
                setVideoFinished(true);
              }
            }}
          />
        ) : hasActualImages ? (
          firstImageLoaded ? (
          <AnimatePresence initial={false} mode="sync">
            <motion.img
              key={currentImageIndex}
              src={mainImage}
              alt={title}
              loading="lazy"
              decoding="async"
              /* Visible card -> high priority; off-screen cards stay in the
                 browser's low-priority queue so the viewport wins bandwidth. */
              fetchPriority={isVisible ? 'high' : 'low'}
              initial={{ x: '100%' }}
              animate={{ x: '0%' }}
              exit={{ x: '-100%' }}
              transition={{ duration: 0.5, ease: [0.32, 0.72, 0, 1] }}
              className="absolute inset-0 w-full h-full object-cover will-change-transform"
              onLoad={() => setImageLoaded(true)}
              onContextMenu={(e) => e.preventDefault()}
              draggable={false}
              style={{ backfaceVisibility: 'hidden' }}
              onError={(event) => {
                const original = originalActualImages[currentImageIndex] || originalActualImages[0];
                if (original && event.currentTarget.src !== original && event.currentTarget.dataset.originalRetried !== '1') {
                  event.currentTarget.dataset.originalRetried = '1';
                  event.currentTarget.src = original;
                  return;
                }
                onImageError(event);
              }}
            />
          </AnimatePresence>
          ) : null
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <span className="text-xs text-muted-foreground">Media not available</span>
          </div>
        )}

        
        {/* Badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {isBoosted && (
            <Badge className="bg-amber-500/90 backdrop-blur-sm text-white text-[10px] px-1.5 py-0.5 border-0">
              ⚡ Boosted
            </Badge>
          )}
          {hasDiscount && discount > 0 && (
            <Badge className="bg-destructive/90 backdrop-blur-sm text-destructive-foreground text-[10px] px-1.5 py-0.5 border-0">
              -{discount}%
            </Badge>
          )}
        </div>

        {/* Image Indicators — only for images that are actually rotatable */}
        {rotatableIndexes.length > 1 && (
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1">
            {rotatableIndexes.slice(0, 4).map((idx) => (
              <div
                key={idx}
                className={`w-1.5 h-1.5 rounded-full transition-colors ${
                  idx === currentImageIndex ? 'bg-white' : 'bg-white/50'
                }`}
              />
            ))}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="pt-2.5 space-y-1">
        {/* Post Time & Location */}
        <div className="flex items-center justify-between text-[10px] text-muted-foreground">
          {postTime && <span>{postTime}</span>}
          <div className="flex items-center gap-0.5">
            <MapPin className="w-2.5 h-2.5" />
            <span className="truncate max-w-[80px]">{getDisplayLocation()}</span>
          </div>
        </div>

        <h3 className="font-medium text-sm text-foreground line-clamp-2 leading-tight">
          {title}
        </h3>

        {/* Price with Bookmark - Hide price when 0 (e.g. promotions) */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            {price > 0 ? (
              <>
                <span className="font-bold text-sm text-primary">
                  {formatPriceCompact(price)}
                </span>
                {originalPrice && originalPrice > price && (
                  <span className="text-[10px] text-muted-foreground line-through">
                    {formatPriceCompact(originalPrice)}
                  </span>
                )}
              </>
            ) : (
              <span className="text-xs text-muted-foreground italic">No price</span>
            )}
          </div>
          <div className="flex items-center gap-1">
            {/* Social media icons */}
            {youtubeUrl && (
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setEmbedVideoUrl(youtubeUrl);
                  setEmbedVideoType('youtube');
                }}
                className="p-1 rounded-full hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors"
              >
                <YouTubeIcon className="w-3.5 h-3.5 text-red-600" />
              </button>
            )}
            {tiktokUrl && (
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setEmbedVideoUrl(tiktokUrl);
                  setEmbedVideoType('tiktok');
                }}
                className="p-1 rounded-full hover:bg-muted transition-colors"
              >
                <TikTokIcon className="w-3.5 h-3.5 text-foreground" />
              </button>
            )}
            <button
              type="button"
              onClick={handleBookmark}
              onPointerDown={(e) => e.stopPropagation()}
              aria-label="Bookmark"
              className="relative z-30 inline-flex items-center justify-center min-h-[44px] min-w-[44px] sm:h-8 sm:w-8 sm:min-h-0 sm:min-w-0 rounded-full hover:bg-muted transition-colors touch-manipulation"
            >
              <Bookmark className={`w-4 h-4 pointer-events-none ${isBookmarked ? 'fill-primary text-primary' : 'text-muted-foreground hover:text-foreground'}`} />
            </button>
          </div>
        </div>

        {/* Animated Assurance Text */}
        <div className="h-4 overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div
              key={assuranceIndex}
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -10, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className={`text-[10px] font-medium ${dynamicAssurances[assuranceIndex]?.color || 'text-muted-foreground'}`}
            >
              {dynamicAssurances[assuranceIndex]?.text}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Seller */}
        {seller && (
          <div className="flex items-center gap-1.5 pt-1">
            <img
              src={seller.business_logo_url || '/placeholder.svg'}
              alt={seller.business_name || 'Seller'}
              className="w-4 h-4 rounded-full object-cover flex-shrink-0"
            />
            <span className="text-[10px] text-muted-foreground truncate">
              {seller.business_name || 'Seller'}
            </span>
            <UnifiedVerifiedBadge 
              isVerified={seller.is_verified} 
              badgeColor={seller.verification_badge_color}
              size="sm" 
            />
          </div>
        )}
      </div>
      {/* Embed Video Modal */}
      {embedVideoUrl && (
        <EmbedVideoModal
          open={!!embedVideoUrl}
          onOpenChange={(open) => { if (!open) setEmbedVideoUrl(null); }}
          url={embedVideoUrl}
          type={embedVideoType}
        />
      )}
    </motion.div>
  );
};

// Memoized: feed lists re-render often while scrolling, and card props are
// stable per item, so this avoids re-rendering every card on every scroll tick.
export default React.memo(HomeProductCard);
