import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';

export const SearchServiceCardSkeleton: React.FC = () => (
  <div className="col-span-2 bg-gradient-to-br from-emerald-500/5 via-card to-teal-500/5 rounded-2xl overflow-hidden border border-border/50">
    <div className="flex flex-col md:flex-row">
      <div className="w-full md:w-1/3 aspect-video md:aspect-auto">
        <Skeleton className="w-full h-full min-h-[150px] rounded-none animate-pulse" />
      </div>
      <div className="flex-1 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <Skeleton className="h-5 w-20 rounded-full animate-pulse" />
          <Skeleton className="h-6 w-24 animate-pulse" />
        </div>
        <Skeleton className="h-6 w-3/4 animate-pulse" />
        <Skeleton className="h-4 w-full animate-pulse" />
        <Skeleton className="h-4 w-2/3 animate-pulse" />
        <div className="flex items-center gap-3">
          <Skeleton className="w-8 h-8 rounded-full animate-pulse" />
          <div className="space-y-1">
            <Skeleton className="h-4 w-24 animate-pulse" />
            <Skeleton className="h-3 w-16 animate-pulse" />
          </div>
        </div>
        <div className="flex items-center gap-2 mt-4">
          <Skeleton className="h-9 flex-1 rounded-full animate-pulse" />
          <Skeleton className="h-9 flex-1 rounded-full animate-pulse" />
        </div>
      </div>
    </div>
  </div>
);

export const SearchEventCardSkeleton: React.FC = () => (
  <div className="col-span-2 bg-gradient-to-br from-violet-500/5 via-card to-purple-500/5 rounded-2xl overflow-hidden border border-border/50">
    <div className="flex flex-col md:flex-row">
      <div className="w-full md:w-2/5 aspect-video md:aspect-auto">
        <Skeleton className="w-full h-full min-h-[150px] rounded-none animate-pulse" />
      </div>
      <div className="flex-1 p-4 space-y-3">
        <div className="flex items-center gap-2">
          <Skeleton className="h-4 w-4 animate-pulse" />
          <Skeleton className="h-4 w-32 animate-pulse" />
        </div>
        <Skeleton className="h-6 w-3/4 animate-pulse" />
        <Skeleton className="h-4 w-full animate-pulse" />
        <Skeleton className="h-4 w-1/2 animate-pulse" />
        <div className="flex items-center gap-2">
          <Skeleton className="h-4 w-4 animate-pulse" />
          <Skeleton className="h-4 w-40 animate-pulse" />
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Skeleton className="w-6 h-6 rounded-full animate-pulse" />
            <Skeleton className="h-3 w-20 animate-pulse" />
          </div>
          <Skeleton className="h-3 w-16 animate-pulse" />
        </div>
        <div className="flex items-center gap-2 mt-4">
          <Skeleton className="h-9 flex-1 rounded-full animate-pulse" />
          <Skeleton className="h-9 flex-1 rounded-full animate-pulse" />
        </div>
      </div>
    </div>
  </div>
);

// Matches the new compact SearchPromotionCard layout
export const SearchPromotionCardSkeleton: React.FC = () => (
  <div className="col-span-2 py-3 px-1 border-b border-border/50">
    {/* Title */}
    <Skeleton className="h-5 w-3/4 mb-2 animate-pulse" />

    {/* Avatars + metadata */}
    <div className="flex items-center gap-3">
      <div className="flex -space-x-2 shrink-0">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="w-7 h-7 rounded-full animate-pulse" />
        ))}
      </div>
      <div className="flex items-center gap-1.5">
        <Skeleton className="h-3 w-14 animate-pulse" />
        <Skeleton className="h-3 w-16 animate-pulse" />
        <Skeleton className="h-3 w-20 animate-pulse" />
      </div>
    </div>

    {/* Bottom row */}
    <div className="flex items-center justify-between mt-2">
      <div className="flex items-center gap-1.5">
        <Skeleton className="h-3 w-20 animate-pulse" />
        <Skeleton className="h-3 w-16 animate-pulse" />
      </div>
      <div className="flex items-center gap-1">
        <Skeleton className="w-7 h-7 rounded-full animate-pulse" />
        <Skeleton className="w-7 h-7 rounded-full animate-pulse" />
      </div>
    </div>
  </div>
);

interface MixedCardSkeletonsProps {
  count?: number;
}

export const MixedCardSkeletons: React.FC<MixedCardSkeletonsProps> = ({ count = 3 }) => {
  const skeletons = [SearchServiceCardSkeleton, SearchEventCardSkeleton, SearchPromotionCardSkeleton];
  
  return (
    <>
      {Array.from({ length: count }).map((_, index) => {
        const SkeletonComponent = skeletons[index % skeletons.length];
        return <SkeletonComponent key={index} />;
      })}
    </>
  );
};

export default MixedCardSkeletons;
