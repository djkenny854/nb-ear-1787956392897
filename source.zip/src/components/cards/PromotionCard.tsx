import React from 'react';
import { Tag, Zap, Gift, Percent, BadgeCheck } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { PromotionTimer } from '@/components/promotion/PromotionTimer';

interface PromotionCardProduct {
  id: string;
  title: string;
  image: string;
}

interface PromotionCardProps {
  id: string;
  title: string;
  type?: string;
  discountPercent?: number;
  validUntil?: string | null;
  startAt?: string | null;
  businessName?: string;
  businessLogo?: string;
  isVerified?: boolean;
  products?: PromotionCardProduct[];
  productCount?: number;
  onClick?: () => void;
  className?: string;
}

const isExpiredFn = (validUntil?: string | null): boolean => {
  if (!validUntil) return false;
  const t = new Date(validUntil).getTime();
  return !isNaN(t) && t <= Date.now();
};

const getTypeIcon = (type?: string) => {
  switch (type) {
    case 'flash_sale':
    case 'flash-sale':
      return <Zap className="w-3 h-3" />;
    case 'bundle':
      return <Gift className="w-3 h-3" />;
    case 'coupon':
      return <Tag className="w-3 h-3" />;
    default:
      return <Percent className="w-3 h-3" />;
  }
};

const getTypeLabel = (type?: string): string => {
  switch (type) {
    case 'flash_sale':
    case 'flash-sale':
      return 'Flash Sale';
    case 'bundle':
      return 'Bundle';
    case 'coupon':
      return 'Coupon';
    case 'happy_hour':
      return 'Happy Hour';
    case 'standard':
    case 'discount':
    default:
      return 'Discount';
  }
};

const PromotionCard: React.FC<PromotionCardProps> = ({
  id,
  title,
  type,
  discountPercent,
  validUntil,
  startAt,
  businessName,
  businessLogo,
  isVerified,
  products = [],
  productCount = 0,
  onClick,
  className,
}) => {
  const isExpired = isExpiredFn(validUntil);
  const displayProducts = products.slice(0, 8);
  const totalProducts = productCount || products.length;

  if (isExpired) return null;

  return (
    <div
      onClick={onClick}
      className={cn(
        "cursor-pointer py-3 px-1 border-b border-border/50 last:border-b-0 transition-colors hover:bg-muted/30",
        className
      )}
    >
      {/* Title */}
      <h3 className="font-bold text-base text-foreground leading-snug line-clamp-2 mb-2">
        {title}
      </h3>

      {/* Avatars row (fills) + Timer on the right */}
      <div className="flex items-center gap-2 mb-2">
        <div className="flex items-center -space-x-2 min-w-0 flex-1 overflow-hidden">
          {displayProducts.length > 0 ? (
            displayProducts.map((product, i) => (
              <div
                key={product.id || i}
                className="w-8 h-8 rounded-full border-2 border-background overflow-hidden bg-muted shrink-0"
                style={{ zIndex: displayProducts.length - i }}
              >
                <img src={product.image} alt={product.title} className="w-full h-full object-cover" loading="lazy" />
              </div>
            ))
          ) : businessLogo ? (
            <div className="w-8 h-8 rounded-full border-2 border-background overflow-hidden bg-muted shrink-0">
              <img src={businessLogo} alt={businessName || ''} className="w-full h-full object-cover" loading="lazy" />
            </div>
          ) : (
            <div className="w-8 h-8 rounded-full border-2 border-background bg-primary/10 flex items-center justify-center shrink-0">
              {getTypeIcon(type)}
            </div>
          )}
          {totalProducts > displayProducts.length && (
            <div className="w-8 h-8 rounded-full border-2 border-background bg-muted flex items-center justify-center text-[10px] font-semibold text-muted-foreground shrink-0">
              +{totalProducts - displayProducts.length}
            </div>
          )}
        </div>
        <div className="shrink-0">
          <PromotionTimer validUntil={validUntil} startAt={startAt} size="sm" />
        </div>
      </div>

      {/* Metadata line */}
      <div className="flex items-center gap-3">
        {/* Overlapping product avatars */}
        <div className="flex items-center gap-1 text-xs text-muted-foreground min-w-0 flex-wrap">
          {/* Business name */}
          {businessName && (
            <span className="flex items-center gap-0.5 shrink-0">
              <span className="truncate max-w-[100px]">{businessName}</span>
              {isVerified && <BadgeCheck className="w-3 h-3 text-primary shrink-0" />}
              <span>·</span>
            </span>
          )}

          {/* Category tag */}
          <span className="flex items-center gap-0.5 shrink-0">
            {getTypeIcon(type)}
            <span>{getTypeLabel(type)}</span>
          </span>

          {/* Product count */}
          {totalProducts > 0 && (
            <>
              <span>·</span>
              <span className="shrink-0">
              {totalProducts} {totalProducts === 1 ? 'product' : 'products'}
              </span>
            </>
          )}

          {/* Discount badge */}
          {discountPercent && discountPercent > 0 && (
            <>
              <span>·</span>
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4 font-semibold">
                {discountPercent}% OFF
              </Badge>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default PromotionCard;
