import React, { useEffect, useState } from "react";
import {
  Bookmark,
  Share2,
  BadgeCheck,
  Tag,
  Zap,
  Percent,
  ChevronRight,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { useBookmarks } from "@/hooks/useBookmarks";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { PromotionTimer } from "@/components/promotion/PromotionTimer";
import { useGlobalSettings } from "@/contexts/AppSettingsContext";

export interface SearchPromotion {
  id: string;
  title: string;
  description: string;
  images: string[];
  discountPercent: number;
  originalPrice?: number;
  discountedPrice?: number;
  promoCode?: string;
  type: "discount" | "flash-sale" | "bundle" | "coupon";
  validUntil: string;
  claimsCount: number;
  maxClaims?: number;
  brand: {
    name: string;
    logo: string;
    isVerified?: boolean;
  };
  termsConditions?: string;
  productAvatars?: { image: string; name: string }[];
  promotionSubType?: string;
}

interface SearchPromotionCardProps {
  promotion: SearchPromotion;
  onClick?: () => void;
}

const SearchPromotionCard: React.FC<SearchPromotionCardProps> = ({ promotion, onClick }) => {
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const bookmarked = isBookmarked(promotion.id, 'promotion');
  const isExpired = !!promotion.validUntil && new Date(promotion.validUntil).getTime() <= Date.now();
  const { settings } = useGlobalSettings();
  const dataSaver = settings.data_saver;
  const [imgIdx, setImgIdx] = useState(0);

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleBookmark(promotion.id, 'promotion');
  };

  const handleShare = (e: React.MouseEvent) => {
    e.stopPropagation();
    const url = `${window.location.origin}/promotion/${promotion.id}`;
    if (navigator.share) {
      navigator.share({ title: promotion.title, url }).catch(() => {});
    } else {
      navigator.clipboard.writeText(url);
      toast.success('Link copied');
    }
  };

  const allProducts = promotion.productAvatars || [];
  const MAX_AVATARS = 8;
  const displayProducts = allProducts.slice(0, MAX_AVATARS);
  const extraCount = allProducts.length - MAX_AVATARS;

  if (isExpired) return null;

  const typeLabel = promotion.promotionSubType === 'flash_sale' ? 'Flash Sale' :
    promotion.promotionSubType === 'happy_hour' ? 'Happy Hour' :
    promotion.promotionSubType === 'seller_wide' ? 'Store-wide' :
    promotion.type === 'flash-sale' ? 'Flash Sale' :
    promotion.type === 'bundle' ? 'Bundle' :
    promotion.type === 'coupon' ? 'Coupon' : 'Discount';

  const typeBadgeColor = promotion.type === 'flash-sale' || promotion.promotionSubType === 'flash_sale'
    ? 'bg-destructive/10 text-destructive border-destructive/20'
    : promotion.type === 'bundle'
    ? 'bg-blue-500/10 text-blue-600 border-blue-500/20 dark:text-blue-400'
    : 'bg-primary/10 text-primary border-primary/20';

  // Media rotates through product avatars (or hero images), unless data-saver.
  const mediaImages = (allProducts.map((p) => p.image).filter(Boolean).length > 0
    ? allProducts.map((p) => p.image).filter(Boolean)
    : (promotion.images || []).filter((x) => !!x && x !== '/placeholder.svg'));

  useEffect(() => {
    if (dataSaver || mediaImages.length <= 1) return;
    const t = setInterval(() => {
      setImgIdx((i) => (i + 1) % mediaImages.length);
    }, 4500);
    return () => clearInterval(t);
  }, [dataSaver, mediaImages.length]);

  const mediaSrc = mediaImages[imgIdx] || mediaImages[0];

  return (
    <motion.article
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className="group cursor-pointer w-full bg-card rounded-2xl overflow-hidden border border-transparent hover:border-primary/30 hover:shadow-xl transition-all will-change-transform"
      style={{ transform: 'translateZ(0)' }}
      aria-label={`Promotion: ${promotion.title}`}
    >
      <div className="flex flex-col sm:flex-row min-h-[180px]">
        {/* Media */}
        <div className="relative w-full sm:w-[280px] md:w-[320px] h-[180px] sm:h-auto sm:max-h-[240px] flex-shrink-0 overflow-hidden bg-muted">
          {mediaSrc ? (
            <AnimatePresence mode="wait">
              <motion.img
                key={mediaSrc}
                src={mediaSrc}
                alt={promotion.title}
                className="h-full w-full object-cover"
                loading="lazy"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.35 }}
              />
            </AnimatePresence>
          ) : (
            <div className="h-full w-full flex items-center justify-center">
              <Tag className="w-12 h-12 text-muted-foreground/30" />
            </div>
          )}

          {/* Gradient overlay */}
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t sm:bg-gradient-to-r from-card/60 via-transparent to-transparent" />

          {/* Badges */}
          <div className="absolute left-3 top-3 flex items-center gap-2">
            <Badge variant="outline" className={cn("text-[10px] font-semibold px-2 py-0.5 backdrop-blur-sm", typeBadgeColor)}>
              {promotion.type === 'flash-sale' && <Zap className="w-3 h-3 mr-0.5" />}
              {typeLabel}
            </Badge>
            <Badge className="bg-destructive text-destructive-foreground font-bold text-[10px] px-2 py-0.5">
              <Percent className="w-3 h-3 mr-0.5" />
              {promotion.discountPercent}% OFF
            </Badge>
          </div>

          {/* Bookmark + share */}
          <div className="absolute right-3 top-3 flex items-center gap-1">
            <button
              type="button"
              onClick={handleBookmark}
              className="rounded-full bg-background/80 backdrop-blur-sm p-2 border border-border hover:bg-background transition"
              aria-label={bookmarked ? 'Remove bookmark' : 'Bookmark'}
            >
              <Bookmark className={cn('h-4 w-4', bookmarked && 'fill-primary text-primary')} />
            </button>
            <button
              type="button"
              onClick={handleShare}
              className="rounded-full bg-background/80 backdrop-blur-sm p-2 border border-border hover:bg-background transition"
              aria-label="Share"
            >
              <Share2 className="h-4 w-4" />
            </button>
          </div>

          {/* Image indicators */}
          {mediaImages.length > 1 && !dataSaver && (
            <div className="absolute bottom-3 left-3 flex gap-1">
              {mediaImages.slice(0, 5).map((_, idx) => (
                <div
                  key={idx}
                  className={cn(
                    "w-1.5 h-1.5 rounded-full transition-all",
                    idx === imgIdx ? "bg-white w-3" : "bg-white/50"
                  )}
                />
              ))}
            </div>
          )}
        </div>

        {/* Content */}
        <div className="flex-1 p-4 sm:p-5 flex flex-col gap-3 min-w-0">
          {/* Title + description */}
          <header className="min-w-0">
            <h3 className="font-bold text-lg text-foreground line-clamp-2 group-hover:text-primary transition-colors">
              {promotion.title}
            </h3>
            {promotion.description && (
              <p className="mt-1.5 text-sm text-muted-foreground line-clamp-2">
                {promotion.description}
              </p>
            )}
          </header>

          {/* Owner / brand */}
          <div className="flex items-center gap-3 min-w-0">
            <Avatar className="h-9 w-9 border-2 border-primary/20">
              <AvatarImage src={promotion.brand.logo} alt={promotion.brand.name} />
              <AvatarFallback className="text-sm font-semibold bg-primary/10 text-primary">
                {promotion.brand.name?.charAt(0) || 'B'}
              </AvatarFallback>
            </Avatar>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5 min-w-0">
                <span className="text-sm font-medium text-foreground truncate">{promotion.brand.name}</span>
                {promotion.brand.isVerified && <BadgeCheck className="w-3.5 h-3.5 text-primary shrink-0" />}
              </div>
              {allProducts.length > 0 && (
                <div className="mt-0.5 text-xs text-muted-foreground">
                  {allProducts.length} {allProducts.length === 1 ? 'product' : 'products'} on offer
                </div>
              )}
            </div>
          </div>

          {/* Avatars strip (flex-fills) + Timer on the right */}
          <div className="flex items-center gap-3 min-w-0">
            <div className="flex items-center min-w-0 flex-1 -space-x-2 overflow-hidden">
              {displayProducts.length > 0 ? (
                displayProducts.map((product, i) => (
                  <div
                    key={i}
                    className="w-8 h-8 rounded-full border-2 border-card overflow-hidden bg-muted shrink-0"
                    style={{ zIndex: displayProducts.length - i }}
                    title={product.name}
                  >
                    {product.image ? (
                      <img src={product.image} alt={product.name} className="w-full h-full object-cover" loading="lazy" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[9px] text-muted-foreground font-medium">
                        {product.name?.charAt(0) || <Tag className="w-3 h-3" />}
                      </div>
                    )}
                  </div>
                ))
              ) : null}
              {extraCount > 0 && (
                <div className="w-8 h-8 rounded-full border-2 border-card bg-muted flex items-center justify-center text-[10px] font-semibold text-muted-foreground shrink-0" style={{ zIndex: 0 }}>
                  +{extraCount}
                </div>
              )}
            </div>
            <div className="shrink-0">
              <PromotionTimer validUntil={promotion.validUntil} size="sm" />
            </div>
          </div>

          {/* CTA */}
          <div className="mt-auto pt-3 border-t border-border/40 flex items-center justify-between gap-4">
            <div className="min-w-0">
              {promotion.originalPrice && promotion.discountedPrice ? (
                <>
                  <div className="text-xs text-muted-foreground line-through">
                    UGX {new Intl.NumberFormat().format(promotion.originalPrice)}
                  </div>
                  <div className="font-bold text-xl text-primary">
                    UGX {new Intl.NumberFormat().format(Math.round(promotion.discountedPrice))}
                  </div>
                </>
              ) : (
                <div className="text-sm text-muted-foreground">
                  Save up to <span className="font-semibold text-destructive">{promotion.discountPercent}%</span>
                </div>
              )}
            </div>
            <Button
              size="default"
              className="rounded-full px-5"
              onClick={(e) => e.stopPropagation()}
            >
              View offer
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>
    </motion.article>
  );
};

export default SearchPromotionCard;
