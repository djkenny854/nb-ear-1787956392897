import React from 'react';
import { MapPin, Clock, Building2, Briefcase, DollarSign, Bookmark } from 'lucide-react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { formatDistanceToNow } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import { useBookmarks } from '@/hooks/useBookmarks';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';

interface HomeJobCardProps {
  id: string;
  title: string;
  companyName: string;
  companyLogo?: string | null;
  location: string;
  jobType: string;
  salaryMin?: number | null;
  salaryMax?: number | null;
  salaryCurrency?: string;
  createdAt: string;
  isVerified?: boolean;
  verificationBadgeColor?: BadgeColor;
  onClick?: () => void;
}

const HomeJobCard: React.FC<HomeJobCardProps> = ({
  id,
  title,
  companyName,
  companyLogo,
  location,
  jobType,
  salaryMin,
  salaryMax,
  salaryCurrency = 'UGX',
  createdAt,
  isVerified,
  verificationBadgeColor,
  onClick,
}) => {
  const navigate = useNavigate();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const bookmarked = isBookmarked(id, 'job');

  const formatSalary = () => {
    if (!salaryMin && !salaryMax) return 'Competitive';
    if (salaryMin && salaryMax) {
      const formatNum = (n: number) => {
        if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
        if (n >= 1000) return `${(n / 1000).toFixed(0)}K`;
        return n.toString();
      };
      return `${salaryCurrency} ${formatNum(salaryMin)} - ${formatNum(salaryMax)}`;
    }
    return salaryMin ? `${salaryCurrency} ${salaryMin.toLocaleString()}+` : `Up to ${salaryCurrency} ${salaryMax?.toLocaleString()}`;
  };

  const timeAgo = formatDistanceToNow(new Date(createdAt), { addSuffix: true });

  const getJobTypeBadgeColor = (type: string) => {
    switch (type.toLowerCase()) {
      case 'full-time': return 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border-emerald-500/30';
      case 'part-time': return 'bg-blue-500/15 text-blue-600 dark:text-blue-400 border-blue-500/30';
      case 'contract': return 'bg-orange-500/15 text-orange-600 dark:text-orange-400 border-orange-500/30';
      case 'internship': return 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border-purple-500/30';
      default: return 'bg-secondary text-secondary-foreground';
    }
  };

  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleBookmark(id, 'job');
  };

  const handleApply = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/apply/${id}`);
  };

  return (
    <motion.div
      whileHover={{ y: -2, scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className="group cursor-pointer bg-gradient-to-r from-primary/5 via-card to-primary/5 backdrop-blur-sm rounded-xl p-4 hover:shadow-lg transition-all duration-300 border border-border/50 hover:border-primary/30 min-w-[280px] max-w-[320px] flex-shrink-0"
    >
      <div className="flex items-start gap-3">
        {/* Company Logo */}
        <div className="w-12 h-12 rounded-lg bg-card flex items-center justify-center overflow-hidden flex-shrink-0 border border-border/50">
          {companyLogo ? (
            <img
              src={companyLogo}
              alt={companyName}
              className="w-full h-full object-cover"
            />
          ) : (
            <Building2 className="w-6 h-6 text-muted-foreground" />
          )}
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div className="flex-1 min-w-0">
              <h3 className="font-semibold text-sm text-foreground line-clamp-1 group-hover:text-primary transition-colors">
                {title}
              </h3>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span className="text-xs text-muted-foreground truncate">{companyName}</span>
                <UnifiedVerifiedBadge 
                  isVerified={isVerified} 
                  badgeColor={verificationBadgeColor}
                  size="xs" 
                />
              </div>
            </div>
            <Badge className={`text-[10px] px-2 py-0.5 border ${getJobTypeBadgeColor(jobType)}`}>
              {jobType}
            </Badge>
          </div>

          {/* Job Details */}
          <div className="flex flex-wrap items-center gap-2 mt-2 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <MapPin className="w-3 h-3" />
              <span className="truncate">{location}</span>
            </div>
            <div className="flex items-center gap-1">
              <DollarSign className="w-3 h-3" />
              <span>{formatSalary()}</span>
            </div>
          </div>

          {/* Time Posted */}
          <div className="flex items-center gap-1 mt-2 text-[10px] text-muted-foreground/70">
            <Clock className="w-3 h-3" />
            <span>{timeAgo}</span>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="mt-3 flex justify-end items-center gap-2">
        <Button
          variant="ghost"
          size="sm"
          className="h-8 px-2 rounded-full hover:bg-muted"
          onClick={handleBookmark}
        >
          <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-primary text-primary' : ''}`} />
        </Button>
        <Button 
          size="sm"
          className="px-4 py-1.5 text-xs font-medium rounded-full bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground transition-colors"
          onClick={handleApply}
        >
          <Briefcase className="w-3 h-3 inline mr-1" />
          Apply
        </Button>
      </div>
    </motion.div>
  );
};

export default HomeJobCard;
