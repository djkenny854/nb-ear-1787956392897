import React from 'react';
import { MapPin, Clock, Bookmark, Briefcase, Building2, DollarSign } from 'lucide-react';
import { motion } from 'framer-motion';
import type { Job } from '@/data/mockData';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { useBookmarks } from '@/hooks/useBookmarks';

interface JobCardProps {
  job: Job;
  onClick?: () => void;
}

const JobCard: React.FC<JobCardProps> = ({ job, onClick }) => {
  const navigate = useNavigate();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const bookmarked = isBookmarked(job.id, 'job');
  
  const handleBookmark = (e: React.MouseEvent) => {
    e.stopPropagation();
    toggleBookmark(job.id, 'job');
  };

  const handleApply = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/apply/${job.id}`);
  };

  return (
    <motion.div
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className="group cursor-pointer bg-gradient-to-r from-primary/5 via-card/40 to-primary/10 backdrop-blur-md rounded-2xl p-5 hover:shadow-xl transition-all duration-300 w-full border border-primary/20 hover:border-primary/40"
    >
      <div className="flex items-stretch gap-4">
        {/* Company Logo */}
        <div className="w-20 h-20 rounded-xl bg-card flex items-center justify-center overflow-hidden flex-shrink-0 shadow-md border border-border/50">
          <img
            src={job.companyLogo}
            alt={job.company}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content */}
        <div className="flex-1 min-w-0 flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-base text-foreground line-clamp-1 group-hover:text-primary transition-colors">
                  {job.title}
                </h3>
                <div className="flex items-center gap-2 mt-1">
                  <Building2 className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-sm text-muted-foreground truncate">{job.company}</span>
                </div>
              </div>
              <Badge variant="secondary" className="text-[10px] px-2 py-0.5 flex-shrink-0">
                {job.type}
              </Badge>
            </div>

            {/* Job Details */}
            <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
              <div className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5" />
                <span>{job.location}</span>
              </div>
              <div className="flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5" />
                <span>{job.salary}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                <span>{job.postedAt}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-2 mt-3">
            <Button
              variant="ghost"
              size="sm"
              className="h-8 px-3 rounded-full hover:bg-muted"
              onClick={handleBookmark}
            >
              <Bookmark className={`w-4 h-4 ${bookmarked ? 'fill-primary text-primary' : ''}`} />
            </Button>
            <Button
              size="sm"
              className="h-8 px-5 rounded-full bg-primary hover:bg-primary/90 text-primary-foreground"
              onClick={handleApply}
            >
              <Briefcase className="w-4 h-4 mr-1" />
              Apply Now
            </Button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default JobCard;
