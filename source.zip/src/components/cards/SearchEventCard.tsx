import React, { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  Bookmark,
  CalendarDays,
  MapPin,
  Ticket,
  Users,
  ChevronRight,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export interface SearchEvent {
  id: string;
  title: string;
  description: string;
  images: string[];
  eventDate: string;
  endDate?: string;
  location: string;
  venue: string;
  isFree: boolean;
  ticketPrice?: number;
  currency?: string;
  category: string;
  currentAttendees: number;
  maxAttendees?: number;
  organizer: {
    name: string;
    logo: string;
  };
}

interface SearchEventCardProps {
  event: SearchEvent;
  onClick?: () => void;
}

const SearchEventCard: React.FC<SearchEventCardProps> = ({ event, onClick }) => {
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  useEffect(() => {
    if (event.images.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % event.images.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [event.images.length]);

  const when = new Date(event.eventDate);
  const dateLabel = when.toLocaleDateString("en-UG", {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
  const timeLabel = when.toLocaleTimeString("en-UG", {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <motion.article
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.99 }}
      transition={{ duration: 0.2 }}
      onClick={onClick}
      className="group cursor-pointer col-span-2 bg-card rounded-2xl overflow-hidden border border-border hover:shadow-lg transition-all"
      aria-label={`Event: ${event.title}`}
    >
      <div className="flex min-h-[140px]">
        {/* Media */}
        <div className="relative w-[42%] min-w-[160px] max-w-[260px] overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.img
              key={currentImageIndex}
              src={event.images[currentImageIndex] || "/placeholder.svg"}
              alt={event.title}
              className="h-full w-full object-cover"
              loading="lazy"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.35 }}
            />
          </AnimatePresence>

          {/* Fade to right */}
          <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-card to-transparent" />

          {/* Type */}
          <div className="absolute left-3 top-3">
            <Badge className="bg-primary text-primary-foreground">Event</Badge>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              setIsBookmarked((v) => !v);
            }}
            className="absolute right-3 top-3 rounded-full bg-background/70 backdrop-blur px-2.5 py-2 border border-border hover:bg-background transition"
            aria-label={isBookmarked ? "Remove bookmark" : "Bookmark"}
          >
            <Bookmark className={cn("h-4 w-4", isBookmarked && "fill-primary text-primary")} />
          </button>

          {/* Attendance */}
          <div className="absolute left-3 bottom-3 inline-flex items-center gap-1 rounded-full bg-background/70 backdrop-blur border border-border px-2.5 py-1 text-[11px] text-foreground">
            <Users className="h-3 w-3" />
            {event.currentAttendees}
            {event.maxAttendees ? `/${event.maxAttendees}` : ""}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 p-4 flex flex-col gap-3">
          <header className="min-w-0">
            <p className="text-xs text-muted-foreground line-clamp-1">{event.category}</p>
            <h3 className="font-semibold text-sm text-foreground line-clamp-2 group-hover:text-primary transition-colors">
              {event.title}
            </h3>
          </header>

          <div className="grid gap-1.5 text-[11px] text-muted-foreground">
            <div className="inline-flex items-center gap-1.5 min-w-0">
              <CalendarDays className="h-3.5 w-3.5" />
              <span className="truncate">{dateLabel} • {timeLabel}</span>
            </div>
            <div className="inline-flex items-center gap-1.5 min-w-0">
              <MapPin className="h-3.5 w-3.5" />
              <span className="truncate">{event.venue} • {event.location}</span>
            </div>
          </div>

          <div className="mt-auto flex items-center justify-between gap-3">
            <div className="min-w-0">
              <div className="text-[11px] text-muted-foreground">Entry</div>
              <div className="font-bold text-sm text-foreground truncate">
                {event.isFree
                  ? "FREE"
                  : `${event.currency || "UGX"} ${new Intl.NumberFormat("en-UG").format(event.ticketPrice || 0)}`}
              </div>
            </div>
            <Button
              size="sm"
              className="rounded-full"
              onClick={(e) => e.stopPropagation()}
            >
              <Ticket className="h-4 w-4" />
              {event.isFree ? "Register" : "Tickets"}
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </motion.article>
  );
};

export default SearchEventCard;
