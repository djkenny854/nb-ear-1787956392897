import React, { useMemo } from 'react';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
} from 'recharts';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export interface ChartData {
  type: 'bar' | 'line' | 'area' | 'pie';
  title: string;
  data: Record<string, unknown>[];
  xKey: string;
  series: { key: string; name: string; color?: string }[];
}

const PALETTE = ['#22c55e', '#3b82f6', '#f59e0b', '#a855f7', '#06b6d4', '#ef4444', '#ec4899'];
const UP = '#22c55e';
const DOWN = '#ef4444';
const NEUTRAL = '#3b82f6';

/** Compute the dominant trend across the first series. */
function summarize(data: Record<string, unknown>[], key: string) {
  const nums = data
    .map((d) => Number(d[key]))
    .filter((n) => Number.isFinite(n));
  if (nums.length < 2) return { delta: 0, pct: 0, min: nums[0] ?? 0, max: nums[0] ?? 0 };
  const first = nums[0];
  const last = nums[nums.length - 1];
  const delta = last - first;
  const pct = first === 0 ? 0 : (delta / Math.abs(first)) * 100;
  return { delta, pct, min: Math.min(...nums), max: Math.max(...nums) };
}

function formatNum(n: number) {
  if (!Number.isFinite(n)) return '—';
  const abs = Math.abs(n);
  if (abs >= 1_000_000) return (n / 1_000_000).toFixed(abs >= 10_000_000 ? 0 : 1) + 'M';
  if (abs >= 1_000) return (n / 1_000).toFixed(abs >= 10_000 ? 0 : 1) + 'k';
  return n % 1 === 0 ? n.toString() : n.toFixed(2);
}

const ChartTooltip: React.FC<any> = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-border/60 bg-popover/95 backdrop-blur px-3 py-2 shadow-lg text-xs">
      {label !== undefined && <div className="text-foreground/80 font-medium mb-1">{label}</div>}
      {payload.map((p: any, i: number) => (
        <div key={i} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
          <span className="text-muted-foreground">{p.name}</span>
          <span className="ml-auto font-semibold text-foreground">{formatNum(Number(p.value))}</span>
        </div>
      ))}
    </div>
  );
};

const EMIChartRenderer: React.FC<{ chart: ChartData }> = ({ chart }) => {
  const { type, title, data, xKey, series } = chart;

  const colors = useMemo(
    () => series.map((s, i) => s.color || PALETTE[i % PALETTE.length]),
    [series]
  );

  const summary = useMemo(
    () => (series[0] ? summarize(data, series[0].key) : null),
    [data, series]
  );

  const trendUp = summary && summary.delta > 0;
  const trendDown = summary && summary.delta < 0;
  const TrendIcon = trendUp ? TrendingUp : trendDown ? TrendingDown : Minus;
  const trendColor = trendUp ? UP : trendDown ? DOWN : 'hsl(var(--muted-foreground))';

  // Use a single gradient color for line/area when there's only one series for the
  // signature Perplexity look (green up / red down).
  const primaryColor =
    series.length === 1
      ? trendUp ? UP : trendDown ? DOWN : NEUTRAL
      : colors[0];
  const gradientId = useMemo(() => `emi-grad-${Math.random().toString(36).slice(2, 9)}`, []);

  const axisProps = {
    tick: { fontSize: 10, fill: 'hsl(var(--muted-foreground))' },
    stroke: 'hsl(var(--border))',
    tickLine: false,
    axisLine: false,
  };

  return (
    <div className="my-3 rounded-2xl bg-card/70 backdrop-blur-sm border border-border/60 overflow-hidden">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 px-4 pt-3 pb-2">
        <div className="min-w-0">
          <h4 className="text-[13px] font-semibold text-foreground leading-tight truncate">
            {title}
          </h4>
          {summary && type !== 'pie' && (
            <p className="text-[11px] text-muted-foreground mt-0.5">
              Range {formatNum(summary.min)} – {formatNum(summary.max)}
            </p>
          )}
        </div>
        {summary && type !== 'pie' && (
          <div
            className="flex items-center gap-1 px-2 py-1 rounded-full text-[11px] font-semibold shrink-0"
            style={{ color: trendColor, background: `${trendColor}1a` }}
          >
            <TrendIcon className="w-3 h-3" />
            {summary.pct >= 0 ? '+' : ''}{summary.pct.toFixed(1)}%
          </div>
        )}
      </div>

      <div className="px-2 pb-3">
        <ResponsiveContainer width="100%" height={220}>
          {type === 'pie' ? (
            <PieChart>
              <Pie
                data={data}
                dataKey={series[0]?.key || 'value'}
                nameKey={xKey}
                cx="50%"
                cy="50%"
                innerRadius={45}
                outerRadius={80}
                paddingAngle={2}
                stroke="hsl(var(--background))"
                strokeWidth={2}
              >
                {data.map((_, i) => (
                  <Cell key={i} fill={PALETTE[i % PALETTE.length]} />
                ))}
              </Pie>
              <Tooltip content={<ChartTooltip />} />
              <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />
            </PieChart>
          ) : type === 'line' ? (
            <LineChart data={data} margin={{ top: 6, right: 12, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="2 4" vertical={false} />
              <XAxis dataKey={xKey} {...axisProps} />
              <YAxis {...axisProps} tickFormatter={(v) => formatNum(Number(v))} width={36} />
              <Tooltip content={<ChartTooltip />} cursor={{ stroke: primaryColor, strokeDasharray: '3 3' }} />
              {series.length > 1 && <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />}
              {series.map((s, i) => (
                <Line
                  key={s.key}
                  type="monotone"
                  dataKey={s.key}
                  name={s.name}
                  stroke={series.length === 1 ? primaryColor : colors[i]}
                  strokeWidth={2.2}
                  dot={false}
                  activeDot={{ r: 4 }}
                />
              ))}
            </LineChart>
          ) : type === 'area' ? (
            <AreaChart data={data} margin={{ top: 6, right: 12, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={primaryColor} stopOpacity={0.35} />
                  <stop offset="100%" stopColor={primaryColor} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="2 4" vertical={false} />
              <XAxis dataKey={xKey} {...axisProps} />
              <YAxis {...axisProps} tickFormatter={(v) => formatNum(Number(v))} width={36} />
              <Tooltip content={<ChartTooltip />} cursor={{ stroke: primaryColor, strokeDasharray: '3 3' }} />
              {series.length > 1 && <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />}
              {series.map((s, i) => (
                <Area
                  key={s.key}
                  type="monotone"
                  dataKey={s.key}
                  name={s.name}
                  stroke={series.length === 1 ? primaryColor : colors[i]}
                  strokeWidth={2}
                  fill={series.length === 1 ? `url(#${gradientId})` : colors[i]}
                  fillOpacity={series.length === 1 ? 1 : 0.25}
                />
              ))}
            </AreaChart>
          ) : (
            <BarChart data={data} margin={{ top: 6, right: 12, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="2 4" vertical={false} />
              <XAxis dataKey={xKey} {...axisProps} interval={0} />
              <YAxis {...axisProps} tickFormatter={(v) => formatNum(Number(v))} width={36} />
              <Tooltip content={<ChartTooltip />} cursor={{ fill: 'hsl(var(--muted) / 0.4)' }} />
              {series.length > 1 && <Legend wrapperStyle={{ fontSize: 11 }} iconType="circle" />}
              {series.map((s, i) => (
                <Bar
                  key={s.key}
                  dataKey={s.key}
                  name={s.name}
                  fill={colors[i]}
                  radius={[6, 6, 0, 0]}
                  maxBarSize={48}
                />
              ))}
            </BarChart>
          )}
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default EMIChartRenderer;
