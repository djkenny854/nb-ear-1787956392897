import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldAlert, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useAccountStatusContext } from '@/components/auth/AccountStatusProvider';
import { format } from 'date-fns';

interface RestrictedActionMessageProps {
  action: string; // e.g., "post listings", "send messages", "apply for jobs"
}

export const RestrictedActionMessage: React.FC<RestrictedActionMessageProps> = ({ action }) => {
  const navigate = useNavigate();
  const { isBanned, isSuspended, suspensionEndDate } = useAccountStatusContext();

  if (!isBanned && !isSuspended) return null;

  return (
    <Card className="border-destructive/30 bg-destructive/5">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
            isBanned ? 'bg-destructive/10' : 'bg-amber-500/10'
          }`}>
            <ShieldAlert className={`h-6 w-6 ${
              isBanned ? 'text-destructive' : 'text-amber-500'
            }`} />
          </div>
          <div className="flex-1">
            <h3 className="font-semibold text-foreground mb-1">
              {isBanned ? 'Account Restricted' : 'Account Suspended'}
            </h3>
            <p className="text-sm text-muted-foreground mb-3">
              {isBanned
                ? `Your account has been restricted. You cannot ${action}.`
                : `Your account is temporarily suspended. You cannot ${action} until the suspension is lifted.`}
            </p>
            {isSuspended && suspensionEndDate && (
              <div className="flex items-center gap-2 text-sm text-amber-600 dark:text-amber-400 mb-3">
                <Clock className="h-4 w-4" />
                <span>Suspension ends: {format(suspensionEndDate, 'PPP')}</span>
              </div>
            )}
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => navigate('/account-restricted')}
            >
              Learn More
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default RestrictedActionMessage;
