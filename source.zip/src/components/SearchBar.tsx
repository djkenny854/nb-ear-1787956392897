import React, { useState, useEffect, useRef } from 'react';
import { X, ImagePlus, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import EMIIcon from '@/components/icons/EMIIcon';
import aiImageSearchIcon from '@/assets/ai-image-search.png';
import bookmarkIcon from '@/assets/bookmark-icon.png';
import searchIcon from '@/assets/search-icon.png';
import soundIcon from '@/assets/sound-icon.png';

export interface ImageSearchFilters {
  category?: string;
  condition?: string;
  searchQuery?: string;
}

interface SearchBarProps {
  onSearch: (query: string) => void;
  onImageSearchFilters?: (filters: ImageSearchFilters) => void;
}

const SearchBar = ({ onSearch, onImageSearchFilters }: SearchBarProps) => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [isImageSearching, setIsImageSearching] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [isFocused, setIsFocused] = useState(false);
  const [isImagePanelOpen, setIsImagePanelOpen] = useState(false);
  const [uploadedImages, setUploadedImages] = useState<{ file: File; preview: string }[]>([]);
  const [rotation, setRotation] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const imageFileInputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Animate gradient rotation
  useEffect(() => {
    const speed = isFocused || isImagePanelOpen ? 8 : 30;
    const interval = setInterval(() => {
      setRotation((prev) => (prev + 1) % 360);
    }, speed);
    return () => clearInterval(interval);
  }, [isFocused, isImagePanelOpen]);

  // Close panel on outside click
  useEffect(() => {
    if (!isImagePanelOpen) return;
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsImagePanelOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [isImagePanelOpen]);

  const handleSearch = () => {
    if (searchQuery.trim()) {
      onSearch(searchQuery);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSearch();
  };

  const handleImageSearch = async (files: File[]) => {
    if (files.length === 0) return;
    setIsImageSearching(true);
    toast({ title: "Analyzing images...", description: "EMI is identifying products" });

    try {
      const base64Promises = files.map(
        (file) =>
          new Promise<string>((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve((reader.result as string).split(',')[1]);
            reader.onerror = reject;
            reader.readAsDataURL(file);
          })
      );
      const base64Images = await Promise.all(base64Promises);

      const { data, error } = await supabase.functions.invoke('image-search', {
        body: { imageBase64: base64Images[0] },
      });

      if (error) {
        toast({ title: "Search failed", description: error.message || "Failed to analyze image", variant: "destructive" });
        setIsImageSearching(false);
        return;
      }

      // New: apply filters directly instead of just putting a word in search
      if (data?.filters && onImageSearchFilters) {
        onImageSearchFilters(data.filters);
        if (data.filters.searchQuery) {
          setSearchQuery(data.filters.searchQuery);
          onSearch(data.filters.searchQuery);
        }
        toast({ 
          title: "Image analyzed", 
          description: `Found: ${data.filters.category || 'items'}${data.filters.condition ? ` (${data.filters.condition})` : ''}` 
        });
        setIsImagePanelOpen(false);
        setUploadedImages([]);
      } else if (data?.searchQuery) {
        // Fallback for backward compat
        setSearchQuery(data.searchQuery);
        onSearch(data.searchQuery);
        toast({ title: "Image analyzed", description: `Searching for: ${data.searchQuery}` });
        setIsImagePanelOpen(false);
        setUploadedImages([]);
      } else {
        toast({ title: "No results", description: "Could not identify products from image", variant: "destructive" });
      }
      setIsImageSearching(false);
    } catch (err) {
      console.error('Image search error:', err);
      toast({ title: "Search failed", description: "Failed to analyze image", variant: "destructive" });
      setIsImageSearching(false);
    }
  };

  const handleAddImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    const newImages = Array.from(files)
      .filter((f) => f.type.startsWith('image/'))
      .slice(0, 2 - uploadedImages.length)
      .map((file) => ({ file, preview: URL.createObjectURL(file) }));
    setUploadedImages((prev) => [...prev, ...newImages].slice(0, 2));
    e.target.value = '';
  };

  const removeImage = (index: number) => {
    setUploadedImages((prev) => {
      URL.revokeObjectURL(prev[index].preview);
      return prev.filter((_, i) => i !== index);
    });
  };

  const handleVoiceSearch = async () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      toast({ title: "Not supported", description: "Voice search is not supported in your browser", variant: "destructive" });
      return;
    }
    if (isRecording) { setIsRecording(false); return; }
    try {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.onstart = () => { setIsRecording(true); toast({ title: "Listening...", description: "Speak your search query" }); };
      recognition.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setSearchQuery(transcript);
        onSearch(transcript);
        toast({ title: "Voice recognized", description: `Searching for: ${transcript}` });
        setIsRecording(false);
      };
      recognition.onerror = () => { setIsRecording(false); };
      recognition.onend = () => { setIsRecording(false); };
      recognition.start();
    } catch (error) {
      toast({ title: "Voice search failed", description: "Please allow microphone access and try again", variant: "destructive" });
      setIsRecording(false);
    }
  };

  const gradientBorder = `linear-gradient(${rotation}deg, 
    hsl(24, 95%, 53%), 
    hsl(38, 92%, 50%), 
    hsl(220, 80%, 55%), 
    hsl(270, 70%, 55%), 
    hsl(24, 95%, 53%)
  )`;

  const borderRadius = '1.5rem';

  return (
    <div className="relative w-full max-w-3xl mx-auto" ref={containerRef}>
      <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={(e) => {
        const file = e.target.files?.[0];
        if (file) handleImageSearch([file]);
      }} />
      <input ref={imageFileInputRef} type="file" accept="image/*" multiple className="hidden" onChange={handleAddImage} />

      {/* Animated gradient border wrapper */}
      <div
        className="relative p-[2px] overflow-hidden transition-all duration-300"
        style={{
          background: gradientBorder,
          borderRadius: borderRadius,
        }}
      >
        <div
          className="bg-card transition-all duration-300"
          style={{ borderRadius: `calc(${borderRadius} - 2px)` }}
        >
          {/* Main search row */}
          <div className="relative flex items-center h-12">
            {/* Bookmark Icon */}
            <button onClick={() => navigate('/bookmarks')} className="flex items-center justify-center w-12 h-12 shrink-0 hover:bg-muted/50 transition-colors" style={{ borderTopLeftRadius: `calc(${borderRadius} - 2px)`, borderBottomLeftRadius: isImagePanelOpen ? '0' : `calc(${borderRadius} - 2px)` }}>
              <img src={bookmarkIcon} alt="Bookmarks" className="h-4 w-4 transition-opacity hover:opacity-80" />
            </button>
            <div className="h-6 w-px bg-border/50" />

            {/* Search Section */}
            <div className="relative flex items-center flex-1 px-4">
              <img src={searchIcon} alt="Search" className="h-4 w-4 mr-3 shrink-0 opacity-70" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={handleKeyPress}
                onFocus={() => setIsFocused(true)}
                onBlur={() => setIsFocused(false)}
                placeholder="Search products, services..."
                className="w-full bg-transparent border-none outline-none text-sm text-foreground flex-1"
              />
            </div>
            <div className="h-6 w-px bg-border/50" />

            {/* Image Search Icon */}
            <button
              onClick={() => setIsImagePanelOpen(!isImagePanelOpen)}
              disabled={isImageSearching}
              className="flex items-center justify-center w-12 h-12 shrink-0 hover:bg-muted/50 transition-colors disabled:opacity-50"
              title="Search by image"
            >
              {isImageSearching ? (
                <EMIIcon className="h-5 w-5" spin={true} />
              ) : (
                <img src={aiImageSearchIcon} alt="Image search" className="h-5 w-5 transition-opacity hover:opacity-80" />
              )}
            </button>
            <div className="h-6 w-px bg-border/50" />

            {/* Voice Search Icon */}
            <button
              onClick={handleVoiceSearch}
              className={`flex items-center justify-center w-12 h-12 shrink-0 hover:bg-muted/50 transition-colors ${isRecording ? 'bg-destructive/10' : ''}`}
              style={{ borderTopRightRadius: `calc(${borderRadius} - 2px)`, borderBottomRightRadius: isImagePanelOpen ? '0' : `calc(${borderRadius} - 2px)` }}
              title="Voice search"
            >
              <img src={soundIcon} alt="Voice search" className={`h-5 w-5 transition-opacity ${isRecording ? 'animate-pulse' : 'hover:opacity-80'}`} />
            </button>
          </div>

          {/* Expandable Image Search Panel */}
          <div
            className="overflow-hidden transition-all duration-300 ease-in-out"
            style={{ maxHeight: isImagePanelOpen ? '220px' : '0px' }}
          >
            <div className="px-4 pb-4 pt-2 border-t border-border/30">
              <p className="text-xs text-muted-foreground mb-3">
                Upload 1-2 images to find similar products
              </p>

              <div className="flex gap-3">
                {/* Uploaded image previews */}
                {uploadedImages.map((img, i) => (
                  <div key={i} className="relative w-20 h-20 rounded-lg overflow-hidden border border-border/50 group">
                    <img src={img.preview} alt="Upload" className="w-full h-full object-cover" />
                    <button
                      onClick={() => removeImage(i)}
                      className="absolute top-1 right-1 h-5 w-5 rounded-full bg-foreground/70 text-background flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}

                {/* Add image placeholder(s) */}
                {Array.from({ length: Math.max(1, 2 - uploadedImages.length) }).map((_, i) => (
                  <button
                    key={`placeholder-${i}`}
                    onClick={() => imageFileInputRef.current?.click()}
                    className="w-20 h-20 rounded-lg border-2 border-dashed border-border/60 hover:border-primary/50 flex flex-col items-center justify-center gap-1 transition-colors"
                  >
                    <ImagePlus className="h-5 w-5 text-muted-foreground" />
                    <span className="text-[10px] text-muted-foreground">Add</span>
                  </button>
                ))}

                {/* Search button */}
                {uploadedImages.length > 0 && (
                  <button
                    onClick={() => handleImageSearch(uploadedImages.map((i) => i.file))}
                    disabled={isImageSearching}
                    className="flex-1 min-w-[80px] h-20 rounded-lg bg-primary text-primary-foreground flex flex-col items-center justify-center gap-1 hover:bg-primary/90 transition-colors disabled:opacity-50"
                  >
                    {isImageSearching ? (
                      <Loader2 className="h-5 w-5 animate-spin" />
                    ) : (
                      <>
                        <EMIIcon className="h-5 w-5" />
                        <span className="text-xs font-medium">Search</span>
                      </>
                    )}
                  </button>
                )}
              </div>

              {/* EMI assurance text */}
              <div className="mt-3 flex items-center gap-1.5">
                <EMIIcon className="h-3 w-3 shrink-0" />
                <p className="text-[10px] text-muted-foreground">
                  Powered by EMI · Early Market Intelligence — Image search is improving and may not always find exact matches
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Overlay when image panel is open */}
      {isImagePanelOpen && (
        <div className="fixed inset-0 bg-foreground/20 backdrop-blur-sm -z-10" onClick={() => setIsImagePanelOpen(false)} />
      )}
    </div>
  );
};

export default SearchBar;
