import React from 'react';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface FilterChip {
  key: string;
  label: string;
  value: string;
}

interface FilterChipsProps {
  chips: FilterChip[];
  onRemove: (key: string) => void;
  onClearAll: () => void;
}

const FilterChips: React.FC<FilterChipsProps> = ({ chips, onRemove, onClearAll }) => {
  if (chips.length === 0) return null;

  return (
    <div className="flex flex-wrap items-center gap-2 p-4 bg-muted/30 border-b border-border">
      <span className="text-sm text-muted-foreground font-medium">Active filters:</span>
      {chips.map((chip) => (
        <Badge
          key={chip.key}
          variant="secondary"
          className="pl-3 pr-1 py-1.5 gap-2 hover:bg-secondary/80 transition-colors"
        >
          <span className="text-xs font-medium">{chip.label}: {chip.value}</span>
          <button
            onClick={() => onRemove(chip.key)}
            className="ml-1 hover:bg-destructive/20 rounded-full p-0.5 transition-colors"
          >
            <X className="w-3 h-3" />
          </button>
        </Badge>
      ))}
      {chips.length > 1 && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearAll}
          className="h-6 px-2 text-xs text-destructive hover:text-destructive hover:bg-destructive/10"
        >
          Clear all
        </Button>
      )}
    </div>
  );
};

export default FilterChips;
