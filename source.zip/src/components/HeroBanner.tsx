import React from 'react';
import { useNavigate } from 'react-router-dom';
import SearchBar from './SearchBar';
import RotatingBanner from './RotatingBanner';
const HeroBanner = () => {
  const navigate = useNavigate();
  const handleSearch = (query: string) => {
    navigate(`/search?q=${encodeURIComponent(query)}`);
  };
  return <div className="relative bg-gradient-to-br from-primary via-orange-600 to-red-600 text-white overflow-hidden">
      {/* Background Images */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-1/3 h-full bg-gradient-to-br from-blue-500/30 to-transparent"></div>
        <div className="absolute top-0 right-0 w-1/3 h-full bg-gradient-to-bl from-purple-500/30 to-transparent"></div>
        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1/2 h-1/2 bg-gradient-to-t from-yellow-500/30 to-transparent"></div>
      </div>

      {/* Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute top-20 left-20 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
        <div className="absolute bottom-20 right-20 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 py-12">
        {/* Main Hero Content */}
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-white to-gray-200 bg-clip-text text-transparent">
            Find Everything You Need
          </h1>
          <p className="text-lg md:text-2xl mb-8 text-white/90 max-w-3xl mx-auto leading-relaxed">
            Discover amazing deals from verified sellers in your area. Shop safely, buy confidently, and connect with your local community.
          </p>
          
          <div className="flex justify-center mb-12">
            
          </div>

          {/* Feature Highlights */}
          
        </div>

        {/* Enhanced Rotating Banner */}
        <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 border border-white/20">
          <RotatingBanner />
        </div>
      </div>
    </div>;
};
export default HeroBanner;