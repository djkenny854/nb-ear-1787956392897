import React, { useState, useEffect, useRef, useLayoutEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useTheme } from 'next-themes';
import { Plus, MoreHorizontal, LogOut, LogIn, Sparkles } from 'lucide-react';
import {
  House,
  Storefront,
  MagnifyingGlass,
  Compass,
  Bell as PhBell,
  ChatCircle,
  Gauge as PhGauge,
  ChatTeardropDots,
  GearSix,
  Lightning,
  FileText as PhFileText,
  BookmarkSimple,
  UserPlus as PhUserPlus,
} from '@phosphor-icons/react';
import { adaptPhosphor } from '@/components/icons/PhosphorAdapter';
import GeminiSparkIcon from '@/components/icons/GeminiSparkIcon';
import { openEarlyMarketAI } from '@/components/ai/EarlyMarketAIIntroDialog';

const Home = adaptPhosphor(House);
const Store = adaptPhosphor(Storefront);
const Search = adaptPhosphor(MagnifyingGlass);
const Users = adaptPhosphor(Compass);
const Bell = adaptPhosphor(PhBell);
const Mail = adaptPhosphor(ChatCircle);
const Gauge = adaptPhosphor(PhGauge);
const MessageSquare = adaptPhosphor(ChatTeardropDots);
const Settings = adaptPhosphor(GearSix);
const Zap = adaptPhosphor(Lightning);
const Package = adaptPhosphor(PhFileText);
const Bookmark = adaptPhosphor(BookmarkSimple);
const FollowIcon = adaptPhosphor(PhUserPlus);
import { supabase } from '@/integrations/supabase/client';
import { cn } from '@/lib/utils';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { useAuth } from '@/components/auth/AuthContext';
import { useUnreadMessages } from '@/hooks/useUnreadMessages';
import { Badge } from '@/components/ui/badge';
import earlyMarketLogo from '@/assets/earlymarket-logo-new.png';
import BrandLogo from '@/components/icons/BrandLogo';

interface LeftSidebarProps {
  collapsed?: boolean;
}

type NavItem = {
  icon: any;
  label: string;
  path: string;
  fillWhenActive?: boolean;
  badge?: string;
  comingSoon?: boolean;
  showLogo?: boolean;
};

interface AdaptiveMenuProps {
  collapsed: boolean;
  menuItems: NavItem[];
  baseMoreItems: NavItem[];
  isActive: (path: string) => boolean;
  unreadCount: number;
  onNavigate: (path: string) => void;
}

const ITEM_HEIGHT_EXPANDED = 52; // approximate px per nav row (expanded)
const ITEM_HEIGHT_COLLAPSED = 50; // 48px button + 2px spacing
const POST_BUTTON_HEIGHT = 56;
const MORE_HEIGHT_EXPANDED = 52;
const MORE_HEIGHT_COLLAPSED = 50;
const SAFETY_PADDING = 16;

const AdaptiveMenu: React.FC<AdaptiveMenuProps> = ({
  collapsed,
  menuItems,
  baseMoreItems,
  isActive,
  unreadCount,
  onNavigate,
}) => {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const listRef = useRef<HTMLDivElement>(null);
  const [visibleCount, setVisibleCount] = useState<number>(menuItems.length);

  // Height-driven overflow: measure the space the nav list actually gets and
  // derive how many rows fit. Items only move into "More" when there is truly
  // no room for them (never a fixed minimum of two).
  useLayoutEffect(() => {
    const el = wrapperRef.current;
    if (!el) return;
    let raf = 0;

    const compute = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const wrapper = wrapperRef.current;
        if (!wrapper) return;
        const itemH = collapsed ? ITEM_HEIGHT_COLLAPSED : ITEM_HEIGHT_EXPANDED;
        const moreH = collapsed ? MORE_HEIGHT_COLLAPSED : MORE_HEIGHT_EXPANDED;
        // Space available to the scrollable nav list = wrapper minus the
        // always-visible Post button and a little breathing room.
        const available =
          wrapper.clientHeight - POST_BUTTON_HEIGHT - SAFETY_PADDING;
        if (available <= 0) return;

        // First assume everything fits (no More row needed for overflow, but
        // the More row is always rendered, so reserve it).
        const fitsAll = menuItems.length * itemH + moreH <= available;
        const next = fitsAll
          ? menuItems.length
          : Math.max(0, Math.floor((available - moreH) / itemH));
        setVisibleCount((prev) => (prev === next ? prev : next));
      });
    };

    compute();
    const ro = new ResizeObserver(compute);
    ro.observe(el);
    window.addEventListener('resize', compute);
    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      window.removeEventListener('resize', compute);
    };
  }, [collapsed, menuItems.length]);



  const visible = menuItems.slice(0, visibleCount);
  const overflow = menuItems.slice(visibleCount);
  const moreItems = [...overflow, ...baseMoreItems];

  const renderRow = (item: NavItem) => (
    <Tooltip key={item.path + item.label}>
      <TooltipTrigger asChild>
        <button
          onClick={() => {
            if (item.path === '/ai') {
              openEarlyMarketAI(onNavigate);
            } else if (!item.comingSoon) {
              onNavigate(item.path);
            }
          }}
          className={cn(
            'flex items-center gap-5 rounded-full hover:bg-accent/10 transition-all duration-150 text-left relative',
            collapsed ? 'justify-center w-12 h-12' : 'w-full px-3 py-3'
          )}
        >
          <div className="relative">
            <item.icon
              className={cn('w-[26px] h-[26px]', isActive(item.path) && 'text-foreground')}
              strokeWidth={isActive(item.path) ? 2.4 : 1.75}
              fill={isActive(item.path) && item.fillWhenActive ? 'currentColor' : 'none'}
            />
            {item.path === '/messages' && unreadCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 min-w-[18px] h-[18px] flex items-center justify-center bg-primary text-primary-foreground text-[10px] font-bold rounded-full px-1">
                {unreadCount > 99 ? '99+' : unreadCount}
              </span>
            )}
          </div>
          {!collapsed && (
            <span className={cn('text-[20px] flex-1 leading-none whitespace-nowrap', isActive(item.path) ? 'font-bold' : 'font-normal')}>
              {item.label}
            </span>
          )}
          {!collapsed && item.badge && (
            <Badge variant="secondary" className="text-[10px] px-1.5 py-0 bg-primary/10 text-primary">
              {item.badge}
            </Badge>
          )}
        </button>
      </TooltipTrigger>
      {collapsed && <TooltipContent side="right" className="font-medium">{item.label}</TooltipContent>}
    </Tooltip>
  );

  return (
    <div
      ref={wrapperRef}
      className={cn(
        'flex-1 min-h-0 flex flex-col overflow-hidden',
        collapsed ? 'items-center' : 'pl-2'
      )}
    >
      <div ref={listRef} className="flex-1 min-h-0 space-y-0.5 overflow-hidden">
        {visible.map(renderRow)}

        {/* More popover */}
        {!collapsed ? (
          <Popover>
            <PopoverTrigger asChild>
              <button className="flex items-center gap-5 px-3 py-3 rounded-full hover:bg-accent/10 transition-all duration-150 text-left w-full">
                <MoreHorizontal className="w-[26px] h-[26px]" strokeWidth={1.75} />
                <span className="text-[20px] font-normal leading-none">More</span>
              </button>
            </PopoverTrigger>
            <PopoverContent
              side="right"
              align="start"
              className="w-60 p-2 bg-background border border-border shadow-lg rounded-xl z-[200]"
            >
              <div className="space-y-0.5">
                {moreItems.map((item) => (
                  <button
                    key={item.label + item.path}
                    onClick={() => !item.comingSoon && onNavigate(item.path)}
                    disabled={item.comingSoon}
                    className={cn(
                      'flex items-center gap-3 p-3 rounded-lg hover:bg-accent/10 transition-all duration-150 text-left w-full',
                      isActive(item.path) && 'font-bold bg-accent/5',
                      item.comingSoon && 'opacity-70 cursor-not-allowed'
                    )}
                  >
                    {item.showLogo ? (
                      <img src={earlyMarketLogo} alt="" className="w-5 h-5 object-contain" />
                    ) : (
                      <item.icon
                        className={cn('w-5 h-5', isActive(item.path) && 'text-foreground')}
                        strokeWidth={isActive(item.path) ? 2.4 : 1.75}
                      />
                    )}
                    <span className={cn('text-[15px] flex-1', isActive(item.path) && 'font-bold')}>{item.label}</span>
                    {item.comingSoon && (
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0">Soon</Badge>
                    )}
                  </button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
        ) : (
          <Popover>
            <PopoverTrigger asChild>
              <button className="flex items-center justify-center w-12 h-12 rounded-full hover:bg-accent/10 transition-all duration-150">
                <MoreHorizontal className="w-[26px] h-[26px]" strokeWidth={1.75} />
              </button>
            </PopoverTrigger>
            <PopoverContent
              side="right"
              align="start"
              className="w-60 p-2 bg-background border border-border shadow-lg rounded-xl z-[200]"
            >
              <div className="space-y-0.5">
                {moreItems.map((item) => (
                  <button
                    key={item.label + item.path}
                    onClick={() => !item.comingSoon && onNavigate(item.path)}
                    disabled={item.comingSoon}
                    className={cn(
                      'flex items-center gap-3 p-3 rounded-lg hover:bg-accent/10 transition-all duration-150 text-left w-full',
                      isActive(item.path) && 'font-bold bg-accent/5',
                      item.comingSoon && 'opacity-70 cursor-not-allowed'
                    )}
                  >
                    {item.showLogo ? (
                      <img src={earlyMarketLogo} alt="" className="w-5 h-5 object-contain" />
                    ) : (
                      <item.icon className="w-5 h-5" strokeWidth={1.75} />
                    )}
                    <span className={cn('text-[15px] flex-1', isActive(item.path) && 'font-bold')}>{item.label}</span>
                  </button>
                ))}
              </div>
            </PopoverContent>
          </Popover>
        )}
      </div>

      {/* Post button — always visible */}
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            onClick={() => onNavigate('/post-ad')}
            className={cn(
              'flex items-center gap-4 rounded-full bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-150 mt-2 shrink-0',
              collapsed ? 'justify-center w-12 h-12' : 'w-full justify-center py-3.5'
            )}
          >
            <Plus className="w-6 h-6" strokeWidth={2.5} />
            {!collapsed && <span className="font-bold text-[16px]">Post</span>}
          </button>
        </TooltipTrigger>
        {collapsed && <TooltipContent side="right" className="font-medium">Create Post</TooltipContent>}
      </Tooltip>
    </div>
  );
};


const LeftSidebar: React.FC<LeftSidebarProps> = ({ collapsed = false }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { theme } = useTheme();
  const { user, signOut } = useAuth();
  const { unreadCount } = useUnreadMessages();

  const menuItems = [
    { icon: Home, label: 'Home', path: '/', fillWhenActive: true },
    { icon: Search, label: 'Marketplace', path: '/marketplace', fillWhenActive: false },
    { icon: Users, label: 'Discover', path: '/discover', fillWhenActive: false },
    { icon: Bell, label: 'Notifications', path: '/notifications', fillWhenActive: true },
    { icon: Mail, label: 'Messages', path: '/messages', fillWhenActive: true },
    { icon: GeminiSparkIcon as any, label: 'Earlymarket AI', path: '/ai', fillWhenActive: true, badge: 'Beta' },
    { icon: Bookmark, label: 'Bookmarks', path: '/bookmarks', fillWhenActive: true },
    { icon: MessageSquare, label: 'Feedback', path: '/feedback', fillWhenActive: false },
    { icon: Settings, label: 'Settings', path: '/account-settings', fillWhenActive: false },
  ];

  const moreItems = [
    { icon: Gauge, label: 'Performance', path: '/sales-analytics', fillWhenActive: false },
    { icon: Zap, label: 'Boost Ad', path: '/boost-ad', fillWhenActive: false },
    { icon: Package, label: 'Drafts', path: '/drafts', fillWhenActive: false },
    { icon: Sparkles, label: 'EarlyMarket Studio', path: '#', fillWhenActive: false, comingSoon: true, showLogo: true },
  ];

  const isActive = (path: string) => {
    if (path === '/') return location.pathname === '/';
    return location.pathname.startsWith(path);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const handleSignIn = () => {
    navigate('/auth');
  };

  // Get user display info
  const userEmail = user?.email || '';
  const userName = user ? (userEmail.split('@')[0] || 'User') : 'Guest';
  const userInitial = userName.charAt(0).toUpperCase();
  const isLoggedIn = !!user;

  // Fetch seller profile for business name, logo, and store_slug
  const [sellerProfile, setSellerProfile] = useState<{ business_name: string; business_logo_url: string | null; store_slug: string | null } | null>(null);
  
  useEffect(() => {
    if (!user?.id) return;
    const fetchSellerProfile = async () => {
      const { data } = await supabase
        .from('seller_profiles')
        .select('business_name, business_logo_url, store_slug')
        .eq('user_id', user.id)
        .maybeSingle();
      if (data) setSellerProfile(data);
    };
    fetchSellerProfile();
  }, [user?.id]);

  const displayName = sellerProfile?.business_name || userName;
  const displayAvatar = sellerProfile?.business_logo_url || user?.user_metadata?.avatar_url;
  const displayInitial = displayName.charAt(0).toUpperCase();

  return (
    <TooltipProvider delayDuration={0}>
      <div className={cn("flex flex-col h-full min-h-0", collapsed ? "items-center py-2" : "py-3")}>
        {/* Logo at the top — X.com style: just the mark, no wordmark.
            BrandLogo inherits text color, so it flips for light/dark theme. */}
        <div
          onClick={() => navigate('/')}
          className={cn(
            'cursor-pointer flex-shrink-0 flex items-center',
            collapsed ? 'justify-center mb-2' : 'pl-3 mb-2'
          )}
          aria-label="EarlyMarket home"
        >
          <div
            className={cn(
              'flex items-center justify-center rounded-full hover:bg-accent/10 transition-colors',
              collapsed ? 'w-11 h-11' : 'w-12 h-12 p-2'
            )}
            style={{ width: collapsed ? undefined : 48, height: collapsed ? undefined : 48 }}
          >
            <BrandLogo className="text-foreground" style={{ width: collapsed ? 28 : 30, height: collapsed ? 28 : 30 }} />
          </div>
        </div>

        <AdaptiveMenu
          collapsed={collapsed}
          menuItems={menuItems}
          baseMoreItems={moreItems}
          isActive={isActive}
          unreadCount={unreadCount}
          onNavigate={navigate}
        />


        {/* Account section at the bottom - X.com style */}
        <div className="flex-shrink-0 mt-auto pt-4">
          {!collapsed ? (
            <Popover>
              <PopoverTrigger asChild>
                <button 
                  className="flex items-center gap-3 p-3 rounded-full hover:bg-accent/10 transition-all duration-200 w-full"
                >
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={displayAvatar} />
                    <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                      {displayInitial}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0 text-left">
                    <p className="font-semibold text-sm truncate">{displayName}</p>
                    <p className="text-xs text-muted-foreground truncate">
                      {isLoggedIn ? `@${userName.toLowerCase()}` : 'Not signed in'}
                    </p>
                  </div>
                  <MoreHorizontal className="w-5 h-5 text-muted-foreground flex-shrink-0" />
                </button>
              </PopoverTrigger>
              <PopoverContent 
                side="top" 
                align="start" 
                className="w-64 p-0 bg-background border border-border shadow-xl rounded-2xl overflow-hidden z-[200]"
              >
                <div className="p-4 border-b border-border">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={user?.user_metadata?.avatar_url} />
                      <AvatarFallback className="bg-primary/10 text-primary font-semibold text-lg">
                        {userInitial}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold truncate">{userName}</p>
                      <p className="text-sm text-muted-foreground truncate">
                        {isLoggedIn ? `@${userName.toLowerCase()}` : 'Not signed in'}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="py-2">
                  {isLoggedIn ? (
                    <>
                      <button 
                        onClick={() => navigate('/profile')}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left"
                      >
                        <span className="text-[15px]">View profile</span>
                      </button>
                      <button 
                        onClick={() => {
                          if (sellerProfile?.store_slug) {
                            navigate('/business/' + sellerProfile.store_slug);
                          } else if (sellerProfile?.business_name) {
                            const slug = sellerProfile.business_name.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
                            navigate('/business/' + slug);
                          } else {
                            navigate('/profile');
                          }
                        }}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left"
                      >
                        <Store className="w-5 h-5" />
                        <span className="text-[15px]">My Store</span>
                      </button>
                      <button 
                        onClick={() => navigate('/account-settings')}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left"
                      >
                        <span className="text-[15px]">Settings</span>
                      </button>
                      <button 
                        onClick={handleSignOut}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left text-destructive"
                      >
                        <LogOut className="w-5 h-5" />
                        <span className="text-[15px]">Sign out</span>
                      </button>
                    </>
                  ) : (
                    <button 
                      onClick={handleSignIn}
                      className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left text-primary"
                    >
                      <LogIn className="w-5 h-5" />
                      <span className="text-[15px]">Sign in</span>
                    </button>
                  )}
                </div>
              </PopoverContent>
            </Popover>
          ) : (
            <Popover>
              <PopoverTrigger asChild>
                <button 
                  className="flex items-center justify-center w-12 h-12 rounded-full hover:bg-accent/10 transition-all duration-200"
                >
                  <Avatar className="w-10 h-10">
                    <AvatarImage src={user?.user_metadata?.avatar_url} />
                    <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                      {userInitial}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </PopoverTrigger>
              <PopoverContent 
                side="right" 
                align="end" 
                className="w-64 p-0 bg-background border border-border shadow-xl rounded-2xl overflow-hidden z-[200]"
              >
                <div className="p-4 border-b border-border">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={user?.user_metadata?.avatar_url} />
                      <AvatarFallback className="bg-primary/10 text-primary font-semibold text-lg">
                        {userInitial}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold truncate">{userName}</p>
                      <p className="text-sm text-muted-foreground truncate">
                        {isLoggedIn ? `@${userName.toLowerCase()}` : 'Not signed in'}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="py-2">
                  {isLoggedIn ? (
                    <>
                      <button 
                        onClick={() => navigate('/profile')}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left"
                      >
                        <span className="text-[15px]">View profile</span>
                      </button>
                      <button 
                        onClick={() => {
                          if (sellerProfile?.store_slug) {
                            navigate('/business/' + sellerProfile.store_slug);
                          } else if (sellerProfile?.business_name) {
                            const slug = sellerProfile.business_name.toLowerCase().trim().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '');
                            navigate('/business/' + slug);
                          } else {
                            navigate('/profile');
                          }
                        }}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left"
                      >
                        <Store className="w-5 h-5" />
                        <span className="text-[15px]">My Store</span>
                      </button>
                      <button 
                        onClick={() => navigate('/account-settings')}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left"
                      >
                        <span className="text-[15px]">Settings</span>
                      </button>
                      <button 
                        onClick={handleSignOut}
                        className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left text-destructive"
                      >
                        <LogOut className="w-5 h-5" />
                        <span className="text-[15px]">Sign out</span>
                      </button>
                    </>
                  ) : (
                    <button 
                      onClick={handleSignIn}
                      className="flex items-center gap-3 px-4 py-3 hover:bg-accent/10 transition-colors w-full text-left text-primary"
                    >
                      <LogIn className="w-5 h-5" />
                      <span className="text-[15px]">Sign in</span>
                    </button>
                  )}
                </div>
              </PopoverContent>
            </Popover>
          )}
        </div>
      </div>
    </TooltipProvider>
  );
};

export default LeftSidebar;