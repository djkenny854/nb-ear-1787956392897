import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { Pencil, Share2, Trash2, Tag, MoreHorizontal, XCircle, Power, Percent, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

interface ProfilePromotionCardProps {
  id: string;
  title: string;
  description?: string | null;
  imageUrl: string | null;
  price?: number | null;
  originalPrice?: number | null;
  status?: string;
  category?: string;
  viewCount?: number;
  hasDiscount?: boolean;
  discountPercent?: number;
  onEdit?: () => void;
  onShare?: () => void;
  onDelete?: () => void;
  onBoost?: () => void;
  onStatusChange?: (status: string) => void;
}

const ProfilePromotionCard: React.FC<ProfilePromotionCardProps> = ({
  id,
  title,
  description,
  imageUrl,
  status,
  category,
  viewCount = 0,
  hasDiscount,
  discountPercent = 0,
  onEdit,
  onShare,
  onDelete,
  onStatusChange,
}) => {
  const navigate = useNavigate();
  const stopProp = (e: React.MouseEvent) => e.stopPropagation();

  // Fetch linked products and promotion details for avatars + countdown
  const { data: promoInfo } = useQuery({
    queryKey: ['profile-promo-info', id],
    queryFn: async () => {
      const { data: promoDetails } = await supabase
        .from('promotion_details')
        .select('id, is_seller_wide, valid_until')
        .eq('ad_id', id)
        .maybeSingle();
      if (!promoDetails) return { products: [], validUntil: null };
      const { data: linked } = await supabase
        .from('promotion_products')
        .select('ad_id')
        .eq('promotion_id', promoDetails.id)
        .limit(5);
      let products: any[] = [];
      if (linked && linked.length > 0) {
        const productIds = linked.map(p => p.ad_id);
        const { data: prods } = await supabase
          .from('ads')
          .select('id, title, images')
          .in('id', productIds);
        products = prods || [];
      }
      return { products, validUntil: promoDetails.valid_until };
    },
    staleTime: 1000 * 60 * 5,
  });

  const linkedProducts = promoInfo?.products || [];
  const validUntil = promoInfo?.validUntil;

  // Countdown timer
  const [timeLeft, setTimeLeft] = useState('');
  useEffect(() => {
    if (!validUntil) return;
    const update = () => {
      const diff = new Date(validUntil).getTime() - Date.now();
      if (diff <= 0) { setTimeLeft('Ended'); return; }
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      if (days > 0) setTimeLeft(`${days}d ${hours}h left`);
      else if (hours > 0) setTimeLeft(`${hours}h ${mins}m left`);
      else setTimeLeft(`${mins}m left`);
    };
    update();
    const interval = setInterval(update, 60000);
    return () => clearInterval(interval);
  }, [validUntil]);

  const statusStyles: Record<string, string> = {
    active: 'bg-green-500/10 text-green-600 border-green-500/20',
    inactive: 'bg-yellow-500/10 text-yellow-600 border-yellow-500/20',
  };

  return (
    <div
      className="bg-card border border-border rounded-xl overflow-hidden cursor-pointer hover:shadow-md transition-shadow group"
      onClick={() => navigate(`/promotion/${id}`)}
    >
      {imageUrl && (
        <div className="relative h-32 overflow-hidden">
          <img src={imageUrl} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
          {hasDiscount && discountPercent > 0 && (
            <Badge className="absolute top-2 left-2 bg-destructive text-destructive-foreground text-[10px] px-1.5 py-0.5">
              -{discountPercent}% OFF
            </Badge>
          )}
        </div>
      )}

      <div className="p-3 space-y-1.5">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-sm text-foreground line-clamp-1">{title}</h3>
          {status && (
            <Badge variant="outline" className={cn("text-[10px] px-1.5 py-0 flex-shrink-0", statusStyles[status])}>
              {status}
            </Badge>
          )}
        </div>

        {description && (
          <p className="text-xs text-muted-foreground line-clamp-2">{description}</p>
        )}

        <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
          {category && (
            <span className="flex items-center gap-0.5">
              <Tag className="w-2.5 h-2.5" />{category}
            </span>
          )}
          {viewCount > 0 && <span>{viewCount} views</span>}
          {timeLeft && (
            <span className="flex items-center gap-0.5 text-amber-600">
              <Clock className="w-2.5 h-2.5" />{timeLeft}
            </span>
          )}
        </div>

        {/* Product avatars instead of price */}
        {linkedProducts && linkedProducts.length > 0 ? (
          <div className="flex items-center gap-1.5">
            <div className="flex -space-x-2">
              {linkedProducts.slice(0, 4).map((product: any) => (
                <Avatar key={product.id} className="w-6 h-6 border-2 border-background">
                  <AvatarImage src={product.images?.[0]} />
                  <AvatarFallback className="text-[8px] bg-muted">
                    {product.title?.charAt(0) || '?'}
                  </AvatarFallback>
                </Avatar>
              ))}
            </div>
            <span className="text-[10px] text-muted-foreground">
              {linkedProducts.length} product{linkedProducts.length > 1 ? 's' : ''}
            </span>
          </div>
        ) : hasDiscount && discountPercent > 0 ? (
          <div className="flex items-center gap-1">
            <Percent className="w-3 h-3 text-destructive" />
            <span className="text-sm font-bold text-destructive">{discountPercent}% off</span>
          </div>
        ) : null}
      </div>

      {/* Action bar */}
      <div className="flex items-center gap-1 px-3 pb-2.5 pt-0">
        {onEdit && (
          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1" onClick={(e) => { stopProp(e); onEdit(); }}>
            <Pencil className="w-3 h-3" />Edit
          </Button>
        )}
        {onShare && (
          <Button size="sm" variant="ghost" className="h-7 px-2 text-xs gap-1" onClick={(e) => { stopProp(e); onShare(); }}>
            <Share2 className="w-3 h-3" />Share
          </Button>
        )}

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button size="icon" variant="ghost" className="h-7 w-7 ml-auto" onClick={stopProp}>
              <MoreHorizontal className="w-3.5 h-3.5" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" onClick={stopProp}>
            {onStatusChange && (
              <>
                {status === 'active' && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('inactive'); }}>
                    <XCircle className="w-4 h-4 mr-2 text-yellow-500" />Deactivate
                  </DropdownMenuItem>
                )}
                {status === 'inactive' && (
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onStatusChange('active'); }}>
                    <Power className="w-4 h-4 mr-2 text-green-500" />Reactivate
                  </DropdownMenuItem>
                )}
              </>
            )}
            {onDelete && (
              <>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); onDelete(); }} className="text-destructive focus:text-destructive">
                  <Trash2 className="w-4 h-4 mr-2" />Delete
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
};

export default ProfilePromotionCard;
