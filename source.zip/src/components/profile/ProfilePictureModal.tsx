import React from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Share2, Download, X } from 'lucide-react';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { toast } from 'sonner';

interface ProfilePictureModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  imageUrl?: string | null;
  fallback: string;
  profileName: string;
  profileUrl?: string;
}

const ProfilePictureModal: React.FC<ProfilePictureModalProps> = ({
  open,
  onOpenChange,
  imageUrl,
  fallback,
  profileName,
  profileUrl,
}) => {
  const handleShare = async () => {
    const url = profileUrl || window.location.href;
    if (navigator.share) {
      try {
        await navigator.share({ title: profileName, url });
      } catch {}
    } else {
      navigator.clipboard.writeText(url);
      toast.success('Profile link copied!');
    }
  };

  const handleDownload = () => {
    if (!imageUrl) return;
    const a = document.createElement('a');
    a.href = imageUrl;
    a.download = `${profileName.replace(/\s+/g, '-')}-profile.jpg`;
    a.target = '_blank';
    a.click();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md p-0 bg-black/95 border-none overflow-hidden">
        {/* Close button */}
        <button
          onClick={() => onOpenChange(false)}
          className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-background/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-background/40 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Image */}
        <div className="flex items-center justify-center min-h-[300px] p-6">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={profileName}
              className="max-w-full max-h-[60vh] rounded-2xl object-contain"
            />
          ) : (
            <div className="w-48 h-48 rounded-full bg-primary/20 flex items-center justify-center">
              <span className="text-6xl font-bold text-primary">{fallback}</span>
            </div>
          )}
        </div>

        {/* Name & Actions */}
        <div className="p-4 bg-background/10 backdrop-blur-sm flex items-center justify-between">
          <p className="text-white font-semibold truncate">{profileName}</p>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/20 rounded-full"
              onClick={handleShare}
            >
              <Share2 className="w-5 h-5" />
            </Button>
            {imageUrl && (
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/20 rounded-full"
                onClick={handleDownload}
              >
                <Download className="w-5 h-5" />
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ProfilePictureModal;
