import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { Button } from '@/components/ui/button';
import { Trash2, MessageSquare, Heart, Eye, Image as ImageIcon, Play } from 'lucide-react';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

interface MyPostsTabProps {
  /** Profile owner whose posts to display. Defaults to the logged-in user. */
  userId?: string;
}

const MyPostsTab: React.FC<MyPostsTabProps> = ({ userId }) => {
  const { user } = useAuth();
  const targetUserId = userId || user?.id;
  const isOwner = !!user?.id && user.id === targetUserId;
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const { data: posts, isLoading } = useQuery({
    queryKey: ['my-posts', targetUserId, isOwner],
    enabled: !!targetUserId,
    queryFn: async () => {
      let q = supabase
        .from('posts')
        .select('id, content, images, video_url, created_at, like_count, comment_count, view_count, is_active')
        .eq('user_id', targetUserId!)
        .order('created_at', { ascending: false });
      // Other people's profiles only see active posts (RLS would enforce this anyway).
      if (!isOwner) q = q.eq('is_active', true);
      const { data, error } = await q;
      if (error) {
        console.error('[MyPostsTab] query error', error);
        throw error;
      }
      return data || [];
    },
  });

  const handleDelete = async () => {
    if (!pendingDeleteId) return;
    setDeleting(true);
    try {
      const { error } = await supabase.from('posts').delete().eq('id', pendingDeleteId);
      if (error) throw error;
      toast.success('Post deleted');
      queryClient.invalidateQueries({ queryKey: ['my-posts', targetUserId, isOwner] });
    } catch (e: any) {
      toast.error(e.message || 'Failed to delete post');
    } finally {
      setDeleting(false);
      setPendingDeleteId(null);
    }
  };

  if (isLoading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1 p-1">
        {[0, 1, 2, 3].map((i) => (
          <Skeleton key={i} className="aspect-square rounded-md" />
        ))}
      </div>
    );
  }

  if (!posts || posts.length === 0) {
    return (
      <div className="p-16 text-center border-b border-border">
        <MessageSquare className="w-16 h-16 mx-auto text-muted-foreground mb-4 opacity-50" />
        <h3 className="font-bold text-2xl mb-2">No posts yet</h3>
        <p className="text-muted-foreground">Your published posts will appear here.</p>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1 p-1">
        {posts.map((p: any) => {
          const thumb = p.images?.[0];
          const hasVideo = !!p.video_url;
          return (
            <div
              key={p.id}
              onClick={() => navigate(`/post/${p.id}`)}
              className="relative group aspect-square bg-muted overflow-hidden rounded-md cursor-pointer"
            >
              {thumb ? (
                <img src={thumb} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                  <ImageIcon className="w-8 h-8 opacity-50" />
                </div>
              )}

              {hasVideo && (
                <div className="absolute top-2 right-2 bg-black/60 rounded-full p-1">
                  <Play className="w-3 h-3 text-white fill-white" />
                </div>
              )}

              {/* Overlay with stats + delete */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex flex-col justify-between p-2 opacity-0 group-hover:opacity-100">
                <div className="flex justify-end">
                  {isOwner && (
                    <Button
                      size="icon"
                      variant="destructive"
                      className="h-8 w-8 rounded-full"
                      onClick={(e) => { e.stopPropagation(); setPendingDeleteId(p.id); }}
                      aria-label="Delete post"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
                <div className="flex items-center justify-center gap-3 text-white text-xs font-medium">
                  <span className="flex items-center gap-1"><Heart className="w-3.5 h-3.5" />{p.like_count || 0}</span>
                  <span className="flex items-center gap-1"><MessageSquare className="w-3.5 h-3.5" />{p.comment_count || 0}</span>
                  <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" />{p.view_count || 0}</span>
                </div>
              </div>

              {/* Always-visible mobile delete (owner only) */}
              {isOwner && (
                <Button
                  size="icon"
                  variant="secondary"
                  className="absolute top-1.5 left-1.5 h-7 w-7 rounded-full sm:hidden bg-background/80"
                  onClick={(e) => { e.stopPropagation(); setPendingDeleteId(p.id); }}
                  aria-label="Delete post"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              )}
            </div>
          );
        })}
      </div>

      <AlertDialog open={!!pendingDeleteId} onOpenChange={(o) => !o && setPendingDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this post?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. The post will be permanently removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={deleting}>
              {deleting ? 'Deleting…' : 'Delete'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default MyPostsTab;
