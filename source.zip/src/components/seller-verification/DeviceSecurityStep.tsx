import React from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  Laptop, 
  Smartphone,
  Monitor,
  Tablet,
  CheckCircle2,
  LogOut,
  Clock,
  MapPin,
  Shield,
  Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

interface DeviceSecurityStepProps {
  userId: string;
}

const DeviceSecurityStep: React.FC<DeviceSecurityStepProps> = ({ userId }) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: devices, isLoading } = useQuery({
    queryKey: ['user-devices', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('user_devices')
        .select('*')
        .eq('user_id', userId)
        .order('last_active_at', { ascending: false });
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!userId
  });

  const { data: loginHistory } = useQuery({
    queryKey: ['login-history', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('user_login_history')
        .select('*')
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(10);
      
      if (error) throw error;
      return data || [];
    },
    enabled: !!userId
  });

  const logoutAllMutation = useMutation({
    mutationFn: async () => {
      const { error } = await supabase.auth.signOut({ scope: 'others' });
      if (error) throw error;
      
      // Mark all devices as not current
      await supabase
        .from('user_devices')
        .update({ is_current: false })
        .eq('user_id', userId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user-devices'] });
      toast({
        title: 'Logged Out',
        description: 'All other devices have been logged out.',
      });
    },
    onError: () => {
      toast({
        title: 'Error',
        description: 'Could not log out from other devices.',
        variant: 'destructive',
      });
    }
  });

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'mobile': return Smartphone;
      case 'tablet': return Tablet;
      case 'desktop': return Monitor;
      default: return Laptop;
    }
  };

  // If no devices recorded, show helpful message
  if (!isLoading && (!devices || devices.length === 0)) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full bg-primary/10">
            <Laptop className="w-8 h-8 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Login Security</h2>
            <p className="text-muted-foreground">Manage your devices and login history</p>
          </div>
        </div>

        <div className="p-6 rounded-xl bg-muted/50 border text-center">
          <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="font-semibold mb-2">No Devices Recorded</h3>
          <p className="text-sm text-muted-foreground mb-4">
            Device tracking will begin with your next login. Your current session is secure.
          </p>
          <div className="flex items-center justify-center gap-2 text-green-600">
            <CheckCircle2 className="w-5 h-5" />
            <span className="font-medium">Current session is active</span>
          </div>
        </div>

        <div className="p-4 rounded-lg bg-blue-50 dark:bg-blue-950/20 border border-blue-200">
          <h4 className="font-medium mb-2 flex items-center gap-2">
            <Shield className="w-4 h-4 text-blue-600" />
            Security Tips
          </h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Enable 2FA for extra security</li>
            <li>• Regularly review your login history</li>
            <li>• Log out from devices you don't recognize</li>
            <li>• Use strong, unique passwords</li>
          </ul>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-3 rounded-full bg-primary/10">
          <Laptop className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Login Security</h2>
          <p className="text-muted-foreground">Manage your devices and login history</p>
        </div>
      </div>

      {/* Devices List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-semibold">Active Devices</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={() => logoutAllMutation.mutate()}
            disabled={logoutAllMutation.isPending}
          >
            {logoutAllMutation.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <LogOut className="w-4 h-4 mr-2" />
            )}
            Log Out All Devices
          </Button>
        </div>

        {isLoading ? (
          <div className="p-8 text-center">
            <Loader2 className="w-8 h-8 animate-spin mx-auto text-muted-foreground" />
          </div>
        ) : (
          <div className="space-y-2">
            {devices?.map((device) => {
              const DeviceIcon = getDeviceIcon(device.device_type);
              
              return (
                <div
                  key={device.id}
                  className={cn(
                    'flex items-center justify-between p-4 rounded-xl border',
                    device.is_current && 'bg-green-50/50 dark:bg-green-950/20 border-green-200'
                  )}
                >
                  <div className="flex items-center gap-3">
                    <DeviceIcon className="w-6 h-6 text-muted-foreground" />
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{device.device_name || 'Unknown Device'}</p>
                        {device.is_current && (
                          <Badge className="bg-green-500/10 text-green-600 border-green-500/20">
                            Current
                          </Badge>
                        )}
                        {device.is_trusted && (
                          <Badge variant="outline">Trusted</Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground mt-1">
                        <span>{device.browser} on {device.os}</span>
                        {device.location && (
                          <span className="flex items-center gap-1">
                            <MapPin className="w-3 h-3" />
                            {device.location}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {device.last_active_at 
                      ? format(new Date(device.last_active_at), 'MMM d, HH:mm')
                      : 'Unknown'}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Recent Login History */}
      {loginHistory && loginHistory.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold">Recent Login Activity</h3>
          <div className="space-y-2">
            {loginHistory.map((login) => (
              <div
                key={login.id}
                className={cn(
                  'flex items-center justify-between p-3 rounded-lg border text-sm',
                  login.login_status === 'failed' && 'bg-red-50/50 dark:bg-red-950/20 border-red-200'
                )}
              >
                <div className="flex items-center gap-2">
                  {login.login_status === 'success' ? (
                    <CheckCircle2 className="w-4 h-4 text-green-600" />
                  ) : (
                    <Shield className="w-4 h-4 text-red-600" />
                  )}
                  <span>{login.login_method} login</span>
                  {login.login_status === 'failed' && (
                    <Badge variant="destructive" className="text-xs">Failed</Badge>
                  )}
                </div>
                <span className="text-xs text-muted-foreground">
                  {format(new Date(login.created_at), 'MMM d, HH:mm')}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="p-4 rounded-lg bg-green-50 dark:bg-green-950/20 border border-green-200">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-green-600" />
          <span className="text-sm font-medium text-green-900 dark:text-green-100">
            Your account security is being monitored
          </span>
        </div>
      </div>
    </div>
  );
};

export default DeviceSecurityStep;