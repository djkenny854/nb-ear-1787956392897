import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ugandaDistricts } from '@/data/ugandaDistricts';
import { 
  FileText, 
  CheckCircle2, 
  Loader2,
  Clock,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface KYCFormStepProps {
  verificationData: any;
  onComplete: () => void;
}

const KYCFormStep: React.FC<KYCFormStepProps> = ({
  verificationData,
  onComplete
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [submitting, setSubmitting] = useState(false);
  
  const [formData, setFormData] = useState({
    fullLegalName: verificationData?.full_legal_name || '',
    ninNumber: verificationData?.nin_number || '',
    dateOfBirth: verificationData?.date_of_birth || '',
    gender: verificationData?.gender || '',
    residentialDistrict: verificationData?.residential_district || '',
    businessName: verificationData?.business_name || '',
    sellerBio: verificationData?.seller_bio || '',
    termsAccepted: verificationData?.terms_accepted || false,
  });

  const [signature, setSignature] = useState<string | null>(verificationData?.digital_signature_url || null);

  const status = verificationData?.kyc_status || 'not_started';

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    // Validation
    if (!formData.fullLegalName || !formData.ninNumber || !formData.dateOfBirth || 
        !formData.gender || !formData.residentialDistrict || !formData.termsAccepted) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in all required fields and accept the terms.',
        variant: 'destructive',
      });
      return;
    }

    setSubmitting(true);
    try {
      await supabase
        .from('seller_verifications')
        .update({
          full_legal_name: formData.fullLegalName,
          nin_number: formData.ninNumber,
          date_of_birth: formData.dateOfBirth,
          gender: formData.gender,
          residential_district: formData.residentialDistrict,
          business_name: formData.businessName || null,
          seller_bio: formData.sellerBio || null,
          digital_signature_url: signature,
          terms_accepted: formData.termsAccepted,
          terms_accepted_at: new Date().toISOString(),
          kyc_status: 'submitted',
          kyc_submitted_at: new Date().toISOString()
        })
        .eq('user_id', user?.id);

      toast({
        title: 'KYC Submitted',
        description: 'Your KYC information has been submitted for review.',
      });
      onComplete();
    } catch (error: any) {
      toast({
        title: 'Submission Failed',
        description: error.message || 'Could not submit KYC form.',
        variant: 'destructive',
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (status === 'approved') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full bg-green-500/10">
            <FileText className="w-8 h-8 text-green-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Seller KYC</h2>
            <p className="text-muted-foreground">Your KYC has been approved</p>
          </div>
        </div>

        <div className="p-6 rounded-xl bg-green-50 dark:bg-green-950/20 border border-green-200">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            <div>
              <p className="font-semibold text-green-900 dark:text-green-100">KYC Approved</p>
              <p className="text-sm text-green-700 dark:text-green-300">
                {formData.fullLegalName}
              </p>
            </div>
          </div>
        </div>

        <Button onClick={onComplete} className="w-full">
          Continue to 2FA Setup
        </Button>
      </div>
    );
  }

  if (status === 'submitted' || status === 'pending') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full bg-amber-500/10">
            <Clock className="w-8 h-8 text-amber-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Seller KYC</h2>
            <p className="text-muted-foreground">Pending review</p>
          </div>
        </div>

        <div className="p-6 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200">
          <div className="flex items-center gap-3">
            <Clock className="w-6 h-6 text-amber-600" />
            <p className="text-sm text-amber-700 dark:text-amber-300">
              Your KYC information is being reviewed.
            </p>
          </div>
        </div>

        <Button onClick={onComplete} className="w-full">
          Continue to 2FA Setup
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-3 rounded-full bg-primary/10">
          <FileText className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Seller KYC Form</h2>
          <p className="text-muted-foreground">Complete your Know Your Customer information</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Full Legal Name */}
        <div>
          <Label>Full Legal Name <span className="text-red-500">*</span></Label>
          <Input
            value={formData.fullLegalName}
            onChange={(e) => handleInputChange('fullLegalName', e.target.value)}
            placeholder="As it appears on your ID"
            className="mt-2"
          />
        </div>

        {/* NIN Number */}
        <div>
          <Label>NIN Number <span className="text-red-500">*</span></Label>
          <Input
            value={formData.ninNumber}
            onChange={(e) => handleInputChange('ninNumber', e.target.value)}
            placeholder="Enter your National ID Number"
            className="mt-2"
          />
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          {/* Date of Birth */}
          <div>
            <Label>Date of Birth <span className="text-red-500">*</span></Label>
            <Input
              type="date"
              value={formData.dateOfBirth}
              onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
              className="mt-2"
            />
          </div>

          {/* Gender */}
          <div>
            <Label>Gender <span className="text-red-500">*</span></Label>
            <Select
              value={formData.gender}
              onValueChange={(value) => handleInputChange('gender', value)}
            >
              <SelectTrigger className="mt-2">
                <SelectValue placeholder="Select gender" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="male">Male</SelectItem>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* District */}
        <div>
          <Label>Residential District <span className="text-red-500">*</span></Label>
          <Select
            value={formData.residentialDistrict}
            onValueChange={(value) => handleInputChange('residentialDistrict', value)}
          >
            <SelectTrigger className="mt-2">
              <SelectValue placeholder="Select district" />
            </SelectTrigger>
            <SelectContent>
              {ugandaDistricts.map((district) => (
                <SelectItem key={String(district)} value={String(district)}>
                  {String(district)}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Business Name (Optional) */}
        <div>
          <Label>Business Name <span className="text-muted-foreground text-xs">(optional)</span></Label>
          <Input
            value={formData.businessName}
            onChange={(e) => handleInputChange('businessName', e.target.value)}
            placeholder="Your business or shop name"
            className="mt-2"
          />
        </div>

        {/* Seller Bio */}
        <div>
          <Label>Short Seller Bio <span className="text-muted-foreground text-xs">(optional)</span></Label>
          <Textarea
            value={formData.sellerBio}
            onChange={(e) => handleInputChange('sellerBio', e.target.value)}
            placeholder="Tell buyers about yourself and your business..."
            className="mt-2"
            rows={3}
          />
        </div>

        {/* Terms Checkbox */}
        <div className="flex items-start space-x-3 pt-4 border-t">
          <Checkbox
            id="terms"
            checked={formData.termsAccepted}
            onCheckedChange={(checked) => handleInputChange('termsAccepted', !!checked)}
          />
          <div className="grid gap-1.5 leading-none">
            <label
              htmlFor="terms"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              I agree to EarlyMarket Terms & Conditions <span className="text-red-500">*</span>
            </label>
            <p className="text-xs text-muted-foreground">
              By checking this box, I confirm that all information provided is accurate and I agree to the platform's terms of service.
            </p>
          </div>
        </div>
      </div>

      <Button 
        onClick={handleSubmit} 
        disabled={submitting}
        className="w-full"
        size="lg"
      >
        {submitting ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Submitting...
          </>
        ) : (
          'Submit KYC'
        )}
      </Button>
    </div>
  );
};

export default KYCFormStep;