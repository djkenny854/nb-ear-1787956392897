import React, { useState, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { uploadToB2 } from '@/utils/b2Upload';
import { 
  Camera, 
  CheckCircle2, 
  Loader2, 
  Upload,
  Clock,
  XCircle,
  RefreshCw
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface SelfieVerificationStepProps {
  verificationData: any;
  onComplete: () => void;
}

const SelfieVerificationStep: React.FC<SelfieVerificationStepProps> = ({
  verificationData,
  onComplete
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selfiePreview, setSelfiePreview] = useState<string | null>(verificationData?.selfie_url || null);
  const [selfieFile, setSelfieFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const status = verificationData?.selfie_status || 'not_started';

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user', width: 640, height: 480 } 
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        streamRef.current = stream;
        setCameraActive(true);
      }
    } catch (error) {
      toast({
        title: 'Camera Access Denied',
        description: 'Please allow camera access to take a selfie.',
        variant: 'destructive',
      });
    }
  };

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
      setCameraActive(false);
    }
  }, []);

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        
        canvasRef.current.toBlob((blob) => {
          if (blob) {
            const file = new File([blob], 'selfie.jpg', { type: 'image/jpeg' });
            setSelfieFile(file);
            setSelfiePreview(canvasRef.current?.toDataURL('image/jpeg') || null);
            stopCamera();
          }
        }, 'image/jpeg', 0.9);
      }
    }
  };

  const handleFileUpload = (file: File | null) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelfieFile(file);
        setSelfiePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if (!selfieFile) {
      toast({
        title: 'No Selfie',
        description: 'Please take or upload a selfie photo.',
        variant: 'destructive',
      });
      return;
    }

    setUploading(true);
    try {
      // Upload to B2
      const result = await uploadToB2(selfieFile, 'verification/selfie');

      // Verify with AI
      setVerifying(true);
      const selfieBase64 = selfiePreview?.split(',')[1];
      
      const { data: verificationResult, error: verifyError } = await supabase.functions.invoke('verify-id-image', {
        body: {
          imageBase64: selfieBase64,
          imageType: 'selfie'
        }
      });

      if (verifyError) throw verifyError;

      // Update verification record
      await supabase
        .from('seller_verifications')
        .update({
          selfie_url: result.url,
          selfie_status: verificationResult?.isValid ? 'submitted' : 'rejected',
          selfie_rejection_reason: verificationResult?.isValid ? null : verificationResult?.reason,
          face_match_score: verificationResult?.faceMatchScore || null
        })
        .eq('user_id', user?.id);

      if (verificationResult?.isValid) {
        toast({
          title: 'Selfie Submitted',
          description: 'Your selfie has been submitted for review.',
        });
        onComplete();
      } else {
        toast({
          title: 'Verification Failed',
          description: verificationResult?.reason || 'Please take a clearer photo.',
          variant: 'destructive',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Upload Failed',
        description: error.message || 'Could not upload selfie.',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
      setVerifying(false);
    }
  };

  const renderStatusContent = () => {
    if (status === 'approved') {
      return (
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-green-500/10">
              <Camera className="w-8 h-8 text-green-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">Selfie Verification</h2>
              <p className="text-muted-foreground">Your selfie has been verified</p>
            </div>
          </div>

          <div className="p-6 rounded-xl bg-green-50 dark:bg-green-950/20 border border-green-200">
            <div className="flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-green-600" />
              <div>
                <p className="font-semibold text-green-900 dark:text-green-100">Face Verified</p>
                <p className="text-sm text-green-700 dark:text-green-300">
                  Face match score: {verificationData?.face_match_score || 'N/A'}%
                </p>
              </div>
            </div>
          </div>

          <Button onClick={onComplete} className="w-full">
            Continue to Social Media
          </Button>
        </div>
      );
    }

    if (status === 'submitted' || status === 'pending') {
      return (
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-amber-500/10">
              <Clock className="w-8 h-8 text-amber-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">Selfie Verification</h2>
              <p className="text-muted-foreground">Pending review</p>
            </div>
          </div>

          <div className="p-6 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200">
            <div className="flex items-center gap-3">
              <Clock className="w-6 h-6 text-amber-600" />
              <p className="text-sm text-amber-700 dark:text-amber-300">
                Your selfie is being reviewed for face matching.
              </p>
            </div>
          </div>

          <Button onClick={onComplete} className="w-full">
            Continue to Social Media
          </Button>
        </div>
      );
    }

    if (status === 'rejected') {
      return (
        <div className="space-y-6">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-full bg-red-500/10">
              <XCircle className="w-8 h-8 text-red-600" />
            </div>
            <div>
              <h2 className="text-2xl font-bold">Selfie Verification</h2>
              <p className="text-muted-foreground">Please retake your selfie</p>
            </div>
          </div>

          <div className="p-6 rounded-xl bg-red-50 dark:bg-red-950/20 border border-red-200 mb-6">
            <p className="text-sm text-red-700 dark:text-red-300">
              {verificationData?.selfie_rejection_reason || 'Face verification failed. Please take a clearer photo.'}
            </p>
          </div>
        </div>
      );
    }

    return null;
  };

  const statusContent = renderStatusContent();
  if (statusContent && status !== 'rejected') return statusContent;

  return (
    <div className="space-y-6">
      {status !== 'rejected' && (
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full bg-primary/10">
            <Camera className="w-8 h-8 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Selfie Verification</h2>
            <p className="text-muted-foreground">Take a clear selfie for face matching</p>
          </div>
        </div>
      )}

      {status === 'rejected' && statusContent}

      <div className="p-4 rounded-lg bg-muted/50 border">
        <h4 className="font-medium mb-2">Tips for a good selfie:</h4>
        <ul className="text-sm text-muted-foreground space-y-1">
          <li>• Face the camera directly</li>
          <li>• Ensure good lighting on your face</li>
          <li>• Remove glasses and hats</li>
          <li>• Keep a neutral expression</li>
        </ul>
      </div>

      {/* Camera/Upload Area */}
      <div className="relative">
        {cameraActive ? (
          <div className="relative">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full rounded-xl"
            />
            <canvas ref={canvasRef} className="hidden" />
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-3">
              <Button variant="outline" onClick={stopCamera}>
                Cancel
              </Button>
              <Button onClick={capturePhoto} size="lg">
                <Camera className="w-4 h-4 mr-2" />
                Capture
              </Button>
            </div>
          </div>
        ) : selfiePreview ? (
          <div className="relative">
            <img 
              src={selfiePreview} 
              alt="Selfie preview" 
              className="w-full max-h-80 object-cover rounded-xl"
            />
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => {
                setSelfiePreview(null);
                setSelfieFile(null);
              }}
              className="absolute top-2 right-2"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Retake
            </Button>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            <button
              onClick={startCamera}
              className="flex flex-col items-center justify-center h-40 border-2 border-dashed rounded-xl hover:border-primary transition-colors"
            >
              <Camera className="w-10 h-10 text-muted-foreground mb-2" />
              <span className="text-sm font-medium">Take Selfie</span>
              <span className="text-xs text-muted-foreground">Use camera</span>
            </button>

            <label className="flex flex-col items-center justify-center h-40 border-2 border-dashed rounded-xl hover:border-primary transition-colors cursor-pointer">
              <Upload className="w-10 h-10 text-muted-foreground mb-2" />
              <span className="text-sm font-medium">Upload Photo</span>
              <span className="text-xs text-muted-foreground">From device</span>
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleFileUpload(e.target.files?.[0] || null)}
                className="hidden"
              />
            </label>
          </div>
        )}
      </div>

      <Button 
        onClick={handleSubmit} 
        disabled={uploading || verifying || !selfiePreview}
        className="w-full"
        size="lg"
      >
        {uploading || verifying ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            {verifying ? 'Verifying face...' : 'Uploading...'}
          </>
        ) : (
          'Submit Selfie'
        )}
      </Button>
    </div>
  );
};

export default SelfieVerificationStep;