import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Mail, 
  CheckCircle2, 
  Loader2, 
  Send,
  RefreshCw
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface EmailVerificationStepProps {
  verificationData: any;
  onComplete: () => void;
}

const EmailVerificationStep: React.FC<EmailVerificationStepProps> = ({
  verificationData,
  onComplete
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);

  const isVerified = verificationData?.email_verified;
  const userEmail = user?.email;

  const handleSendVerification = async () => {
    if (!userEmail) return;
    
    setSending(true);
    try {
      // Send verification email via Supabase Auth
      const { error } = await supabase.auth.resend({
        type: 'signup',
        email: userEmail,
      });

      if (error) throw error;

      // Update verification record
      await supabase
        .from('seller_verifications')
        .update({
          email_verification_sent_at: new Date().toISOString()
        })
        .eq('user_id', user?.id);

      setSent(true);
      toast({
        title: 'Verification Email Sent',
        description: 'Check your inbox and click the verification link.',
      });
    } catch (error: any) {
      toast({
        title: 'Failed to Send',
        description: error.message || 'Could not send verification email.',
        variant: 'destructive',
      });
    } finally {
      setSending(false);
    }
  };

  const handleCheckStatus = async () => {
    try {
      const { data: { user: refreshedUser }, error } = await supabase.auth.getUser();
      
      if (error) throw error;
      
      if (refreshedUser?.email_confirmed_at) {
        // Update verification record
        await supabase
          .from('seller_verifications')
          .update({
            email_verified: true,
            email_verified_at: new Date().toISOString()
          })
          .eq('user_id', user?.id);
        
        toast({
          title: 'Email Verified!',
          description: 'Your email has been successfully verified.',
        });
        onComplete();
      } else {
        toast({
          title: 'Not Yet Verified',
          description: 'Please check your email and click the verification link.',
          variant: 'destructive',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Error',
        description: 'Could not check verification status.',
        variant: 'destructive',
      });
    }
  };

  if (isVerified) {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full bg-green-500/10">
            <Mail className="w-8 h-8 text-green-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Email Verification</h2>
            <p className="text-muted-foreground">Your email is verified</p>
          </div>
        </div>

        <div className="p-6 rounded-xl bg-green-50 dark:bg-green-950/20 border border-green-200">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            <div>
              <p className="font-semibold text-green-900 dark:text-green-100">Email Verified</p>
              <p className="text-sm text-green-700 dark:text-green-300">{userEmail}</p>
            </div>
          </div>
        </div>

        <Button onClick={onComplete} className="w-full">
          Continue to Phone Verification
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-3 rounded-full bg-primary/10">
          <Mail className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Email Verification</h2>
          <p className="text-muted-foreground">Verify your email address to continue</p>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <Label>Your Email Address</Label>
          <Input 
            value={userEmail || ''} 
            disabled 
            className="mt-2 bg-muted"
          />
        </div>

        {sent ? (
          <div className="p-6 rounded-xl bg-blue-50 dark:bg-blue-950/20 border border-blue-200 text-center">
            <Send className="w-12 h-12 text-blue-600 mx-auto mb-4" />
            <h3 className="font-semibold text-lg mb-2">Verification Email Sent!</h3>
            <p className="text-sm text-muted-foreground mb-4">
              We've sent a verification link to <strong>{userEmail}</strong>. 
              Check your inbox and click the link to verify.
            </p>
            <div className="flex gap-3 justify-center">
              <Button 
                variant="outline" 
                onClick={handleSendVerification}
                disabled={sending}
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Resend Email
              </Button>
              <Button onClick={handleCheckStatus}>
                I've Verified
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 rounded-lg bg-muted/50 border">
              <h4 className="font-medium mb-2">What happens next?</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• We'll send a verification link to your email</li>
                <li>• Click the link to verify your email address</li>
                <li>• Return here and click "I've Verified"</li>
              </ul>
            </div>

            <Button 
              onClick={handleSendVerification} 
              disabled={sending}
              className="w-full"
              size="lg"
            >
              {sending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Send Verification Email
                </>
              )}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default EmailVerificationStep;