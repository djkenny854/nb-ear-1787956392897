import React, { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card } from '@/components/ui/card';
import { uploadToB2 } from '@/utils/b2Upload';
import { 
  CreditCard, 
  CheckCircle2, 
  Loader2, 
  Upload,
  Shield,
  Clock,
  XCircle,
  AlertCircle
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface GovernmentIDStepProps {
  verificationData: any;
  onComplete: () => void;
}

const GovernmentIDStep: React.FC<GovernmentIDStepProps> = ({
  verificationData,
  onComplete
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [idType, setIdType] = useState<'national_id' | 'passport' | 'drivers_license' | null>(
    verificationData?.id_type || null
  );
  const [idNumber, setIdNumber] = useState(verificationData?.id_number || '');
  const [frontImage, setFrontImage] = useState<File | null>(null);
  const [backImage, setBackImage] = useState<File | null>(null);
  const [frontPreview, setFrontPreview] = useState<string | null>(verificationData?.id_front_url || null);
  const [backPreview, setBackPreview] = useState<string | null>(verificationData?.id_back_url || null);
  const [uploading, setUploading] = useState(false);
  const [verifying, setVerifying] = useState(false);

  const status = verificationData?.id_status || 'not_started';

  const idTypes = [
    { id: 'national_id' as const, label: 'National ID (NIN)', icon: CreditCard },
    { id: 'passport' as const, label: 'Passport', icon: Shield },
    { id: 'drivers_license' as const, label: "Driver's License", icon: Shield },
  ];

  const handleFileChange = (type: 'front' | 'back', file: File | null) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (type === 'front') {
          setFrontImage(file);
          setFrontPreview(reader.result as string);
        } else {
          setBackImage(file);
          setBackPreview(reader.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async () => {
    if (!idType || !idNumber || !frontImage || (idType !== 'passport' && !backImage)) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in all required fields and upload images.',
        variant: 'destructive',
      });
      return;
    }

    setUploading(true);
    try {
      // Upload images to B2
      const uploadPromises = [
        uploadToB2(frontImage, 'verification/id-front'),
      ];
      if (idType !== 'passport' && backImage) {
        uploadPromises.push(uploadToB2(backImage, 'verification/id-back'));
      }

      const results = await Promise.all(uploadPromises);
      const frontUrl = results[0].url;
      const backUrl = results[1]?.url || null;

      // Verify with AI
      setVerifying(true);
      const frontBase64 = frontPreview?.split(',')[1];
      
      const { data: verificationResult, error: verifyError } = await supabase.functions.invoke('verify-id-image', {
        body: {
          imageBase64: frontBase64,
          imageType: 'id_front',
          selectedIdType: idType
        }
      });

      if (verifyError) throw verifyError;

      // Update verification record
      await supabase
        .from('seller_verifications')
        .update({
          id_type: idType,
          id_number: idNumber,
          id_front_url: frontUrl,
          id_back_url: backUrl,
          id_status: verificationResult?.isValid ? 'submitted' : 'rejected',
          id_rejection_reason: verificationResult?.isValid ? null : verificationResult?.reason
        })
        .eq('user_id', user?.id);

      if (verificationResult?.isValid) {
        toast({
          title: 'ID Submitted',
          description: 'Your government ID has been submitted for review.',
        });
        onComplete();
      } else {
        toast({
          title: 'Verification Failed',
          description: verificationResult?.reason || 'Please upload a clearer image.',
          variant: 'destructive',
        });
      }
    } catch (error: any) {
      toast({
        title: 'Upload Failed',
        description: error.message || 'Could not upload images.',
        variant: 'destructive',
      });
    } finally {
      setUploading(false);
      setVerifying(false);
    }
  };

  if (status === 'approved') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full bg-green-500/10">
            <CreditCard className="w-8 h-8 text-green-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Government ID</h2>
            <p className="text-muted-foreground">Your ID has been verified</p>
          </div>
        </div>

        <div className="p-6 rounded-xl bg-green-50 dark:bg-green-950/20 border border-green-200">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            <div>
              <p className="font-semibold text-green-900 dark:text-green-100">ID Verified</p>
              <p className="text-sm text-green-700 dark:text-green-300">
                {verificationData?.id_type?.replace('_', ' ')} - {verificationData?.id_number}
              </p>
            </div>
          </div>
        </div>

        <Button onClick={onComplete} className="w-full">
          Continue to Selfie Verification
        </Button>
      </div>
    );
  }

  if (status === 'submitted' || status === 'pending') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full bg-amber-500/10">
            <Clock className="w-8 h-8 text-amber-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Government ID</h2>
            <p className="text-muted-foreground">Pending review</p>
          </div>
        </div>

        <div className="p-6 rounded-xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200">
          <div className="flex items-center gap-3">
            <Clock className="w-6 h-6 text-amber-600" />
            <div>
              <p className="font-semibold text-amber-900 dark:text-amber-100">Under Review</p>
              <p className="text-sm text-amber-700 dark:text-amber-300">
                Your ID is being reviewed. This usually takes 1-2 business days.
              </p>
            </div>
          </div>
        </div>

        <Button onClick={onComplete} className="w-full">
          Continue to Selfie Verification
        </Button>
      </div>
    );
  }

  if (status === 'rejected') {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-full bg-red-500/10">
            <XCircle className="w-8 h-8 text-red-600" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Government ID</h2>
            <p className="text-muted-foreground">Verification rejected</p>
          </div>
        </div>

        <div className="p-6 rounded-xl bg-red-50 dark:bg-red-950/20 border border-red-200">
          <div className="flex items-start gap-3">
            <XCircle className="w-6 h-6 text-red-600 flex-shrink-0" />
            <div>
              <p className="font-semibold text-red-900 dark:text-red-100">Rejected</p>
              <p className="text-sm text-red-700 dark:text-red-300">
                {verificationData?.id_rejection_reason || 'Please upload clearer images and try again.'}
              </p>
            </div>
          </div>
        </div>

        {/* Show upload form for re-upload */}
        <IDUploadForm 
          idType={idType}
          setIdType={setIdType}
          idNumber={idNumber}
          setIdNumber={setIdNumber}
          frontPreview={frontPreview}
          backPreview={backPreview}
          handleFileChange={handleFileChange}
          handleSubmit={handleSubmit}
          uploading={uploading}
          verifying={verifying}
          idTypes={idTypes}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-3 rounded-full bg-primary/10">
          <CreditCard className="w-8 h-8 text-primary" />
        </div>
        <div>
          <h2 className="text-2xl font-bold">Government ID Upload</h2>
          <p className="text-muted-foreground">Upload your government-issued ID</p>
        </div>
      </div>

      <IDUploadForm 
        idType={idType}
        setIdType={setIdType}
        idNumber={idNumber}
        setIdNumber={setIdNumber}
        frontPreview={frontPreview}
        backPreview={backPreview}
        handleFileChange={handleFileChange}
        handleSubmit={handleSubmit}
        uploading={uploading}
        verifying={verifying}
        idTypes={idTypes}
      />
    </div>
  );
};

interface IDUploadFormProps {
  idType: 'national_id' | 'passport' | 'drivers_license' | null;
  setIdType: (type: 'national_id' | 'passport' | 'drivers_license' | null) => void;
  idNumber: string;
  setIdNumber: (num: string) => void;
  frontPreview: string | null;
  backPreview: string | null;
  handleFileChange: (type: 'front' | 'back', file: File | null) => void;
  handleSubmit: () => void;
  uploading: boolean;
  verifying: boolean;
  idTypes: Array<{ id: 'national_id' | 'passport' | 'drivers_license'; label: string; icon: any }>;
}

const IDUploadForm: React.FC<IDUploadFormProps> = ({
  idType, setIdType, idNumber, setIdNumber,
  frontPreview, backPreview, handleFileChange,
  handleSubmit, uploading, verifying, idTypes
}) => (
  <div className="space-y-6">
    {/* ID Type Selection */}
    <div>
      <Label className="mb-3 block">Select Document Type</Label>
      <div className="grid grid-cols-3 gap-3">
        {idTypes.map((type) => (
          <Card
            key={type.id}
            onClick={() => setIdType(type.id)}
            className={cn(
              'p-4 cursor-pointer transition-all text-center',
              idType === type.id 
                ? 'border-2 border-primary bg-primary/5' 
                : 'border hover:border-primary/50'
            )}
          >
            <type.icon className={cn(
              'w-6 h-6 mx-auto mb-2',
              idType === type.id ? 'text-primary' : 'text-muted-foreground'
            )} />
            <span className="text-xs font-medium">{type.label}</span>
          </Card>
        ))}
      </div>
    </div>

    {/* ID Number */}
    <div>
      <Label>ID Number</Label>
      <Input
        value={idNumber}
        onChange={(e) => setIdNumber(e.target.value)}
        placeholder="Enter your ID number"
        className="mt-2"
      />
    </div>

    {/* Upload Areas */}
    {idType && (
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <Label className="mb-2 block">
            {idType === 'passport' ? 'Passport Photo Page' : 'Front Side'}
          </Label>
          <label className={cn(
            'flex flex-col items-center justify-center h-40 border-2 border-dashed rounded-lg cursor-pointer transition-colors',
            frontPreview ? 'border-green-500 bg-green-50 dark:bg-green-950/20' : 'border-muted-foreground/30 hover:border-primary'
          )}>
            {frontPreview ? (
              <img src={frontPreview} alt="Front" className="h-full w-full object-cover rounded-lg" />
            ) : (
              <>
                <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                <span className="text-sm text-muted-foreground">Click to upload</span>
              </>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={(e) => handleFileChange('front', e.target.files?.[0] || null)}
              className="hidden"
            />
          </label>
        </div>

        {idType !== 'passport' && (
          <div>
            <Label className="mb-2 block">Back Side</Label>
            <label className={cn(
              'flex flex-col items-center justify-center h-40 border-2 border-dashed rounded-lg cursor-pointer transition-colors',
              backPreview ? 'border-green-500 bg-green-50 dark:bg-green-950/20' : 'border-muted-foreground/30 hover:border-primary'
            )}>
              {backPreview ? (
                <img src={backPreview} alt="Back" className="h-full w-full object-cover rounded-lg" />
              ) : (
                <>
                  <Upload className="w-8 h-8 text-muted-foreground mb-2" />
                  <span className="text-sm text-muted-foreground">Click to upload</span>
                </>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleFileChange('back', e.target.files?.[0] || null)}
                className="hidden"
              />
            </label>
          </div>
        )}
      </div>
    )}

    <Button 
      onClick={handleSubmit} 
      disabled={uploading || verifying || !idType || !idNumber || !frontPreview}
      className="w-full"
      size="lg"
    >
      {uploading || verifying ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          {verifying ? 'Verifying...' : 'Uploading...'}
        </>
      ) : (
        'Submit for Verification'
      )}
    </Button>
  </div>
);

export default GovernmentIDStep;