import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Drawer, DrawerContent } from '@/components/ui/drawer';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { useIsMobile } from '@/hooks/use-mobile';
import EarlyMarketAI from '@/pages/EarlyMarketAI';

interface AIQuickChatProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

/** The full EarlyMarket AI experience presented as a drawer/window. */
const AIQuickChat: React.FC<AIQuickChatProps> = ({ open, onOpenChange }) => {
  const navigate = useNavigate();
  const isMobile = useIsMobile();
  const [viewportHeight, setViewportHeight] = useState<number | null>(null);

  useEffect(() => {
    if (!open) return;
    const viewport = window.visualViewport;
    const update = () => setViewportHeight(viewport?.height || window.innerHeight);
    update();
    viewport?.addEventListener('resize', update);
    viewport?.addEventListener('scroll', update);
    return () => {
      viewport?.removeEventListener('resize', update);
      viewport?.removeEventListener('scroll', update);
    };
  }, [open]);

  const expand = () => {
    onOpenChange(false);
    navigate('/ai');
  };

  const body = (
    <EarlyMarketAI compact onClose={() => onOpenChange(false)} onExpand={expand} />
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent
          className="p-0 overflow-hidden rounded-t-2xl [&>button]:hidden [&>div:last-child]:overflow-hidden transition-[height] duration-200 ease-out"
          style={{ height: viewportHeight ? Math.min(viewportHeight * 0.92, viewportHeight - 8) : '92dvh', maxHeight: '92dvh' }}
        >
          {body}
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[760px] p-0 gap-0 h-[760px] max-h-[90vh] overflow-hidden rounded-2xl [&>button]:hidden">
        {body}
      </DialogContent>
    </Dialog>
  );
};

export default AIQuickChat;
