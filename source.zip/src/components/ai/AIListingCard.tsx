import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, Bookmark, BadgeCheck, MapPin, ShoppingBag, Briefcase, Calendar, Tag, Sparkles, GitCompare, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

export interface Listing {
  id: string;
  type?: string;
  title: string;
  price?: number | null;
  currency?: string;
  specs?: [string, string][];
  images?: string[];
  seller?: string;
  seller_url?: string;
  verified?: boolean;
  location?: string;
  url?: string;
}

const TYPE_ICON: Record<string, any> = {
  product: ShoppingBag,
  service: Sparkles,
  job: Briefcase,
  event: Calendar,
  promotion: Tag,
};

const formatPrice = (price?: number | null, currency = 'UGX') => {
  if (price == null) return null;
  try {
    return `${currency} ${price.toLocaleString()}`;
  } catch {
    return `${currency} ${price}`;
  }
};

interface Props {
  listing: Listing;
  isBookmarked: boolean;
  onBookmark: (id: string) => void;
}

const AIListingCard: React.FC<Props> = ({ listing, isBookmarked, onBookmark }) => {
  const TypeIcon = TYPE_ICON[(listing.type || 'product').toLowerCase()] || ShoppingBag;
  const images = (listing.images || []).filter(Boolean).slice(0, 2);
  const price = formatPrice(listing.price ?? undefined, listing.currency || 'UGX');
  const [queued, setQueued] = useState(false);

  useEffect(() => {
    const sync = () => {
      try {
        const q: any[] = JSON.parse(sessionStorage.getItem('em_compare_queue') || '[]');
        setQueued(q.some(x => x.id === listing.id));
      } catch { /* noop */ }
    };
    sync();
    window.addEventListener('em-compare-changed', sync);
    return () => window.removeEventListener('em-compare-changed', sync);
  }, [listing.id]);

  const handleCompare = () => {
    let q: any[] = [];
    try { q = JSON.parse(sessionStorage.getItem('em_compare_queue') || '[]'); } catch {}
    const exists = q.findIndex(x => x.id === listing.id);
    if (exists >= 0) {
      q.splice(exists, 1);
    } else {
      q.push({ id: listing.id, title: listing.title, type: listing.type, seller: listing.seller });
      if (q.length > 4) q = q.slice(-4);
    }
    sessionStorage.setItem('em_compare_queue', JSON.stringify(q));
    window.dispatchEvent(new CustomEvent('em-compare-changed'));

    if (q.length >= 2) {
      // Fire the comparison automatically. Pass IDs explicitly so the AI calls
      // get_listing_by_id to fetch full specs / description / district / images.
      const summary = q.map((x, i) => `${i + 1}) "${x.title}" — id: ${x.id}`).join('\n');
      const prompt = `Compare these ${q.length} EarlyMarket listings side-by-side. For EACH item below, call the get_listing_by_id tool with the given id to fetch its full details (title, price, brand, model, condition, description, specs, district / location, images, seller / owner business name, verification). Then build the comparison table and summary exactly as instructed in the system prompt.\n\n${summary}`;
      sessionStorage.setItem('em_compare_queue', '[]');
      window.dispatchEvent(new CustomEvent('em-compare-changed'));
      window.dispatchEvent(new CustomEvent('em-ai-prompt', { detail: { text: prompt } }));
    }
  };

  return (
    <div className="my-3 rounded-xl border border-border/60 bg-card/60 backdrop-blur p-3 hover:border-border transition-colors">
      <div className="flex items-start gap-2 mb-2">
        <TypeIcon className="w-4 h-4 text-primary mt-0.5 shrink-0" />
        <div className="flex-1 min-w-0">
          <h4 className="font-semibold text-foreground text-sm leading-snug">{listing.title}</h4>
          <div className="flex items-center gap-2 flex-wrap mt-0.5 text-xs text-muted-foreground">
            {listing.seller && (
              listing.seller_url ? (
                <Link to={listing.seller_url} className="hover:text-foreground flex items-center gap-1">
                  {listing.seller}
                  {listing.verified && <BadgeCheck className="w-3 h-3 text-primary" />}
                </Link>
              ) : (
                <span className="flex items-center gap-1">
                  {listing.seller}
                  {listing.verified && <BadgeCheck className="w-3 h-3 text-primary" />}
                </span>
              )
            )}
            {listing.location && (
              <span className="flex items-center gap-1"><MapPin className="w-3 h-3" />{listing.location}</span>
            )}
          </div>
        </div>
        {price && (
          <span className="text-sm font-semibold text-foreground whitespace-nowrap">{price}</span>
        )}
      </div>

      {listing.specs && listing.specs.length > 0 && (
        <div className="grid grid-cols-2 gap-x-3 gap-y-1 mb-2 text-[12px]">
          {listing.specs.slice(0, 4).map(([k, v], i) => (
            <div key={i} className="flex items-center gap-1.5 min-w-0">
              <span className="text-muted-foreground shrink-0">{k}:</span>
              <span className="text-foreground/90 truncate">{v}</span>
            </div>
          ))}
        </div>
      )}

      {images.length > 0 && (
        <div className="flex gap-2 mb-2">
          {images.map((src, i) => (
            <a
              key={i}
              href={src}
              target="_blank"
              rel="noopener noreferrer"
              className="h-20 w-24 sm:h-24 sm:w-28 shrink-0 rounded-lg overflow-hidden bg-muted border border-border/40"
            >
              <img src={src} alt="" loading="lazy" className="w-full h-full object-cover" />
            </a>
          ))}
        </div>
      )}

      <div className="flex items-center gap-2">
        {listing.url && (
          <Link
            to={listing.url}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-foreground text-background text-xs font-medium hover:bg-foreground/90 transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            View listing
          </Link>
        )}
        <button
          onClick={() => onBookmark(listing.id)}
          className={cn(
            'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors',
            isBookmarked
              ? 'bg-primary/10 text-primary border-primary/30'
              : 'bg-muted/40 text-foreground border-border/60 hover:bg-muted'
          )}
        >
          <Bookmark className={cn('w-3.5 h-3.5', isBookmarked && 'fill-current')} />
          {isBookmarked ? 'Saved' : 'Save'}
        </button>
        <button
          onClick={handleCompare}
          title={queued ? 'Remove from comparison' : 'Add to comparison'}
          className={cn(
            'flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-medium border transition-colors',
            queued
              ? 'bg-primary text-primary-foreground border-primary'
              : 'bg-muted/40 text-foreground border-border/60 hover:bg-muted'
          )}
        >
          {queued ? <Check className="w-3.5 h-3.5" /> : <GitCompare className="w-3.5 h-3.5" />}
          {queued ? 'Queued' : 'Compare'}
        </button>
      </div>
    </div>
  );
};

export default AIListingCard;
