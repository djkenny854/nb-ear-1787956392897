import React from 'react';
import EarlyMarketAIIcon from '@/components/icons/EarlyMarketAIIcon';

/**
 * Decorative halo of AI provider logos circling the EarlyMarket AI mark.
 * Surfaces the underlying models powering the assistant: Anthropic Claude,
 * Google Gemini, and OpenAI. Shown on the AI chat empty state.
 */

const AnthropicLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  // Anthropic mark — three angular strokes
  <svg viewBox="0 0 256 176" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path
      fill="#D97757"
      d="M147.486878,0 C153.532233,16.4853595 163.665223,39.6391765 178.885849,68.4614509 C194.106474,97.2837253 207.530802,121.347794 219.158832,140.653171 C225.928835,151.892833 232.59131,162.964512 239.146257,173.868211 L239.146257,173.868211 L191.602192,173.868211 C190.523853,170.74824 188.731843,166.531991 186.226161,161.21946 C183.720479,155.906929 181.836828,151.973365 180.575207,149.418766 L180.575207,149.418766 L75.5384839,149.418766 C72.7660567,155.475487 67.6885156,163.625302 60.3058605,173.868211 L60.3058605,173.868211 L17.0309038,173.868211 C28.4225873,156.171072 39.0492123,138.598223 48.9107788,121.149666 C58.7723452,103.701108 67.2914221,88.3157844 74.4680093,74.9933841 C81.6445966,61.6709837 88.4036399,48.7591574 94.7451391,36.2579053 C101.086638,23.7566532 106.685454,12.6859881 111.541587,3.04588985 L111.541587,3.04588985 Z M128.395918,42.7155869 L94.0654566,113.873932 L162.516716,113.873932 L128.395918,42.7155869 Z"
      transform="translate(-17 0)"
    />
  </svg>
);

const GeminiLogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  // Gemini sparkle mark
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...props}>
    <defs>
      <linearGradient id="gem-g" x1="0" y1="0" x2="24" y2="24" gradientUnits="userSpaceOnUse">
        <stop offset="0" stopColor="#4796E3" />
        <stop offset="0.5" stopColor="#8F6BE7" />
        <stop offset="1" stopColor="#E64BB5" />
      </linearGradient>
    </defs>
    <path fill="url(#gem-g)" d="M12 0c.3 4.6 1.7 8.1 4.2 10.5C18.7 13 22 13.7 24 12c-4.6.3-8.1 1.7-10.5 4.2C11 18.7 10.3 22 12 24c-.3-4.6-1.7-8.1-4.2-10.5C5.3 11 2 10.3 0 12c4.6-.3 8.1-1.7 10.5-4.2C13 5.3 13.7 2 12 0z" />
  </svg>
);

const OpenAILogo: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" {...props}>
    <path
      fill="currentColor"
      d="M22.282 9.821a5.985 5.985 0 0 0-.516-4.91 6.046 6.046 0 0 0-6.51-2.9A6.065 6.065 0 0 0 4.981 4.18a5.985 5.985 0 0 0-3.998 2.9 6.046 6.046 0 0 0 .743 7.097 5.98 5.98 0 0 0 .51 4.911 6.051 6.051 0 0 0 6.515 2.9A5.985 5.985 0 0 0 13.26 24a6.056 6.056 0 0 0 5.772-4.206 5.99 5.99 0 0 0 3.997-2.9 6.056 6.056 0 0 0-.747-7.073zM13.26 22.43a4.476 4.476 0 0 1-2.876-1.04l.141-.081 4.779-2.758a.795.795 0 0 0 .392-.681v-6.737l2.02 1.168a.071.071 0 0 1 .038.052v5.583a4.504 4.504 0 0 1-4.494 4.494zM3.6 18.304a4.47 4.47 0 0 1-.535-3.014l.142.085 4.783 2.759a.771.771 0 0 0 .78 0l5.843-3.369v2.332a.08.08 0 0 1-.033.062L9.74 19.95a4.5 4.5 0 0 1-6.14-1.646zM2.34 7.896a4.485 4.485 0 0 1 2.366-1.973V11.6a.766.766 0 0 0 .388.676l5.815 3.355-2.02 1.168a.076.076 0 0 1-.071 0l-4.83-2.786A4.504 4.504 0 0 1 2.34 7.872zm16.597 3.855-5.833-3.387L15.119 7.2a.076.076 0 0 1 .071 0l4.83 2.791a4.494 4.494 0 0 1-.676 8.105v-5.678a.79.79 0 0 0-.407-.667zm2.01-3.023-.141-.085-4.774-2.782a.776.776 0 0 0-.785 0L9.409 9.23V6.897a.066.066 0 0 1 .028-.061l4.83-2.787a4.5 4.5 0 0 1 6.68 4.66zm-12.64 4.135-2.02-1.164a.08.08 0 0 1-.038-.057V6.075a4.5 4.5 0 0 1 7.375-3.453l-.142.08L8.704 5.46a.795.795 0 0 0-.393.681zm1.097-2.365 2.602-1.5 2.607 1.5v2.999l-2.597 1.5-2.607-1.5z"
    />
  </svg>
);

const providers = [
  { name: 'Anthropic Claude', Logo: AnthropicLogo, light: 'bg-white' },
  { name: 'Google Gemini', Logo: GeminiLogo, light: 'bg-white' },
  { name: 'OpenAI', Logo: OpenAILogo, light: 'bg-black text-white' },
] as const;

interface Props {
  className?: string;
  size?: number; // px diameter of the central icon
}

const AIProviderHalo: React.FC<Props> = ({ className = '', size = 64 }) => {
  const radius = size * 0.95; // distance from center for orbital chips
  const chip = Math.max(28, size * 0.42); // chip diameter
  // Distribute around the upper hemisphere
  const positions = [
    { angle: -140 }, // top-left
    { angle: -90 }, // top
    { angle: -40 }, // top-right
  ];

  return (
    <div
      className={`relative inline-flex items-center justify-center ${className}`}
      style={{ width: size + chip * 2, height: size + chip * 1.4 }}
    >
      <div
        className="absolute"
        style={{ width: size, height: size, left: '50%', top: '50%', transform: 'translate(-50%,-50%)' }}
      >
        <EarlyMarketAIIcon className="w-full h-full" />
      </div>
      {providers.map((p, i) => {
        const rad = (positions[i].angle * Math.PI) / 180;
        const x = Math.cos(rad) * radius;
        const y = Math.sin(rad) * radius;
        return (
          <div
            key={p.name}
            title={p.name}
            aria-label={p.name}
            className={`absolute rounded-full shadow-md border border-border/60 flex items-center justify-center overflow-hidden ${p.light}`}
            style={{
              width: chip,
              height: chip,
              left: `calc(50% + ${x}px - ${chip / 2}px)`,
              top: `calc(50% + ${y}px - ${chip / 2}px)`,
            }}
          >
            <p.Logo style={{ width: chip * 0.6, height: chip * 0.6 }} />
          </div>
        );
      })}
    </div>
  );
};

export default AIProviderHalo;