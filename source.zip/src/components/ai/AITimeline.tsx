import React, { useState } from 'react';
import {
  Search, Store, MapPin, Camera, TrendingUp, Star, Package, Shield,
  BarChart, Users, Tag, Zap, ShoppingBag, Briefcase, LineChart, FileText,
  FolderOpen, Compass, BarChart3, ChevronDown, ChevronRight, CheckCircle2,
  Loader2, Globe, Cloud,
} from 'lucide-react';
import { cn } from '@/lib/utils';

export type TimelineIconKey =
  | 'search' | 'marketplace' | 'services' | 'jobs' | 'trending' | 'prices'
  | 'analytics' | 'listings' | 'categories' | 'sellers' | 'chart' | 'draft'
  | 'web' | 'cloud' | 'default';

export interface TimelineSource {
  label: string;
  sublabel?: string;
  avatar?: string;
}

export interface TimelineStep {
  label: string;
  icon: TimelineIconKey;
  done?: boolean;
  queries?: string[];
  sources?: TimelineSource[];
}

const STEP_ICON: Record<TimelineIconKey, any> = {
  search: Globe,
  marketplace: ShoppingBag,
  services: Briefcase,
  jobs: Briefcase,
  trending: TrendingUp,
  prices: LineChart,
  analytics: BarChart3,
  listings: FolderOpen,
  categories: Tag,
  sellers: Store,
  chart: BarChart,
  draft: FileText,
  web: Globe,
  cloud: Cloud,
  default: Compass,
};

const SourceAvatar: React.FC<{ src?: string; label: string }> = ({ src, label }) => {
  const [err, setErr] = useState(false);
  if (src && !err) {
    return (
      <img
        src={src}
        alt=""
        loading="lazy"
        onError={() => setErr(true)}
        className="w-4 h-4 rounded-sm object-cover shrink-0"
      />
    );
  }
  return (
    <span className="w-4 h-4 rounded-sm shrink-0 bg-gradient-to-br from-primary/30 to-primary/10 flex items-center justify-center text-[8px] font-bold text-primary/80 uppercase">
      {label.charAt(0)}
    </span>
  );
};

const TimelineStepRow: React.FC<{
  step: TimelineStep;
  defaultOpen?: boolean;
  live?: boolean;
}> = ({ step, defaultOpen = true, live = false }) => {
  const [open, setOpen] = useState(defaultOpen);
  const Icon = STEP_ICON[step.icon] || Compass;
  const sources = step.sources || [];
  const queries = step.queries || [];
  const visibleSources = sources.slice(0, 3);
  const hiddenCount = sources.length - visibleSources.length;

  return (
    <div className="text-sm">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-2 py-1.5 text-foreground/90 hover:text-foreground transition-colors text-left"
      >
        <Icon className="w-4 h-4 text-muted-foreground shrink-0" />
        <span className="flex-1 truncate text-[13px]">{step.label}</span>
        {live && !step.done && (
          <Loader2 className="w-3.5 h-3.5 text-primary animate-spin shrink-0" />
        )}
        <ChevronDown className={cn('w-3.5 h-3.5 text-muted-foreground transition-transform shrink-0', !open && '-rotate-90')} />
      </button>
      {open && (queries.length > 0 || sources.length > 0) && (
        <div className="ml-6 pl-2 space-y-1 pb-1">
          {queries.map((q, i) => (
            <div key={`q-${i}`} className="flex items-center gap-2 text-[12px] text-muted-foreground py-0.5">
              <Search className="w-3 h-3 shrink-0" />
              <span className="truncate">{q}</span>
            </div>
          ))}
          {visibleSources.map((s, i) => (
            <div key={`s-${i}`} className="flex items-center gap-2 text-[12px] py-0.5">
              <SourceAvatar src={s.avatar} label={s.label} />
              <span className="truncate text-foreground/85 underline decoration-foreground/20 underline-offset-2">
                {s.label}
              </span>
              {s.sublabel && (
                <span className="text-muted-foreground/70 truncate shrink-0">{s.sublabel}</span>
              )}
            </div>
          ))}
          {hiddenCount > 0 && (
            <div className="text-[12px] text-muted-foreground pt-0.5 pl-1">+{hiddenCount} more</div>
          )}
        </div>
      )}
    </div>
  );
};

interface AITimelineProps {
  steps: TimelineStep[];
  live?: boolean;
  /** When false the whole timeline is collapsed to a "Completed N steps" header. */
  defaultExpanded?: boolean;
}

const AITimeline: React.FC<AITimelineProps> = ({ steps, live = false, defaultExpanded = false }) => {
  const [expanded, setExpanded] = useState(defaultExpanded || live);
  if (!steps.length) return null;
  const completedCount = steps.length;

  return (
    <div className="mb-3 text-[13px]">
      <button
        onClick={() => setExpanded(!expanded)}
        className="flex items-center gap-1.5 text-muted-foreground hover:text-foreground transition-colors py-1"
      >
        <span className="text-[13px]">Completed {completedCount} {completedCount === 1 ? 'step' : 'steps'}</span>
        <ChevronDown className={cn('w-3.5 h-3.5 transition-transform', !expanded && '-rotate-90')} />
      </button>
      {expanded && (
        <div className="mt-1 space-y-0.5">
          {steps.map((s, i) => (
            <TimelineStepRow key={i} step={s} defaultOpen={live || i === steps.length - 1} live={live} />
          ))}
        </div>
      )}
    </div>
  );
};

export default AITimeline;
