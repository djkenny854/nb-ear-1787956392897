import React, { useState, useEffect, useRef, useCallback } from 'react';
import { getAppBaseUrl } from '@/utils/getAppUrl';
import { Heart, MessageCircle, Share2, Bookmark, MoreHorizontal, Plus, BarChart3, MessageSquare, Package, Settings, Zap, Briefcase, ChevronLeft, ChevronRight, Menu, X, AlertCircle, RefreshCw, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate, useLocation, useNavigationType, useSearchParams } from 'react-router-dom';
import { useAuth } from '@/components/auth/AuthContext';
import { CommentModal } from '@/components/CommentModal';
import { PromotionCountdown } from '@/components/PromotionCountdown';
import ShareModal from '@/components/ShareModal';
import VideoPlayer from '@/components/VideoPlayer';
import VideoEmbed from '@/components/VideoEmbed';
import SuggestedAccounts from '@/components/SuggestedAccounts';

import VideoPreviewModal from '@/components/feed/VideoPreviewModal';
import XStyleFeedCard from '@/components/feed/XStyleFeedCard';
import XStyleVideoCard from '@/components/feed/XStyleVideoCard';
import FeedSkeleton from '@/components/feed/FeedSkeleton';
import FeedCardSkeleton from '@/components/feed/FeedCardSkeleton';
import MaterialSpinner from '@/components/ui/MaterialSpinner';
import SwipeToMessage from '@/components/feed/SwipeToMessage';
import XStyleRightSidebar from '@/components/feed/XStyleRightSidebar';
import FeedSearchPanel from '@/components/feed/FeedSearchPanel';
import { SponsoredSection } from '@/components/feed/SponsoredCarousel';
import GetVerifiedPromoCard from '@/components/feed/GetVerifiedPromoCard';
import DiscountedProductsSection from '@/components/feed/DiscountedProductsSection';
import PinnedByFollowedSection from '@/components/feed/PinnedByFollowedSection';
import ServicesForYouSection from '@/components/feed/ServicesForYouSection';
import WorkspaceUpdatesSection, { WorkspaceUpdateFeedCard, useWorkspaceUpdatesFeed } from '@/components/feed/WorkspaceUpdatesSection';
import DiscountsForYouSection from '@/components/feed/DiscountsForYouSection';
import OfflineBanner from '@/components/common/OfflineBanner';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';

import { useFeedCarousels } from '@/hooks/usePinnedProducts';
import { useAppSettings } from '@/hooks/useAppSettings';
import { useFeedState, getIsNavigatingBack } from '@/hooks/useFeedState';
import { useBookmarks } from '@/hooks/useBookmarks';
import { useFollowingSet } from '@/hooks/useFollowing';
import { useIsMobile } from '@/hooks/use-mobile';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';
import { motion, AnimatePresence } from 'framer-motion';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import { rankFeedItems } from '@/lib/feedRanking';
import PostDetailView from '@/components/feed/PostDetailView';
import BackToTopButton from '@/components/BackToTopButton';
interface FeedItem {
  id: string;
  title: string;
  description: string;
  price: number;
  original_price?: number | null;
  has_discount?: boolean;
  images: string[];
  category: string;
  location: string;
  created_at: string;
  listing_type: string;
  content_type: 'ad' | 'post' | 'event'; // Track the source type
  promotion_valid_until?: string | null;
  b2_video_url?: string | null;
  video_thumbnail_url?: string | null;
  media_dimensions?: { w: number; h: number }[] | null;
  video_width?: number | null;
  video_height?: number | null;
  youtube_url?: string | null;
  tiktok_url?: string | null;
  website_url?: string | null;
  tags?: string[];
  attached_services?: string[];
  attached_products?: string[];
  allow_comments?: boolean;
  seller: {
    id: string;
    user_id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
    is_featured?: boolean;
    verification_badge_color?: string | null;
    current_service_status?: 'available' | 'busy' | 'closed' | 'limited_slots';
  };
  is_sponsored?: boolean;
  sponsored_until?: string | null;
  is_liked?: boolean;
  is_saved?: boolean;
  like_count: number;
  is_interested?: boolean;
  view_count: number;
  comment_count?: number;
  _isFromFollowed?: boolean; // Track if item is from a followed seller
  job_details?: {
    company_name?: string;
    salary_min?: number;
    salary_max?: number;
    salary_currency?: string;
    job_type?: string;
    work_location?: string;
    positions?: { role: string; quantity: number; job_type?: string; salary_min?: number; salary_max?: number; salary_negotiable?: boolean; requirements?: string }[];
    number_of_positions?: number;
    job_posting_type?: 'single' | 'multiple';
    campaign_title?: string;
    apply_method?: string;
    application_deadline?: string;
  };
  service_details?: {
    starting_price?: number;
    experience_years?: number;
    service_area?: string[];
    pricing_type?: string;
    accommodation_type?: string;
    price_period?: string;
    amenities?: string[];
    booking_method?: string;
    booking_phone?: string;
    booking_url?: string;
  };
  seller_service_status?: 'available' | 'busy' | 'closed' | 'limited_slots';
  promotion_details?: {
    discount_percentage?: number;
    discount_amount?: number;
    original_price?: number;
    brand_name?: string;
    is_seller_wide?: boolean;
    promotion_type?: string;
    valid_until?: string;
    start_at?: string;
  };
  digital_product_details?: {
    file_type?: string;
    file_size?: string;
  };
  event_details?: {
    event_date?: string;
    end_date?: string;
    venue_name?: string;
    venue_address?: string;
    is_free?: boolean;
    ticket_price?: number;
    ticket_currency?: string;
    max_attendees?: number;
    current_attendees?: number;
  };
}
interface TrendingItem {
  category: string;
  count: number;
}
interface SellerToFollow {
  id: string;
  business_name: string;
  business_logo_url: string;
  is_verified: boolean;
}
interface BoostedAd {
  id: string;
  title: string;
  price: number;
  images: string[];
}
// Global video controller - only one video plays at a time
let currentlyPlayingVideo: HTMLVideoElement | null = null;

export const setCurrentlyPlayingVideo = (video: HTMLVideoElement | null) => {
  if (currentlyPlayingVideo && currentlyPlayingVideo !== video) {
    currentlyPlayingVideo.pause();
  }
  currentlyPlayingVideo = video;
};

const SocialFeed: React.FC = () => {
  const isMobile = useIsMobile();
  const { isOnline } = useNetworkStatus();
  const { globalPinnedProducts, discountedProducts, loadingPinned, loadingDiscounted } = useFeedCarousels();
  const { saveFeedState, restoreFeedState, restoreScrollPosition, clearFeedState } = useFeedState();
  const location = useLocation();
  const navigationType = useNavigationType();
  const [feedItems, setFeedItems] = useState<FeedItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [page, setPage] = useState(0);
  const loadMoreRef = useRef<HTMLDivElement>(null);
  const touchStartY = useRef(0);
  const isValidSwipe = useRef(false);
  const [trendingItems, setTrendingItems] = useState<TrendingItem[]>([]);
  const [sellersToFollow, setSellersToFollow] = useState<SellerToFollow[]>([]);
  const { items: workspaceUpdates } = useWorkspaceUpdatesFeed(20);
  const [boostedAds, setBoostedAds] = useState<BoostedAd[]>([]);
  const [loadingTrending, setLoadingTrending] = useState(true);
  const [loadingSellers, setLoadingSellers] = useState(true);
  const [loadingBoosted, setLoadingBoosted] = useState(true);
  const [currentTrendingIndex, setCurrentTrendingIndex] = useState(0);
  const [currentBoostedIndex, setCurrentBoostedIndex] = useState(0);
  const [followingStates, setFollowingStates] = useState<{
    [key: string]: boolean;
  }>({});
  const [commentModalOpen, setCommentModalOpen] = useState(false);
  const [selectedPost, setSelectedPost] = useState<FeedItem | null>(null);
  const [expandedDescriptions, setExpandedDescriptions] = useState<{
    [key: string]: boolean;
  }>({});
  const [rightSidebarOpen, setRightSidebarOpen] = useState(false);
  const [showSwipeHint, setShowSwipeHint] = useState(false);
  const [hasShownSwipeHint, setHasShownSwipeHint] = useState(() => {
    return localStorage.getItem('swipeHintShown') === 'true';
  });
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestedAccountsShown, setSuggestedAccountsShown] = useState(false);
  const sidebarRef = useRef<HTMLDivElement>(null);
  const touchStartX = useRef(0);
  const touchEndX = useRef(0);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [shareItem, setShareItem] = useState<FeedItem | null>(null);
  const [videoPreviewItem, setVideoPreviewItem] = useState<FeedItem | null>(null);
  const [videoPreviewOpen, setVideoPreviewOpen] = useState(false);
  const [postDetailOpen, setPostDetailOpen] = useState(false);
  const [postDetailItem, setPostDetailItem] = useState<FeedItem | null>(null);
  const [stateRestored, setStateRestored] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  const tabFromUrl = (searchParams.get('tab') as 'following' | 'foryou' | 'search' | null);
  const validTab = tabFromUrl === 'following' || tabFromUrl === 'foryou' || tabFromUrl === 'search' ? tabFromUrl : 'foryou';
  const [activeTab, setActiveTabState] = useState<'following' | 'foryou' | 'search'>(validTab);

  // Keep state in sync with URL (back/forward, shared links)
  useEffect(() => {
    if (validTab !== activeTab) setActiveTabState(validTab);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tabFromUrl]);

  const setActiveTab = useCallback((tab: 'following' | 'foryou' | 'search') => {
    setActiveTabState(tab);
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      if (tab === 'foryou') next.delete('tab');
      else next.set('tab', tab);
      return next;
    }, { replace: true });
    // Always start Following tab from the top and refresh so newly-followed
    // sellers' content shows up immediately.
    if (tab === 'following') {
      requestAnimationFrame(() => {
        const c = document.getElementById('social-feed-scroll-container');
        c?.scrollTo({ top: 0, behavior: 'auto' });
        window.scrollTo({ top: 0, behavior: 'auto' });
      });
      // Fire-and-forget refresh so the feed picks up freshly-followed users.
      try { fetchFeedItems(0, true); } catch {}
    }
  }, [setSearchParams]);


  const ITEMS_PER_PAGE = 10; // Load 10 items per page for subsequent pagination
  const INITIAL_FAST_LOAD = 12; // Load 12 items initially per spec
  const {
    user
  } = useAuth();
  const navigate = useNavigate();
  const { settings } = useAppSettings();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const { allBlockedIds } = useBlockedUsers();
  const followingSet = useFollowingSet();
  const followingCountRef = useRef<number>(followingSet.size);

  // When the follow set grows (user just followed someone), refresh the feed
  // so their content lands in the Following tab immediately.
  useEffect(() => {
    if (followingSet.size > followingCountRef.current) {
      followingCountRef.current = followingSet.size;
      try { fetchFeedItems(0, true); } catch {}
    } else {
      followingCountRef.current = followingSet.size;
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [followingSet]);

  
  // Track pending scroll restoration
  const [pendingScrollPosition, setPendingScrollPosition] = useState<number | null>(null);

  // Pull-to-refresh (mobile) state
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [pullDistance, setPullDistance] = useState(0);
  const pullStartY = useRef(0);
  const isPullingRef = useRef(false);

  // Continuously track scroll position so unmount cleanup always has the latest value
  const scrollPositionRef = useRef<number>(0);

  useEffect(() => {
    const container = document.getElementById('social-feed-scroll-container');
    if (!container) return;
    const handleScroll = () => {
      scrollPositionRef.current = container.scrollTop;
    };
    container.addEventListener('scroll', handleScroll, { passive: true });
    return () => container.removeEventListener('scroll', handleScroll);
  }, [loading]); // re-attach when loading changes (container may remount)

  // Track whether current user is an unverified seller (to show "Get Verified" promo)
  const [showVerificationPromo, setShowVerificationPromo] = useState(false);

  useEffect(() => {
    const checkSellerVerification = async () => {
      if (!user?.id) {
        setShowVerificationPromo(false);
        return;
      }
      const { data } = await supabase
        .from('seller_profiles')
        .select('is_verified')
        .eq('user_id', user.id)
        .maybeSingle();
      
      // Show promo only if they have a seller profile and are NOT verified
      setShowVerificationPromo(!!data && !data.is_verified);
    };
    checkSellerVerification();
  }, [user?.id]);

  // Auto-refresh when coming back online
  const prevOnlineRef = React.useRef(isOnline);
  useEffect(() => {
    if (isOnline && !prevOnlineRef.current && hasMore) {
      loadMoreItems();
    }
    prevOnlineRef.current = isOnline;
  }, [isOnline]);

  // Fetch feed items on mount - check for prefetched data first
  useEffect(() => {
    setError(null);

    // Detect actual page refresh (F5 / reload) vs. SPA navigation
    const isPageRefresh = performance.navigation
      ? performance.navigation.type === 1
      : (performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming)?.type === 'reload';

    if (isPageRefresh) {
      // Clear all feed state on refresh so user starts from the top
      clearFeedState();
      sessionStorage.removeItem('feed_seed');
    }

    // Check for saved state only if not a refresh
    const savedState = !isPageRefresh ? restoreFeedState() : null;
    const hasCachedItems = !!(savedState && savedState.items.length > 0);
    const isFresh = hasCachedItems &&
      (Date.now() - (savedState!.timestamp || 0)) < 5 * 60 * 1000;

    if (hasCachedItems) {
      // Stale-while-revalidate: render cached cards immediately so the user
      // never sees a skeleton on return. If the cache is stale (>5min) we
      // still show it instantly and refresh in the background.
      setFeedItems(savedState!.items);
      setPage(savedState!.page);
      setHasMore(savedState!.hasMore);
      setLoading(false);
      setStateRestored(true);
      setPendingScrollPosition(savedState!.scrollPosition);

      if (!isFresh && navigator.onLine) {
        // Background refresh — does not show the skeleton.
        setTimeout(() => fetchFeedItems(0, true), 0);
      }
    } else {
      // If offline, skip fetching entirely and show offline state
      if (!navigator.onLine) {
        setLoading(false);
        setStateRestored(true);
        return;
      }
      setLoading(true);
      // Check for prefetched data from PrefetchProvider
      const prefetchedRaw = sessionStorage.getItem('social_feed_prefetch');
      if (prefetchedRaw) {
        try {
          const prefetched = JSON.parse(prefetchedRaw);
          if (prefetched.timestamp && (Date.now() - prefetched.timestamp) < 3 * 60 * 1000) {
            sessionStorage.removeItem('social_feed_prefetch');
            processPrefetchedFeedData(prefetched);
            setStateRestored(true);
          } else {
            sessionStorage.removeItem('social_feed_prefetch');
            clearFeedState();
            sessionStorage.removeItem('feed_seed');
            setFeedItems([]);
            setPage(0);
            setHasMore(true);
            setStateRestored(true);
            fetchFeedItems(0, true);
          }
        } catch {
          clearFeedState();
          sessionStorage.removeItem('feed_seed');
          setFeedItems([]);
          setPage(0);
          setHasMore(true);
          setStateRestored(true);
          fetchFeedItems(0, true);
        }
      } else {
        clearFeedState();
        sessionStorage.removeItem('feed_seed');
        setFeedItems([]);
        setPage(0);
        setHasMore(true);
        setStateRestored(true);
        fetchFeedItems(0, true);
      }
    }
    
    // Always fetch sidebar data
    fetchTrending();
    fetchSellersToFollow();
    fetchBoostedAds();
    
    // Show swipe hint after a delay on mobile (only once)
    if (!hasShownSwipeHint && window.innerWidth < 1280) {
      const timer = setTimeout(() => {
        setShowSwipeHint(true);
        setTimeout(() => {
          setShowSwipeHint(false);
          setHasShownSwipeHint(true);
          localStorage.setItem('swipeHintShown', 'true');
        }, 3000);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, []); // Run once on mount

  // Restore scroll position INSTANTLY after items render
  useEffect(() => {
    if (pendingScrollPosition !== null && feedItems.length > 0 && !loading) {
      requestAnimationFrame(() => {
        const container = document.getElementById('social-feed-scroll-container');
        if (container) {
          container.scrollTop = pendingScrollPosition;
        }
        setPendingScrollPosition(null);
      });
    }
  }, [feedItems.length, loading, pendingScrollPosition]);

  // Save feed state ONLY on unmount (when navigating to a detail page)
  // Uses refs for scroll position to avoid stale closure / missing DOM issues
  const feedItemsRef = useRef(feedItems);
  const pageRef = useRef(page);
  const hasMoreRef = useRef(hasMore);
  const savedByClickRef = useRef(false); // prevent unmount from overwriting click-time save
  feedItemsRef.current = feedItems;
  pageRef.current = page;
  hasMoreRef.current = hasMore;

  useEffect(() => {
    return () => {
      // If handleItemClick already saved state (with correct scroll position),
      // don't overwrite — ScrollToTop may have reset scrollTop to 0 by now
      if (savedByClickRef.current) return;

      if (feedItemsRef.current.length > 0) {
        const state = {
          scrollPosition: scrollPositionRef.current,
          items: feedItemsRef.current,
          page: pageRef.current,
          hasMore: hasMoreRef.current,
          timestamp: Date.now(),
        };
        try {
          sessionStorage.setItem('social_feed_state', JSON.stringify(state));
        } catch (e) {
          console.error('Failed to save feed state:', e);
        }
      }
    };
  }, []); // empty deps — runs only on unmount, reads from refs

  // Infinite scroll observer - aggressive prefetching
  useEffect(() => {
    const rootEl = document.getElementById('social-feed-scroll-container');

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loadingMore && !loading && isOnline) {
          loadMoreItems();
        }
      },
      {
        // Prefetch very early - 1200px ahead (about 3-4 screens) for seamless scrolling
        root: rootEl || null,
        rootMargin: '1200px 0px',
        threshold: 0,
      }
    );

    if (loadMoreRef.current) {
      observer.observe(loadMoreRef.current);
    }

    return () => observer.disconnect();
  }, [hasMore, loadingMore, loading, page, isOnline]);

  // Auto-rotate trending items every 3 seconds
  useEffect(() => {
    if (trendingItems.length > 0) {
      const interval = setInterval(() => {
        setCurrentTrendingIndex(prev => (prev + 1) % trendingItems.length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [trendingItems]);

  // Auto-rotate boosted ads every 3 seconds
  useEffect(() => {
    if (boostedAds.length > 0) {
      const interval = setInterval(() => {
        setCurrentBoostedIndex(prev => (prev + 1) % boostedAds.length);
      }, 3000);
      return () => clearInterval(interval);
    }
  }, [boostedAds]);
  /**
   * Process prefetched feed data from PrefetchProvider.
   * Formats raw DB rows into FeedItem[] and applies ranking, same as fetchFeedItems.
   */
  const processPrefetchedFeedData = async (prefetched: { ads: any[]; posts: any[]; events: any[]; followedUserIds: string[] }) => {
    try {
      const { ads: adsData, posts: postsData, events: eventsData, followedUserIds } = prefetched;
      
      const isFromFollowed = (uid: string) => followedUserIds.includes(uid);

      // Filter posts by visibility
      const filteredPosts = postsData.filter((post: any) => {
        if (post.visibility === 'everyone') return true;
        if (post.visibility === 'followers' && user?.id && followedUserIds.includes(post.user_id)) return true;
        if (post.user_id === user?.id) return true;
        return false;
      });

      // Format ads
      const formattedAds: FeedItem[] = (adsData || []).map((item: any) => {
        const sellerUserId = item.seller_profiles?.user_id || '';
        return {
          id: item.id,
          title: item.title,
          description: item.description || '',
          price: item.price || 0,
          images: item.images || [],
          category: item.category,
          location: item.location,
          created_at: item.created_at,
          listing_type: item.listing_type || 'physical_products',
          content_type: 'ad' as const,
          b2_video_url: item.b2_video_url || null,
          video_thumbnail_url: item.video_thumbnail_url || null,
          media_dimensions: (item.media_dimensions as any) || null,
          video_width: item.video_width || null,
          video_height: item.video_height || null,
          youtube_url: item.youtube_url || null,
          tiktok_url: item.tiktok_url || null,
          allow_comments: item.allow_comments !== false,
          is_sponsored: item.is_sponsored || false,
          sponsored_until: item.sponsored_until || null,
          seller: {
            id: item.seller_profiles?.id || '',
            user_id: sellerUserId,
            business_name: item.seller_profiles?.business_name || '',
            business_logo_url: item.seller_profiles?.business_logo_url || '',
            is_verified: item.seller_profiles?.is_verified || false,
            is_featured: item.seller_profiles?.is_featured || false,
            verification_badge_color: item.seller_profiles?.verification_badge_color || null,
            current_service_status: item.seller_profiles?.current_service_status || undefined,
          },
          like_count: 0,
          view_count: item.view_count || 0,
          is_liked: false,
          is_saved: false,
          _isFromFollowed: isFromFollowed(sellerUserId),
        };
      });

      // Format posts
      const formattedPosts: FeedItem[] = filteredPosts.map((post: any) => {
        const sp = post.seller_profiles;
        const sellerUserId = sp?.user_id || post.user_id || '';
        return {
          id: post.id,
          title: post.title || '',
          description: post.content || '',
          price: 0,
          images: post.images || [],
          category: 'post',
          location: post.location || '',
          created_at: post.created_at || new Date().toISOString(),
          listing_type: 'post',
          content_type: 'post' as const,
          b2_video_url: post.video_url || null,
          youtube_url: post.youtube_url || null,
          tiktok_url: post.tiktok_url || null,
          website_url: post.website_url || null,
          tags: post.tags || [],
          attached_services: post.attached_services || [],
          attached_products: (post as any).attached_products || [],
          media_dimensions: ((post as any).media_dimensions as any) || null,
          video_width: (post as any).video_width || null,
          video_height: (post as any).video_height || null,
          video_thumbnail_url: (post as any).video_thumbnail_url || null,
          seller: {
            id: sp?.id || '',
            user_id: sellerUserId,
            business_name: sp?.business_name || post.title?.slice(0, 20) || 'Poster',
            business_logo_url: sp?.business_logo_url || '',
            is_verified: sp?.is_verified || false,
            is_featured: sp?.is_featured || false,
            verification_badge_color: sp?.verification_badge_color || null,
          },
          like_count: post.like_count || 0,
          view_count: post.view_count || 0,
          is_liked: false,
          is_saved: false,
          _isFromFollowed: isFromFollowed(sellerUserId),
        };
      });

      // Format events
      const formattedEvents: FeedItem[] = (eventsData || []).filter((e: any) => e.seller_profiles).map((event: any) => {
        const sellerUserId = event.seller_profiles?.user_id || '';
        return {
          id: event.id,
          title: event.title,
          description: event.description || '',
          price: event.ticket_price || 0,
          images: event.images || [],
          category: event.category,
          location: event.location || '',
          created_at: event.created_at,
          listing_type: 'event',
          content_type: 'event' as const,
          b2_video_url: event.video_url || null,
          youtube_url: null,
          tiktok_url: null,
          media_dimensions: ((event as any).media_dimensions as any) || null,
          video_width: (event as any).video_width || null,
          video_height: (event as any).video_height || null,
          video_thumbnail_url: (event as any).video_thumbnail_url || null,
          seller: {
            id: event.seller_profiles?.id || '',
            user_id: sellerUserId,
            business_name: event.seller_profiles?.business_name || 'Unknown',
            business_logo_url: event.seller_profiles?.business_logo_url || '',
            is_verified: event.seller_profiles?.is_verified || false,
            is_featured: event.seller_profiles?.is_featured || false,
          },
          like_count: 0,
          view_count: event.view_count || 0,
          is_liked: false,
          is_saved: false,
          event_details: {
            event_date: event.event_date,
            end_date: event.end_date,
            venue_name: event.venue_name,
            venue_address: event.venue_address,
            is_free: event.is_free,
            ticket_price: event.ticket_price,
            ticket_currency: event.ticket_currency,
            max_attendees: event.max_attendees,
            current_attendees: event.current_attendees,
          },
          _isFromFollowed: isFromFollowed(sellerUserId),
        };
      });

      const allItems = [...formattedAds, ...formattedPosts, ...formattedEvents];
      
      // Batch fetch engagement counts for prefetched items
      const allItemIds = allItems.map(item => item.id);
      if (allItemIds.length > 0) {
        const { data: engagementCounts } = await supabase
          .from('content_engagements')
          .select('content_id')
          .in('content_id', allItemIds)
          .eq('engagement_type', 'interested');
        
        if (engagementCounts) {
          const likeMap = new Map<string, number>();
          engagementCounts.forEach(e => {
            likeMap.set(e.content_id, (likeMap.get(e.content_id) || 0) + 1);
          });
          allItems.forEach(item => {
            item.like_count = likeMap.get(item.id) || 0;
          });
        }
      }

      // Apply ranking with session seed so ordering varies per device/session
      const prefetchSeed = parseInt(sessionStorage.getItem('feed_seed') || '0') || Date.now();
      if (!sessionStorage.getItem('feed_seed')) {
        sessionStorage.setItem('feed_seed', prefetchSeed.toString());
      }
      let ranked: FeedItem[] = rankFeedItems(allItems as any, undefined, prefetchSeed) as FeedItem[];
      
      // Filter blocked users
      if (allBlockedIds.length > 0) {
        ranked = ranked.filter(item => !allBlockedIds.includes(item.seller?.user_id));
      }

      setFeedItems(ranked);
      setPage(0);
      setHasMore(true);
      setLoading(false);
    } catch (e) {
      console.error('Failed to process prefetched feed data:', e);
      // Fall back to fresh fetch
      fetchFeedItems(0, true);
    }
  };

  // Seeded random shuffle for personalization that changes on refresh
  const shuffleArray = <T,>(array: T[], seed: number): T[] => {
    const shuffled = [...array];
    let currentIndex = shuffled.length;
    let randomValue: number;
    
    // Simple seeded random
    const seededRandom = () => {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    };
    
    while (currentIndex !== 0) {
      randomValue = Math.floor(seededRandom() * currentIndex);
      currentIndex--;
      [shuffled[currentIndex], shuffled[randomValue]] = [shuffled[randomValue], shuffled[currentIndex]];
    }
    
    return shuffled;
  };

  const fetchFeedItems = async (pageNum: number = 0, isInitial: boolean = false) => {
    try {
      if (isInitial) {
        setLoading(true);
        setError(null);
      }
      
      const offset = pageNum * ITEMS_PER_PAGE;
      
      // Generate a session-based seed for personalized shuffling
      const sessionSeed = parseInt(sessionStorage.getItem('feed_seed') || '0') || Date.now();
      if (!sessionStorage.getItem('feed_seed')) {
        sessionStorage.setItem('feed_seed', sessionSeed.toString());
      }
      
      const userSeedComponent = user?.id ? parseInt(user.id.replace(/-/g, '').slice(0, 8), 16) : 0;
      const combinedSeed = sessionSeed + userSeedComponent + (pageNum * 1000);
      
      // Get followed user IDs first (needed for filtering)
      let followedUserIds: string[] = [];
      if (user?.id) {
        const { data: follows } = await supabase
          .from('follows')
          .select('following_id')
          .eq('follower_id', user.id);
        followedUserIds = follows?.map(f => f.following_id) || [];
      }

      // Build queries for parallel execution
      const fetchLimit = isInitial ? INITIAL_FAST_LOAD : ITEMS_PER_PAGE;
      const postsLimit = isInitial ? 3 : 8;
      const eventsLimit = isInitial ? 2 : 5;
      
      // Ads query - include is_sponsored and is_featured from seller
      const adsQuery = supabase
        .from('ads')
        .select(`
          id, title, description, price, original_price, has_discount, images, category, location, created_at,
          view_count, save_count, listing_type, b2_video_url, youtube_url, tiktok_url, allow_comments,
          is_sponsored, is_boosted, sponsored_until, seller_id, media_dimensions, video_width, video_height, video_thumbnail_url,
          seller_profiles(id, user_id, business_name, business_logo_url, is_verified, is_featured, verification_badge_color, current_service_status, portfolio_updated_at)
        `)
        .eq('status', 'active')
        .or(`expires_at.is.null,expires_at.gt.${new Date().toISOString()}`)
        .order('created_at', { ascending: false })
        .range(offset, offset + fetchLimit - 1);
      
      // Posts query (posts table doesn't have allow_comments yet, default to true)
      const postsQuery = supabase
        .from('posts')
        .select(`
          id, title, content, location, created_at, view_count, like_count,
          comment_count, share_count, tags, visibility, user_id, seller_id,
          images, video_url, youtube_url, tiktok_url, website_url, attached_services,
          attached_products, media_dimensions, video_width, video_height, video_thumbnail_url,
          seller_profiles(id, user_id, business_name, business_logo_url, is_verified, is_featured, verification_badge_color, store_slug)
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .range(offset, offset + postsLimit);
      
      // Events query
      const eventsQuery = supabase
        .from('events')
        .select(`
          id, title, description, category, location, created_at, view_count, video_url, images,
          media_dimensions, video_width, video_height, video_thumbnail_url, cover_image,
          event_date, end_date, venue_name, venue_address, is_free, ticket_price, ticket_currency,
          max_attendees, current_attendees,
          seller_profiles(id, user_id, business_name, business_logo_url, is_verified, is_featured, verification_badge_color)
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .range(offset, offset + eventsLimit);

      // Run all main queries in PARALLEL for speed
      const [adsResult, postsResult, eventsResult] = await Promise.all([
        adsQuery,
        postsQuery,
        eventsQuery
      ]);

      if (adsResult.error) throw adsResult.error;
      
      const adsData = adsResult.data || [];
      const postsData = postsResult.data || [];
      const eventsData = eventsResult.data || [];
      
      // Filter posts by visibility
      const filteredPosts = postsData.filter(post => {
        if (post.visibility === 'everyone') return true;
        if (post.visibility === 'followers' && user?.id && followedUserIds.includes(post.user_id)) return true;
        if (post.user_id === user?.id) return true;
        return false;
      });

      // Get detail IDs for batch fetch
      const promotionIds = adsData.filter(ad => ad.listing_type === 'promotions').map(ad => ad.id);
      const jobIds = adsData.filter(ad => ad.listing_type === 'jobs').map(ad => ad.id);
      const serviceIds = adsData.filter(ad => ad.listing_type === 'services').map(ad => ad.id);
      const digitalIds = adsData.filter(ad => ad.listing_type === 'digital_products').map(ad => ad.id);
      
      // Fetch details in PARALLEL
      const [promoResult, jobResult, serviceResult, digitalResult] = await Promise.all([
        promotionIds.length > 0 
          ? supabase.from('promotion_details').select('ad_id, valid_until, start_at, discount_percentage, discount_amount, original_price, brand_name, is_seller_wide, promotion_type').in('ad_id', promotionIds)
          : Promise.resolve({ data: [] }),
        jobIds.length > 0
          ? supabase.from('job_details').select('ad_id, company_name, salary_min, salary_max, salary_currency, job_type, work_location, positions, number_of_positions, job_posting_type, campaign_title, application_deadline, apply_method').in('ad_id', jobIds)
          : Promise.resolve({ data: [] }),
        serviceIds.length > 0
          ? supabase.from('service_details').select('ad_id, starting_price, experience_years, pricing_type, accommodation_type, price_period, amenities, booking_method, booking_phone, booking_url').in('ad_id', serviceIds)
          : Promise.resolve({ data: [] }),
        digitalIds.length > 0
          ? supabase.from('digital_product_details').select('ad_id, file_type, file_size').in('ad_id', digitalIds)
          : Promise.resolve({ data: [] })
      ]);
      
      // Filter out promotions whose valid_until has already passed (client-side
      // belt-and-braces; DB trigger restores prices/state on the next view).
      const _nowMs = Date.now();
      const promotionDetails = (promoResult.data || []).filter((p: any) =>
        !p.valid_until || new Date(p.valid_until).getTime() > _nowMs
      );
      const expiredPromoAdIds = new Set(
        (promoResult.data || [])
          .filter((p: any) => p.valid_until && new Date(p.valid_until).getTime() <= _nowMs)
          .map((p: any) => p.ad_id)
      );
      const jobDetails = jobResult.data || [];
      const serviceDetails = serviceResult.data || [];
      const digitalDetails = digitalResult.data || [];

      // Helper to check if item is from followed user
      const isFromFollowed = (userIdToCheck: string) => followedUserIds.includes(userIdToCheck);

      // Filter out jobs with expired application deadlines
      const currentTime = new Date();
      const expiredJobAdIds = new Set(
        jobDetails
          .filter(j => j.application_deadline && new Date(j.application_deadline) < currentTime)
          .map(j => j.ad_id)
      );
      const filteredAdsData = adsData.filter(item => !expiredJobAdIds.has(item.id) && !expiredPromoAdIds.has(item.id));

      // Format ads with followed priority marker
      const formattedAds: FeedItem[] = filteredAdsData?.map(item => {
        const promoDetail = promotionDetails.find(p => p.ad_id === item.id);
        const jobDetail = jobDetails.find(j => j.ad_id === item.id);
        const serviceDetail = serviceDetails.find(s => s.ad_id === item.id);
        const digitalDetail = digitalDetails.find(d => d.ad_id === item.id);
        const sp = item.seller_profiles as any;
        const sellerUserId = sp?.user_id || (item as any).seller_id || '';
        return {
          id: item.id,
          title: item.title,
          description: item.description || '',
          price: item.price || 0,
          original_price: (item as any).original_price || null,
          has_discount: (item as any).has_discount || false,
          images: item.images || [],
          category: item.category,
          location: item.location,
          created_at: item.created_at,
          listing_type: item.listing_type || 'physical_products',
          content_type: 'ad' as const,
          promotion_valid_until: promoDetail?.valid_until || null,
          b2_video_url: item.b2_video_url || null,
          video_thumbnail_url: item.video_thumbnail_url || null,
          media_dimensions: (item.media_dimensions as any) || null,
          video_width: item.video_width || null,
          video_height: item.video_height || null,
          youtube_url: item.youtube_url || null,
          tiktok_url: item.tiktok_url || null,
          allow_comments: (item as any).allow_comments !== false,
          is_sponsored: (item as any).is_sponsored || false,
          sponsored_until: (item as any).sponsored_until || null,
          seller: {
            id: sp?.id || (item as any).seller_id || '',
            user_id: sellerUserId,
            business_name: sp?.business_name || 'Regular User',
            business_logo_url: sp?.business_logo_url || '',
            is_verified: sp?.is_verified || false,
            is_featured: sp?.is_featured || false,
            current_service_status: sp?.current_service_status || undefined
          },
          like_count: 0,
          view_count: item.view_count || 0,
          is_liked: false,
          is_saved: false,
          job_details: jobDetail ? {
            company_name: jobDetail.company_name,
            salary_min: jobDetail.salary_min,
            salary_max: jobDetail.salary_max,
            salary_currency: jobDetail.salary_currency,
            job_type: jobDetail.job_type,
            work_location: jobDetail.work_location,
            positions: jobDetail.positions as { role: string; quantity: number }[] || [],
            number_of_positions: jobDetail.number_of_positions,
            job_posting_type: jobDetail.job_posting_type as 'single' | 'multiple' | undefined,
            campaign_title: jobDetail.campaign_title,
            apply_method: jobDetail.apply_method,
            application_deadline: jobDetail.application_deadline
          } : undefined,
          service_details: serviceDetail ? {
            starting_price: serviceDetail.starting_price,
            experience_years: serviceDetail.experience_years,
            pricing_type: serviceDetail.pricing_type,
            accommodation_type: serviceDetail.accommodation_type,
            price_period: serviceDetail.price_period,
            amenities: serviceDetail.amenities,
            booking_method: serviceDetail.booking_method,
            booking_phone: serviceDetail.booking_phone,
            booking_url: serviceDetail.booking_url,
          } : undefined,
          promotion_details: promoDetail ? {
            discount_percentage: promoDetail.discount_percentage,
            discount_amount: promoDetail.discount_amount,
            original_price: promoDetail.original_price,
            brand_name: promoDetail.brand_name,
            is_seller_wide: promoDetail.is_seller_wide,
            promotion_type: promoDetail.promotion_type,
            valid_until: promoDetail.valid_until,
            start_at: promoDetail.start_at
          } : undefined,
          digital_product_details: digitalDetail ? {
            file_type: digitalDetail.file_type,
            file_size: digitalDetail.file_size
          } : undefined,
          _isFromFollowed: isFromFollowed(sellerUserId), // Internal marker for sorting
          _portfolioUpdatedAt: (item.seller_profiles as any).portfolio_updated_at // For service boost
        };
      }) || [];

      // Format posts (with media) with followed marker - use filtered posts
      // Allow posts without seller profiles (use fallback display)
      const formattedPosts: FeedItem[] = filteredPosts?.map(post => {
        const sellerProfile = post.seller_profiles as any;
        const sellerUserId = sellerProfile?.user_id || post.user_id || '';
        
        // Determine display name: seller profile > title-based > "Poster"
        const displayName = sellerProfile?.business_name || 
                           post.title?.slice(0, 20) ||
                           'Poster';
        const avatarUrl = sellerProfile?.business_logo_url || '';
        
        return {
          id: post.id,
          title: post.title || '',
          description: post.content || '',
          price: 0,
          images: post.images || [],
          category: 'post',
          location: post.location || '',
          created_at: post.created_at || new Date().toISOString(),
          listing_type: 'post',
          content_type: 'post' as const,
          b2_video_url: post.video_url || null,
          youtube_url: post.youtube_url || null,
          tiktok_url: post.tiktok_url || null,
          website_url: post.website_url || null,
          tags: post.tags || [],
          attached_services: post.attached_services || [],
          attached_products: (post as any).attached_products || [],
          media_dimensions: ((post as any).media_dimensions as any) || null,
          video_width: (post as any).video_width || null,
          video_height: (post as any).video_height || null,
          video_thumbnail_url: (post as any).video_thumbnail_url || null,
          seller: {
            id: sellerProfile?.id || '',
            user_id: sellerUserId,
            business_name: displayName,
            business_logo_url: avatarUrl,
            is_verified: sellerProfile?.is_verified || false,
            is_featured: sellerProfile?.is_featured || false,
            verification_badge_color: sellerProfile?.verification_badge_color || null,
          },
          like_count: post.like_count || 0,
          view_count: post.view_count || 0,
          is_liked: false,
          is_saved: false,
          _isFromFollowed: isFromFollowed(sellerUserId)
        };
      }) || [];

      // Format events (can have video) with followed marker
      const formattedEvents: FeedItem[] = eventsData?.filter(event => event.seller_profiles).map(event => {
        const sellerUserId = (event.seller_profiles as any)?.user_id || '';
        return {
          id: event.id,
          title: event.title,
          description: event.description || '',
          price: event.ticket_price || 0,
          images: event.images || [],
          category: event.category,
          location: event.location || '',
          created_at: event.created_at,
          listing_type: 'event',
          content_type: 'event' as const,
          b2_video_url: event.video_url || null,
          youtube_url: null,
          tiktok_url: null,
          media_dimensions: ((event as any).media_dimensions as any) || null,
          video_width: (event as any).video_width || null,
          video_height: (event as any).video_height || null,
          video_thumbnail_url: (event as any).video_thumbnail_url || null,
          seller: {
            id: (event.seller_profiles as any)?.id || '',
            user_id: sellerUserId,
            business_name: (event.seller_profiles as any)?.business_name || 'Unknown',
            business_logo_url: (event.seller_profiles as any)?.business_logo_url || '',
            is_verified: (event.seller_profiles as any)?.is_verified || false,
            is_featured: (event.seller_profiles as any)?.is_featured || false,
          },
          like_count: 0,
          view_count: event.view_count || 0,
          is_liked: false,
          is_saved: false,
          event_details: {
            event_date: event.event_date,
            end_date: event.end_date,
            venue_name: event.venue_name,
            venue_address: event.venue_address,
            is_free: event.is_free,
            ticket_price: event.ticket_price,
            ticket_currency: event.ticket_currency,
            max_attendees: event.max_attendees,
            current_attendees: event.current_attendees
          },
          _isFromFollowed: isFromFollowed(sellerUserId)
        };
      }) || [];

      // Merge all items
      const allItems = [...formattedAds, ...formattedPosts, ...formattedEvents];

      // Batch fetch engagement counts AND comment counts for all items in parallel
      const allItemIds = allItems.map(item => item.id);
      if (allItemIds.length > 0) {
        const [commentCountsResult, engagementCountsResult, userInterestedResult] = await Promise.all([
          supabase
            .from('comments')
            .select('content_id')
            .in('content_id', allItemIds)
            .is('parent_comment_id', null),
          supabase
            .from('content_engagements')
            .select('content_id')
            .in('content_id', allItemIds)
            .eq('engagement_type', 'interested'),
          user
            ? supabase
                .from('content_engagements')
                .select('content_id')
                .in('content_id', allItemIds)
                .eq('engagement_type', 'interested')
                .eq('user_id', user.id)
            : Promise.resolve({ data: [] as { content_id: string }[] }),
        ]);
        
        const commentCounts = commentCountsResult.data;
        if (commentCounts) {
          const countMap = new Map<string, number>();
          commentCounts.forEach(c => {
            countMap.set(c.content_id, (countMap.get(c.content_id) || 0) + 1);
          });
          allItems.forEach(item => {
            if (item.content_type === 'post' && (item as any)._postCommentCount !== undefined) {
              item.comment_count = (item as any)._postCommentCount;
            } else {
              item.comment_count = countMap.get(item.id) || 0;
            }
          });
        }

        // Set initial like_count from content_engagements for all content types
        const engagementCounts = engagementCountsResult.data;
        if (engagementCounts) {
          const likeMap = new Map<string, number>();
          engagementCounts.forEach(e => {
            likeMap.set(e.content_id, (likeMap.get(e.content_id) || 0) + 1);
          });
          allItems.forEach(item => {
            item.like_count = likeMap.get(item.id) || 0;
          });
        }

        // Seed the current user's own "interested" state so cards don't each query it.
        const userInterestedSet = new Set(
          ((userInterestedResult as any)?.data || []).map((e: { content_id: string }) => e.content_id)
        );
        allItems.forEach(item => {
          item.is_interested = userInterestedSet.has(item.id);
        });
      }
      
      // Apply bucket-based ranking with combined seed (per-device + page)
      let newItems: FeedItem[] = rankFeedItems(allItems as any, undefined, combinedSeed) as FeedItem[];
      
      // Filter out blocked users' content
      if (allBlockedIds.length > 0) {
        newItems = newItems.filter(item => !allBlockedIds.includes(item.seller?.user_id));
      }

      // Only mark "end" when ALL sources are exhausted.
      // The previous logic could end early if one source ran short.
      const anyReturned =
        adsData.length > 0 ||
        (filteredPosts?.length || 0) > 0 ||
        (eventsData?.length || 0) > 0;

      if (!anyReturned) {
        setHasMore(false);
      }

      if (isInitial) {
        setFeedItems(newItems);
      } else {
        // Append new items, avoiding duplicates
        setFeedItems(prev => {
          const existingIds = new Set(prev.map(item => item.id));
          const uniqueNewItems = newItems.filter(item => !existingIds.has(item.id));
          return [...prev, ...uniqueNewItems];
        });
      }
    } catch (error) {
      console.error('Error fetching feed:', error);
      if (isInitial) {
        setError('Failed to load feed. Please check your internet connection.');
      }
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  const loadMoreItems = async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    const nextPage = page + 1;
    setPage(nextPage);
    await fetchFeedItems(nextPage, false);
  };
  const fetchTrending = async () => {
    try {
      const {
        data,
        error
      } = await supabase.from('ads').select('category').eq('status', 'active');
      if (error) throw error;

      // Count occurrences of each category
      const categoryCounts = data?.reduce((acc: {
        [key: string]: number;
      }, item) => {
        acc[item.category] = (acc[item.category] || 0) + 1;
        return acc;
      }, {});

      // Convert to array and sort by count
      const trending = Object.entries(categoryCounts || {}).map(([category, count]) => ({
        category,
        count: count as number
      })).sort((a, b) => b.count - a.count).slice(0, 4);
      setTrendingItems(trending);
    } catch (error) {
      console.error('Error fetching trending:', error);
    } finally {
      setLoadingTrending(false);
    }
  };
  const fetchSellersToFollow = async () => {
    try {
      // Get users we're already following to exclude them
      let followedUserIds: string[] = [];
      if (user?.id) {
        const { data: followsData } = await supabase
          .from('follows')
          .select('following_id')
          .eq('follower_id', user.id);
        followedUserIds = followsData?.map(f => f.following_id) || [];
      }

      let query = supabase
        .from('seller_profiles')
        .select('id, user_id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug')
        .eq('is_verified', true)
        .limit(40);

      // Exclude our own profile and already followed users
      if (user?.id) {
        query = query.neq('user_id', user.id);
      }

      const { data, error } = await query;
      if (error) throw error;

      // Filter out sellers we're already following
      const pool = (data || []).filter(seller =>
        !followedUserIds.includes(seller.user_id)
      );

      // Per-session/device shuffle so users see different suggestions
      const seed =
        parseInt(sessionStorage.getItem('feed_seed') || '0') ||
        Math.floor(Math.random() * 1_000_000);
      const shuffled = shuffleArray(pool, seed);

      setSellersToFollow(shuffled.slice(0, 8));
    } catch (error) {
      console.error('Error fetching sellers:', error);
    } finally {
      setLoadingSellers(false);
    }
  };
  const fetchBoostedAds = async () => {
    try {
      const {
        data,
        error
      } = await supabase.from('ads').select('id, title, price, images').eq('is_boosted', true).eq('status', 'active').order('created_at', {
        ascending: false
      }).limit(3);
      if (error) throw error;
      setBoostedAds(data?.map(ad => ({
        id: ad.id,
        title: ad.title,
        price: ad.price || 0,
        images: ad.images || []
      })) || []);
    } catch (error) {
      console.error('Error fetching boosted ads:', error);
    } finally {
      setLoadingBoosted(false);
    }
  };
  const handleLike = async (itemId: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }

    // Update UI optimistically
    setFeedItems(prev => prev.map(item => item.id === itemId ? {
      ...item,
      is_liked: !item.is_liked,
      like_count: item.is_liked ? item.like_count - 1 : item.like_count + 1
    } : item));

    // TODO: Implement like system in backend
  };
  // Helper to get the correct item_type for bookmarks based on content type and listing type
  const getBookmarkItemType = (item: FeedItem): string => {
    if (item.content_type === 'event') return 'event';
    if (item.content_type === 'post') return 'post';
    if (item.content_type === 'ad') {
      switch (item.listing_type) {
        case 'jobs': return 'job';
        case 'services': return 'service';
        case 'promotions': return 'promotion';
        default: return 'product';
      }
    }
    return 'product';
  };

  const handleSave = async (itemId: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }

    // Find the item to get its type
    const item = feedItems.find(i => i.id === itemId);
    if (!item) return;

    const itemType = getBookmarkItemType(item);
    
    // Toggle bookmark using the hook (this handles the database operation)
    const newSavedState = await toggleBookmark(itemId, itemType);

    // Update UI to reflect the new state
    setFeedItems(prev => prev.map(i => i.id === itemId ? {
      ...i,
      is_saved: newSavedState
    } : i));
  };
  const handleShare = (item: FeedItem) => {
    setShareItem(item);
    setShareModalOpen(true);
  };

  // Get the correct detail page route based on content type and listing type
  const getItemDetailRoute = (item: FeedItem): string => {
    // Handle events
    if (item.content_type === 'event') {
      return `/event/${item.id}`;
    }
    
    // Handle posts - no detail page yet
    if (item.content_type === 'post') {
      return '';
    }
    
    // Handle ads based on listing_type
    if (item.content_type === 'ad') {
      switch (item.listing_type) {
        case 'jobs':
          return `/job/${item.id}`;
        case 'promotions':
          return `/promotion/${item.id}`;
        case 'services':
          return `/service/${item.id}`;
        case 'digital_products':
          return `/digital/${item.id}`;
        default:
          return `/ad/${item.id}`;
      }
    }
    
    return `/ad/${item.id}`;
  };

  const handleItemClick = (item: FeedItem) => {
    // Posts open as a dedicated full page
    if (item.content_type === 'post') {
      navigate(`/post/${item.id}`);
      return;
    }

    const route = getItemDetailRoute(item);
    if (!route) return;

    // Mark that we'll save, so the unmount effect doesn't overwrite the click-time scroll.
    savedByClickRef.current = true;
    // Capture scroll BEFORE navigating (cheap synchronous read).
    const scrollNow = scrollPositionRef.current;
    // Navigate IMMEDIATELY so the click feels instant.
    navigate(route);
    // Defer the expensive JSON.stringify of the cached feed to the next idle tick.
    const saveLater = () => {
      try {
        sessionStorage.setItem('social_feed_state', JSON.stringify({
          scrollPosition: scrollNow,
          items: feedItemsRef.current,
          page: pageRef.current,
          hasMore: hasMoreRef.current,
          timestamp: Date.now(),
        }));
      } catch (e) { /* quota or serialize error */ }
    };
    if (typeof (window as any).requestIdleCallback === 'function') {
      (window as any).requestIdleCallback(saveLater, { timeout: 1000 });
    } else {
      setTimeout(saveLater, 0);
    }
  };

  const handleFollowSeller = async (sellerId: string) => {
    if (!user) {
      navigate('/auth');
      return;
    }

    const seller = sellersToFollow.find(s => s.id === sellerId);
    if (!seller) return;

    try {
      // Insert follow record
      await supabase
        .from('follows')
        .insert({
          follower_id: user.id,
          following_id: (seller as any).user_id,
        });

      // Remove seller from list after following
      setSellersToFollow(prev => prev.filter(s => s.id !== sellerId));
    } catch (error) {
      console.error('Follow error:', error);
    }
  };
  // Offline with no cached items — show offline banner immediately
  if (!isOnline && feedItems.length === 0 && !loading) {
    return <div className="flex gap-0 w-full h-full">
        <div className="flex-1 max-w-[640px] xl:max-w-[720px] h-full overflow-y-auto border-r border-border">
          <OfflineBanner variant="fullpage" onRetry={() => {
            if (navigator.onLine) {
              setLoading(true);
              fetchFeedItems(0, true);
              fetchTrending();
              fetchSellersToFollow();
              fetchBoostedAds();
            }
          }} />
        </div>
        <div className="hidden xl:block w-72 flex-shrink-0"></div>
      </div>;
  }

  if (loading) {
    return <div className="flex gap-0 w-full h-full">
        {/* Same geometry as the loaded feed so nothing shifts when data lands */}
        <div className="relative flex-1 min-w-0 sm:max-w-[600px] lg:w-[598px] lg:max-w-[598px] lg:flex-none mx-auto h-full overflow-y-auto overflow-x-hidden border-r border-l border-border">
          <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border">
            <div className="flex">
              <div className="flex-1 py-4 text-[15px] text-center font-bold">For You</div>
              <div className="flex-1 py-4 text-[15px] text-center text-muted-foreground">Following</div>
              {isMobile && (
                <div className="flex-1 py-4 text-[15px] text-center text-muted-foreground">Search</div>
              )}
            </div>
          </div>
          {Array.from({ length: 4 }).map((_, i) => (
            <FeedCardSkeleton key={i} />
          ))}
        </div>
        <div className="hidden md:block flex-1 min-w-[290px] max-w-[420px] shrink-0" />
      </div>;
  }

  // Error state
  if (error && feedItems.length === 0) {
    return <div className="flex gap-0 w-full h-full">
        <div className="flex-1 max-w-[640px] xl:max-w-[720px] h-full overflow-y-auto border-r border-border flex items-center justify-center">
          <div className="flex flex-col items-center justify-center p-8 text-center">
            <AlertCircle className="w-16 h-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold text-foreground mb-2">Oops! Something went wrong</h3>
            <p className="text-muted-foreground mb-6 max-w-sm">{error}</p>
            <Button 
              onClick={() => fetchFeedItems(0, true)} 
              className="gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              Try Again
            </Button>
          </div>
        </div>
        <div className="hidden xl:block w-72 flex-shrink-0"></div>
      </div>;
  }
  // Handle swipe gestures for right sidebar on mobile
  // Only trigger from the right edge of the screen, not from carousels
  
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.targetTouches[0];
    touchStartX.current = touch.clientX;
    touchStartY.current = touch.clientY;
    touchEndX.current = touch.clientX;
    
    // Only allow swipe to open from the right edge (last 40px of screen)
    // For closing, allow from anywhere when sidebar is open
    const screenWidth = window.innerWidth;
    const isFromRightEdge = touch.clientX > screenWidth - 40;
    
    // Check if the touch target is inside a horizontal scrollable element (carousel)
    const target = e.target as HTMLElement;
    const isInsideCarousel = target.closest('[data-carousel]') !== null ||
                             target.closest('.embla') !== null ||
                             target.closest('[class*="overflow-x"]') !== null ||
                             target.closest('.overflow-x-auto') !== null ||
                             target.closest('.overflow-x-scroll') !== null;
    
    isValidSwipe.current = (isFromRightEdge && !rightSidebarOpen && !isInsideCarousel) || rightSidebarOpen;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isValidSwipe.current) return;
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!isValidSwipe.current) return;
    
    const swipeDistance = touchStartX.current - touchEndX.current;
    const swipeDistanceY = Math.abs(touchStartY.current - (touchEndX.current ? touchStartY.current : 0));
    
    // Only trigger if horizontal swipe is dominant (not scrolling vertically)
    const isHorizontalSwipe = Math.abs(swipeDistance) > swipeDistanceY * 1.5;
    
    if (!isHorizontalSwipe) return;
    
    // Swipe left to open sidebar (from right edge only)
    if (swipeDistance > 60 && !rightSidebarOpen) {
      setRightSidebarOpen(true);
    }
    // Swipe right to close sidebar
    if (swipeDistance < -60 && rightSidebarOpen) {
      setRightSidebarOpen(false);
    }
    
    isValidSwipe.current = false;
  };

  // Filter feed based on search
  const handleSearch = (query: string) => {
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  // Pull-to-refresh handlers for the feed scroll container
  const PULL_THRESHOLD = 70;
  const handleFeedPullStart = (e: React.TouchEvent) => {
    const c = document.getElementById('social-feed-scroll-container');
    if (!c || c.scrollTop > 0 || isRefreshing) return;
    pullStartY.current = e.touches[0].clientY;
    isPullingRef.current = true;
  };
  const handleFeedPullMove = (e: React.TouchEvent) => {
    if (!isPullingRef.current || isRefreshing) return;
    const c = document.getElementById('social-feed-scroll-container');
    if (c && c.scrollTop > 0) {
      isPullingRef.current = false;
      setPullDistance(0);
      return;
    }
    const diff = e.touches[0].clientY - pullStartY.current;
    if (diff > 0) {
      setPullDistance(Math.min(diff * 0.5, PULL_THRESHOLD + 20));
    }
  };
  const handleFeedPullEnd = async () => {
    if (!isPullingRef.current) return;
    isPullingRef.current = false;
    if (pullDistance >= PULL_THRESHOLD && !isRefreshing) {
      setIsRefreshing(true);
      setPullDistance(PULL_THRESHOLD * 0.7);
      try {
        await fetchFeedItems(0, true);
      } catch {
        /* ignore */
      }
      setIsRefreshing(false);
    }
    setPullDistance(0);
  };

  return <div 
    className="flex gap-0 w-full h-full relative"
    style={{ touchAction: 'pan-y' }}
  >
      {/* Invisible swipe zone on the right edge for sidebar gesture */}
      <div
        className="xl:hidden fixed right-0 top-0 bottom-0 w-10 z-40"
        style={{ touchAction: 'pan-x' }}
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      />
      
      {/* Swipe hint indicator - shows once */}
      <AnimatePresence>
        {showSwipeHint && (
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 50 }}
            className="xl:hidden fixed right-4 top-1/2 -translate-y-1/2 z-50 flex items-center gap-2 bg-primary text-primary-foreground px-4 py-3 rounded-full shadow-lg"
          >
            <ChevronLeft className="w-5 h-5 animate-pulse" />
            <span className="text-sm font-medium">Swipe to explore</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Center Feed - X.com style smooth scrolling, reduced width on large screens */}
       <div 
         className="relative flex-1 min-w-0 sm:max-w-[600px] lg:w-[598px] lg:max-w-[598px] lg:flex-none mx-auto h-full overflow-y-auto overflow-x-hidden border-r border-l border-border overscroll-contain" 
         id="social-feed-scroll-container"
         style={{ 
           WebkitOverflowScrolling: 'touch',
           touchAction: 'pan-y',
           height: '100%',
           maxHeight: '100%',
           transform: 'translateZ(0)',
           willChange: 'scroll-position',
         }}
         onTouchStart={handleFeedPullStart}
         onTouchMove={handleFeedPullMove}
         onTouchEnd={handleFeedPullEnd}
       >
        {/* Pull-to-refresh indicator */}
        {(pullDistance > 0 || isRefreshing) && (
          <div
            className="absolute left-1/2 -translate-x-1/2 z-40 pointer-events-none"
            style={{ top: Math.max(8, pullDistance - 28), opacity: isRefreshing ? 1 : Math.min(pullDistance / PULL_THRESHOLD, 1) }}
          >
            <div className="bg-background shadow-md rounded-full p-2 border border-border">
              <MaterialSpinner size={24} />
            </div>
          </div>
        )}
        {/* Sticky tabs header with swipe transitions for mobile */}
        <div className="sticky top-0 z-30 bg-background/95 backdrop-blur-sm border-b border-border transition-transform duration-300 will-change-transform" style={{ transform: 'translateZ(0)' }}>
          <div className="flex">
            <button 
              onClick={() => setActiveTab('foryou')}
              className={`flex-1 py-4 text-[15px] text-center hover:bg-muted/50 transition-colors relative flex flex-col items-center ${activeTab === 'foryou' ? 'font-bold' : 'text-muted-foreground'}`}
            >
              <span>For You</span>
              {activeTab === 'foryou' && (
                <motion.div 
                  layoutId="activeTab"
                  className="absolute bottom-0 h-1 bg-primary rounded-full" 
                  style={{ width: '52px' }}
                />
              )}
            </button>
            <button 
              onClick={() => setActiveTab('following')}
              className={`flex-1 py-4 text-[15px] text-center hover:bg-muted/50 transition-colors relative flex flex-col items-center ${activeTab === 'following' ? 'font-bold' : 'text-muted-foreground'}`}
            >
              <span>Following</span>
              {activeTab === 'following' && (
                <motion.div 
                  layoutId="activeTab"
                  className="absolute bottom-0 h-1 bg-primary rounded-full" 
                  style={{ width: '68px' }}
                />
              )}
            </button>
            {/* Search tab - only on mobile */}
            {isMobile && (
              <button 
                onClick={() => setActiveTab('search')}
                className={`flex-1 py-4 text-[15px] text-center hover:bg-muted/50 transition-colors relative flex flex-col items-center ${activeTab === 'search' ? 'font-bold' : 'text-muted-foreground'}`}
              >
                <span>Search</span>
                {activeTab === 'search' && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute bottom-0 h-1 bg-primary rounded-full" 
                    style={{ width: '52px' }}
                  />
                )}
              </button>
            )}
          </div>
        </div>

        {/* Tab content with swipe animation */}
        <AnimatePresence mode="wait">
          {activeTab === 'search' && isMobile ? (
            <motion.div
              key="search"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.2 }}
              className="min-h-[calc(100dvh-180px)] pb-[env(safe-area-inset-bottom)]"
            >
              <FeedSearchPanel
                onLike={handleLike}
                onSave={handleSave}
                onShare={handleShare}
                onComment={(item) => {
                  setSelectedPost(item);
                  setCommentModalOpen(true);
                }}
              />
            </motion.div>
          ) : (
            <motion.div
              key="feed"
              initial={{ opacity: 0, x: activeTab === 'foryou' ? 50 : -50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: activeTab === 'foryou' ? -50 : 50 }}
              transition={{ duration: 0.2 }}
              className="min-h-[calc(100dvh-180px)] pb-[env(safe-area-inset-bottom)]"
            >
              {/* Pinned products by people you follow - show at top for Following tab */}
              {activeTab === 'following' && user && <PinnedByFollowedSection />}

              {/* Sign-in gate for the Following tab */}
              {activeTab === 'following' && !user && (
                <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
                  <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <Plus className="w-8 h-8 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Sign in to see who you follow</h3>
                  <p className="text-muted-foreground text-sm max-w-sm mb-4">
                    Follow sellers and creators to see their latest posts, products and services here.
                  </p>
                  <Button onClick={() => navigate('/auth')}>Sign in</Button>
                </div>
              )}

              {/* Filter feed items based on active tab */}
              {activeTab === 'following' && !user ? null : (() => {
                // Filter items for Following tab - only show content from followed users
                // and sort newest-first so recently-followed sellers surface at top.
                const displayItems = activeTab === 'following' 
                  ? feedItems
                      .filter(item => item._isFromFollowed)
                      .slice()
                      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
                  : feedItems;

                

                
                // Show empty state for Following tab if no followed content
                if (activeTab === 'following' && displayItems.length === 0 && !loading) {
                  return (
                    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
                      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                        <Plus className="w-8 h-8 text-muted-foreground" />
                      </div>
                      <h3 className="text-lg font-semibold mb-2">No posts from people you follow</h3>
                      <p className="text-muted-foreground text-sm max-w-sm mb-4">
                        Follow sellers and creators to see their posts here
                      </p>
                      <Button variant="outline" onClick={() => setActiveTab('foryou')}>
                        Explore For You
                      </Button>
                    </div>
                  );
                }
                
                return displayItems.map((item, index) => <div key={item.id}>
                  {/* Use X-style video card for items with videos */}
                  <SwipeToMessage
                      item={item}
                      onSwipe={() => {
                        if (item.content_type === 'ad' && item.listing_type === 'jobs') {
                          handleItemClick(item);
                        } else {
                          navigate('/messages', {
                            state: {
                              recipientId: item.seller.user_id,
                              recipientName: item.seller.business_name,
                              adId: item.id,
                              adTitle: item.title,
                            }
                          });
                        }
                      }}
                      showHint={index === 0 && !localStorage.getItem('swipeToMessageShown')}
                    >
                      {item.b2_video_url && (!item.images || item.images.length === 0) ? (
                        <XStyleVideoCard
                          item={item}
                          onVideoClick={() => {
                            // For posts, open the rich post detail view
                            // (scrollable media + embeds + comments + replies)
                            // instead of a bare video preview.
                            if (item.content_type === 'post') {
                              navigate(`/post/${item.id}`);
                              
                            } else {
                              setVideoPreviewItem(item);
                              setVideoPreviewOpen(true);
                            }
                          }}
                          onLike={handleLike}
                          onSave={handleSave}
                          onShare={() => handleShare(item)}
                          onComment={() => {
                            if (item.content_type === 'post') {
                              navigate(`/post/${item.id}`);
                              
                            } else {
                              setSelectedPost(item);
                              setCommentModalOpen(true);
                            }
                          }}
                          onSellerClick={() => navigate(getSellerProfileUrl(item.seller))}
                          onItemClick={() => handleItemClick(item)}
                          scrollContainer={document.getElementById('social-feed-scroll-container')}
                          autoplayEnabled={settings.autoplay_videos && !settings.data_saver}
                        />
                      ) : (
                        <XStyleFeedCard
                          item={item}
                          onLike={handleLike}
                          onSave={handleSave}
                          onShare={() => handleShare(item)}
                          onComment={() => {
                            if (item.content_type === 'post') {
                              navigate(`/post/${item.id}`);
                              
                            } else {
                              setSelectedPost(item);
                              setCommentModalOpen(true);
                            }
                          }}
                          onSellerClick={() => navigate(getSellerProfileUrl(item.seller))}
                          onClick={() => handleItemClick(item)}
                          onVideoClick={(videoUrl) => {
                            if (item.content_type === 'post') {
                              navigate(`/post/${item.id}`);
                              
                            } else {
                              setVideoPreviewItem({ ...item, b2_video_url: videoUrl });
                              setVideoPreviewOpen(true);
                            }
                          }}
                        />
                      )}
                    </SwipeToMessage>
              
              {/* Inject Suggested Accounts ONLY ONCE after the 4th post */}
              {index === 3 && sellersToFollow.length > 0 && <SuggestedAccounts sellers={sellersToFollow} onFollow={handleFollowSeller} followingStates={followingStates} />}
              
              {/* Inject "Get Verified" promo card at position 5 and 30 (only twice, only for unverified sellers) */}
              {showVerificationPromo && (index === 4 || index === 29) && (
                <GetVerifiedPromoCard />
              )}
              
              {/* Inject Trending Now section after every 20 posts */}
              {(index + 1) % 20 === 0 && globalPinnedProducts.length > 0 && (
                <SponsoredSection 
                  products={globalPinnedProducts} 
                  loading={loadingPinned}
                  title="Trending Now"
                />
              )}
              
              {/* Inject Hot Deals section after every 25 posts */}
              {(index + 1) % 25 === 0 && discountedProducts.length > 0 && (
                <DiscountedProductsSection 
                  products={discountedProducts.map(p => ({
                    ...p,
                    is_verified: true
                  }))} 
                  loading={loadingDiscounted}
                />
              )}
              
              {/* Inject Services For You once after 15th post */}
              {index === 14 && <ServicesForYouSection />}
              {/* Removed: "Fresh from service workspaces" horizontal carousel — individual WorkspaceUpdateFeedCard with before/after slider still injected below */}

              {/* Inject individual workspace update as a full feed post every 6 items */}
              {(() => {
                if (index === 0 || workspaceUpdates.length === 0) return null;
                if (index % 6 !== 0) return null;
                const updateIndex = Math.floor(index / 6) - 1;
                // Inject each workspace update only ONCE (no modulo wrap) so the
                // same card is never shown repeatedly as the user scrolls.
                const update = workspaceUpdates[updateIndex];
                if (!update) return null;
                return <WorkspaceUpdateFeedCard key={`wu-${update.id}-${index}`} update={update} />;
              })()}
              
              {/* Inject Discounts For You once after 30th post */}
              {index === 29 && <DiscountsForYouSection />}
              </div>);
              })()}
              
              {/* Infinite scroll trigger */}
              <div ref={loadMoreRef} className="py-4">
                {isOnline && loadingMore && (
                  <div className="flex justify-center py-6">
                    <MaterialSpinner size={32} />
                  </div>
                )}
                {!hasMore && feedItems.length > 0 && (
                  <p className="text-center text-muted-foreground py-8">
                    You've reached the end
                  </p>
                )}
                {!isOnline && feedItems.length > 0 && (
                  <OfflineBanner onRetry={() => { if (hasMore) loadMoreItems(); }} />
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Right Sidebar - Tablet & Desktop: sticky position with independent scroll, flex to fill remaining space */}
       <div className="hidden md:block flex-1 min-w-[290px] max-w-[420px] shrink-0">
         <div className="h-full overflow-y-auto overscroll-contain scrollbar-thin scrollbar-thumb-muted scrollbar-track-transparent px-4">
          <XStyleRightSidebar
            trendingItems={trendingItems}
            sellersToFollow={sellersToFollow}
            boostedAds={boostedAds}
            loadingTrending={loadingTrending}
            loadingSellers={loadingSellers}
            loadingBoosted={loadingBoosted}
            currentTrendingIndex={currentTrendingIndex}
            currentBoostedIndex={currentBoostedIndex}
            followingStates={followingStates}
            onFollowSeller={handleFollowSeller}
            isOpen={true}
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            onSearch={handleSearch}
          />
        </div>
      </div>

      {/* Mobile Right Sidebar - Slide in overlay */}
      <AnimatePresence>
        {rightSidebarOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="md:hidden fixed inset-0 bg-background/80 backdrop-blur-sm z-40"
              onClick={() => setRightSidebarOpen(false)}
            />
            
            {/* Sidebar */}
            <motion.div
              ref={sidebarRef}
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="md:hidden fixed right-0 top-0 bottom-0 w-[85%] max-w-[350px] bg-background border-l border-border z-50 overflow-y-auto p-4"
            >
              {/* Close button */}
              <button 
                onClick={() => setRightSidebarOpen(false)}
                className="absolute top-4 left-4 p-2 rounded-full hover:bg-muted transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="pt-12">
                <XStyleRightSidebar
                  trendingItems={trendingItems}
                  sellersToFollow={sellersToFollow}
                  boostedAds={boostedAds}
                  loadingTrending={loadingTrending}
                  loadingSellers={loadingSellers}
                  loadingBoosted={loadingBoosted}
                  currentTrendingIndex={currentTrendingIndex}
                  currentBoostedIndex={currentBoostedIndex}
                  followingStates={followingStates}
                  onFollowSeller={handleFollowSeller}
                  isOpen={true}
                  searchQuery={searchQuery}
                  onSearchChange={setSearchQuery}
                  onSearch={handleSearch}
                />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Comment Modal */}
      <CommentModal 
        open={commentModalOpen} 
        onOpenChange={setCommentModalOpen} 
        contentType={selectedPost?.content_type || 'ad'}
        contentId={selectedPost?.id || ''}
        images={selectedPost?.images || []}
        author={{
          name: selectedPost?.seller.business_name || 'User',
          avatar: selectedPost?.seller.business_logo_url,
          is_verified: selectedPost?.seller.is_verified
        }}
        caption={selectedPost?.description}
        sellerId={selectedPost?.seller.id}
        sellerUserId={selectedPost?.seller.user_id}
        allowComments={selectedPost?.allow_comments !== false}
      />

      {/* Share Modal */}
      {shareItem && <ShareModal open={shareModalOpen} onOpenChange={setShareModalOpen} title={shareItem.title} url={`${getAppBaseUrl()}${getItemDetailRoute(shareItem) || `/ad/${shareItem.id}`}`} />}

      {/* Post Detail (TikTok-style) */}
      <PostDetailView
        post={postDetailItem as any}
        open={postDetailOpen}
        onClose={() => { setPostDetailOpen(false); setPostDetailItem(null); }}
      />

      {/* Video Preview Modal */}
      {videoPreviewItem && (
        <VideoPreviewModal
          item={videoPreviewItem}
          isOpen={videoPreviewOpen}
          onClose={() => {
            setVideoPreviewOpen(false);
            setVideoPreviewItem(null);
          }}
          onLike={handleLike}
          onSave={handleSave}
          onShare={handleShare}
          onComment={(item) => {
            // Cast to FeedItem type to satisfy TypeScript
            setSelectedPost(item as FeedItem);
            setCommentModalOpen(true);
          }}
        />
      )}

      <BackToTopButton />
    </div>;

};
export default SocialFeed;