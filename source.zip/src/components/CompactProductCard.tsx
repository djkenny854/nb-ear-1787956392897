import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Heart, Share2, Eye, ChevronLeft, ChevronRight, MapPin, Star, Package, ShoppingCart, Bookmark, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';
import ShareModal from '@/components/ShareModal';

interface CompactProductCardProps {
  ad: {
    id: string;
    title: string;
    price: number;
    currency: string;
    location: string;
    images: string[];
    created_at: string;
    is_boosted?: boolean;
    category: string;
    seller_id: string;
    view_count?: number;
    brand?: string;
    model?: string;
    condition?: string;
    features?: string;
    listing_type?: string;
    has_discount?: boolean;
    original_price?: number;
    seller: {
      business_name: string;
      business_logo_url?: string;
      is_verified: boolean;
      district?: string;
      sub_county?: string;
    };
  };
  onClick: (id: string) => void;
}

const CompactProductCard: React.FC<CompactProductCardProps> = ({ ad, onClick }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isLiked, setIsLiked] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [currentHighlight, setCurrentHighlight] = useState(0);
  const [shareModalOpen, setShareModalOpen] = useState(false);

  // Product highlights for cycling text
  const highlights = [
    ad.brand && `${ad.brand}`,
    ad.condition && `${ad.condition}`,
    ad.features && ad.features.split(',')[0],
    `${ad.category}`,
    `Posted ${new Date(ad.created_at).toLocaleDateString()}`
  ].filter(Boolean);

  // Auto-rotate images randomly between 4s, 5s, and 6s
  useEffect(() => {
    if (ad.images && ad.images.length > 1) {
      const getRandomInterval = () => {
        const intervals = [6000, 8000, 10000];
        return intervals[Math.floor(Math.random() * intervals.length)];
      };
      
      const rotateImage = () => {
        setCurrentImageIndex((prev) => (prev + 1) % ad.images.length);
        const nextInterval = getRandomInterval();
        timeoutId = setTimeout(rotateImage, nextInterval);
      };
      
      let timeoutId = setTimeout(rotateImage, getRandomInterval());
      return () => clearTimeout(timeoutId);
    }
  }, [ad.images]);

  // Auto-rotate highlights every 6 seconds
  useEffect(() => {
    if (highlights.length > 1) {
      const interval = setInterval(() => {
        setCurrentHighlight((prev) => (prev + 1) % highlights.length);
      }, 6000);
      return () => clearInterval(interval);
    }
  }, [highlights.length]);

  const nextImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (ad.images && ad.images.length > 0) {
      setCurrentImageIndex((prev) => (prev + 1) % ad.images.length);
    }
  };

  const prevImage = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (ad.images && ad.images.length > 0) {
      setCurrentImageIndex((prev) => (prev - 1 + ad.images.length) % ad.images.length);
    }
  };

  const formatPrice = (price: number, currency: string) => {
    return new Intl.NumberFormat('en-UG', {
      style: 'currency',
      currency: currency || 'UGX',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const getDiscountPercentage = () => {
    if (ad.has_discount && ad.original_price && ad.price) {
      return Math.round(((ad.original_price - ad.price) / ad.original_price) * 100);
    }
    return 0;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else if (diffInHours < 168) { // Less than a week
      return `${Math.floor(diffInHours / 24)}d ago`;
    } else {
      return date.toLocaleDateString();
    }
  };

  return (
    <Card 
      className="group cursor-pointer transition-all duration-500 border-border/50 hover:border-primary/50 overflow-hidden bg-card hover:shadow-2xl hover:shadow-primary/10 transform hover:-translate-y-1"
      onClick={() => onClick(ad.id)}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="relative">
        {/* Image Container */}
        <div className="relative aspect-[4/3] overflow-hidden bg-gradient-to-br from-muted/30 to-muted/60">
          {ad.images && ad.images.length > 0 ? (
            <>
              <img
                src={ad.images[currentImageIndex]}
                alt={ad.title}
                className="w-full h-full object-cover transition-all duration-700 group-hover:scale-110 group-hover:brightness-110"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  target.src = '/placeholder.svg';
                }}
              />
              
              {/* Dynamic Text Overlay */}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-3">
                <div className="text-white text-xs font-medium animate-fade-in">
                  {highlights[currentHighlight]}
                </div>
              </div>
              
              {/* Image Navigation */}
              {ad.images.length > 1 && (
                <div className="absolute inset-0 flex items-center justify-between px-2 opacity-0 group-hover:opacity-100 transition-all duration-300">
                  <Button
                    variant="secondary"
                    size="sm"
                    className="w-8 h-8 p-0 bg-white/90 hover:bg-white backdrop-blur-sm text-gray-800 shadow-lg"
                    onClick={prevImage}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="w-8 h-8 p-0 bg-white/90 hover:bg-white backdrop-blur-sm text-gray-800 shadow-lg"
                    onClick={nextImage}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              )}
              
              {/* Image Indicators */}
              {ad.images.length > 1 && (
                <div className="absolute top-2 left-1/2 transform -translate-x-1/2 flex gap-1">
                  {ad.images.map((_, index) => (
                    <div
                      key={index}
                      className={cn(
                        "w-2 h-1 rounded-full transition-all duration-300",
                        index === currentImageIndex ? "bg-white shadow-lg" : "bg-white/50"
                      )}
                    />
                  ))}
                </div>
              )}
            </>
          ) : (
            <div className="w-full h-full bg-gradient-to-br from-muted/30 to-muted/60 flex items-center justify-center">
              <Package className="w-12 h-12 text-muted-foreground/50" />
            </div>
          )}

          {/* Top Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {ad.is_boosted && (
              <Badge className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground text-xs px-2 py-1 shadow-lg backdrop-blur-sm">
                ⚡ Featured
              </Badge>
            )}
            {ad.has_discount && ad.original_price && (
              <Badge className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-2 py-1 shadow-lg animate-pulse">
                -{getDiscountPercentage()}%
              </Badge>
            )}
          </div>

          {/* Action Buttons */}
          <div className="absolute top-2 right-2 flex flex-col gap-2 transform translate-x-full group-hover:translate-x-0 transition-transform duration-300">
            <Button
              variant="secondary"
              size="sm"
              className={cn(
                "w-8 h-8 p-0 backdrop-blur-sm shadow-lg transition-all duration-300",
                isLiked ? "bg-red-50 text-red-500 hover:bg-red-100" : "bg-white/90 hover:bg-white text-gray-800"
              )}
              onClick={(e) => {
                e.stopPropagation();
                setIsLiked(!isLiked);
              }}
            >
              <Heart className={cn("w-4 h-4 transition-all", isLiked && "fill-current scale-110")} />
            </Button>
            <Button
              variant="secondary"
              size="sm"
              className="w-8 h-8 p-0 bg-white/90 hover:bg-white backdrop-blur-sm text-gray-800 shadow-lg"
              onClick={(e) => {
                e.stopPropagation();
              }}
            >
              <Bookmark className="w-4 h-4" />
            </Button>
            <Button
              variant="secondary"
              size="sm"
              className="w-8 h-8 p-0 bg-white/90 hover:bg-white backdrop-blur-sm text-gray-800 shadow-lg"
              onClick={(e) => {
                e.stopPropagation();
                setShareModalOpen(true);
              }}
            >
              <Share2 className="w-4 h-4" />
            </Button>
          </div>

          {/* Quick Action Bar - Appears on Hover */}
          <div className={cn(
            "absolute bottom-0 left-0 right-0 transform transition-all duration-300 bg-gradient-to-t from-black/90 via-black/70 to-transparent p-3",
            isHovered ? "translate-y-0 opacity-100" : "translate-y-full opacity-0"
          )}>
            <div className="flex gap-2 justify-center">
              <Button
                variant="secondary"
                size="sm"
                className="bg-white/20 hover:bg-white/30 text-white border-white/30 backdrop-blur-sm text-xs px-3"
                onClick={(e) => e.stopPropagation()}
              >
                <Eye className="w-3 h-3 mr-1" />
                View
              </Button>
              <Button
                variant="secondary"
                size="sm"
                className="bg-primary/80 hover:bg-primary text-white text-xs px-3"
                onClick={(e) => e.stopPropagation()}
              >
                <ShoppingCart className="w-3 h-3 mr-1" />
                Cart
              </Button>
            </div>
          </div>
        </div>

        {/* Content */}
        <CardContent className="p-4 space-y-3 bg-gradient-to-b from-card to-card/95">
          {/* Title and Date */}
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-primary transition-colors flex-1 leading-tight">
              {ad.title}
            </h3>
            <div className="flex items-center gap-1 text-xs text-muted-foreground shrink-0">
              <Calendar className="w-3 h-3" />
              <span>{formatDate(ad.created_at)}</span>
            </div>
          </div>

          {/* Price and Views */}
          <div className="flex items-center justify-between">
            {ad.listing_type !== 'jobs' && ad.listing_type !== 'promotions' ? (
              <div className="flex flex-col">
                <p className="text-xl font-bold text-primary leading-tight">
                  {formatPrice(ad.price, ad.currency)}
                </p>
                {ad.has_discount && ad.original_price && (
                  <div className="flex items-center gap-1">
                    <p className="text-xs text-muted-foreground line-through">
                      {formatPrice(ad.original_price, ad.currency)}
                    </p>
                    <span className="text-xs text-red-600 font-medium">
                      (-{getDiscountPercentage()}%)
                    </span>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  {ad.listing_type === 'jobs' ? 'Job Opening' : 'Special Offer'}
                </Badge>
              </div>
            )}
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Eye className="w-3 h-3" />
              <span>{ad.view_count || Math.floor(Math.random() * 500) + 50}</span>
            </div>
          </div>

          {/* Location */}
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="w-3 h-3 text-primary/70" />
            <span className="truncate font-medium">{ad.location}</span>
          </div>

          {/* Seller Info */}
          <div className="flex items-center justify-between pt-2 border-t border-border/50">
            <div className="flex items-center gap-2">
              <Avatar className="w-6 h-6 ring-2 ring-primary/20">
                <AvatarImage src={ad.seller.business_logo_url} />
                <AvatarFallback className="text-xs bg-gradient-to-br from-primary/20 to-primary/10 text-primary font-semibold">
                  {ad.seller.business_name?.charAt(0)?.toUpperCase() || 'S'}
                </AvatarFallback>
              </Avatar>
              <div className="flex items-center gap-1">
                <span className="text-xs font-medium text-foreground truncate max-w-20">
                  {ad.seller.business_name}
                </span>
                {ad.seller.is_verified && (
                  <svg viewBox="0 0 22 22" className="w-3 h-3 text-primary fill-current">
                    <path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z"/>
                  </svg>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-1">
              <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
              <span className="text-xs font-medium text-muted-foreground">4.{Math.floor(Math.random() * 5) + 5}</span>
            </div>
          </div>
        </CardContent>
      </div>

      {/* Share Modal */}
      <ShareModal
        open={shareModalOpen}
        onOpenChange={setShareModalOpen}
        title={ad.title}
        url={`${window.location.origin}/ad/${ad.id}`}
      />
    </Card>
  );
};

export default CompactProductCard;
