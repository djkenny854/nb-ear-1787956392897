
import React from 'react';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Star, Award } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import VerificationBadge from './VerificationBadge';

interface BannerSeller {
  id: string;
  business_name: string;
  business_description: string;
  business_logo_url: string;
  is_verified: boolean;
  rating: number;
  total_sales: number;
}

interface SellerBannerProps {
  sellers: BannerSeller[];
}

const SellerBanner: React.FC<SellerBannerProps> = ({ sellers }) => {
  const navigate = useNavigate();

  const handleSellerClick = (sellerId: string) => {
    navigate(`/business/${sellerId}`);
  };

  if (!sellers || sellers.length === 0) {
    return null;
  }

  return (
    <div className="py-6 bg-gradient-to-r from-primary/5 to-orange-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold text-gray-900">Featured Sellers</h2>
          <Badge className="bg-gradient-to-r from-yellow-400 to-yellow-600 text-black">
            <Star className="w-3 h-3 mr-1" />
            Promoted
          </Badge>
        </div>
        
        <Carousel className="w-full">
          <CarouselContent className="-ml-2 md:-ml-4">
            {sellers.map((seller) => (
              <CarouselItem key={seller.id} className="pl-2 md:pl-4 basis-full md:basis-1/2 lg:basis-1/3">
                <div 
                  className="relative overflow-hidden rounded-xl cursor-pointer group hover:shadow-lg transition-all duration-300"
                  onClick={() => handleSellerClick(seller.id)}
                >
                  {/* Banner Background */}
                  <div className="relative h-32 md:h-36 bg-gradient-to-br from-primary/20 to-orange-100">
                    <div className="w-full h-full bg-gradient-to-br from-primary/30 to-orange-200 group-hover:from-primary/40 group-hover:to-orange-300 transition-all duration-300" />
                    
                    {/* Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    
                    {/* Banner Type Badge */}
                    <Badge className="absolute top-3 right-3 bg-gradient-to-r from-blue-500 to-blue-700 text-white">
                      <Award className="w-3 h-3 mr-1" />
                      Featured
                    </Badge>
                  </div>
                  
                  {/* Seller Info */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 text-white">
                    <div className="flex items-center gap-3 mb-2">
                      <div className="w-12 h-12 rounded-full border-2 border-white overflow-hidden bg-white flex-shrink-0">
                        <img
                          src={seller.business_logo_url || "/placeholder.svg"}
                          alt={`${seller.business_name} logo`}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-bold text-white truncate text-lg">
                            {seller.business_name}
                          </h3>
                          <VerificationBadge 
                            isVerified={seller.is_verified} 
                            size="sm"
                            className="bg-green-500 text-white border-green-400"
                          />
                        </div>
                        <div className="flex items-center gap-3 text-sm text-white/90">
                          <div className="flex items-center gap-1">
                            <Star className="w-4 h-4 fill-current text-yellow-400" />
                            <span>{seller.rating?.toFixed(1) || '0.0'}</span>
                          </div>
                          <span>•</span>
                          <span>{seller.total_sales?.toLocaleString() || '0'} sales</span>
                        </div>
                      </div>
                    </div>
                    <p className="text-white/90 text-sm line-clamp-2">{seller.business_description}</p>
                  </div>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="hidden md:flex" />
          <CarouselNext className="hidden md:flex" />
        </Carousel>
      </div>
    </div>
  );
};

export default SellerBanner;
