import React, { useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { isRealNativeRuntime } from '@/hooks/useCapacitor';
// Dynamic import to avoid crashing on web — only run on real native runtime
const safePreferencesSet = async (key: string, value: string): Promise<void> => {
  if (!isRealNativeRuntime()) return;
  try {
    const { Preferences } = await import('@capacitor/preferences');
    await Preferences.set({ key, value });
  } catch {}
};
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';
import onboardingWelcome from '@/assets/onboarding-welcome-new.png';
import onboardingDiscover from '@/assets/onboarding-discover-new.png';
import onboardingConnect from '@/assets/onboarding-connect-new.png';
import onboardingStart from '@/assets/onboarding-start-new.png';

interface OnboardingSlidesProps {
  onFinish: () => void;
}

const STORAGE_KEY = 'earlymarket_onboarding_complete';

const slides = [
  {
    title: 'Welcome to EarlyMarket',
    tagline: 'The social business marketplace where people buy, sell, hire, and grow real businesses.',
    image: onboardingWelcome,
  },
  {
    title: 'Discover & Shop',
    tagline: 'Browse thousands of products, services, jobs, and events — all in one place.',
    image: onboardingDiscover,
  },
  {
    title: 'Connect & Sell',
    tagline: 'Verified businesses, structured listings, and real engagement that builds trust.',
    image: onboardingConnect,
  },
  {
    title: 'Your Marketplace Awaits',
    tagline: 'Join thousands of sellers and buyers. Your next opportunity is one tap away.',
    image: onboardingStart,
  },
];

const swipeThreshold = 50;

const slideVariants = {
  enter: (dir: number) => ({ x: dir > 0 ? '100%' : '-100%', opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (dir: number) => ({ x: dir > 0 ? '-100%' : '100%', opacity: 0 }),
};

const OnboardingSlides: React.FC<OnboardingSlidesProps> = ({ onFinish }) => {
  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(1);
  const swiping = useRef(false);

  const isLast = current === slides.length - 1;

  const finish = useCallback(() => {
    localStorage.setItem(STORAGE_KEY, 'true');
    safePreferencesSet(STORAGE_KEY, 'true');
    onFinish();
  }, [onFinish]);

  const goTo = useCallback((idx: number, dir: number) => {
    if (idx < 0 || idx >= slides.length) return;
    setDirection(dir);
    setCurrent(idx);
  }, []);

  const next = useCallback(() => {
    if (isLast) { finish(); return; }
    goTo(current + 1, 1);
  }, [current, isLast, finish, goTo]);

  const handleDragEnd = useCallback((_: any, info: PanInfo) => {
    if (swiping.current) return;
    const { offset, velocity } = info;
    if (Math.abs(offset.x) > swipeThreshold || Math.abs(velocity.x) > 500) {
      swiping.current = true;
      if (offset.x < 0 && current < slides.length - 1) {
        goTo(current + 1, 1);
      } else if (offset.x > 0 && current > 0) {
        goTo(current - 1, -1);
      }
      setTimeout(() => { swiping.current = false; }, 400);
    }
  }, [current, goTo]);

  const slide = slides[current];

  return (
    <div className="fixed inset-0 z-[100] bg-background flex flex-col overflow-hidden">
      {/* Top bar: logo left, skip right */}
      <div
        className="flex items-center justify-between px-6 pb-2 relative z-10"
        style={{ paddingTop: 'max(2.5rem, env(safe-area-inset-top))' }}
      >
        <img src={earlymarketLogo} alt="EarlyMarket" className="w-9 h-9 object-contain" />
        {!isLast && (
          <button
            onClick={finish}
            className="text-sm font-semibold text-foreground/70 uppercase tracking-wide px-3 py-1.5"
          >
            Skip
          </button>
        )}
      </div>

      {/* Slide content */}
      <div className="flex-1 flex flex-col items-center relative overflow-hidden">
        <AnimatePresence initial={false} custom={direction} mode="wait">
          <motion.div
            key={current}
            custom={direction}
            variants={slideVariants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.18}
            onDragEnd={handleDragEnd}
            className="flex flex-col items-center w-full h-full touch-pan-y px-4"
          >
            {/* Illustration area with glassmorphism blob background */}
            <div className="relative w-full flex justify-center items-center mt-2" style={{ maxWidth: 400, minHeight: 340 }}>
              {/* Deformed glassmorphism blob */}
              <div
                className="absolute inset-0 m-auto pointer-events-none"
                style={{
                  width: '90%',
                  height: '90%',
                  borderRadius: '42% 58% 62% 38% / 45% 55% 45% 55%',
                  background: 'hsl(var(--muted) / 0.6)',
                  backdropFilter: 'blur(20px)',
                  filter: 'blur(2px)',
                }}
              />
              {/* SVG Illustration */}
              <motion.img
                src={slide.image}
                alt={slide.title}
                className="relative z-10 w-[85%] object-contain"
                style={{ maxHeight: 340 }}
                initial={{ scale: 0.88, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.08, duration: 0.5, ease: 'easeOut' }}
              />
            </div>

            {/* Title */}
            <motion.h1
              className="text-2xl font-bold text-foreground text-center mb-2 mt-8 leading-tight tracking-tight"
              initial={{ filter: 'blur(12px)', opacity: 0, y: 18 }}
              animate={{ filter: 'blur(0px)', opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.15, ease: 'easeOut' }}
            >
              {slide.title}
            </motion.h1>

            {/* Tagline */}
            <motion.p
              className="text-sm text-muted-foreground text-center leading-relaxed max-w-[280px] font-normal"
              initial={{ filter: 'blur(10px)', opacity: 0, y: 14 }}
              animate={{ filter: 'blur(0px)', opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: 0.3, ease: 'easeOut' }}
            >
              {slide.tagline}
            </motion.p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom nav: dots left, Next/Get Started right */}
      <div
        className="relative z-10 px-8 flex items-center justify-between"
        style={{ paddingBottom: 'max(2.5rem, env(safe-area-inset-bottom))' }}
      >
        {/* Dot indicators */}
        <div className="flex gap-2">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => goTo(i, i > current ? 1 : -1)}
              className={`rounded-full transition-all duration-300 ${
                i === current
                  ? 'w-6 h-2.5 bg-primary'
                  : 'w-2.5 h-2.5 bg-muted-foreground/25'
              }`}
              style={{ borderRadius: 999 }}
            />
          ))}
        </div>

        {/* Next / Get Started button */}
        <button
          onClick={isLast ? finish : next}
          className="flex items-center gap-2 text-primary font-semibold text-sm"
        >
          <span>{isLast ? 'Get Started' : 'Next'}</span>
          <span className="w-9 h-9 rounded-full bg-primary flex items-center justify-center">
            <ArrowRight className="w-4 h-4 text-primary-foreground" />
          </span>
        </button>
      </div>
    </div>
  );
};

export default OnboardingSlides;
