// Backward-compatible wrapper around StyledQRCode
import React from 'react';
import StyledQRCode from '@/components/StyledQRCode';

interface BrandedQRCodeProps {
  value: string;
  size?: number;
  title?: string;
  subtitle?: string;
  logoUrl?: string;
  showDownload?: boolean;
}

const BrandedQRCode: React.FC<BrandedQRCodeProps> = ({
  value,
  size = 220,
  title,
  subtitle,
  showDownload = true,
}) => {
  return (
    <StyledQRCode
      value={value}
      size={size}
      title={title}
      subtitle={subtitle}
      showDownload={showDownload}
    />
  );
};

export default BrandedQRCode;
