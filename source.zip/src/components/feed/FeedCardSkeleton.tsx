import React from 'react';

/**
 * FeedCardSkeleton
 *
 * Shape-matched skeleton frame for a single social-feed / marketplace card.
 * Structurally mirrors the real card so swapping skeleton ↔ real content
 * causes zero layout shift.
 *
 * Sizes follow the EarlyMarket Keep-Alive + Skeleton spec:
 *   - Header:   avatar 40×40, name 38%×13, username 22%×11
 *   - Body:     three text lines (100%, 88%, 65%) × 13, 8px gap
 *   - Media:    16:9 box, max-h 300px, radius 12px
 *   - Actions:  four items, each circle 18×18 + count 22×11, row pr-8
 *   - Padding:  py-3 (12) px-4 (16), bottom border matches feed divider
 *
 * Animation comes from the global `.em-skeleton-shimmer` utility defined
 * in src/index.css. Do not swap to `.skeleton-shimmer` — that is the
 * legacy opacity-pulse used by other parts of the app.
 */
const FeedCardSkeleton: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div
      aria-hidden="true"
      data-em-skeleton="feed-card"
      className={[
        'w-full',
        'py-3 px-4',
        'border-b border-border',
        'select-none',
        className ?? '',
      ].join(' ')}
    >
      {/* Header row: avatar + name/username */}
      <div className="flex items-start gap-3">
        <div
          className="em-skeleton-shimmer rounded-full shrink-0"
          style={{ width: 40, height: 40 }}
        />
        <div className="flex-1 min-w-0 pt-1">
          <div
            className="em-skeleton-shimmer rounded"
            style={{ width: '38%', height: 13 }}
          />
          <div
            className="em-skeleton-shimmer rounded mt-2"
            style={{ width: '22%', height: 11 }}
          />
        </div>
      </div>

      {/* Text content: 3 lines @ 100% / 88% / 65%, 8px gap */}
      <div className="mt-3 flex flex-col" style={{ rowGap: 8 }}>
        <div className="em-skeleton-shimmer rounded" style={{ width: '100%', height: 13 }} />
        <div className="em-skeleton-shimmer rounded" style={{ width: '88%', height: 13 }} />
        <div className="em-skeleton-shimmer rounded" style={{ width: '65%', height: 13 }} />
      </div>

      {/* Media: 16:9, capped at 300px tall */}
      <div className="mt-3 w-full" style={{ maxHeight: 300 }}>
        <div
          className="em-skeleton-shimmer w-full"
          style={{
            aspectRatio: '16 / 9',
            maxHeight: 300,
            borderRadius: 12,
          }}
        />
      </div>

      {/* Action row: 4 evenly-spaced items, pr-8 to match real card */}
      <div className="mt-3 flex items-center justify-between" style={{ paddingRight: 32 }}>
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex items-center gap-2">
            <div
              className="em-skeleton-shimmer rounded-full"
              style={{ width: 18, height: 18 }}
            />
            <div
              className="em-skeleton-shimmer rounded"
              style={{ width: 22, height: 11 }}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default FeedCardSkeleton;
