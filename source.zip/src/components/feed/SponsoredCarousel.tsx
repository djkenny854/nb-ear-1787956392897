import React, { useRef, useState, useEffect } from 'react';
import { ChevronRight, ChevronLeft, Store, Heart, TrendingUp } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { cn } from '@/lib/utils';
import RailScroller from '@/components/common/RailScroller';

interface ProductItem {
  id: string;
  title: string;
  price: number;
  images: string[];
  seller_id: string;
  seller_name: string;
  seller_logo?: string;
  is_pinned?: boolean;
  has_discount?: boolean;
  original_price?: number;
  view_count?: number;
}

// Transparent X-style horizontal product card
const XStyleProductCard: React.FC<{ product: ProductItem; showDiscount?: boolean }> = ({ 
  product, 
  showDiscount 
}) => {
  const navigate = useNavigate();
  
  return (
    <div 
      onClick={() => navigate(`/ad/${product.id}`)}
      className="flex-shrink-0 w-[140px] cursor-pointer group"
    >
      <div className="relative aspect-square rounded-xl overflow-hidden mb-1.5 bg-foreground/5 border border-border/30">
        {product.images?.[0] ? (
          <img 
            src={product.images[0]} 
            alt={product.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground">
            <Store className="w-6 h-6" />
          </div>
        )}
        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300 flex items-center justify-center">
          <Heart className="w-5 h-5 text-white opacity-0 group-hover:opacity-80 transition-opacity duration-300" />
        </div>
      </div>
      <p className="text-[12px] font-medium text-foreground line-clamp-1">{product.title}</p>
      <div className="flex items-center gap-1">
        <span className="text-[11px] font-bold text-primary">{(localStorage.getItem('app_currency') || 'UGX')} {product.price?.toLocaleString()}</span>
      </div>
    </div>
  );
};

// Loading skeleton for carousel
const CarouselSkeleton: React.FC = () => (
  <div className="border-b border-border py-3 px-4">
    <div className="flex items-center justify-between mb-2">
      <div className="flex items-center gap-2">
        <Skeleton className="w-4 h-4 rounded-full" />
        <Skeleton className="w-32 h-3" />
      </div>
      <Skeleton className="w-12 h-3" />
    </div>
    <div className="flex gap-3 overflow-hidden">
      {Array.from({ length: 4 }).map((_, i) => (
        <div key={i} className="flex-shrink-0 w-[140px]">
          <Skeleton className="aspect-square rounded-xl mb-1.5" />
          <Skeleton className="w-full h-3 mb-1" />
          <Skeleton className="w-14 h-3" />
        </div>
      ))}
    </div>
  </div>
);

// Custom hook for carousel scroll
const useCarouselScroll = (scrollRef: React.RefObject<HTMLDivElement>) => {
  const [canScrollPrev, setCanScrollPrev] = useState(false);
  const [canScrollNext, setCanScrollNext] = useState(true);

  const checkScroll = () => {
    if (scrollRef.current) {
      const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
      setCanScrollPrev(scrollLeft > 0);
      setCanScrollNext(scrollLeft < scrollWidth - clientWidth - 10);
    }
  };

  useEffect(() => {
    checkScroll();
    const el = scrollRef.current;
    if (el) {
      el.addEventListener('scroll', checkScroll);
      return () => el.removeEventListener('scroll', checkScroll);
    }
  }, []);

  const scrollPrev = () => {
    scrollRef.current?.scrollBy({ left: -280, behavior: 'smooth' });
  };

  const scrollNext = () => {
    scrollRef.current?.scrollBy({ left: 280, behavior: 'smooth' });
  };

  return { canScrollPrev, canScrollNext, scrollPrev, scrollNext };
};

// Trending Section - X.com style inline in feed (no icons, no sponsored badge)
export const SponsoredSection: React.FC<{ 
  products: ProductItem[]; 
  loading?: boolean;
  title?: string;
}> = ({ products, loading, title = "Trending Now" }) => {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const { canScrollPrev, canScrollNext, scrollPrev, scrollNext } = useCarouselScroll(scrollRef);
  
  if (loading) return <CarouselSkeleton />;
  if (!products || products.length === 0) return null;

  // Sort by view_count for trending (highest engagement first)
  const sortedProducts = [...products].sort((a, b) => (b.view_count || 0) - (a.view_count || 0));

  return (
    <div className="border-b border-border py-3">
      <div className="flex items-center justify-between mb-2 px-4">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-[14px] text-foreground">{title}</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="hidden sm:flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => { e.stopPropagation(); scrollPrev(); }}
              disabled={!canScrollPrev}
              className={cn(
                "h-6 w-6 rounded-full",
                !canScrollPrev && "opacity-30 cursor-not-allowed"
              )}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => { e.stopPropagation(); scrollNext(); }}
              disabled={!canScrollNext}
              className={cn(
                "h-6 w-6 rounded-full",
                !canScrollNext && "opacity-30 cursor-not-allowed"
              )}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          <button 
            onClick={() => navigate('/search')}
            className="text-[12px] text-primary flex items-center gap-0.5 hover:underline"
          >
            See all
          </button>
        </div>
      </div>
      <RailScroller>
      <div 
        ref={scrollRef}
        className="flex gap-3 overflow-x-auto pb-2 px-4 scrollbar-hide scroll-smooth"
      >
        {sortedProducts.slice(0, 10).map((product) => (
          <XStyleProductCard 
            key={product.id} 
            product={product} 
            showDiscount={false}
          />
        ))}
      </div>
      </RailScroller>
    </div>
  );
};

export default SponsoredSection;
