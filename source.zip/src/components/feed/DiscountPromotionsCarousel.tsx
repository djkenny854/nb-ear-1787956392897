import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { Skeleton } from '@/components/ui/skeleton';
import DiscountPromotionCard from './DiscountPromotionCard';

interface DiscountPromotion {
  id: string;
  ad_id: string;
  title: string;
  description: string;
  discount_percentage: number;
  promotion_type: string;
  offer_type: string;
  start_at: string | null;
  valid_until: string | null;
  state: string;
  images: string[];
  seller: {
    id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
  };
  products: {
    id: string;
    image: string;
    title: string;
    discount_percentage?: number;
  }[];
}

const DiscountPromotionsCarousel: React.FC = () => {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [promotions, setPromotions] = useState<DiscountPromotion[]>([]);
  const [loading, setLoading] = useState(true);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  useEffect(() => {
    fetchDiscountPromotions();
  }, []);

  const fetchDiscountPromotions = async () => {
    try {
      // FIX: Fetch promotions that are discount type OR have a discount_percentage > 0
      // This ensures all discount-related promotions are shown, not just those with offer_type='Discount'
      const { data: promoData, error } = await supabase
        .from('promotion_details')
        .select(`
          id,
          ad_id,
          discount_percentage,
          promotion_type,
          offer_type,
          start_at,
          valid_until,
          state,
          is_seller_wide,
          ads!inner(
            id,
            title,
            description,
            images,
            status,
            seller_profiles(
              id,
              business_name,
              business_logo_url,
              is_verified
            )
          )
        `)
        .or('offer_type.eq.Discount,discount_percentage.gt.0')
        .eq('ads.status', 'active')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;

      const formattedPromotions: DiscountPromotion[] = [];
      
      for (const promo of promoData || []) {
        const ad = promo.ads as any;
        const seller = ad.seller_profiles;

        // First, try to get products from promotion_products table (linked products)
        const { data: linkedProducts, error: linkedError } = await supabase
          .from('promotion_products')
          .select(`
            id,
            ad_id,
            discount_percentage,
            ads!inner (
              id,
              title,
              images
            )
          `)
          .eq('promotion_id', promo.id);

        let products: { id: string; image: string; title: string; discount_percentage?: number }[] = [];
        
        if (!linkedError && linkedProducts && linkedProducts.length > 0) {
          // Use linked products from promotion_products
          products = linkedProducts.map((lp: any) => ({
            id: lp.ads.id,
            title: lp.ads.title,
            image: lp.ads.images?.[0] || '/placeholder.svg',
            discount_percentage: lp.discount_percentage || promo.discount_percentage || 0
          }));
        } else if (promo.is_seller_wide) {
          // Fallback: Fetch products from that seller only if store-wide
          const { data: sellerProducts } = await supabase
            .from('ads')
            .select('id, title, images')
            .eq('seller_id', seller.id)
            .eq('status', 'active')
            .eq('listing_type', 'physical_products')
            .limit(6);

          products = (sellerProducts || []).map(p => ({
            id: p.id,
            title: p.title,
            image: p.images?.[0] || '/placeholder.svg',
            discount_percentage: promo.discount_percentage || 0
          }));
        }

        formattedPromotions.push({
          id: promo.id,
          ad_id: promo.ad_id,
          title: ad.title,
          description: ad.description || '',
          discount_percentage: promo.discount_percentage || 0,
          promotion_type: promo.promotion_type || 'standard',
          offer_type: promo.offer_type || 'Discount',
          start_at: promo.start_at,
          valid_until: promo.valid_until,
          state: promo.state || 'live',
          images: ad.images || [],
          seller: {
            id: seller.id,
            business_name: seller.business_name,
            business_logo_url: seller.business_logo_url,
            is_verified: seller.is_verified,
          },
          products,
        });
      }

      setPromotions(formattedPromotions);
    } catch (error) {
      console.error('Error fetching discount promotions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanScrollLeft(scrollLeft > 0);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  const scroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const scrollAmount = 320;
    scrollRef.current.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
  };

  if (loading) {
    return (
      <div className="space-y-3 px-4">
        <div className="flex items-center gap-2">
          <Skeleton className="h-5 w-5 rounded" />
          <Skeleton className="h-5 w-40" />
        </div>
        <div className="flex gap-4 overflow-hidden">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-[220px] w-[300px] rounded-2xl shrink-0" />
          ))}
        </div>
      </div>
    );
  }

  if (promotions.length === 0) {
    return null;
  }

  return (
    <div className="relative py-4">
      {/* Header */}
      <div className="flex items-center justify-between px-4 mb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-gradient-to-br from-red-500 to-orange-500">
            <Sparkles className="h-4 w-4 text-white" />
          </div>
          <h2 className="font-bold text-base sm:text-lg">Live Discounts & Deals</h2>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={() => scroll('left')}
            disabled={!canScrollLeft}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 rounded-full"
            onClick={() => scroll('right')}
            disabled={!canScrollRight}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Carousel */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex gap-4 overflow-x-auto scrollbar-hide px-4 pb-2"
        style={{ scrollSnapType: 'x mandatory' }}
      >
        {promotions.map((promo, index) => (
          <motion.div
            key={promo.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="shrink-0 w-[300px] sm:w-[340px]"
            style={{ scrollSnapAlign: 'start' }}
          >
            <DiscountPromotionCard
              id={promo.id}
              title={promo.title}
              description={promo.description}
              discountPercent={promo.discount_percentage}
              promotionType={promo.promotion_type as any}
              offerType={promo.offer_type}
              startAt={promo.start_at || undefined}
              validUntil={promo.valid_until || undefined}
              products={promo.products}
              seller={promo.seller}
              coverImage={promo.images?.[0]}
              onClick={() => navigate(`/promotion/${promo.ad_id}`)}
              onSellerClick={() => navigate(`/business/${promo.seller.id}`)}
              onRemindMe={() => {
                // TODO: Implement reminder functionality
                console.log('Set reminder for', promo.id);
              }}
            />
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default DiscountPromotionsCarousel;
