import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import BeforeAfterSlider from '@/components/common/BeforeAfterSlider';
import {
  Sparkles,
  ArrowLeftRight,
  Video,
  Megaphone,
  ImageIcon,
  Star,
  BadgeCheck,
  Quote,
  Play,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { useViewTracking } from '@/hooks/useViewTracking';
import ReelVideoPlayer from '@/components/feed/ReelVideoPlayer';
import RailScroller from '@/components/common/RailScroller';

interface WorkspaceUpdate {
  id: string;
  service_id: string;
  seller_id: string;
  update_type: string;
  title: string | null;
  caption: string | null;
  images: string[];
  video_url: string | null;
  video_thumbnail_url: string | null;
  before_image_url: string | null;
  after_image_url: string | null;
  created_at: string;
  like_count: number;
  comment_count: number;
  share_count: number;
  ad?: { id: string; title: string; category: string | null; status?: string } | null;
  seller?: { business_name: string; business_logo_url: string | null; is_verified: boolean } | null;
}

const typeMeta: Record<string, { icon: React.ElementType; label: string; color: string }> = {
  work: { icon: ImageIcon, label: 'New work', color: 'text-sky-600 bg-sky-500/10' },
  reel: { icon: Video, label: 'Reel', color: 'text-purple-600 bg-purple-500/10' },
  before_after: { icon: ArrowLeftRight, label: 'Before / After', color: 'text-emerald-600 bg-emerald-500/10' },
  promo: { icon: Sparkles, label: 'Promo', color: 'text-pink-600 bg-pink-500/10' },
  announcement: { icon: Megaphone, label: 'Announcement', color: 'text-blue-600 bg-blue-500/10' },
  progress: { icon: ImageIcon, label: 'Progress update', color: 'text-amber-600 bg-amber-500/10' },
  testimonial: { icon: Star, label: 'Customer review', color: 'text-yellow-600 bg-yellow-500/10' },
};

const useWorkspaceUpdatesFeed = (limit = 20) => {
  const [items, setItems] = useState<WorkspaceUpdate[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { data: updates } = await supabase
          .from('service_updates' as any)
          .select(
            `id, service_id, seller_id, update_type, title, caption, images,
             video_url, video_thumbnail_url, before_image_url, after_image_url,
             created_at, like_count, comment_count, share_count,
             ad:ads!service_updates_service_id_fkey(id, title, category, status)`
          )
          .eq('is_active', true)
          .order('created_at', { ascending: false })
          .limit(limit);

        const list = ((updates as any[]) || []).filter((r) => !r.ad || r.ad?.status === 'active');
        const sellerIds = Array.from(new Set(list.map((r) => r.seller_id).filter(Boolean)));

        let sellersMap = new Map<string, any>();
        if (sellerIds.length) {
          const { data: sellers } = await supabase
            .from('seller_profiles')
            .select('user_id, business_name, business_logo_url, is_verified')
            .in('user_id', sellerIds);
          sellersMap = new Map((sellers || []).map((s: any) => [s.user_id, s]));
        }

        const enriched = list.map((u) => ({
          ...u,
          seller: sellersMap.get(u.seller_id) || null,
        }));

        if (!cancelled) setItems(enriched as any);
      } catch (e) {
        console.warn('workspace updates fetch failed', e);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [limit]);

  return { items, loading };
};

/** Single full-width feed card representing one workspace update.
 *  Engagement icons are intentionally hidden — views are aggregated to the
 *  service workspace itself via useViewTracking, so all updates contribute
 *  to the same workspace's totals (instead of each update getting its own). */
export const WorkspaceUpdateFeedCard: React.FC<{ update: WorkspaceUpdate }> = ({ update }) => {
  const navigate = useNavigate();
  const meta = typeMeta[update.update_type] || typeMeta.work;
  const Icon = meta.icon;
  const sellerName = update.seller?.business_name || 'Service workspace';

  // Track views against the parent service (contentType: 'service') so all
  // updates from the same workspace add up to one view counter. 4s in-view
  // threshold per the user's spec.
  const trackerRef = useViewTracking({
    contentId: update.service_id,
    contentType: 'service',
    sourcePage: 'feed',
    threshold: 0.5,
    viewDuration: 4000,
  });

  const goService = () => navigate(`/service/${update.service_id}`);

  return (
    <article
      ref={trackerRef}
      className="border-b border-border bg-card hover:bg-muted/30 transition-colors cursor-pointer"
      onClick={goService}
    >
      <div className="p-4">
        {/* Header */}
        <div className="flex items-start gap-3">
          <Avatar className="h-10 w-10 shrink-0">
            <AvatarImage src={update.seller?.business_logo_url || ''} />
            <AvatarFallback>{sellerName[0]}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="font-semibold text-sm truncate">{sellerName}</span>
              {update.seller?.is_verified && <BadgeCheck className="w-4 h-4 text-primary" />}
              <Badge className={cn('gap-1 border-0 text-[10px] h-5 px-1.5', meta.color)}>
                <Icon className="w-3 h-3" /> {meta.label}
              </Badge>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground mt-0.5">
              {update.ad?.title && <span className="truncate">{update.ad.title}</span>}
              <span>·</span>
              <span>{formatDistanceToNow(new Date(update.created_at), { addSuffix: true })}</span>
            </div>
          </div>
        </div>

        {/* Title / caption */}
        {(update.title || update.caption) && (
          <div className="mt-2 pl-[52px]">
            {update.title && <p className="text-sm font-semibold leading-snug">{update.title}</p>}
            {update.caption && (
              <p className="text-sm text-foreground/90 mt-0.5 line-clamp-4 whitespace-pre-wrap">
                {update.caption}
              </p>
            )}
          </div>
        )}

        {/* Media — variant-aware */}
        <div className="mt-3 pl-[52px]">
          {update.update_type === 'before_after' && update.before_image_url && update.after_image_url ? (
            <div className="rounded-xl overflow-hidden border border-border" onClick={(e) => e.stopPropagation()}>
              <BeforeAfterSlider
                beforeUrl={update.before_image_url}
                afterUrl={update.after_image_url}
              />
            </div>
          ) : update.update_type === 'testimonial' ? (
            <div className="relative rounded-xl border border-amber-500/30 bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent p-4">
              <Quote className="absolute top-2 right-2 w-8 h-8 text-amber-500/30" />
              <div className="flex items-center gap-1 mb-2">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                ))}
              </div>
              {update.caption && (
                <p className="text-sm italic text-foreground/90 leading-relaxed">"{update.caption}"</p>
              )}
              {update.images?.[0] && (
                <img src={update.images[0]} className="mt-3 w-full max-h-72 object-cover rounded-lg" alt="" />
              )}
            </div>
          ) : update.video_url ? (
            <div className="relative" onClick={(e) => e.stopPropagation()}>
              <ReelVideoPlayer
                src={update.video_url}
                poster={update.video_thumbnail_url}
              />
              <Badge className="absolute top-2 left-2 z-30 bg-purple-600 text-white border-0 text-[10px] pointer-events-none">
                <Video className="w-3 h-3 mr-1" /> Reel
              </Badge>
            </div>
          ) : update.images && update.images.length > 0 ? (
            <div className={cn(
              'grid gap-1 rounded-xl overflow-hidden border border-border',
              update.images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
            )}>
              {update.images.slice(0, 4).map((src, i) => (
                <img
                  key={i}
                  src={src}
                  className={cn(
                    'w-full object-cover',
                    update.images.length === 1 ? 'max-h-[480px]' : 'h-44'
                  )}
                  alt=""
                />
              ))}
            </div>
          ) : null}
        </div>

        {/* Footer — no per-update engagement icons; views aggregate to the workspace */}
        <div className="mt-3 pl-[52px] flex items-center text-xs text-muted-foreground">
          <span className="ml-auto text-primary font-medium">View workspace →</span>
        </div>
      </div>
    </article>
  );
};


/** Original carousel kept for backwards compatibility */
const WorkspaceUpdatesSection: React.FC = () => {
  const { items, loading } = useWorkspaceUpdatesFeed(6);
  const navigate = useNavigate();

  if (loading) {
    return (
      <div className="mx-4 my-4 rounded-2xl border border-border bg-card p-4">
        <Skeleton className="h-5 w-40 mb-3" />
        <div className="flex gap-3 overflow-hidden">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-48 w-64 rounded-xl shrink-0" />
          ))}
        </div>
      </div>
    );
  }
  if (items.length === 0) return null;

  return (
    <div className="mx-4 my-4 rounded-2xl border border-border bg-card overflow-hidden">
      <div className="p-4 border-b border-border flex items-center gap-2">
        <Sparkles className="w-4 h-4 text-primary" />
        <p className="text-sm font-semibold">Fresh from service workspaces</p>
      </div>
      <RailScroller>
      <div className="flex gap-3 overflow-x-auto p-3 snap-x snap-mandatory">
        {items.map((u) => {
          const meta = typeMeta[u.update_type] || typeMeta.work;
          const Icon = meta.icon;
          const cover =
            u.update_type === 'before_after' && u.after_image_url
              ? u.after_image_url
              : u.video_thumbnail_url || u.images?.[0] || u.before_image_url;
          return (
            <button
              key={u.id}
              onClick={() => navigate(`/service/${u.service_id}`)}
              className="snap-start shrink-0 w-64 rounded-xl border border-border overflow-hidden bg-background text-left hover:shadow-md transition-shadow"
            >
              <div className="relative aspect-video bg-muted">
                {cover ? (
                  <img src={cover} className="w-full h-full object-cover" alt="" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                    <Icon className="w-8 h-8" />
                  </div>
                )}
                <Badge className={cn('absolute top-2 left-2 gap-1 border-0', meta.color)}>
                  <Icon className="w-3 h-3" /> {meta.label}
                </Badge>
              </div>
              <div className="p-3">
                <p className="text-xs font-medium truncate">{u.seller?.business_name || 'Seller'}</p>
                {u.title && <p className="text-sm font-semibold line-clamp-1">{u.title}</p>}
              </div>
            </button>
          );
        })}
      </div>
      </RailScroller>
    </div>
  );
};

export { useWorkspaceUpdatesFeed };
export default WorkspaceUpdatesSection;
