import React, { useRef, useState, useCallback } from 'react';
import { MessageCircle, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { hapticFeedback } from '@/components/CapacitorProvider';

interface SwipeToMessageProps {
  children: React.ReactNode;
  item: { content_type: string; listing_type?: string; title: string };
  onSwipe: () => void;
  showHint?: boolean;
}

const SWIPE_THRESHOLD = 70;

const SwipeToMessage: React.FC<SwipeToMessageProps> = ({ children, item, onSwipe, showHint }) => {
  const startX = useRef(0);
  const startY = useRef(0);
  const [offset, setOffset] = useState(0);
  const [swiping, setSwiping] = useState(false);
  const [hintVisible, setHintVisible] = useState(showHint);
  const [triggered, setTriggered] = useState(false);
  const hapticTriggered = useRef(false);

  // Enable swipe on all card types
  const swipeDisabled = false;

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    if (swipeDisabled) return;
    // Don't trigger swipe on carousels or horizontal scrollable containers
    const target = e.target as HTMLElement;
    if (target.closest('[data-carousel]') || target.closest('.overflow-x-auto') || target.closest('.scrollbar-hide')) {
      return;
    }
    startX.current = e.touches[0].clientX;
    startY.current = e.touches[0].clientY;
    setSwiping(true);
    hapticTriggered.current = false;
  }, [swipeDisabled]);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    if (!swiping || swipeDisabled) return;
    const dx = e.touches[0].clientX - startX.current;
    const dy = Math.abs(e.touches[0].clientY - startY.current);
    
    // If vertical scrolling, cancel swipe
    if (dy > Math.abs(dx)) {
      setSwiping(false);
      setOffset(0);
      return;
    }
    
    // Only allow right swipe with elastic feel
    if (dx > 0) {
      const dampened = Math.min(dx * 0.6, 130);
      setOffset(dampened);
      
      // Haptic feedback when crossing threshold
      if (dampened > SWIPE_THRESHOLD && !hapticTriggered.current) {
        hapticTriggered.current = true;
        hapticFeedback.medium();
      }
    }
  }, [swiping, swipeDisabled]);

  const handleTouchEnd = useCallback(() => {
    if (swipeDisabled) return;
    if (offset > SWIPE_THRESHOLD) {
      setTriggered(true);
      localStorage.setItem('swipeToMessageShown', 'true');
      setHintVisible(false);
      hapticFeedback.light();
      // Small delay for visual feedback before navigating
      setTimeout(() => {
        onSwipe();
        setTriggered(false);
      }, 150);
    }
    setOffset(0);
    setSwiping(false);
  }, [offset, onSwipe, swipeDisabled]);

  // Hide hint after 3 seconds
  React.useEffect(() => {
    if (hintVisible) {
      const timer = setTimeout(() => setHintVisible(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [hintVisible]);

  if (swipeDisabled) {
    return <>{children}</>;
  }

  return (
    <div className="relative overflow-hidden">
      {/* Background reveal on swipe */}
      <AnimatePresence>
        {offset > 15 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: Math.min(offset / SWIPE_THRESHOLD, 1) }}
            exit={{ opacity: 0 }}
            className="absolute inset-y-0 left-0 w-24 flex items-center justify-center bg-primary/10 z-0"
          >
            <motion.div 
              className="flex flex-col items-center gap-1"
              animate={{ scale: offset > SWIPE_THRESHOLD ? 1.2 : 1 }}
              transition={{ type: 'spring', stiffness: 400, damping: 15 }}
            >
              <MessageCircle className={`w-5 h-5 ${offset > SWIPE_THRESHOLD ? 'text-primary' : 'text-primary/70'}`} />
              <span className={`text-[10px] font-medium ${offset > SWIPE_THRESHOLD ? 'text-primary' : 'text-primary/70'}`}>Chat</span>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Swipe hint */}
      <AnimatePresence>
        {hintVisible && (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="absolute top-1/2 -translate-y-1/2 left-2 z-20 flex items-center gap-1 bg-primary/90 text-primary-foreground text-[11px] px-2.5 py-1.5 rounded-full shadow-lg"
          >
            <ChevronRight className="w-3 h-3 animate-pulse" />
            Swipe to chat
          </motion.div>
        )}
      </AnimatePresence>

      <div
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        style={{ 
          transform: `translateX(${offset}px)`, 
          transition: swiping ? 'none' : 'transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94)' 
        }}
        className="relative z-10 bg-background"
      >
        {children}
      </div>
    </div>
  );
};

export default SwipeToMessage;
