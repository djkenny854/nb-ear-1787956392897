import React from 'react';
import FeedCardSkeleton from './FeedCardSkeleton';

/**
 * FeedCardShell
 *
 * Two-layer wrapper that fades a FeedCardSkeleton out as the real card
 * fades in. Both layers occupy the same box, so no layout shift occurs.
 *
 * Behavior:
 *  - isLoaded=false → skeleton is relatively-positioned (drives layout
 *    height), opacity 1, pointer-events auto; real content is absolutely
 *    positioned over it with opacity 0, pointer-events none.
 *  - isLoaded=true  → real content becomes relatively-positioned and
 *    opacity 1; skeleton becomes absolutely positioned, opacity 0,
 *    pointer-events none, so it consumes no layout space and stays
 *    invisible during the 0.35s fade.
 *
 * The 0.35s opacity transition is intentional and matches the spec.
 */
interface FeedCardShellProps {
  isLoaded: boolean;
  children: React.ReactNode;
  /** Optional custom skeleton, defaults to <FeedCardSkeleton /> */
  skeleton?: React.ReactNode;
  className?: string;
}

const TRANSITION = 'opacity 0.35s ease-out';

const FeedCardShell: React.FC<FeedCardShellProps> = ({
  isLoaded,
  children,
  skeleton,
  className,
}) => {
  const skeletonNode = skeleton ?? <FeedCardSkeleton />;

  return (
    <div className={['relative w-full', className ?? ''].join(' ')}>
      {/* Skeleton layer */}
      <div
        aria-hidden={isLoaded ? 'true' : undefined}
        style={{
          position: isLoaded ? 'absolute' : 'relative',
          inset: isLoaded ? 0 : undefined,
          width: '100%',
          opacity: isLoaded ? 0 : 1,
          pointerEvents: isLoaded ? 'none' : 'auto',
          transition: TRANSITION,
        }}
      >
        {skeletonNode}
      </div>

      {/* Real content layer */}
      <div
        style={{
          position: isLoaded ? 'relative' : 'absolute',
          inset: isLoaded ? undefined : 0,
          width: '100%',
          opacity: isLoaded ? 1 : 0,
          pointerEvents: isLoaded ? 'auto' : 'none',
          transition: TRANSITION,
        }}
      >
        {children}
      </div>
    </div>
  );
};

export default FeedCardShell;
