import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Search, X, TrendingUp, MapPin, Calendar, Tag, Briefcase, ShoppingBag, Users, Package } from 'lucide-react';
import { cn } from '@/lib/utils';
import { supabase } from '@/integrations/supabase/client';
import { motion, AnimatePresence } from 'framer-motion';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';
import { format } from 'date-fns';

interface SellerResult {
  type: 'seller';
  id: string;
  business_name: string;
  business_logo_url: string | null;
  is_verified: boolean;
  verification_badge_color?: string | null;
  store_slug: string | null;
  follower_count: number | null;
}

interface ProductResult {
  type: 'product';
  id: string;
  title: string;
  price: number;
  images: string[];
  category: string;
  listing_type: string;
}

interface EventResult {
  type: 'event';
  id: string;
  title: string;
  location: string;
  event_date: string;
  is_free: boolean;
  cover_image: string | null;
}

interface ServiceResult {
  type: 'service';
  id: string;
  title: string;
  price: number;
  location: string;
  images: string[];
}

interface JobResult {
  type: 'job';
  id: string;
  title: string;
  location: string;
  company_name?: string;
}

type SearchResult = SellerResult | ProductResult | EventResult | ServiceResult | JobResult;

interface TrendingSearch {
  term: string;
  count: number;
}

const SearchDropdown: React.FC = () => {
  const navigate = useNavigate();
  const [query, setQuery] = useState('');
  const [isFocused, setIsFocused] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [trendingSearches, setTrendingSearches] = useState<TrendingSearch[]>([
    { term: 'Electronics', count: 2400 },
    { term: 'Fashion', count: 1800 },
    { term: 'Real Estate', count: 1200 },
  ]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Fetch all content matching query - sellers, products, services, jobs, events
  useEffect(() => {
    const searchAll = async () => {
      if (query.trim().length < 2) {
        setResults([]);
        return;
      }

      setLoading(true);
      try {
        // Search in parallel
        const [sellersRes, productsRes, eventsRes] = await Promise.all([
          // Sellers
          supabase
            .from('seller_profiles')
            .select('id, business_name, business_logo_url, is_verified, verification_badge_color, store_slug, follower_count')
            .ilike('business_name', `%${query}%`)
            .eq('is_active', true)
            .limit(3),
          
          // Products (ads) - includes products, services, jobs
          supabase
            .from('ads')
            .select('id, title, price, images, category, listing_type, location, job_details(company_name)')
            .ilike('title', `%${query}%`)
            .eq('status', 'active')
            .limit(6),
          
          // Events
          supabase
            .from('events')
            .select('id, title, location, event_date, is_free, cover_image')
            .ilike('title', `%${query}%`)
            .eq('is_active', true)
            .gte('event_date', new Date().toISOString())
            .limit(3),
        ]);

        const allResults: SearchResult[] = [];

        // Add sellers
        if (sellersRes.data) {
          sellersRes.data.forEach((s) => {
            allResults.push({ ...s, type: 'seller' } as SellerResult);
          });
        }

        // Add products/services/jobs from ads
        if (productsRes.data) {
          productsRes.data.forEach((p: any) => {
            if (p.listing_type === 'jobs') {
              allResults.push({
                type: 'job',
                id: p.id,
                title: p.title,
                location: p.location || '',
                company_name: p.job_details?.[0]?.company_name,
              } as JobResult);
            } else if (p.listing_type === 'services') {
              allResults.push({
                type: 'service',
                id: p.id,
                title: p.title,
                price: p.price,
                location: p.location || '',
                images: p.images || [],
              } as ServiceResult);
            } else {
              allResults.push({
                type: 'product',
                id: p.id,
                title: p.title,
                price: p.price,
                images: p.images || [],
                category: p.category,
                listing_type: p.listing_type,
              } as ProductResult);
            }
          });
        }

        // Add events
        if (eventsRes.data) {
          eventsRes.data.forEach((e) => {
            allResults.push({ ...e, type: 'event' } as EventResult);
          });
        }

        setResults(allResults);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setLoading(false);
      }
    };

    const debounce = setTimeout(searchAll, 300);
    return () => clearTimeout(debounce);
  }, [query]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsFocused(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query.trim())}`);
      setIsFocused(false);
      setQuery('');
    }
  };

  const handleResultClick = (result: SearchResult) => {
    switch (result.type) {
      case 'seller':
        navigate(`/business/${result.store_slug || result.id}`);
        break;
      case 'product':
        if (result.listing_type === 'promotions') {
          navigate(`/promotion/${result.id}`);
        } else {
          navigate(`/ad/${result.id}`);
        }
        break;
      case 'service':
        navigate(`/service/${result.id}`);
        break;
      case 'job':
        navigate(`/job/${result.id}`);
        break;
      case 'event':
        navigate(`/event/${result.id}`);
        break;
    }
    setIsFocused(false);
    setQuery('');
  };

  const handleTrendingClick = (term: string) => {
    navigate(`/search?q=${encodeURIComponent(term)}`);
    setIsFocused(false);
    setQuery('');
  };

  const showDropdown = isFocused && (query.length > 0 || trendingSearches.length > 0);

  const getResultIcon = (result: SearchResult) => {
    switch (result.type) {
      case 'seller': return <Users className="w-4 h-4" />;
      case 'product': return <Package className="w-4 h-4" />;
      case 'service': return <ShoppingBag className="w-4 h-4" />;
      case 'job': return <Briefcase className="w-4 h-4" />;
      case 'event': return <Calendar className="w-4 h-4" />;
    }
  };

  const getResultTypeLabel = (result: SearchResult) => {
    switch (result.type) {
      case 'seller': return 'Seller';
      case 'product': return result.listing_type === 'promotions' ? 'Deal' : 'Product';
      case 'service': return 'Service';
      case 'job': return 'Job';
      case 'event': return 'Event';
    }
  };

  const renderResult = (result: SearchResult) => {
    switch (result.type) {
      case 'seller':
        return (
          <button
            key={`seller-${result.id}`}
            onClick={() => handleResultClick(result)}
            className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left"
          >
            <Avatar className="w-10 h-10 flex-shrink-0">
              <AvatarImage src={result.business_logo_url || ''} />
              <AvatarFallback className="bg-muted text-foreground font-semibold">
                {result.business_name?.charAt(0)}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1">
                <span className="font-semibold text-[15px] truncate">{result.business_name}</span>
                {result.is_verified && (
                  <UnifiedVerifiedBadge isVerified badgeColor={result.verification_badge_color} size="sm" />
                )}
              </div>
              <p className="text-muted-foreground text-xs truncate flex items-center gap-1">
                <Users className="w-3 h-3" />
                Seller • @{result.store_slug || result.business_name?.toLowerCase().replace(/\s+/g, '')}
              </p>
            </div>
          </button>
        );

      case 'product':
        return (
          <button
            key={`product-${result.id}`}
            onClick={() => handleResultClick(result)}
            className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-lg bg-muted overflow-hidden flex-shrink-0">
              {result.images?.[0] ? (
                <img src={result.images[0]} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Package className="w-4 h-4 text-muted-foreground" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-[15px] truncate">{result.title}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Tag className="w-3 h-3" />
                  {getResultTypeLabel(result)}
                </span>
                <span className="text-primary font-semibold">
                  UGX {result.price?.toLocaleString()}
                </span>
              </div>
            </div>
          </button>
        );

      case 'service':
        return (
          <button
            key={`service-${result.id}`}
            onClick={() => handleResultClick(result)}
            className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-lg bg-muted overflow-hidden flex-shrink-0">
              {result.images?.[0] ? (
                <img src={result.images[0]} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <ShoppingBag className="w-4 h-4 text-muted-foreground" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-[15px] truncate">{result.title}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <ShoppingBag className="w-3 h-3 text-green-500" />
                  Service
                </span>
                {result.location && (
                  <span className="flex items-center gap-0.5">
                    <MapPin className="w-3 h-3" />
                    {result.location}
                  </span>
                )}
              </div>
            </div>
          </button>
        );

      case 'job':
        return (
          <button
            key={`job-${result.id}`}
            onClick={() => handleResultClick(result)}
            className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
              <Briefcase className="w-5 h-5 text-blue-500" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-[15px] truncate">{result.title}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Briefcase className="w-3 h-3 text-blue-500" />
                  Job
                </span>
                {result.company_name && (
                  <span className="truncate">{result.company_name}</span>
                )}
              </div>
            </div>
          </button>
        );

      case 'event':
        return (
          <button
            key={`event-${result.id}`}
            onClick={() => handleResultClick(result)}
            className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left"
          >
            <div className="w-10 h-10 rounded-lg bg-purple-500/10 overflow-hidden flex-shrink-0">
              {result.cover_image ? (
                <img src={result.cover_image} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-purple-500" />
                </div>
              )}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-[15px] truncate">{result.title}</p>
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3 text-purple-500" />
                  {format(new Date(result.event_date), 'MMM d')}
                </span>
                {result.is_free && (
                  <span className="px-1.5 py-0.5 bg-green-500/10 text-green-500 rounded text-[10px]">Free</span>
                )}
              </div>
            </div>
          </button>
        );
    }
  };

  // Group results by type for organized display
  const sellerResults = results.filter(r => r.type === 'seller');
  const otherResults = results.filter(r => r.type !== 'seller');

  return (
    <div ref={containerRef} className="relative">
      <form onSubmit={handleSubmit}>
        <div className={cn(
          "relative transition-all duration-200 rounded-full",
          isFocused && "ring-2 ring-primary/50"
        )}>
          <input
            ref={inputRef}
            type="text"
            placeholder="Search sellers, products, events..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onFocus={() => setIsFocused(true)}
            className="w-full bg-muted/30 border-0 rounded-full py-3 px-4 pl-12 text-sm focus:outline-none focus:bg-muted/50 placeholder:text-muted-foreground/60 transition-colors"
          />
          <Search className={cn(
            "w-5 h-5 absolute left-4 top-3.5 transition-colors",
            isFocused ? "text-primary" : "text-muted-foreground"
          )} />
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery('');
                inputRef.current?.focus();
              }}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 rounded-full bg-primary text-primary-foreground hover:bg-primary/80 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </form>

      {/* Dropdown */}
      <AnimatePresence>
        {showDropdown && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.15 }}
            className="absolute top-full left-0 right-0 mt-1 bg-background border border-border rounded-2xl shadow-xl overflow-hidden z-50 max-h-[70vh] overflow-y-auto"
          >
            {/* Search results */}
            {query.length >= 2 && (
              <>
                {loading ? (
                  <div className="p-4 text-center text-muted-foreground text-sm">
                    Searching...
                  </div>
                ) : results.length > 0 ? (
                  <div className="py-2 divide-y divide-border/50">
                    {/* Sellers section */}
                    {sellerResults.length > 0 && (
                      <div>
                        <p className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase">Sellers</p>
                        {sellerResults.map(renderResult)}
                      </div>
                    )}
                    
                    {/* Products/Services/Jobs/Events section */}
                    {otherResults.length > 0 && (
                      <div>
                        <p className="px-4 py-2 text-xs font-semibold text-muted-foreground uppercase">Results</p>
                        {otherResults.map(renderResult)}
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="p-4 text-center text-muted-foreground text-sm">
                    No results found for "{query}"
                  </div>
                )}

                {/* Search for query button */}
                <button
                  onClick={handleSubmit}
                  className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left border-t border-border"
                >
                  <div className="w-10 h-10 rounded-full bg-muted/50 flex items-center justify-center">
                    <Search className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <span className="text-[15px]">Search for "{query}"</span>
                </button>
              </>
            )}

            {/* Trending searches - shown when focused but no query */}
            {query.length < 2 && trendingSearches.length > 0 && (
              <div className="py-2">
                {trendingSearches.map((item, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleTrendingClick(item.term)}
                    className="w-full px-4 py-3 flex items-center gap-3 hover:bg-muted/50 transition-colors text-left"
                  >
                    <div className="w-10 h-10 rounded-full bg-muted/30 flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-muted-foreground" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className="font-medium text-[15px]">{item.term}</span>
                      <p className="text-xs text-muted-foreground">Trending</p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default SearchDropdown;