import React from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Percent, ShoppingBag, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import RailScroller from '@/components/common/RailScroller';

interface PromotionProduct {
  id: string;
  title: string;
  price: number;
  currency: string;
  images: string[];
  discount_percentage: number;
  features?: string;
}

interface PromotionProductsCarouselProps {
  adId: string;
  discountPercent?: number;
  sellerId?: string;
  isSellerWide?: boolean;
  maxItems?: number;
  promotionImages?: string[]; // Fallback to show main promotion images
  promotionTitle?: string;
  onNoProducts?: () => void; // Callback when no products found
}

const PromotionProductsCarousel: React.FC<PromotionProductsCarouselProps> = ({
  adId,
  discountPercent = 0,
  sellerId,
  isSellerWide = false,
  maxItems = 6,
  promotionImages = [],
  promotionTitle = '',
  onNoProducts,
}) => {
  const navigate = useNavigate();
  const [products, setProducts] = React.useState<PromotionProduct[]>([]);
  const [loading, setLoading] = React.useState(true);
  const [showMainImages, setShowMainImages] = React.useState(false);
  const containerRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    fetchProducts();
  }, [adId]);

  const fetchProducts = async () => {
    try {
      // First, try to get promotion details (may not exist for older promotions)
      const { data: promoDetails, error: promoError } = await supabase
        .from('promotion_details')
        .select('id, discount_percentage, is_seller_wide')
        .eq('ad_id', adId)
        .maybeSingle(); // Use maybeSingle instead of single to avoid 406 errors

      // Use passed-in discountPercent as primary, then promoDetails, then default to 0
      // This ensures the discount from props takes precedence
      const defaultDiscount = discountPercent > 0 
        ? discountPercent 
        : (promoDetails?.discount_percentage || 0);
      const sellerWide = promoDetails?.is_seller_wide ?? isSellerWide ?? false;

      // If we have promotion_details, try to get linked products
      if (promoDetails?.id) {
        const { data: promoProducts } = await supabase
          .from('promotion_products')
          .select('ad_id, discount_percentage')
          .eq('promotion_id', promoDetails.id)
          .limit(maxItems);

        if (promoProducts && promoProducts.length > 0) {
          const productIds = promoProducts.map(pp => pp.ad_id);
          const { data: productDetails } = await supabase
            .from('ads')
            .select('id, title, price, currency, images, features')
            .in('id', productIds);

          const mappedProducts = (productDetails || []).map(product => {
            const promoProduct = promoProducts.find(pp => pp.ad_id === product.id);
            return {
              ...product,
              currency: product.currency || 'UGX',
              images: product.images || [],
              discount_percentage: promoProduct?.discount_percentage || defaultDiscount,
              features: product.features || '',
            };
          });

          setProducts(mappedProducts);
          setLoading(false);
          return;
        }
      }
      
      // Fallback: ONLY fetch all seller products for seller-wide promotions
      // Do NOT fetch all products just because no promotion_products were found
      if (sellerWide && sellerId) {
        const { data: sellerProducts } = await supabase
          .from('ads')
          .select('id, title, price, currency, images, features')
          .eq('seller_id', sellerId)
          .eq('status', 'active')
          .in('listing_type', ['physical_products', 'digital_products'])
          .limit(maxItems);

        if (sellerProducts && sellerProducts.length > 0) {
          const mappedProducts = sellerProducts.map(product => ({
            ...product,
            currency: product.currency || 'UGX',
            images: product.images || [],
            discount_percentage: defaultDiscount,
            features: product.features || '',
          }));

          setProducts(mappedProducts);
        }
      }
    } catch (error) {
      console.error('Error fetching promotion products:', error);
    } finally {
      setLoading(false);
    }
  };

  const scroll = (direction: 'left' | 'right') => {
    if (!containerRef.current) return;
    const scrollAmount = 200;
    containerRef.current.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
  };

  const handleProductClick = (e: React.MouseEvent, productId: string) => {
    e.stopPropagation();
    navigate(`/ad/${productId}`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-4">
        <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // If no products but we have promotion images, show them instead
  if (products.length === 0) {
    if (promotionImages.length > 0) {
      // Render promotion main images as a simple gallery
      return (
        <div className="mt-2 rounded-2xl overflow-hidden border border-border relative">
          {promotionImages.length === 1 ? (
            <img
              src={promotionImages[0]}
              alt={promotionTitle}
              className="w-full max-h-[400px] object-cover"
            />
          ) : (
            <div className={cn(
              "grid gap-[2px]",
              promotionImages.length === 2 ? "grid-cols-2" : 
              promotionImages.length >= 3 ? "grid-cols-2" : ""
            )}>
              {promotionImages.slice(0, 4).map((img, idx) => (
                <div 
                  key={idx} 
                  className={cn(
                    "overflow-hidden",
                    promotionImages.length === 3 && idx === 0 ? "row-span-2 h-[280px]" : "h-[139px]"
                  )}
                >
                  <img
                    src={img}
                    alt={`${promotionTitle} ${idx + 1}`}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          )}
          {discountPercent > 0 && (
            <div className="absolute bottom-3 left-3">
              <div className="bg-red-500 text-white text-sm font-bold px-3 py-1.5 rounded-lg flex items-center gap-1.5">
                <Percent className="w-4 h-4" />
                {discountPercent}% OFF
              </div>
            </div>
          )}
        </div>
      );
    }
    // Notify parent that no products were found
    onNoProducts?.();
    return null;
  }

  const calculateDiscountedPrice = (price: number, discount: number) => {
    return Math.round(price * (1 - discount / 100));
  };

  // Parse features from string - handle JSON, comma-separated, or plain text
  const parseFeatures = (features?: string): string[] => {
    if (!features) return [];
    
    // Check if it's JSON format (starts with { or [)
    const trimmed = features.trim();
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      try {
        const parsed = JSON.parse(trimmed);
        // If it's an object, extract values
        if (typeof parsed === 'object' && !Array.isArray(parsed)) {
          return Object.values(parsed).filter(v => typeof v === 'string' && v.trim()).slice(0, 2) as string[];
        }
        // If it's an array, filter strings
        if (Array.isArray(parsed)) {
          return parsed.filter(v => typeof v === 'string' && v.trim()).slice(0, 2);
        }
      } catch {
        // Not valid JSON, continue with comma parsing
      }
    }
    
    // Comma-separated or plain text
    return features.split(',').map(f => f.trim()).filter(Boolean).slice(0, 2);
  };

  return (
    <div className="mt-3">
      {/* Header */}
      <div className="flex items-center justify-between mb-3 px-1">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-red-500/10">
            <ShoppingBag className="w-3.5 h-3.5 text-red-500" />
          </div>
          <span className="text-xs font-semibold text-foreground">
            Products on Discount ({products.length})
          </span>
        </div>
        {products.length > 2 && (
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 rounded-full"
              onClick={(e) => { e.stopPropagation(); scroll('left'); }}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 rounded-full"
              onClick={(e) => { e.stopPropagation(); scroll('right'); }}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      {/* X.com Style Carousel */}
      <RailScroller>
      <div
        ref={containerRef}
        className="flex gap-3 overflow-x-auto scrollbar-hide pb-2"
        style={{ scrollSnapType: 'x mandatory' }}
      >
        {products.map((product, index) => {
          const features = parseFeatures(product.features);
          const discountedPrice = calculateDiscountedPrice(product.price || 0, product.discount_percentage);
          const hasValidDiscount = product.discount_percentage > 0 && product.price > 0;
          
          return (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              onClick={(e) => handleProductClick(e, product.id)}
              className="relative flex-shrink-0 w-[180px] md:w-[200px] aspect-[3/4] rounded-xl overflow-hidden cursor-pointer group"
              style={{ scrollSnapAlign: 'start' }}
            >
              {/* Product Image - fills the card */}
              {product.images[0] ? (
                <img
                  src={product.images[0]}
                  alt={product.title}
                  className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                />
              ) : (
                <div className="w-full h-full bg-muted flex items-center justify-center">
                  <ShoppingBag className="w-10 h-10 text-muted-foreground" />
                </div>
              )}

              {/* Gradient overlay with details - X.com style */}
              {/* Mobile: always visible, Desktop: show on hover */}
              <div 
                className={cn(
                  "absolute inset-0 flex flex-col justify-end p-3 transition-opacity duration-300",
                  "bg-gradient-to-t from-black/90 via-black/50 to-transparent",
                  "opacity-100 md:opacity-0 md:group-hover:opacity-100"
                )}
              >
                {/* Product Title */}
                <h4 className="text-white font-semibold text-sm line-clamp-2 mb-1.5">
                  {product.title}
                </h4>

                {/* Discount & Prices */}
                <div className="flex items-center gap-2 flex-wrap">
                  {hasValidDiscount ? (
                    <>
                      <span className="bg-red-500 text-white text-xs font-bold px-1.5 py-0.5 rounded">
                        -{product.discount_percentage}%
                      </span>
                      <span className="text-white font-bold text-sm">
                        {product.currency} {discountedPrice.toLocaleString()}
                      </span>
                    </>
                  ) : (
                    <span className="text-white font-bold text-sm">
                      {product.currency} {(product.price || 0).toLocaleString()}
                    </span>
                  )}
                </div>
                
                {/* Original Price - only show if there's a valid discount */}
                {hasValidDiscount && (
                  <div className="text-white/60 text-xs line-through mt-0.5">
                    {product.currency} {(product.price || 0).toLocaleString()}
                  </div>
                )}

                {/* Features - if available */}
                {features.length > 0 && (
                  <div className="flex items-center gap-1 mt-2 text-white/70 text-xs">
                    {features.map((feature, idx) => (
                      <React.Fragment key={idx}>
                        {idx > 0 && <span className="text-white/40">•</span>}
                        <span className="truncate max-w-[70px]">{feature}</span>
                      </React.Fragment>
                    ))}
                  </div>
                )}
              </div>

              {/* Discount badge - visible when overlay is hidden (desktop only) - only show if discount > 0 */}
              {hasValidDiscount && (
                <div className="absolute top-2 left-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-md md:opacity-100 md:group-hover:opacity-0 transition-opacity duration-300 hidden md:flex items-center gap-0.5">
                  <Percent className="w-3 h-3" />
                  {product.discount_percentage}%
                </div>
              )}
            </motion.div>
          );
        })}
      </div>
      </RailScroller>
    </div>
  );
};

export default PromotionProductsCarousel;
