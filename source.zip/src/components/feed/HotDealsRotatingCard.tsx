import React, { useEffect, useMemo, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Bookmark, Clock, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useBookmarks } from '@/hooks/useBookmarks';
import { Skeleton } from '@/components/ui/skeleton';

interface DealLike {
  id: string;
  title: string;
  price: number;
  original_price?: number;
  images: string[];
  seller_id: string;
  seller_name: string;
  seller_logo?: string;
  is_verified?: boolean;
}

interface Props {
  deals: DealLike[];
  loading?: boolean;
}

const ROTATE_MS = 6000;

const HotDealsRotatingCard: React.FC<Props> = ({ deals, loading }) => {
  const navigate = useNavigate();
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(true);

  const items = useMemo(() => deals.slice(0, 20), [deals]);

  // Pause when off-screen
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { threshold: 0.4 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (paused || !inView || items.length <= 1) return;
    const t = setInterval(() => {
      setIndex((i) => (i + 1) % items.length);
    }, ROTATE_MS);
    return () => clearInterval(t);
  }, [paused, inView, items.length]);

  if (loading) {
    return (
      <div className="px-4 py-3">
        <Skeleton className="h-40 w-full rounded-2xl" />
      </div>
    );
  }
  if (!items.length) return null;

  const deal = items[index];
  const discount = deal.original_price
    ? Math.round(((deal.original_price - deal.price) / deal.original_price) * 100)
    : 0;

  // "Sources" — unique sellers among the deal pool, capped at 5 avatars
  const uniqueSellers = Array.from(
    new Map(items.map((d) => [d.seller_id, d])).values()
  );
  const avatars = uniqueSellers.slice(0, 5);
  const totalSources = uniqueSellers.length;

  const bookmarked = isBookmarked(deal.id, 'product');

  return (
    <div
      ref={containerRef}
      className="px-3 py-3"
      onTouchStart={() => setPaused(true)}
      onTouchEnd={() => setPaused(false)}
    >
      <div className="flex items-center justify-between mb-2 px-1">
        <div className="flex items-center gap-2">
          <span className="text-[13px] font-bold text-foreground">Hot Deals</span>
          <span className="text-[10px] text-red-500 font-semibold">
            {totalSources} sellers
          </span>
        </div>
        <button
          onClick={() => navigate('/search?onSale=true&contentType=products')}
          className="text-[11px] text-red-500 font-medium flex items-center gap-0.5"
        >
          See all <ChevronRight className="w-3 h-3" />
        </button>
      </div>

      <div className="relative bg-card border border-border/60 rounded-2xl overflow-hidden shadow-sm">
        <AnimatePresence mode="wait">
          <motion.button
            key={deal.id}
            type="button"
            onClick={() => navigate(`/ad/${deal.id}`)}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.45, ease: 'easeOut' }}
            className="w-full text-left"
          >
            <div className="flex gap-3 p-3">
              {/* Image */}
              <div className="relative w-24 h-24 rounded-xl overflow-hidden bg-muted flex-shrink-0">
                {deal.images?.[0] ? (
                  <img
                    src={deal.images[0]}
                    alt={deal.title}
                    loading="lazy"
                    decoding="async"
                    className="w-full h-full object-cover"
                  />
                ) : null}
                {discount > 0 && (
                  <div className="absolute bottom-1 left-1 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
                    -{discount}%
                  </div>
                )}
              </div>

              {/* Body */}
              <div className="flex-1 min-w-0">
                <h3 className="text-[14px] font-semibold text-foreground line-clamp-2 leading-snug">
                  {deal.title}
                </h3>
                <div className="flex items-center gap-1 mt-1 text-[11px] text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  <span>Limited offer</span>
                </div>
                <p className="text-[12px] text-muted-foreground mt-1 line-clamp-2">
                  {discount > 0
                    ? `Save ${discount}% on this deal from ${deal.seller_name}.`
                    : `Special offer from ${deal.seller_name}.`}
                </p>
              </div>
            </div>

            {/* Sources row */}
            <div className="flex items-center justify-between border-t border-border/50 px-3 py-2">
              <div className="flex items-center gap-2">
                <div className="flex -space-x-2">
                  {avatars.map((a) => (
                    <img
                      key={a.seller_id}
                      src={a.seller_logo || '/placeholder.svg'}
                      alt={a.seller_name}
                      className="w-5 h-5 rounded-full border border-background object-cover bg-muted"
                    />
                  ))}
                </div>
                <span className="text-[11px] text-muted-foreground">
                  {totalSources} {totalSources === 1 ? 'source' : 'sources'}
                </span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  aria-label="Interested"
                  onClick={(e) => {
                    e.stopPropagation();
                    setPaused(true);
                  }}
                  className="inline-flex items-center justify-center h-8 w-8 rounded-full hover:bg-muted"
                >
                  <Sparkles className="w-4 h-4 text-amber-500" />
                </button>
                <button
                  type="button"
                  aria-label="Bookmark"
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleBookmark(deal.id, 'product');
                  }}
                  className="inline-flex items-center justify-center h-8 w-8 rounded-full hover:bg-muted"
                >
                  <Bookmark
                    className={`w-4 h-4 ${
                      bookmarked ? 'fill-primary text-primary' : 'text-muted-foreground'
                    }`}
                  />
                </button>
              </div>
            </div>
          </motion.button>
        </AnimatePresence>

        {/* Progress dots */}
        {items.length > 1 && (
          <div className="absolute top-2 right-2 flex gap-1">
            {items.slice(0, Math.min(items.length, 8)).map((_, i) => (
              <span
                key={i}
                className={`h-1 rounded-full transition-all ${
                  i === index % 8 ? 'w-3 bg-red-500' : 'w-1 bg-muted-foreground/30'
                }`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default HotDealsRotatingCard;