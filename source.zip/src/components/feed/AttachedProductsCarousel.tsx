import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, Loader2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useCurrency } from '@/contexts/CurrencyContext';

interface Props {
  productIds: string[];
}

interface ProductRow {
  id: string;
  title: string;
  price: number | null;
  images: string[] | null;
}

const AttachedProductsCarousel: React.FC<Props> = ({ productIds }) => {
  const navigate = useNavigate();
  const { formatPrice } = useCurrency();
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      if (!productIds?.length) { setLoading(false); return; }
      const { data } = await supabase
        .from('ads')
        .select('id, title, price, images')
        .in('id', productIds.slice(0, 5))
        .eq('status', 'active')
        .limit(5);
      if (!cancelled) {
        setProducts((data as ProductRow[]) || []);
        setLoading(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, [productIds]);

  if (loading) {
    return (
      <div className="mt-3 flex items-center gap-2 text-muted-foreground text-sm px-1">
        <Loader2 className="w-4 h-4 animate-spin" />
        <span>Loading products...</span>
      </div>
    );
  }

  if (products.length === 0) return null;

  return (
    <div className="mt-3 p-3 border border-border rounded-2xl bg-muted/20">
      <div className="flex items-center gap-1.5 mb-2">
        <Package className="w-4 h-4 text-primary" />
        <span className="text-[13px] font-semibold text-foreground">
          Attached Products
        </span>
      </div>
      <div
        className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1 snap-x snap-mandatory"
        style={{ scrollbarWidth: 'none' }}
      >
        {products.map((p) => (
          <button
            key={p.id}
            onClick={(e) => { e.stopPropagation(); navigate(`/ad/${p.id}`); }}
            className="snap-start flex-shrink-0 w-28 text-left group"
            title={p.title}
          >
            <div className="w-28 h-28 rounded-xl overflow-hidden bg-muted border border-border group-hover:border-primary/60 transition-colors">
              {p.images?.[0] ? (
                <img
                  src={p.images[0]}
                  alt={p.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                  <Package className="w-6 h-6" />
                </div>
              )}
            </div>
            <p className="mt-1.5 text-[12px] font-medium text-foreground line-clamp-2 leading-tight">
              {p.title}
            </p>
            {typeof p.price === 'number' && p.price > 0 && (
              <p className="text-[11px] text-primary font-semibold">
                {formatPrice(p.price)}
              </p>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default AttachedProductsCarousel;