import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Timer, Bell, Flame, Clock, ChevronRight, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';
import { usePromotionReminders } from '@/hooks/usePromotionReminders';

interface ProductAvatar {
  id: string;
  image: string;
  title: string;
}

interface LiveDiscountCardProps {
  id: string;
  title: string;
  description?: string;
  discountPercent: number;
  promotionType: 'scheduled_drop' | 'happy_hour' | 'seller_wide' | 'standard' | 'category_takeover';
  startAt?: string;
  validUntil?: string;
  products: ProductAvatar[];
  seller: {
    id: string;
    business_name: string;
    business_logo_url?: string;
    is_verified: boolean;
  };
  coverImage?: string;
  onClick: () => void;
  onSellerClick: () => void;
  onRemindMe?: () => void;
}

const LiveDiscountCard: React.FC<LiveDiscountCardProps> = ({
  id,
  title,
  description,
  discountPercent,
  promotionType,
  startAt,
  validUntil,
  products,
  seller,
  coverImage,
  onClick,
  onSellerClick,
  onRemindMe,
}) => {
  const [timeRemaining, setTimeRemaining] = useState<string>('');
  const [status, setStatus] = useState<'upcoming' | 'live' | 'ended'>('live');
  
  const { isReminderSet, toggleReminder, loading: reminderLoading } = usePromotionReminders();
  const hasReminder = isReminderSet(id);

  useEffect(() => {
    const calculateStatus = () => {
      const now = new Date();
      const start = startAt ? new Date(startAt) : null;
      const end = validUntil ? new Date(validUntil) : null;

      if (start && start > now) {
        setStatus('upcoming');
        const diff = start.getTime() - now.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);

        if (days > 0) {
          setTimeRemaining(`${days}d ${hours}h`);
        } else if (hours > 0) {
          setTimeRemaining(`${hours}h ${minutes}m`);
        } else {
          setTimeRemaining(`${minutes}m ${seconds}s`);
        }
      } else if (end && end < now) {
        setStatus('ended');
        setTimeRemaining('Ended');
      } else {
        setStatus('live');
        if (end) {
          const diff = end.getTime() - now.getTime();
          const hours = Math.floor(diff / (1000 * 60 * 60));
          const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
          if (hours > 24) {
            const days = Math.floor(hours / 24);
            setTimeRemaining(`${days}d left`);
          } else if (hours > 0) {
            setTimeRemaining(`${hours}h ${minutes}m`);
          } else {
            setTimeRemaining(`${minutes}m`);
          }
        } else {
          setTimeRemaining('');
        }
      }
    };

    calculateStatus();
    const interval = setInterval(calculateStatus, 1000);
    return () => clearInterval(interval);
  }, [startAt, validUntil]);

  // Don't render if ended
  if (status === 'ended') return null;

  const handleRemindMe = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (startAt) {
      await toggleReminder(id, startAt);
    }
    onRemindMe?.();
  };

  // Generate gradient based on promotion type
  const getGradientColors = () => {
    switch (promotionType) {
      case 'scheduled_drop':
        return { from: 'from-violet-600', via: 'via-purple-500', to: 'to-fuchsia-500' };
      case 'happy_hour':
        return { from: 'from-cyan-500', via: 'via-blue-500', to: 'to-indigo-600' };
      case 'seller_wide':
        return { from: 'from-amber-500', via: 'via-orange-500', to: 'to-red-500' };
      case 'category_takeover':
        return { from: 'from-emerald-500', via: 'via-green-500', to: 'to-teal-500' };
      default:
        return { from: 'from-rose-500', via: 'via-red-500', to: 'to-orange-500' };
    }
  };

  const gradient = getGradientColors();
  const maxVisible = 4;
  const visibleProducts = products.slice(0, maxVisible);
  const remainingCount = Math.max(0, products.length - maxVisible);

  return (
    <motion.article
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="relative overflow-hidden rounded-2xl cursor-pointer shadow-xl group"
      style={{ minWidth: '280px', maxWidth: '320px' }}
    >
      {/* Animated gradient background */}
      <div className={cn(
        "absolute inset-0 bg-gradient-to-br opacity-95",
        gradient.from, gradient.via, gradient.to
      )} />
      
      {/* Animated shine effect */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-30 transition-opacity duration-500">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
      </div>
      
      {/* Cover image with blur overlay */}
      {coverImage && (
        <>
          <div 
            className="absolute inset-0 opacity-40"
            style={{
              backgroundImage: `url(${coverImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
          <div className="absolute inset-0 bg-black/30 backdrop-blur-[1px]" />
        </>
      )}

      {/* Content */}
      <div className="relative z-10 p-4">
        {/* Top row - Status and discount */}
        <div className="flex items-center justify-between mb-3">
          {status === 'upcoming' ? (
            <Badge className="bg-white/20 backdrop-blur-sm text-white border-0 gap-1.5 font-medium">
              <Clock className="h-3 w-3" />
              Starts in {timeRemaining}
            </Badge>
          ) : (
            <Badge className="bg-white/20 backdrop-blur-sm text-white border-0 gap-1.5 font-medium">
              <Flame className="h-3 w-3 animate-pulse" />
              LIVE {timeRemaining && `• ${timeRemaining}`}
            </Badge>
          )}
          <motion.div
            initial={{ scale: 1 }}
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="bg-white text-foreground font-black text-lg px-3 py-1 rounded-full shadow-lg"
          >
            {discountPercent}% OFF
          </motion.div>
        </div>

        {/* Product Avatars */}
        <div className="flex items-center mb-3">
          <div className="flex -space-x-3">
            {visibleProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, scale: 0.5, x: -10 }}
                animate={{ opacity: 1, scale: 1, x: 0 }}
                transition={{ delay: index * 0.08 }}
                className="relative"
                style={{ zIndex: visibleProducts.length - index }}
              >
                <Avatar className="h-12 w-12 border-2 border-white/60 shadow-lg ring-1 ring-black/10">
                  <AvatarImage src={product.image} alt={product.title} className="object-cover" />
                  <AvatarFallback className="bg-white/30 text-white text-xs font-medium">
                    {product.title?.charAt(0)}
                  </AvatarFallback>
                </Avatar>
              </motion.div>
            ))}
            {remainingCount > 0 && (
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.35 }}
                className="h-12 w-12 rounded-full bg-black/50 backdrop-blur-sm border-2 border-white/60 shadow-lg flex items-center justify-center"
              >
                <span className="text-white font-bold text-sm">+{remainingCount}</span>
              </motion.div>
            )}
          </div>
        </div>

        {/* Title */}
        <h3 className="text-white font-bold text-base leading-tight mb-1.5 line-clamp-2 drop-shadow-sm">
          {title}
        </h3>

        {/* Seller info */}
        <div 
          className="flex items-center gap-2 mb-3"
          onClick={(e) => {
            e.stopPropagation();
            onSellerClick();
          }}
        >
          <Avatar className="h-5 w-5 border border-white/40">
            <AvatarImage src={seller.business_logo_url} />
            <AvatarFallback className="bg-white/20 text-white text-[10px]">
              {seller.business_name?.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <span className="text-white/90 text-xs font-medium hover:underline truncate">
            {seller.business_name}
          </span>
          <UnifiedVerifiedBadge isVerified={seller.is_verified} size="sm" />
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2">
          {status === 'upcoming' && (
            <Button
              size="sm"
              className={cn(
                "bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm text-xs h-8",
                hasReminder && "bg-white/40"
              )}
              onClick={handleRemindMe}
              disabled={reminderLoading}
            >
              <Bell className={cn("h-3.5 w-3.5 mr-1", hasReminder && "fill-current")} />
              {hasReminder ? 'Set!' : 'Remind'}
            </Button>
          )}
          <Button
            size="sm"
            className="bg-white text-foreground hover:bg-white/90 ml-auto text-xs h-8 font-semibold shadow-md"
          >
            {status === 'upcoming' ? 'Preview' : 'Shop'}
            <ChevronRight className="h-3.5 w-3.5 ml-0.5" />
          </Button>
        </div>
      </div>

      {/* Decorative sparkles */}
      <Sparkles className="absolute top-3 right-3 h-4 w-4 text-white/40" />
    </motion.article>
  );
};

export default LiveDiscountCard;
