import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Clock, Flame, Bell, ChevronLeft, ChevronRight, Percent, Heart, MessageCircle, Share2, Bookmark, Eye } from 'lucide-react';
import { cn } from '@/lib/utils';
import UnifiedVerifiedBadge from '@/components/UnifiedVerifiedBadge';
import { useNavigate } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { usePromotionReminders } from '@/hooks/usePromotionReminders';

interface PromotionProduct {
  id: string;
  title: string;
  price: number;
  original_price?: number;
  image: string;
  discount_percentage?: number;
}

interface PromotionFeedCardProps {
  id: string;
  title: string;
  description?: string;
  discountPercent: number;
  startAt?: string;
  validUntil?: string;
  coverImage?: string;
  products: PromotionProduct[];
  seller: {
    id: string;
    business_name: string;
    business_logo_url?: string;
    is_verified: boolean;
  };
  createdAt: string;
  likeCount?: number;
  viewCount?: number;
  onLike?: () => void;
  onComment?: () => void;
  onShare?: () => void;
  onSave?: () => void;
  isLiked?: boolean;
  isSaved?: boolean;
}

const PromotionFeedCard: React.FC<PromotionFeedCardProps> = ({
  id,
  title,
  description,
  discountPercent,
  startAt,
  validUntil,
  coverImage,
  products,
  seller,
  createdAt,
  likeCount = 0,
  viewCount = 0,
  onLike,
  onComment,
  onShare,
  onSave,
  isLiked,
  isSaved,
}) => {
  const navigate = useNavigate();
  const [currentProductIndex, setCurrentProductIndex] = useState(0);
  const [timeStatus, setTimeStatus] = useState<'upcoming' | 'live' | 'ended'>('live');
  const [timeRemaining, setTimeRemaining] = useState('');
  
  const { isReminderSet, toggleReminder, loading: reminderLoading } = usePromotionReminders();
  const hasReminder = isReminderSet(id);

  useEffect(() => {
    const calculateStatus = () => {
      const now = new Date();
      const start = startAt ? new Date(startAt) : null;
      const end = validUntil ? new Date(validUntil) : null;

      if (start && start > now) {
        setTimeStatus('upcoming');
        const diff = start.getTime() - now.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);

        if (days > 0) {
          setTimeRemaining(`Starts in ${days}d ${hours}h`);
        } else if (hours > 0) {
          setTimeRemaining(`Starts in ${hours}h ${minutes}m`);
        } else {
          setTimeRemaining(`Starts in ${minutes}m ${seconds}s`);
        }
      } else if (end && end < now) {
        setTimeStatus('ended');
        setTimeRemaining('Ended');
      } else {
        setTimeStatus('live');
        if (end) {
          const diff = end.getTime() - now.getTime();
          const hours = Math.floor(diff / (1000 * 60 * 60));
          const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
          if (hours > 24) {
            const days = Math.floor(hours / 24);
            setTimeRemaining(`Ends in ${days}d`);
          } else if (hours > 0) {
            setTimeRemaining(`Ends in ${hours}h ${minutes}m`);
          } else {
            setTimeRemaining(`Ends in ${minutes}m`);
          }
        } else {
          setTimeRemaining('');
        }
      }
    };

    calculateStatus();
    const interval = setInterval(calculateStatus, 1000);
    return () => clearInterval(interval);
  }, [startAt, validUntil]);

  const nextProduct = () => {
    setCurrentProductIndex((prev) => (prev + 1) % products.length);
  };

  const prevProduct = () => {
    setCurrentProductIndex((prev) => (prev - 1 + products.length) % products.length);
  };

  const currentProduct = products[currentProductIndex];

  // If ended, don't show in feed
  if (timeStatus === 'ended') return null;

  return (
    <div className="border-b border-border bg-card hover:bg-muted/30 transition-colors">
      {/* Header */}
      <div className="flex items-center gap-3 p-3 pb-2">
        <Avatar 
          className="h-10 w-10 cursor-pointer ring-2 ring-destructive/30"
          onClick={() => navigate(`/business/${seller.id}`)}
        >
          <AvatarImage src={seller.business_logo_url} />
          <AvatarFallback className="bg-gradient-to-br from-destructive/20 to-orange-500/20 text-destructive font-bold">
            {seller.business_name?.charAt(0)}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1.5">
            <span 
              className="font-semibold text-sm truncate cursor-pointer hover:underline"
              onClick={() => navigate(`/business/${seller.id}`)}
            >
              {seller.business_name}
            </span>
            <UnifiedVerifiedBadge isVerified={seller.is_verified} size="sm" />
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>{formatDistanceToNow(new Date(createdAt), { addSuffix: true })}</span>
            <Badge className="gap-1 text-[10px] px-1.5 py-0 h-5 bg-gradient-to-r from-destructive to-orange-500 text-white border-0">
              <Percent className="h-2.5 w-2.5" />
              PROMO
            </Badge>
          </div>
        </div>
        
        {/* Status Badge */}
        {timeStatus === 'upcoming' ? (
          <Badge className="bg-purple-500/90 text-white border-0 gap-1 text-xs">
            <Clock className="h-3 w-3" />
            {timeRemaining}
          </Badge>
        ) : (
          <Badge className="bg-destructive/90 text-white border-0 gap-1 text-xs animate-pulse">
            <Flame className="h-3 w-3" />
            LIVE
          </Badge>
        )}
      </div>

      {/* Title and Description */}
      <div className="px-3 pb-2">
        <h3 className="font-bold text-base">{title}</h3>
        {description && (
          <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{description}</p>
        )}
      </div>

      {/* Discount Banner */}
      <div className="mx-3 mb-2 rounded-xl overflow-hidden bg-gradient-to-r from-destructive via-orange-500 to-destructive p-3 text-white">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-3xl font-black">{discountPercent}%</span>
            <span className="text-lg font-bold ml-1">OFF</span>
          </div>
          <div className="text-right text-sm">
            <div className="font-medium">{timeRemaining || 'Limited Time'}</div>
            <div className="text-white/80 text-xs">{products.length} products included</div>
          </div>
        </div>
      </div>

      {/* Product Carousel */}
      {products.length > 0 && currentProduct && (
        <div className="relative mx-3 mb-3">
          <div className="relative rounded-xl overflow-hidden bg-muted aspect-[4/3]">
            <img
              src={currentProduct.image}
              alt={currentProduct.title}
              className="w-full h-full object-cover cursor-pointer"
              onClick={() => navigate(`/ad/${currentProduct.id}`)}
            />
            
            {/* Discount overlay */}
            <div className="absolute top-3 left-3">
              <Badge className="bg-destructive text-white text-sm font-bold px-2.5 py-1 shadow-lg">
                -{currentProduct.discount_percentage || discountPercent}%
              </Badge>
            </div>

            {/* Product info overlay */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent p-4 pt-12">
              <h4 className="text-white font-semibold text-sm line-clamp-1 mb-1">
                {currentProduct.title}
              </h4>
              <div className="flex items-center gap-2">
                <span className="text-white font-bold">
                  UGX {(currentProduct.price).toLocaleString()}
                </span>
                {currentProduct.original_price && (
                  <span className="text-white/60 text-sm line-through">
                    UGX {currentProduct.original_price.toLocaleString()}
                  </span>
                )}
              </div>
            </div>

            {/* Navigation arrows */}
            {products.length > 1 && (
              <>
                <button
                  onClick={(e) => { e.stopPropagation(); prevProduct(); }}
                  className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); nextProduct(); }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center text-white hover:bg-black/70 transition-colors"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </>
            )}
          </div>

          {/* Carousel indicators */}
          {products.length > 1 && (
            <div className="flex justify-center gap-1.5 mt-2">
              {products.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setCurrentProductIndex(idx)}
                  className={cn(
                    "h-1.5 rounded-full transition-all",
                    idx === currentProductIndex 
                      ? "w-4 bg-destructive" 
                      : "w-1.5 bg-muted-foreground/30 hover:bg-muted-foreground/50"
                  )}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Reminder button for upcoming */}
      {timeStatus === 'upcoming' && startAt && (
        <div className="px-3 pb-2">
          <Button
            size="sm"
            variant={hasReminder ? "secondary" : "outline"}
            className="w-full gap-2"
            onClick={() => toggleReminder(id, startAt)}
            disabled={reminderLoading}
          >
            <Bell className={cn("h-4 w-4", hasReminder && "fill-current")} />
            {hasReminder ? 'Reminder Set' : 'Remind Me When It Starts'}
          </Button>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between px-3 py-2 border-t border-border/50">
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            className={cn("gap-1.5 h-8 px-2", isLiked && "text-destructive")}
            onClick={onLike}
          >
            <Heart className={cn("h-4 w-4", isLiked && "fill-current")} />
            <span className="text-xs">{likeCount || ''}</span>
          </Button>
          <Button variant="ghost" size="sm" className="gap-1.5 h-8 px-2" onClick={onComment}>
            <MessageCircle className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="sm" className="gap-1.5 h-8 px-2" onClick={onShare}>
            <Share2 className="h-4 w-4" />
          </Button>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground flex items-center gap-1">
            <Eye className="h-3 w-3" />
            {viewCount}
          </span>
          <Button
            variant="ghost"
            size="sm"
            className={cn("h-8 px-2", isSaved && "text-primary")}
            onClick={onSave}
          >
            <Bookmark className={cn("h-4 w-4", isSaved && "fill-current")} />
          </Button>
        </div>
      </div>
    </div>
  );
};

export default React.memo(PromotionFeedCard, (prev, next) =>
  prev.id === next.id &&
  prev.isLiked === next.isLiked &&
  prev.isSaved === next.isSaved &&
  prev.likeCount === next.likeCount &&
  prev.viewCount === next.viewCount
);


