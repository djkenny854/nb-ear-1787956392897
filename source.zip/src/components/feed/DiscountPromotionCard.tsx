import React, { useState, useEffect, useMemo } from 'react';
import { motion } from 'framer-motion';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Timer, Bell, Flame, ChevronRight, Tag, Gift, Calendar, Percent } from 'lucide-react';
import { cn } from '@/lib/utils';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';

interface ProductAvatar {
  id: string;
  image: string;
  title: string;
  discount_percentage?: number;
}

interface DiscountPromotionCardProps {
  id: string;
  title: string;
  description?: string;
  discountPercent: number;
  promotionType: 'scheduled_drop' | 'happy_hour' | 'seller_wide' | 'standard' | 'category_takeover';
  offerType?: string;
  startAt?: string;
  validUntil?: string;
  products: ProductAvatar[];
  seller: {
    id: string;
    business_name: string;
    business_logo_url?: string;
    is_verified: boolean;
    verification_badge_color?: BadgeColor;
  };
  coverImage?: string;
  onClick: () => void;
  onSellerClick: () => void;
  onRemindMe?: () => void;
}

// Map offer types to display labels
const getOfferTypeLabel = (offerType?: string): { label: string; icon: React.ElementType } => {
  switch (offerType?.toLowerCase()) {
    case 'discount':
      return { label: 'Discount Sale', icon: Percent };
    case 'offer':
      return { label: 'Special Offer', icon: Tag };
    case 'giveaway':
      return { label: 'Giveaway', icon: Gift };
    case 'event':
      return { label: 'Promo Event', icon: Calendar };
    default:
      return { label: 'Special Offer', icon: Tag };
  }
};

const DiscountPromotionCard: React.FC<DiscountPromotionCardProps> = ({
  id,
  title,
  description,
  discountPercent,
  promotionType,
  offerType,
  startAt,
  validUntil,
  products,
  seller,
  coverImage,
  onClick,
  onSellerClick,
  onRemindMe,
}) => {
  const [timeRemaining, setTimeRemaining] = useState<string>('');
  const [status, setStatus] = useState<'upcoming' | 'live' | 'ended'>('live');
  const [isReminderSet, setIsReminderSet] = useState(false);

  const offerInfo = useMemo(() => getOfferTypeLabel(offerType), [offerType]);

  useEffect(() => {
    const calculateStatus = () => {
      const now = new Date();
      const start = startAt ? new Date(startAt) : null;
      const end = validUntil ? new Date(validUntil) : null;

      if (start && start > now) {
        setStatus('upcoming');
        const diff = start.getTime() - now.getTime();
        const days = Math.floor(diff / (1000 * 60 * 60 * 24));
        const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diff % (1000 * 60)) / 1000);

        if (days > 0) {
          setTimeRemaining(`${days}d ${hours}h`);
        } else if (hours > 0) {
          setTimeRemaining(`${hours}h ${minutes}m`);
        } else {
          setTimeRemaining(`${minutes}m ${seconds}s`);
        }
      } else if (end && end < now) {
        setStatus('ended');
        setTimeRemaining('Ended');
      } else {
        setStatus('live');
        if (end) {
          const diff = end.getTime() - now.getTime();
          const hours = Math.floor(diff / (1000 * 60 * 60));
          const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
          if (hours > 24) {
            const days = Math.floor(hours / 24);
            setTimeRemaining(`${days}d left`);
          } else if (hours > 0) {
            setTimeRemaining(`${hours}h ${minutes}m left`);
          } else {
            setTimeRemaining(`${minutes}m left`);
          }
        } else {
          setTimeRemaining('');
        }
      }
    };

    calculateStatus();
    const interval = setInterval(calculateStatus, 1000);
    return () => clearInterval(interval);
  }, [startAt, validUntil]);

  const handleRemindMe = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsReminderSet(true);
    onRemindMe?.();
  };

  // Generate gradient based on promotion type
  const getGradientClass = () => {
    switch (promotionType) {
      case 'scheduled_drop':
        return 'from-purple-600 via-purple-500 to-indigo-600';
      case 'happy_hour':
        return 'from-blue-600 via-cyan-500 to-blue-600';
      case 'seller_wide':
        return 'from-orange-600 via-amber-500 to-orange-600';
      case 'category_takeover':
        return 'from-green-600 via-emerald-500 to-green-600';
      default:
        return 'from-red-600 via-rose-500 to-red-600';
    }
  };

  const getStatusBadge = () => {
    if (status === 'upcoming') {
      return (
        <Badge className="bg-purple-500/90 text-white border-0 gap-1">
          <Timer className="h-3 w-3" />
          Starts in {timeRemaining}
        </Badge>
      );
    }
    if (status === 'live') {
      return (
        <Badge className="bg-red-500/90 text-white border-0 gap-1 animate-pulse">
          <Flame className="h-3 w-3" />
          LIVE {timeRemaining && `• ${timeRemaining}`}
        </Badge>
      );
    }
    return (
      <Badge variant="secondary" className="gap-1">
        Ended
      </Badge>
    );
  };

  // Get the offer type badge with icon
  const getOfferTypeBadge = () => {
    const Icon = offerInfo.icon;
    
    if (discountPercent > 0) {
      return (
        <Badge className="bg-white/20 text-white border-0 text-lg font-bold px-3">
          {discountPercent}% OFF
        </Badge>
      );
    }
    
    return (
      <Badge className="bg-white/20 text-white border-0 text-sm font-bold px-3 gap-1">
        <Icon className="h-3 w-3" />
        {offerInfo.label}
      </Badge>
    );
  };

  // Show max 3-4 product avatars with larger size
  const maxVisible = 4;
  const visibleProducts = products.slice(0, maxVisible);
  const remainingCount = Math.max(0, products.length - maxVisible);

  return (
    <motion.article
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      onClick={onClick}
      className="relative overflow-hidden rounded-2xl cursor-pointer border border-border bg-card shadow-lg"
    >
      {/* Background gradient */}
      <div className={cn(
        "absolute inset-0 bg-gradient-to-br opacity-90",
        getGradientClass()
      )} />
      
      {/* Cover image with blur overlay */}
      {coverImage && (
        <>
          <div 
            className="absolute inset-0"
            style={{
              backgroundImage: `url(${coverImage})`,
              backgroundSize: 'cover',
              backgroundPosition: 'center',
            }}
          />
          {/* Blur overlay for text readability */}
          <div className="absolute inset-0 bg-black/40 backdrop-blur-[2px]" />
        </>
      )}

      {/* Content */}
      <div className="relative z-10 p-4 sm:p-5">
        {/* Top row - Status and discount/offer type */}
        <div className="flex items-center justify-between mb-3">
          {getStatusBadge()}
          {getOfferTypeBadge()}
        </div>

        {/* Product Avatars - Larger, overlapping style */}
        {visibleProducts.length > 0 && (
          <div className="flex items-center mb-4">
            <div className="flex -space-x-4">
              {visibleProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, scale: 0.5, x: -20 }}
                  animate={{ opacity: 1, scale: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="relative"
                  style={{ zIndex: visibleProducts.length - index }}
                >
                  <Avatar className="h-14 w-14 sm:h-16 sm:w-16 border-[3px] border-white/50 shadow-xl ring-2 ring-black/20">
                    <AvatarImage src={product.image} alt={product.title} className="object-cover" />
                    <AvatarFallback className="bg-white/30 text-white text-sm font-medium">
                      {product.title?.charAt(0)}
                    </AvatarFallback>
                  </Avatar>
                  {product.discount_percentage && product.discount_percentage > 0 && (
                    <div className="absolute -bottom-1 -right-1 bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                      -{product.discount_percentage}%
                    </div>
                  )}
                </motion.div>
              ))}
              {remainingCount > 0 && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.5 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.4 }}
                  className="h-14 w-14 sm:h-16 sm:w-16 rounded-full bg-black/60 border-[3px] border-white/50 shadow-xl ring-2 ring-black/20 flex items-center justify-center"
                >
                  <span className="text-white font-bold text-base">+{remainingCount}</span>
                </motion.div>
              )}
            </div>
          </div>
        )}

        {/* Title */}
        <h3 className="text-white font-bold text-lg sm:text-xl mb-1 line-clamp-2">
          {title}
        </h3>

        {/* Seller info */}
        <div 
          className="flex items-center gap-2 mb-3"
          onClick={(e) => {
            e.stopPropagation();
            onSellerClick();
          }}
        >
          <Avatar className="h-6 w-6">
            <AvatarImage src={seller.business_logo_url} />
            <AvatarFallback className="bg-white/20 text-white text-xs">
              {seller.business_name?.charAt(0)}
            </AvatarFallback>
          </Avatar>
          <span className="text-white/90 text-sm font-medium hover:underline">
            {seller.business_name}
          </span>
          <UnifiedVerifiedBadge 
            isVerified={seller.is_verified} 
            badgeColor={seller.verification_badge_color}
            size="sm" 
          />
        </div>

        {/* Description snippet */}
        {description && (
          <p className="text-white/70 text-sm line-clamp-2 mb-4">
            {description}
          </p>
        )}

        {/* Action buttons */}
        <div className="flex items-center gap-2">
          {status === 'upcoming' && (
            <Button
              size="sm"
              variant="secondary"
              className={cn(
                "bg-white/20 hover:bg-white/30 text-white border-0",
                isReminderSet && "bg-white/40"
              )}
              onClick={handleRemindMe}
            >
              <Bell className={cn("h-4 w-4 mr-1", isReminderSet && "fill-current")} />
              {isReminderSet ? 'Reminder Set' : 'Remind Me'}
            </Button>
          )}
          <Button
            size="sm"
            className="bg-white text-foreground hover:bg-white/90 ml-auto"
            onClick={(e) => {
              e.stopPropagation();
              onClick();
            }}
          >
            {status === 'upcoming' ? 'Preview' : 'Shop Now'}
            <ChevronRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      </div>

      {/* Subtle pattern overlay */}
      <div 
        className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='20' height='20' viewBox='0 0 20 20' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23fff' fill-opacity='0.4' fill-rule='evenodd'%3E%3Ccircle cx='3' cy='3' r='3'/%3E%3Ccircle cx='13' cy='13' r='3'/%3E%3C/g%3E%3C/svg%3E")`,
        }}
      />
    </motion.article>
  );
};

export default DiscountPromotionCard;
