import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX, Play, Maximize2 } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { useVideoModal } from '@/contexts/VideoModalContext';
import { cn } from '@/lib/utils';
import SmartVideo from '@/components/media/SmartVideo';

/**
 * ReelVideoPlayer
 *
 * Compact video player used for short-form reels (e.g. service workspace
 * updates). Mirrors the feel of XStyleVideoCard's video block:
 *   • adaptive aspect ratio derived from the poster image (no fixed 9:16)
 *   • autoplays muted when in view via IntersectionObserver, pauses otherwise
 *   • global mute toggle (shared with the rest of the feed via VideoModalContext)
 *   • bottom progress bar (counts forward as the video plays)
 *   • tap to open a fullscreen modal with native controls
 */
interface ReelVideoPlayerProps {
  src: string;
  poster?: string | null;
  className?: string;
  /** Maximum frame width in px (keeps portrait reels readable). */
  maxWidth?: number;
  /** Hard ceiling on rendered height (px). */
  maxHeight?: number;
}

const ReelVideoPlayer: React.FC<ReelVideoPlayerProps> = ({
  src,
  poster,
  className,
  maxWidth = 360,
  maxHeight = 560,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { globalMuted, setGlobalMuted, isVideoModalOpen, setIsVideoModalOpen } = useVideoModal();

  // Aspect-ratio detection: try poster first (cheap), fall back to video metadata.
  const [aspect, setAspect] = useState<number>(9 / 16); // sane portrait default
  const aspectFromPoster = useRef(false);
  const [progress, setProgress] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);

  // Derive aspect from poster
  useEffect(() => {
    if (!poster) return;
    const img = new Image();
    img.onload = () => {
      if (img.naturalWidth && img.naturalHeight) {
        aspectFromPoster.current = true;
        setAspect(img.naturalWidth / img.naturalHeight);
      }
    };
    img.src = poster;
  }, [poster]);

  // Autoplay-in-view via IO
  useEffect(() => {
    const el = containerRef.current;
    const v = videoRef.current;
    if (!el || !v) return;
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (modalOpen || isVideoModalOpen) return;
          if (entry.isIntersecting && entry.intersectionRatio >= 0.5) {
            v.play().then(() => setIsPlaying(true)).catch(() => {});
          } else {
            v.pause();
            setIsPlaying(false);
          }
        });
      },
      { threshold: [0, 0.5, 1] }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [modalOpen, isVideoModalOpen]);

  // Progress + intrinsic aspect fallback
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onMeta = () => {
      if (!aspectFromPoster.current && v.videoWidth && v.videoHeight) {
        setAspect(v.videoWidth / v.videoHeight);
      }
    };
    const onTime = () => {
      if (v.duration) setProgress((v.currentTime / v.duration) * 100);
    };
    v.addEventListener('loadedmetadata', onMeta);
    v.addEventListener('timeupdate', onTime);
    return () => {
      v.removeEventListener('loadedmetadata', onMeta);
      v.removeEventListener('timeupdate', onTime);
    };
  }, []);

  // Sync mute with global state
  useEffect(() => {
    if (videoRef.current) videoRef.current.muted = globalMuted;
  }, [globalMuted]);

  const toggleMute = (e: React.MouseEvent) => {
    e.stopPropagation();
    setGlobalMuted(!globalMuted);
  };

  const openModal = (e: React.MouseEvent) => {
    e.stopPropagation();
    setModalOpen(true);
    setIsVideoModalOpen(true);
    videoRef.current?.pause();
  };

  const closeModal = (open: boolean) => {
    setModalOpen(open);
    if (!open) setIsVideoModalOpen(false);
  };

  // Clamp aspect so we never render an ultra-narrow or ultra-wide reel.
  const clamped = Math.min(Math.max(aspect, 9 / 16), 16 / 9);

  return (
    <>
      <div
        ref={containerRef}
        onClick={openModal}
        className={cn(
          'relative overflow-hidden rounded-xl border border-border bg-black mx-auto cursor-pointer',
          className
        )}
        style={{
          width: '100%',
          maxWidth,
          aspectRatio: String(clamped),
          maxHeight,
        }}
      >
        <SmartVideo
          ref={videoRef}
          src={src}
          poster={poster || undefined}
          muted={globalMuted}
          loop
          autoPlayInView={false}
          className="w-full h-full object-cover"
        />

        {/* Center play overlay when paused */}
        {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-12 h-12 rounded-full bg-black/50 flex items-center justify-center">
              <Play className="w-6 h-6 text-white fill-white ml-0.5" />
            </div>
          </div>
        )}

        {/* Mute toggle (top-right) */}
        <button
          type="button"
          onClick={toggleMute}
          aria-label={globalMuted ? 'Unmute' : 'Mute'}
          className="absolute top-2 right-2 z-20 w-8 h-8 rounded-full bg-black/55 hover:bg-black/70 flex items-center justify-center text-white"
        >
          {globalMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* Expand hint (bottom-right) */}
        <div className="absolute bottom-2 right-2 z-20 w-7 h-7 rounded-full bg-black/45 flex items-center justify-center text-white/90 pointer-events-none">
          <Maximize2 className="w-3.5 h-3.5" />
        </div>

        {/* Progress bar (bottom) */}
        <div className="absolute left-0 right-0 bottom-0 h-1 bg-white/15">
          <div
            className="h-full bg-primary transition-[width] duration-150"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <Dialog open={modalOpen} onOpenChange={closeModal}>
        <DialogContent className="max-w-3xl p-0 bg-black border-0 overflow-hidden">
          <DialogTitle className="sr-only">Video player</DialogTitle>
          <DialogDescription className="sr-only">Fullscreen video playback</DialogDescription>
          <SmartVideo
            src={src}
            poster={poster || undefined}
            autoPlay
            controls
            className="w-full h-auto max-h-[85vh] bg-black"
          />
        </DialogContent>
      </Dialog>
    </>
  );
};

export default ReelVideoPlayer;