import React, { useState } from 'react';
import { getShareableUrl } from '@/utils/getAppUrl';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuSeparator,
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { 
  Flag, 
  UserMinus, 
  EyeOff, 
  Link2, 
  Bookmark, 
  MessageCircleWarning,
  MoreHorizontal,
  Ban
} from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { useBlockedUsers } from '@/hooks/useBlockedUsers';
import { useAuth } from '@/components/auth/AuthContext';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface FeedCardMenuProps {
  itemId: string;
  itemType: 'ad' | 'post' | 'event';
  sellerId?: string;
  sellerUserId?: string;
  sellerName?: string;
  onSave?: () => void;
  isSaved?: boolean;
  isFollowing?: boolean;
  onUnfollow?: () => void;
}

const FeedCardMenu: React.FC<FeedCardMenuProps> = ({
  itemId,
  itemType,
  sellerId,
  sellerUserId,
  sellerName,
  onSave,
  isSaved,
  isFollowing,
  onUnfollow,
}) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { blockUser, isBlockedByMe } = useBlockedUsers();
  const [showBlockConfirm, setShowBlockConfirm] = useState(false);
  const [blocking, setBlocking] = useState(false);

  const handleCopyLink = () => {
    const url = getShareableUrl(`/${itemType === 'ad' ? 'ad' : itemType}/${itemId}`);
    navigator.clipboard.writeText(url);
    toast.success('Link copied to clipboard');
  };

  const handleReport = () => {
    navigate(`/report?type=${itemType}&id=${itemId}`);
  };

  const handleNotInterested = () => {
    toast.success("We'll show you less content like this");
  };

  const handleUnfollow = () => {
    if (onUnfollow) {
      onUnfollow();
    } else {
      toast.success(`Unfollowed ${sellerName || 'this seller'}`);
    }
  };

  const handleMute = () => {
    toast.success(`Muted ${sellerName || 'this seller'}`);
  };

  const handleBlockClick = () => {
    if (!user) {
      toast.error('Please sign in to block users');
      return;
    }
    if (!sellerUserId) {
      toast.error('Cannot block this user');
      return;
    }
    setShowBlockConfirm(true);
  };

  const handleConfirmBlock = async () => {
    if (!sellerUserId) return;
    
    setBlocking(true);
    const success = await blockUser(sellerUserId, sellerName);
    setBlocking(false);
    setShowBlockConfirm(false);
    
    if (success) {
      // Optionally refresh the page or hide the content
      window.location.reload();
    }
  };

  const isAlreadyBlocked = sellerUserId ? isBlockedByMe(sellerUserId) : false;

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button 
            className="relative z-20 inline-flex items-center justify-center h-11 w-11 sm:h-9 sm:w-9 -m-1 hover:bg-muted rounded-full transition-colors touch-manipulation"
            aria-label="More options"
            onClick={(e) => { e.stopPropagation(); }}
            onPointerDown={(e) => e.stopPropagation()}
          >
            <MoreHorizontal className="w-4 h-4 text-muted-foreground" />
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent 
          align="end" 
          className="w-64 rounded-2xl bg-background/95 backdrop-blur-xl border border-border/50 shadow-xl p-1"
          onClick={(e) => e.stopPropagation()}
        >
          <DropdownMenuItem 
            onClick={handleNotInterested}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-muted"
          >
            <EyeOff className="w-4 h-4" />
            <div>
              <p className="font-medium text-sm">Not interested</p>
              <p className="text-xs text-muted-foreground">Show less like this</p>
            </div>
          </DropdownMenuItem>

          {sellerId && isFollowing && (
            <DropdownMenuItem 
              onClick={handleUnfollow}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-muted"
            >
              <UserMinus className="w-4 h-4" />
              <div>
                <p className="font-medium text-sm">Unfollow @{sellerName}</p>
                <p className="text-xs text-muted-foreground">Stop seeing their posts</p>
              </div>
            </DropdownMenuItem>
          )}

          {sellerId && isFollowing && (
            <DropdownMenuItem 
              onClick={handleMute}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-muted"
            >
              <MessageCircleWarning className="w-4 h-4" />
              <div>
                <p className="font-medium text-sm">Mute @{sellerName}</p>
                <p className="text-xs text-muted-foreground">Mute notifications</p>
              </div>
            </DropdownMenuItem>
          )}

          <DropdownMenuSeparator className="my-1" />

          <DropdownMenuItem 
            onClick={onSave}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-muted"
          >
            <Bookmark className={`w-4 h-4 ${isSaved ? 'fill-primary text-primary' : ''}`} />
            <span className="font-medium text-sm">{isSaved ? 'Remove from bookmarks' : 'Bookmark'}</span>
          </DropdownMenuItem>

          <DropdownMenuItem 
            onClick={handleCopyLink}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-muted"
          >
            <Link2 className="w-4 h-4" />
            <span className="font-medium text-sm">Copy link</span>
          </DropdownMenuItem>

          <DropdownMenuSeparator className="my-1" />

          {sellerUserId && !isAlreadyBlocked && (
            <DropdownMenuItem 
              onClick={handleBlockClick}
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-muted text-destructive"
            >
              <Ban className="w-4 h-4" />
              <div>
                <p className="font-medium text-sm">Block @{sellerName}</p>
                <p className="text-xs text-muted-foreground/70">Hide all their content</p>
              </div>
            </DropdownMenuItem>
          )}

          <DropdownMenuItem 
            onClick={handleReport}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer hover:bg-muted text-destructive"
          >
            <Flag className="w-4 h-4" />
            <div>
              <p className="font-medium text-sm">Report</p>
              <p className="text-xs text-muted-foreground/70">Report this content</p>
            </div>
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>

      <AlertDialog open={showBlockConfirm} onOpenChange={setShowBlockConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Block {sellerName}?</AlertDialogTitle>
            <AlertDialogDescription>
              They won't be able to see your content or contact you, and you won't see their posts, products, or services in your feed. You can unblock them anytime from settings.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={blocking}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleConfirmBlock}
              disabled={blocking}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {blocking ? 'Blocking...' : 'Block'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default FeedCardMenu;
