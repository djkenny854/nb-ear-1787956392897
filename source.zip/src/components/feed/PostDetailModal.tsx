import React, { useState } from 'react';
import { X, Heart, MessageCircle, Share2, Bookmark, MapPin, Globe, ExternalLink, Wrench, Play } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle } from '@/components/ui/drawer';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useIsMobile } from '@/hooks/use-mobile';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';
import { useNavigate } from 'react-router-dom';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import VideoPlayer from '@/components/VideoPlayer';
import { YouTubeIcon, TikTokIcon } from '@/components/icons/SocialIcons';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useEngagement, useInterested } from '@/hooks/useEngagement';
import { useAuth } from '@/components/auth/AuthContext';
import { useCurrency } from '@/contexts/CurrencyContext';

interface PostData {
  id: string;
  title: string;
  content: string;
  images?: string[];
  video_url?: string;
  youtube_url?: string;
  tiktok_url?: string;
  website_url?: string;
  location?: string;
  tags?: string[];
  attached_services?: string[];
  created_at: string;
  like_count: number;
  comment_count: number;
  share_count: number;
  view_count: number;
  seller: {
    id: string;
    user_id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
    verification_badge_color?: BadgeColor;
    slug?: string;
  };
}

interface PostDetailModalProps {
  post: PostData | null;
  open: boolean;
  onClose: () => void;
}

const PostDetailModal: React.FC<PostDetailModalProps> = ({ post, open, onClose }) => {
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const { formatPriceCompact } = useCurrency();
  const { user } = useAuth();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Fetch attached services
  const { data: attachedServicesData } = useQuery({
    queryKey: ['post-attached-services', post?.attached_services],
    queryFn: async () => {
      if (!post?.attached_services?.length) return [];
      const { data } = await supabase
        .from('ads')
        .select('id, title, price, images, listing_type')
        .in('id', post.attached_services);
      return data || [];
    },
    enabled: !!post?.attached_services?.length,
  });

  const { isInterested, toggleInterested, count: likeCount } = useInterested(post?.id || '', 'post');

  if (!post) return null;

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diffInSeconds < 60) return `${diffInSeconds}s ago`;
    if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
    if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
    if (diffInSeconds < 604800) return `${Math.floor(diffInSeconds / 86400)}d ago`;
    
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  };

  const handleSellerClick = () => {
    onClose();
    navigate(getSellerProfileUrl({ 
      id: post.seller.id, 
      business_name: post.seller.business_name,
      store_slug: post.seller.slug 
    }));
  };

  const handleServiceClick = (serviceId: string) => {
    onClose();
    navigate(`/ad/${serviceId}`);
  };

  const content = (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center gap-3 p-4 border-b">
        <Avatar 
          className="h-10 w-10 cursor-pointer" 
          onClick={handleSellerClick}
        >
          <AvatarImage src={post.seller.business_logo_url} />
          <AvatarFallback className="bg-primary/10 text-primary font-semibold">
            {post.seller.business_name.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1">
            <span 
              className="font-semibold text-sm hover:underline cursor-pointer"
              onClick={handleSellerClick}
            >
              {post.seller.business_name}
            </span>
            <UnifiedVerifiedBadge 
              isVerified={post.seller.is_verified}
              badgeColor={post.seller.verification_badge_color}
              size="sm"
            />
          </div>
          <span className="text-xs text-muted-foreground">{getTimeAgo(post.created_at)}</span>
        </div>
        {!isMobile && (
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        )}
      </div>

      {/* Content */}
      <ScrollArea className="flex-1">
        <div className="p-4 space-y-4">
          {/* Text Content */}
          <p className="text-sm whitespace-pre-wrap">{post.content}</p>

          {/* Video */}
          {post.video_url && (
            <div className="rounded-xl overflow-hidden bg-black">
              <VideoPlayer
                src={post.video_url}
                className="w-full max-h-[400px]"
                controls
              />
            </div>
          )}

          {/* Images */}
          {post.images && post.images.length > 0 && (
            <div className={`grid gap-2 ${
              post.images.length === 1 ? 'grid-cols-1' : 'grid-cols-2'
            }`}>
              {post.images.map((img, index) => (
                <div 
                  key={index}
                  className={`relative rounded-xl overflow-hidden ${
                    post.images!.length === 3 && index === 0 ? 'row-span-2' : ''
                  }`}
                >
                  <img
                    src={img}
                    alt=""
                    className="w-full h-full object-cover aspect-video"
                  />
                </div>
              ))}
            </div>
          )}

          {/* YouTube/TikTok Links */}
          {(post.youtube_url || post.tiktok_url) && (
            <div className="flex flex-wrap gap-2">
              {post.youtube_url && (
                <a
                  href={post.youtube_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-3 py-2 bg-red-50 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg text-sm hover:bg-red-100 dark:hover:bg-red-900/30 transition-colors"
                >
                  <Play className="h-4 w-4" />
                  Watch on YouTube
                  <ExternalLink className="h-3 w-3" />
                </a>
              )}
              {post.tiktok_url && (
                <a
                  href={post.tiktok_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-3 py-2 bg-gray-100 dark:bg-gray-800 rounded-lg text-sm hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors"
                >
                  <Play className="h-4 w-4" />
                  Watch on TikTok
                  <ExternalLink className="h-3 w-3" />
                </a>
              )}
            </div>
          )}

          {/* Website Link */}
          {post.website_url && (
            <a
              href={post.website_url.startsWith('http') ? post.website_url : `https://${post.website_url}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 p-3 border rounded-xl hover:bg-muted transition-colors"
            >
              <Globe className="h-5 w-5 text-blue-500" />
              <span className="text-sm flex-1 truncate text-primary">{post.website_url}</span>
              <ExternalLink className="h-4 w-4 text-muted-foreground" />
            </a>
          )}

          {/* Location */}
          {post.location && (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span>{post.location}</span>
            </div>
          )}

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {post.tags.map((tag, index) => (
                <Badge key={index} variant="secondary" className="text-xs">
                  #{tag}
                </Badge>
              ))}
            </div>
          )}

          {/* Attached Services */}
          {attachedServicesData && attachedServicesData.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <Wrench className="h-4 w-4" />
                Attached Services
              </h4>
              <div className="space-y-2">
                {attachedServicesData.map(service => (
                  <button
                    key={service.id}
                    onClick={() => handleServiceClick(service.id)}
                    className="w-full flex items-center gap-3 p-3 border rounded-xl hover:bg-muted transition-colors text-left"
                  >
                    {service.images?.[0] && (
                      <img
                        src={service.images[0]}
                        alt=""
                        className="w-12 h-12 rounded-lg object-cover"
                      />
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{service.title}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatPriceCompact(service.price || 0)}
                      </p>
                    </div>
                    <ExternalLink className="h-4 w-4 text-muted-foreground" />
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Footer Actions */}
      <div className="border-t p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button 
              onClick={() => user && toggleInterested()}
              className={`flex items-center gap-1.5 transition-colors ${
                isInterested ? 'text-red-500' : 'text-muted-foreground hover:text-red-500'
              }`}
            >
              <Heart className={`h-5 w-5 ${isInterested ? 'fill-current' : ''}`} />
              
            </button>
            <button className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors">
              <MessageCircle className="h-5 w-5" />
              
            </button>
            <button className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors">
              <Share2 className="h-5 w-5" />
              <span className="text-sm">{post.share_count || ''}</span>
            </button>
          </div>
          <button className="text-muted-foreground hover:text-primary transition-colors">
            <Bookmark className="h-5 w-5" />
          </button>
        </div>
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
        <DrawerContent className="max-h-[90vh]">
          <DrawerHeader className="sr-only">
            <DrawerTitle>Post Details</DrawerTitle>
          </DrawerHeader>
          {content}
        </DrawerContent>
      </Drawer>
    );
  }

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="max-w-lg p-0 max-h-[85vh] overflow-hidden">
        {content}
      </DialogContent>
    </Dialog>
  );
};

export default PostDetailModal;
