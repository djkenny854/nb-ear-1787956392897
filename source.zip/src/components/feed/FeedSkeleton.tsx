import React, { memo } from 'react';
import { cn } from '@/lib/utils';

interface FeedSkeletonProps {
  count?: number;
}

// Optimized skeleton without heavy animations - pure CSS shimmer
const SkeletonBox = memo(({ className }: { className?: string }) => (
  <div 
    className={cn(
      "bg-muted/50 rounded skeleton-shimmer",
      className
    )} 
  />
));
SkeletonBox.displayName = 'SkeletonBox';

// Single feed item skeleton - X.com style
const FeedItemSkeleton = memo(() => (
  <div className="border-b border-border px-4 py-3">
    <div className="flex gap-3">
      {/* Avatar */}
      <SkeletonBox className="w-10 h-10 rounded-full shrink-0" />
      
      <div className="flex-1 min-w-0 space-y-2">
        {/* Header: name + handle + time */}
        <div className="flex items-center gap-2">
          <SkeletonBox className="h-4 w-24" />
          <SkeletonBox className="h-3 w-16" />
        </div>

        {/* Content text lines */}
        <div className="space-y-1.5 pt-1">
          <SkeletonBox className="h-[14px] w-full" />
          <SkeletonBox className="h-[14px] w-[85%]" />
          <SkeletonBox className="h-[14px] w-[60%]" />
        </div>

        {/* Image placeholder */}
        <SkeletonBox className="h-48 md:h-64 w-full rounded-xl mt-3" />

        {/* Action bar */}
        <div className="flex items-center justify-between max-w-[400px] mt-3 -ml-1">
          <SkeletonBox className="w-8 h-8 rounded-full" />
          <SkeletonBox className="w-8 h-8 rounded-full" />
          <SkeletonBox className="w-8 h-8 rounded-full" />
          <SkeletonBox className="w-8 h-8 rounded-full" />
          <div className="flex gap-2">
            <SkeletonBox className="w-8 h-8 rounded-full" />
            <SkeletonBox className="w-8 h-8 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  </div>
));
FeedItemSkeleton.displayName = 'FeedItemSkeleton';

const FeedSkeleton: React.FC<FeedSkeletonProps> = memo(({ count = 2 }) => {
  return (
    <>
      {Array.from({ length: count }).map((_, index) => (
        <FeedItemSkeleton key={index} />
      ))}
    </>
  );
});
FeedSkeleton.displayName = 'FeedSkeleton';

export default FeedSkeleton;
