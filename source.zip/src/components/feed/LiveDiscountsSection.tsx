import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Flame, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useNavigate } from 'react-router-dom';
import { Skeleton } from '@/components/ui/skeleton';
import LiveDiscountCard from './LiveDiscountCard';
import RailScroller from '@/components/common/RailScroller';

interface DiscountPromotion {
  id: string;
  ad_id: string;
  title: string;
  description: string;
  discount_percentage: number;
  promotion_type: string;
  start_at: string | null;
  valid_until: string | null;
  state: string;
  images: string[];
  seller: {
    id: string;
    business_name: string;
    business_logo_url: string;
    is_verified: boolean;
  };
  products: {
    id: string;
    image: string;
    title: string;
  }[];
}

const LiveDiscountsSection: React.FC = () => {
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [promotions, setPromotions] = useState<DiscountPromotion[]>([]);
  const [loading, setLoading] = useState(true);
  const [canScrollLeft, setCanScrollLeft] = useState(false);
  const [canScrollRight, setCanScrollRight] = useState(true);

  useEffect(() => {
    fetchDiscountPromotions();
  }, []);

  const fetchDiscountPromotions = async () => {
    try {
      const now = new Date().toISOString();
      
      // Fetch only live or upcoming promotions (not ended)
      const { data: promoData, error } = await supabase
        .from('promotion_details')
        .select(`
          id,
          ad_id,
          discount_percentage,
          promotion_type,
          start_at,
          valid_until,
          state,
          is_seller_wide,
          ads!inner(
            id,
            title,
            description,
            images,
            status,
            seller_profiles(
              id,
              user_id,
              business_name,
              business_logo_url,
              is_verified
            )
          )
        `)
        .eq('offer_type', 'Discount')
        .eq('ads.status', 'active')
        .or(`valid_until.is.null,valid_until.gt.${now}`)
        .order('created_at', { ascending: false })
        .limit(8);

      if (error) throw error;

      // Filter out expired promotions and format
      const formattedPromotions: DiscountPromotion[] = [];
      
      for (const promo of promoData || []) {
        // Check if expired
        if (promo.valid_until && new Date(promo.valid_until) < new Date()) {
          continue;
        }

        const ad = promo.ads as any;
        const seller = ad.seller_profiles;

        // First try to fetch from promotion_products table (linked products)
        let products: { id: string; title: string; image: string }[] = [];
        
        const { data: promoProducts } = await supabase
          .from('promotion_products')
          .select('ad_id')
          .eq('promotion_id', promo.id)
          .limit(6);
        
        if (promoProducts && promoProducts.length > 0) {
          // Fetch product details for linked products
          const productIds = promoProducts.map(pp => pp.ad_id);
          const { data: productDetails } = await supabase
            .from('ads')
            .select('id, title, images')
            .in('id', productIds);
          
          products = (productDetails || []).map(p => ({
            id: p.id,
            title: p.title,
            image: p.images?.[0] || '/placeholder.svg',
          }));
        } else if (promo.is_seller_wide) {
          // Fallback: For seller-wide promotions without linked products, fetch seller's products
          const { data: sellerProducts } = await supabase
            .from('ads')
            .select('id, title, images')
            .eq('seller_id', seller.id)
            .eq('status', 'active')
            .in('listing_type', ['physical_products', 'digital_products'])
            .limit(6);
          
          products = (sellerProducts || []).map(p => ({
            id: p.id,
            title: p.title,
            image: p.images?.[0] || '/placeholder.svg',
          }));
        }

        formattedPromotions.push({
          id: promo.id,
          ad_id: promo.ad_id,
          title: ad.title,
          description: ad.description || '',
          discount_percentage: promo.discount_percentage || 0,
          promotion_type: promo.promotion_type || 'standard',
          start_at: promo.start_at,
          valid_until: promo.valid_until,
          state: promo.state || 'live',
          images: ad.images || [],
          seller: {
            id: seller.id,
            business_name: seller.business_name,
            business_logo_url: seller.business_logo_url,
            is_verified: seller.is_verified,
          },
          products,
        });
      }

      setPromotions(formattedPromotions);
    } catch (error) {
      console.error('Error fetching discount promotions:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleScroll = () => {
    if (!scrollRef.current) return;
    const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
    setCanScrollLeft(scrollLeft > 0);
    setCanScrollRight(scrollLeft < scrollWidth - clientWidth - 10);
  };

  const scroll = (direction: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const scrollAmount = 300;
    scrollRef.current.scrollBy({
      left: direction === 'left' ? -scrollAmount : scrollAmount,
      behavior: 'smooth',
    });
  };

  if (loading) {
    return (
      <div className="py-4 border-b border-border">
        <div className="flex items-center gap-2 px-4 mb-3">
          <Skeleton className="h-6 w-6 rounded" />
          <Skeleton className="h-5 w-40" />
        </div>
        <div className="flex gap-3 overflow-hidden px-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-[200px] w-[300px] rounded-2xl shrink-0" />
          ))}
        </div>
      </div>
    );
  }

  if (promotions.length === 0) {
    return null;
  }

  return (
    <div className="py-4 border-b border-border bg-gradient-to-b from-muted/30 to-transparent">
      {/* Header */}
      <div className="flex items-center justify-between px-4 mb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-gradient-to-br from-red-500 to-orange-500 shadow-md">
            <Flame className="h-4 w-4 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-sm sm:text-base flex items-center gap-1.5">
              Live Discounts
              <Sparkles className="h-4 w-4 text-amber-500" />
            </h2>
            <p className="text-xs text-muted-foreground">Hot deals happening now</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 rounded-full"
            onClick={() => scroll('left')}
            disabled={!canScrollLeft}
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 rounded-full"
            onClick={() => scroll('right')}
            disabled={!canScrollRight}
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Carousel */}
      <RailScroller>
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex gap-3 overflow-x-auto scrollbar-hide px-4 pb-2"
        style={{ scrollSnapType: 'x mandatory' }}
        data-carousel
      >
        {promotions.map((promo, index) => (
          <motion.div
            key={promo.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.08 }}
            style={{ scrollSnapAlign: 'start' }}
          >
            <LiveDiscountCard
              id={promo.id}
              title={promo.title}
              description={promo.description}
              discountPercent={promo.discount_percentage}
              promotionType={promo.promotion_type as any}
              startAt={promo.start_at || undefined}
              validUntil={promo.valid_until || undefined}
              products={promo.products}
              seller={promo.seller}
              coverImage={promo.images?.[0]}
              onClick={() => navigate(`/promotion/${promo.ad_id}`)}
              onSellerClick={() => navigate(`/business/${promo.seller.id}`)}
              onRemindMe={() => {
                console.log('Set reminder for', promo.id);
              }}
            />
          </motion.div>
        ))}
      </div>
      </RailScroller>
    </div>
  );
};

export default LiveDiscountsSection;
