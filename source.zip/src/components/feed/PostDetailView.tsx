import React, { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { VisuallyHidden } from '@radix-ui/react-visually-hidden';
import {
  X, Heart, MessageCircle, Share2, Bookmark, ChevronLeft, ChevronRight,
  MapPin, Globe, ExternalLink, ArrowUp, Loader2, Search, MoreHorizontal,
} from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';
import { useNavigate } from 'react-router-dom';
import { useIsMobile } from '@/hooks/use-mobile';
import { useAuth } from '@/components/auth/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import VideoPlayer from '@/components/VideoPlayer';
import UnifiedVerifiedBadge, { BadgeColor } from '@/components/UnifiedVerifiedBadge';
import { useInterested, useEngagement } from '@/hooks/useEngagement';
import { useBookmarks } from '@/hooks/useBookmarks';
import { useFollow } from '@/hooks/useFollow';
import { getSellerProfileUrl } from '@/lib/sellerUrl';
import { getAppBaseUrl } from '@/utils/getAppUrl';
import ShareModal from '@/components/ShareModal';

export interface PostDetailItem {
  id: string;
  title?: string;
  description?: string;
  content?: string;
  images?: string[];
  b2_video_url?: string | null;
  video_url?: string | null;
  youtube_url?: string | null;
  tiktok_url?: string | null;
  website_url?: string | null;
  location?: string;
  tags?: string[];
  attached_products?: string[];
  attached_services?: string[];
  created_at: string;
  like_count?: number;
  comment_count?: number;
  view_count?: number;
  allow_comments?: boolean;
  seller: {
    id: string;
    user_id: string;
    business_name: string;
    business_logo_url?: string;
    is_verified?: boolean;
    verification_badge_color?: BadgeColor | string | null;
    slug?: string;
  };
}

interface PostDetailViewProps {
  post: PostDetailItem | null;
  open: boolean;
  onClose: () => void;
}

interface CommentRow {
  id: string;
  user_id: string;
  content: string;
  created_at: string;
  parent_comment_id: string | null;
  user?: { name: string; avatar?: string };
}

const timeAgo = (date: string) => {
  const d = Math.floor((Date.now() - new Date(date).getTime()) / 1000);
  if (d < 60) return `${d}s`;
  if (d < 3600) return `${Math.floor(d / 60)}m`;
  if (d < 86400) return `${Math.floor(d / 3600)}h`;
  if (d < 604800) return `${Math.floor(d / 86400)}d`;
  return new Date(date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
};

/** Rotating loader shown inside the reserved media frame. */
const MediaSpinner: React.FC = () => (
  <div className="absolute inset-0 z-10 flex items-center justify-center bg-black">
    <div className="w-8 h-8 rounded-full border-2 border-white/25 border-t-white animate-spin" />
  </div>
);

const PostDetailView: React.FC<PostDetailViewProps> = ({ post, open, onClose }) => {
  const isMobile = useIsMobile();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isInterested, toggleInterested, count: likeCount, isLoading: interestedLoading } = useInterested(post?.id || '', 'post');
  const { isBookmarked, toggleBookmark } = useBookmarks();
  const { trackClick } = useEngagement();
  const { isFollowing, toggleFollow } = useFollow(post?.seller.user_id || '');
  const [mediaIdx, setMediaIdx] = useState(0);
  const [mediaLoaded, setMediaLoaded] = useState(false);
  const [comments, setComments] = useState<CommentRow[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const touchStartX = useRef<number | null>(null);
  // Natural aspect ratio of the visible media (width / height). Keeps portrait
  // clips portrait instead of forcing them into a zoomed landscape frame.
  const [mediaRatio, setMediaRatio] = useState<number>(4 / 5);
  const [attached, setAttached] = useState<
    { id: string; title: string; price: number; images: string[]; listing_type: string }[]
  >([]);

  // Build media list
  const videoSrc = post?.b2_video_url || post?.video_url || null;
  const images = post?.images || [];
  const media: { type: 'video' | 'image'; src: string }[] = [
    ...images.map((src) => ({ type: 'image' as const, src })),
    ...(videoSrc ? [{ type: 'video' as const, src: videoSrc }] : []),
  ];

  useEffect(() => {
    if (open) setMediaIdx(0);
  }, [open, post?.id]);

  // Reset the fade-in whenever the visible media changes.
  useEffect(() => { setMediaLoaded(false); setMediaRatio(4 / 5); }, [post?.id, mediaIdx]);

  // Fetch comments when opening
  useEffect(() => {
    if (!open || !post?.id) return;
    let cancelled = false;
    (async () => {
      setLoadingComments(true);
      try {
        const { data } = await supabase
          .from('comments')
          .select('*')
          .eq('content_type', 'post')
          .eq('content_id', post.id)
          .order('created_at', { ascending: false });
        if (cancelled) return;
        const ids = [...new Set((data || []).map((c) => c.user_id))];
        const userMap: Record<string, { name: string; avatar?: string }> = {};
        if (ids.length) {
          const { data: sellers } = await supabase
            .from('seller_profiles')
            .select('user_id, business_name, business_logo_url')
            .in('user_id', ids);
          (sellers || []).forEach((s) => {
            userMap[s.user_id] = { name: s.business_name || 'User', avatar: s.business_logo_url || undefined };
          });
          const missing = ids.filter((i) => !userMap[i]);
          if (missing.length) {
            const { data: profs } = await supabase.rpc('get_public_user_profiles', { p_user_ids: missing });
            (profs || []).forEach((p: any) => {
              userMap[p.user_id] = { name: p.display_name || 'User', avatar: p.avatar_url || undefined };
            });
          }
        }
        if (cancelled) return;
        setComments((data || []).map((c) => ({ ...c, user: userMap[c.user_id] || { name: 'User' } })));
      } finally {
        if (!cancelled) setLoadingComments(false);
      }
    })();
    return () => { cancelled = true; };
  }, [open, post?.id]);

  // Fetch attached products / services so they render inside the post.
  useEffect(() => {
    const ids = [
      ...((post?.attached_products as string[]) || []),
      ...((post?.attached_services as string[]) || []),
    ].filter(Boolean);
    if (!open || ids.length === 0) { setAttached([]); return; }
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from('ads')
        .select('id, title, price, images, listing_type')
        .in('id', ids);
      if (!cancelled) setAttached((data as any) || []);
    })();
    return () => { cancelled = true; };
  }, [open, post?.id]);

  if (!post) return null;

  const captionText = post.description || post.content || post.title || '';

  const handlePrev = () => setMediaIdx((i) => (i - 1 + media.length) % media.length);
  const handleNext = () => setMediaIdx((i) => (i + 1) % media.length);

  const handleSellerClick = () => {
    onClose();
    navigate(getSellerProfileUrl({
      id: post.seller.id,
      business_name: post.seller.business_name,
      store_slug: post.seller.slug,
    }));
  };

  const goAttached = (a: { id: string; listing_type: string }) => {
    onClose();
    if (a.listing_type === 'services') navigate(`/service/${a.id}`);
    else if (a.listing_type === 'digital_products') navigate(`/digital/${a.id}`);
    else navigate(`/ad/${a.id}`);
  };

  const handleSubmitComment = async () => {
    if (!user) { toast.error('Please sign in to comment'); return; }
    if (!newComment.trim()) return;
    setSubmitting(true);
    try {
      const { data, error } = await supabase
        .from('comments')
        .insert({
          user_id: user.id,
          content_type: 'post',
          content_id: post.id,
          content: newComment.trim(),
        })
        .select()
        .single();
      if (error) throw error;
      const { data: sp } = await supabase
        .from('seller_profiles')
        .select('business_name, business_logo_url')
        .eq('user_id', user.id)
        .maybeSingle();
      let name = sp?.business_name;
      let avatar = sp?.business_logo_url;
      if (!name) {
        const { data: profs } = await supabase.rpc('get_public_user_profiles', { p_user_ids: [user.id] });
        name = profs?.[0]?.display_name || user.email?.split('@')[0] || 'You';
        avatar = avatar || profs?.[0]?.avatar_url;
      }
      setComments((prev) => [{ ...(data as any), user: { name, avatar } }, ...prev]);
      setNewComment('');
    } catch (e) {
      toast.error('Failed to post comment');
    } finally {
      setSubmitting(false);
    }
  };

  const handleSave = async () => {
    if (!user) { toast.error('Please sign in to save'); return; }
    await toggleBookmark(post.id, 'post');
  };

  const handleShare = () => setShareOpen(true);
  const shareUrl = `${getAppBaseUrl()}/?post=${post.id}`;

  const onTouchStart = (e: React.TouchEvent) => { touchStartX.current = e.touches[0].clientX; };
  const onTouchEnd = (e: React.TouchEvent) => {
    if (touchStartX.current == null || media.length <= 1) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    if (Math.abs(dx) > 50) (dx < 0 ? handleNext : handlePrev)();
    touchStartX.current = null;
  };

  // Media element
  const mediaPane = (
    <div
      className="relative w-full h-full bg-black flex items-center justify-center select-none"
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
    >
      {media.length === 0 ? (
        <div className="text-white/60 text-sm">No media</div>
      ) : media[mediaIdx].type === 'video' ? (
        <VideoPlayer src={media[mediaIdx].src} className="max-h-full max-w-full" controls autoPlay />
      ) : (
        <>
          {!mediaLoaded && <MediaSpinner />}
          <img
            key={media[mediaIdx].src}
            src={media[mediaIdx].src}
            alt=""
            className={cn(
              'max-h-full max-w-full object-contain transition-opacity duration-300',
              mediaLoaded ? 'opacity-100' : 'opacity-0',
            )}
            draggable={false}
            onLoad={() => setMediaLoaded(true)}
            onError={() => setMediaLoaded(true)}
            onContextMenu={(e) => e.preventDefault()}
          />
        </>
      )}

      {media.length > 1 && (
        <>
          <button
            onClick={handlePrev}
            className="hidden md:flex absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-background/80 hover:bg-background items-center justify-center shadow-lg"
            aria-label="Previous"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={handleNext}
            className="hidden md:flex absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-background/80 hover:bg-background items-center justify-center shadow-lg"
            aria-label="Next"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
          {/* Dots */}
          <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
            {media.map((_, i) => (
              <button
                key={i}
                onClick={() => setMediaIdx(i)}
                className={cn(
                  'h-1.5 rounded-full transition-all',
                  i === mediaIdx ? 'w-6 bg-white' : 'w-1.5 bg-white/50'
                )}
                aria-label={`Go to media ${i + 1}`}
              />
            ))}
          </div>
          <div className="absolute top-3 right-3 px-2 py-0.5 rounded-full bg-black/60 text-white text-xs">
            {mediaIdx + 1}/{media.length}
          </div>
        </>
      )}

      {/* Mobile close button overlay */}
      {isMobile && (
        <button
          onClick={onClose}
          className="absolute top-3 left-3 w-9 h-9 rounded-full bg-black/50 text-white flex items-center justify-center"
          aria-label="Close"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>
      )}
    </div>
  );

  // Sidebar / details
  const detailsPane = (
    <div className="flex flex-col h-full bg-background min-h-0">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b">
        {isMobile && (
          <button onClick={onClose} aria-label="Back" className="mr-1 -ml-1 p-1 shrink-0">
            <ChevronLeft className="h-5 w-5" />
          </button>
        )}
        <div className="flex items-center gap-3 min-w-0 flex-1">
          <Avatar className="h-9 w-9 cursor-pointer" onClick={handleSellerClick}>
            <AvatarImage src={post.seller.business_logo_url} />
            <AvatarFallback className="bg-primary/10 text-primary text-sm font-semibold">
              {post.seller.business_name?.[0]?.toUpperCase() || 'U'}
            </AvatarFallback>
          </Avatar>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1">
              <span
                className="font-semibold text-sm truncate cursor-pointer hover:underline"
                onClick={handleSellerClick}
              >
                {post.seller.business_name}
              </span>
              {post.seller.is_verified && (
                <UnifiedVerifiedBadge
                  isVerified
                  badgeColor={post.seller.verification_badge_color as BadgeColor}
                  size="sm"
                />
              )}
            </div>
            <span className="text-xs text-muted-foreground">{timeAgo(post.created_at)}</span>
          </div>
          {user && user.id !== post.seller.user_id && (
            <Button
              size="sm"
              variant={isFollowing ? 'outline' : 'default'}
              className="rounded-full h-8 px-4"
              onClick={() => toggleFollow()}
            >
              {isFollowing ? 'Following' : 'Follow'}
            </Button>
          )}
        </div>
        {!isMobile && (
          <Button variant="ghost" size="icon" onClick={onClose} className="ml-2">
            <X className="h-5 w-5" />
          </Button>
        )}
      </div>

      {/* Caption + comments scrollable */}
      <ScrollArea className="flex-1 min-h-0">
        <div className="p-4 space-y-4">
          {/* Mobile: media lives inside the scroll so it scrolls away with content */}
          {isMobile && media.length > 0 && (
            <div
              className="-mx-4 -mt-4 mb-1 relative bg-black"
              onTouchStart={onTouchStart}
              onTouchEnd={onTouchEnd}
            >
              {/* Reserved media frame — keeps the layout stable and shows a
                  spinner while the media downloads instead of popping in. */}
              <div
                className="relative w-full bg-black overflow-hidden"
                style={{
                  aspectRatio: String(Math.min(Math.max(mediaRatio, 9 / 16), 16 / 9)),
                  maxHeight: '80vh',
                }}
              >
                {media[mediaIdx].type === 'video' ? (
                  <VideoPlayer
                    src={media[mediaIdx].src}
                    className="absolute inset-0 w-full h-full object-contain"
                    controls
                    autoPlay
                  />
                ) : (
                  <>
                    {!mediaLoaded && <MediaSpinner />}
                    <img
                      key={media[mediaIdx].src}
                      src={media[mediaIdx].src}
                      alt=""
                      className={cn(
                        'absolute inset-0 w-full h-full object-contain transition-opacity duration-300',
                        mediaLoaded ? 'opacity-100' : 'opacity-0',
                      )}
                      draggable={false}
                      onLoad={(e) => {
                        const im = e.currentTarget;
                        if (im.naturalWidth && im.naturalHeight) setMediaRatio(im.naturalWidth / im.naturalHeight);
                        setMediaLoaded(true);
                      }}
                      onError={() => setMediaLoaded(true)}
                      onContextMenu={(e) => e.preventDefault()}
                    />
                  </>
                )}
              </div>
              {media.length > 1 && (
                <>
                  <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5">
                    {media.map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setMediaIdx(i)}
                        className={cn('h-1.5 rounded-full transition-all', i === mediaIdx ? 'w-6 bg-white' : 'w-1.5 bg-white/50')}
                        aria-label={`Go to media ${i + 1}`}
                      />
                    ))}
                  </div>
                  <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-black/60 text-white text-xs">
                    {mediaIdx + 1}/{media.length}
                  </div>
                </>
              )}
            </div>
          )}

          {captionText && (
            <p className="text-sm whitespace-pre-wrap leading-relaxed">{captionText}</p>
          )}

          {/* Tags */}
          {post.tags && post.tags.length > 0 && (
            <div className="flex flex-wrap gap-1.5">
              {post.tags.map((t, i) => (
                <Badge key={i} variant="secondary" className="text-xs">#{t}</Badge>
              ))}
            </div>
          )}

          {/* Attached products / services */}
          {attached.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-semibold">Attached</h4>
              <div className="flex gap-3 overflow-x-auto -mx-1 px-1 pb-1">
                {attached.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => goAttached(a)}
                    className="shrink-0 w-36 text-left rounded-xl border border-border overflow-hidden hover:shadow-md transition-shadow"
                  >
                    <div className="aspect-square bg-muted">
                      {a.images?.[0] && (
                        <img src={a.images[0]} alt={a.title} className="w-full h-full object-cover" />
                      )}
                    </div>
                    <div className="p-2">
                      <p className="text-xs font-medium line-clamp-2">{a.title}</p>
                      {a.price > 0 && (
                        <p className="text-xs text-primary font-semibold mt-0.5">UGX {a.price.toLocaleString()}</p>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Location */}
          {post.location && (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <MapPin className="h-3.5 w-3.5" />
              <span>{post.location}</span>
            </div>
          )}

          {/* Website */}
          {post.website_url && (
            <a
              href={post.website_url.startsWith('http') ? post.website_url : `https://${post.website_url}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 p-3 border rounded-xl hover:bg-muted transition-colors"
            >
              <Globe className="h-4 w-4 text-primary" />
              <span className="text-sm flex-1 truncate text-primary">{post.website_url}</span>
              <ExternalLink className="h-4 w-4 text-muted-foreground" />
            </a>
          )}

          {/* External video links */}
          {(post.youtube_url || post.tiktok_url) && (
            <div className="flex flex-wrap gap-2">
              {post.youtube_url && (
                <a href={post.youtube_url} target="_blank" rel="noopener noreferrer"
                  className="text-xs px-3 py-1.5 rounded-full bg-red-500/10 text-red-600 dark:text-red-400 hover:bg-red-500/20 transition-colors">
                  Watch on YouTube
                </a>
              )}
              {post.tiktok_url && (
                <a href={post.tiktok_url} target="_blank" rel="noopener noreferrer"
                  className="text-xs px-3 py-1.5 rounded-full bg-foreground/10 hover:bg-foreground/20 transition-colors">
                  Watch on TikTok
                </a>
              )}
            </div>
          )}

          {/* Comments */}
          <div className="pt-2 border-t">
            <div className="flex items-center justify-between py-2">
              <h4 className="text-sm font-semibold">
                Comments {comments.length > 0 ? `(${comments.length})` : ''}
              </h4>
            </div>
            {post.allow_comments === false ? (
              <p className="text-xs text-muted-foreground py-4 text-center">
                Comments are turned off for this post.
              </p>
            ) : loadingComments ? (
              <div className="space-y-3 py-2">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="flex gap-3">
                    <Skeleton className="w-8 h-8 rounded-full" />
                    <div className="flex-1 space-y-2">
                      <Skeleton className="h-3 w-1/3" />
                      <Skeleton className="h-3 w-2/3" />
                    </div>
                  </div>
                ))}
              </div>
            ) : comments.length === 0 ? (
              <p className="text-xs text-muted-foreground py-6 text-center">
                Be the first to comment.
              </p>
            ) : (
              <div className="space-y-3 py-2">
                {comments.map((c) => (
                  <div key={c.id} className="flex gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={c.user?.avatar} />
                      <AvatarFallback className="bg-primary/10 text-primary text-xs">
                        {c.user?.name?.[0]?.toUpperCase() || 'U'}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="bg-muted/60 rounded-2xl px-3 py-2">
                        <span className="text-xs font-semibold">{c.user?.name}</span>
                        <p className="text-sm whitespace-pre-wrap break-words">{c.content}</p>
                      </div>
                      <span className="text-[10px] text-muted-foreground ml-3">{timeAgo(c.created_at)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </ScrollArea>

      {/* Action bar */}
      <div className="border-t bg-background">
        <div className="flex items-center justify-between px-4 py-2.5">
          <div className="flex items-center gap-5">
            <button
              onClick={async () => {
                if (!user) { toast.error('Please sign in to react'); navigate('/auth'); return; }
                try {
                  await toggleInterested();
                  trackClick(post.id, 'post', 'item', 'details');
                } catch (e: any) {
                  toast.error(e?.message || 'Failed to update');
                }
              }}
              disabled={interestedLoading}
              className={cn(
                'flex items-center gap-1.5 transition-colors disabled:opacity-50',
                isInterested ? 'text-red-500' : 'text-foreground hover:text-red-500'
              )}
            >
              <Heart className={cn('h-6 w-6', isInterested && 'fill-current')} />
              {likeCount > 0 && <span className="text-xs font-medium">{likeCount}</span>}
            </button>
            <button className="flex items-center gap-1.5 text-foreground hover:text-primary transition-colors">
              <MessageCircle className="h-6 w-6" />
              {comments.length > 0 && <span className="text-xs font-medium">{comments.length}</span>}
            </button>
            <button
              onClick={handleSave}
              className={cn(
                'flex items-center gap-1.5 transition-colors',
                isBookmarked(post.id) ? 'text-primary' : 'text-foreground hover:text-primary'
              )}
            >
              <Bookmark className={cn('h-6 w-6', isBookmarked(post.id) && 'fill-current')} />
            </button>
            <button onClick={handleShare} className="flex items-center gap-1.5 text-foreground hover:text-primary transition-colors">
              <Share2 className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Comment input */}
        {post.allow_comments !== false && (
          <div className="px-3 pb-3">
            <div className="flex items-center gap-2 bg-muted/50 rounded-full px-3 py-1.5 border focus-within:border-primary/50">
              <Avatar className="w-6 h-6">
                <AvatarFallback className="bg-primary/10 text-primary text-xs">
                  {user?.email?.[0]?.toUpperCase() || 'U'}
                </AvatarFallback>
              </Avatar>
              <input
                type="text"
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && handleSubmitComment()}
                placeholder="Add comment..."
                className="flex-1 bg-transparent outline-none text-sm py-1"
              />
              <button
                onClick={handleSubmitComment}
                disabled={!newComment.trim() || submitting}
                className={cn(
                  'p-1.5 rounded-full transition-all',
                  newComment.trim() ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                )}
              >
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <ArrowUp className="w-4 h-4" />}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <>
      <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
        <DialogContent
          className={cn(
            'p-0 overflow-hidden gap-0 border-0 sm:rounded-xl',
            'w-screen h-[100dvh] max-w-none sm:max-w-none',
            'lg:w-[90vw] lg:h-[90vh] lg:max-w-[1200px]'
          )}
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          <VisuallyHidden>
            <DialogTitle>Post detail</DialogTitle>
          </VisuallyHidden>

          {/* Mobile: stacked. Desktop: side-by-side */}
          <div className="flex flex-col lg:flex-row w-full h-full min-h-0">
            {/* Desktop media pane — only when media exists. On mobile the media
                is rendered inside the scrollable details pane so it scrolls away. */}
            {media.length > 0 && (
              <div className="hidden lg:block lg:w-[60%] h-full flex-shrink-0">
                {mediaPane}
              </div>
            )}
            <div className={cn(
              'flex-1 min-h-0 border-border',
              media.length > 0 ? 'lg:w-[40%] lg:border-l' : 'lg:w-full'
            )}>
              {detailsPane}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <ShareModal
        open={shareOpen}
        onOpenChange={setShareOpen}
        title={post.seller.business_name + (post.title ? ' — ' + post.title : '')}
        description={captionText.slice(0, 140)}
        url={shareUrl}
        imageUrl={images[0]}
      />
    </>
  );
};

export default PostDetailView;
