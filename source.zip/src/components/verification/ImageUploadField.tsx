import { useState } from "react";
import { Label } from "@/components/ui/label";
import { Upload, X, CheckCircle, AlertCircle, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface ImageUploadFieldProps {
  label: string;
  id: string;
  value: File | null;
  onChange: (file: File | null) => void;
  error?: string;
  required?: boolean;
}

export const ImageUploadField = ({
  label,
  id,
  value,
  onChange,
  error,
  required = true,
}: ImageUploadFieldProps) => {
  const [preview, setPreview] = useState<string | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<{
    isValid: boolean;
    reason: string;
  } | null>(null);
  const { toast } = useToast();

  const verifyImage = async (base64: string, file: File) => {
    setVerifying(true);
    setVerificationResult(null);

    try {
      // Determine image type from id
      let imageType = "selfie";
      if (id.includes("front")) imageType = "id_front";
      else if (id.includes("back")) imageType = "id_back";

      const { data, error } = await supabase.functions.invoke("verify-id-image", {
        body: {
          imageBase64: base64.split(",")[1], // Remove data:image/jpeg;base64, prefix
          imageType,
        },
      });

      if (error) throw error;

      if (data.isValid) {
        setVerificationResult({ isValid: true, reason: data.reason });
        onChange(file);
        toast({
          title: "Image verified",
          description: "Document looks valid and ready to upload.",
        });
      } else {
        setVerificationResult({ isValid: false, reason: data.reason });
        toast({
          title: "Image verification failed",
          description: data.reason || "Please upload a clear, valid document.",
          variant: "destructive",
        });
        // Clear the file
        onChange(null);
        setPreview(null);
      }
    } catch (error) {
      console.error("Verification error:", error);
      toast({
        title: "Verification error",
        description: "Could not verify image. Please try again.",
        variant: "destructive",
      });
      // Allow upload anyway if verification service fails
      onChange(file);
      setVerificationResult({ isValid: true, reason: "Verification service unavailable, image accepted" });
    } finally {
      setVerifying(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setPreview(base64);
        verifyImage(base64, file);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemove = () => {
    onChange(null);
    setPreview(null);
    setVerificationResult(null);
  };

  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="text-sm font-medium">
        {label} {required && <span className="text-destructive">*</span>}
      </Label>
      
      <div className={cn(
        "relative border-2 border-dashed rounded-lg transition-colors",
        error ? "border-destructive" : 
        verificationResult?.isValid === false ? "border-destructive bg-destructive/5" :
        verificationResult?.isValid === true ? "border-green-500 bg-green-50" : 
        "border-border hover:border-primary",
        "overflow-hidden"
      )}>
        {verifying ? (
          <div className="relative aspect-[3/2] bg-muted animate-pulse flex flex-col items-center justify-center gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
            <div className="text-sm font-medium">Verifying image...</div>
            <div className="text-xs text-muted-foreground">Using AI to validate document</div>
          </div>
        ) : preview ? (
          <div className="relative aspect-[3/2] group">
            <img
              src={preview}
              alt={label}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <button
                type="button"
                onClick={handleRemove}
                className="p-2 bg-background rounded-full hover:bg-destructive hover:text-destructive-foreground transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            {verificationResult && (
              <div className={cn(
                "absolute top-2 right-2 p-1.5 rounded-full",
                verificationResult.isValid ? "bg-green-500 text-white" : "bg-destructive text-destructive-foreground"
              )}>
                {verificationResult.isValid ? (
                  <CheckCircle className="w-4 h-4" />
                ) : (
                  <AlertCircle className="w-4 h-4" />
                )}
              </div>
            )}
          </div>
        ) : (
          <label
            htmlFor={id}
            className="flex flex-col items-center justify-center py-12 cursor-pointer hover:bg-muted/50 transition-colors"
          >
            <Upload className="w-10 h-10 text-muted-foreground mb-3" />
            <p className="text-sm font-medium text-foreground mb-1">
              Click to upload {label.toLowerCase()}
            </p>
            <p className="text-xs text-muted-foreground">
              PNG, JPG up to 5MB
            </p>
          </label>
        )}
        
        <input
          type="file"
          id={id}
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
      </div>
      
      {verificationResult && !verificationResult.isValid && (
        <p className="text-xs text-destructive mt-2">
          <AlertCircle className="w-3 h-3 inline mr-1" />
          {verificationResult.reason}
        </p>
      )}
      
      {error && (
        <p className="text-xs text-destructive mt-2">{error}</p>
      )}
    </div>
  );
};
