import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Clock, XCircle, Building2 } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import verifiedBadge from '@/assets/verified-badge.png';

interface VerificationStatusBannerProps {
  status: 'not_submitted' | 'pending' | 'approved' | 'rejected' | 'verified' | 'not_verified' | null;
  rejectionReason?: string | null;
  isLoading?: boolean;
  isVerified?: boolean;
  hasSellerProfile?: boolean;
  sellerType?: string | null;
  accountTier?: string | null;
}

export const VerificationStatusBanner: React.FC<VerificationStatusBannerProps> = ({
  status,
  rejectionReason,
  isLoading,
  isVerified,
  hasSellerProfile = true,
  sellerType = null,
  accountTier = null,
}) => {
  // Use account_tier to determine if business account
  const isBusinessAccount = accountTier === 'business' || accountTier === 'organization';
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <div className="p-4 bg-muted/50 border-b border-border">
        <div className="flex items-start gap-3">
          <Skeleton className="w-10 h-10 rounded-full" />
          <div className="flex-1 space-y-2">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-3 w-48" />
          </div>
        </div>
      </div>
    );
  }

  // Already verified via seller profile
  if (isVerified) {
    return (
      <div className="p-4 bg-[#1d9bf01a] border-b border-[#1d9bf033]">
        <div className="flex items-start gap-3">
          <img 
            src={verifiedBadge} 
            alt="Verified" 
            className="w-10 h-10 flex-shrink-0"
          />
          <div className="flex-1">
            <h3 className="font-bold text-[15px] text-foreground">You're Verified!</h3>
            <p className="text-[13px] text-muted-foreground mt-0.5">
              Enjoy all premium features including boosted visibility and trust badge.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Pending verification
  if (status === 'pending') {
    return (
      <div className="p-4 bg-amber-500/10 border-b border-amber-500/20">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-amber-500 flex items-center justify-center flex-shrink-0 animate-pulse">
            <Clock className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-[15px] text-foreground">Verification Pending</h3>
            <p className="text-[13px] text-muted-foreground mt-0.5">
              Your verification request is being reviewed. We'll notify you within 2-3 business days.
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Rejected verification
  if (status === 'rejected') {
    return (
      <div className="p-4 bg-red-500/10 border-b border-red-500/20">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-red-500 flex items-center justify-center flex-shrink-0">
            <XCircle className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-[15px] text-foreground">Verification Rejected</h3>
            {rejectionReason && (
              <p className="text-[13px] text-red-500 mt-0.5 mb-2">
                Reason: {rejectionReason}
              </p>
            )}
            <Button 
              size="sm" 
              className="rounded-full bg-foreground text-background hover:bg-foreground/90 font-bold px-4 h-8 text-sm" 
              onClick={() => navigate('/verification')}
            >
              Resubmit
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Regular user without business account - "Create Business Account" CTA
  if (!isBusinessAccount) {
    return (
      <div className="mx-3 mt-3 p-4 rounded-2xl border border-border relative overflow-hidden">
        {/* X.com style gradient background */}
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-primary/5 to-accent/10 rounded-2xl" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background/50 rounded-2xl" />
        
        <div className="relative flex items-start gap-3">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center flex-shrink-0 shadow-lg">
            <Building2 className="w-5 h-5 text-primary-foreground" />
          </div>
          <div className="flex-1">
            <h3 className="font-bold text-[15px] text-foreground">Start selling on EarlyMarket</h3>
            <p className="text-[13px] text-muted-foreground mt-0.5 mb-3">
              Create a business account to post products, services, and reach thousands of buyers.
            </p>
            <Button 
              size="sm" 
              className="rounded-full bg-foreground text-background hover:bg-foreground/90 font-bold px-4 h-8 text-sm" 
              onClick={() => navigate('/create-business-account')}
            >
              Create Business Account
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Seller without verification - X.com style "Get verified" CTA
  return (
    <div className="p-4 bg-[#1d9bf01a] border-b border-[#1d9bf033]">
      <div className="flex items-start gap-3">
        <img 
          src={verifiedBadge} 
          alt="Verified Badge" 
          className="w-10 h-10 flex-shrink-0"
        />
        <div className="flex-1">
          <h3 className="font-bold text-[15px] text-foreground">You aren't verified yet</h3>
          <p className="text-[13px] text-muted-foreground mt-0.5 mb-3">
            Get verified for boosted replies, analytics, ad-free browsing, and more.
          </p>
          <Button 
            size="sm" 
            className="rounded-full bg-foreground text-background hover:bg-foreground/90 font-bold px-4 h-8 text-sm" 
            onClick={() => navigate('/verification')}
          >
            Get verified
          </Button>
        </div>
      </div>
    </div>
  );
};