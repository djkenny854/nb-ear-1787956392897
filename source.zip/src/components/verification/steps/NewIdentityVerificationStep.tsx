import React, { useState, useEffect, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { 
  Upload, 
  CheckCircle2, 
  CreditCard,
  UserCircle,
  FileImage,
  AlertCircle,
  Loader2,
  Sparkles,
  X
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';

interface IdentityVerificationStepProps {
  onNext?: () => void;
  onBack?: () => void;
  formData?: any;
  onFormDataChange?: (data: any) => void;
  onValidationChange?: (isValid: boolean) => void;
}

// Shimmer loading animation component (ChatGPT-style)
const ShimmerOverlay = () => (
  <div className="absolute inset-0 overflow-hidden rounded-xl">
    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent shimmer-animation" />
    <div className="absolute inset-0 backdrop-blur-[2px] bg-primary/10" />
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
      <Sparkles className="w-6 h-6 text-primary animate-pulse" />
      <span className="text-xs font-medium text-primary">AI Verifying...</span>
    </div>
  </div>
);

const NewIdentityVerificationStep: React.FC<IdentityVerificationStepProps> = ({ 
  formData = {}, 
  onFormDataChange,
  onValidationChange
}) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [idType, setIdType] = useState<'passport' | 'national_id' | 'drivers_license' | null>(
    formData.idType || null
  );
  const [fullName, setFullName] = useState(formData.fullName || '');
  const [idNumber, setIdNumber] = useState(formData.idNumber || '');
  
  // Image states
  const [frontImage, setFrontImage] = useState<File | null>(formData.frontImage || null);
  const [frontPreview, setFrontPreview] = useState<string | null>(null);
  const [backImage, setBackImage] = useState<File | null>(formData.backImage || null);
  const [backPreview, setBackPreview] = useState<string | null>(null);
  const [selfieImage, setSelfieImage] = useState<File | null>(formData.selfieImage || null);
  const [selfiePreview, setSelfiePreview] = useState<string | null>(null);
  
  // Verification states
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationComplete, setVerificationComplete] = useState(false);
  const [verificationError, setVerificationError] = useState<string | null>(null);

  const idTypes = [
    { id: 'national_id' as const, label: 'National ID', icon: CreditCard },
    { id: 'passport' as const, label: 'Passport', icon: FileImage },
    { id: 'drivers_license' as const, label: "Driver's License", icon: CreditCard }
  ];

  const needsBackImage = idType && idType !== 'passport';
  const allImagesSelected = frontImage && selfieImage && (!needsBackImage || backImage);

  // Calculate if form is valid
  const isValid = idType && fullName.trim() && idNumber.trim() && verificationComplete;

  // Notify parent of validation changes
  useEffect(() => {
    if (onValidationChange) {
      onValidationChange(!!isValid);
    }
    
    if (onFormDataChange && (frontImage || selfieImage || fullName || idNumber || idType)) {
      onFormDataChange({
        ...formData,
        idType,
        fullName,
        idNumber,
        frontImage,
        backImage: needsBackImage ? backImage : null,
        selfieImage,
        extractedData: { idNumber, fullName }
      });
    }
  }, [isValid, idType, fullName, idNumber, frontImage, backImage, selfieImage, verificationComplete]);

  // Auto-verify when all images are selected
  useEffect(() => {
    if (allImagesSelected && !isVerifying && !verificationComplete) {
      handleBatchVerify();
    }
  }, [frontImage, backImage, selfieImage, idType]);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result.split(',')[1]);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const handleBatchVerify = async () => {
    if (!allImagesSelected) return;
    
    setIsVerifying(true);
    setVerificationError(null);

    try {
      const frontBase64 = await fileToBase64(frontImage!);
      const selfieBase64 = await fileToBase64(selfieImage!);
      
      // Verify front image
      const { data: frontResult, error: frontError } = await supabase.functions.invoke('verify-id-image', {
        body: { imageBase64: frontBase64, imageType: 'id_front', selectedIdType: idType }
      });
      
      if (frontError || !frontResult?.isValid) {
        throw new Error(frontResult?.reason || 'Front ID verification failed');
      }

      // Auto-fill extracted data
      if (frontResult.extractedData) {
        if (frontResult.extractedData.fullName && !fullName) {
          setFullName(frontResult.extractedData.fullName);
        }
        if (frontResult.extractedData.idNumber && !idNumber) {
          setIdNumber(frontResult.extractedData.idNumber);
        }
      }

      // Verify back image if needed
      if (needsBackImage && backImage) {
        const backBase64 = await fileToBase64(backImage);
        const { data: backResult, error: backError } = await supabase.functions.invoke('verify-id-image', {
          body: { imageBase64: backBase64, imageType: 'id_back', selectedIdType: idType }
        });
        
        if (backError || !backResult?.isValid) {
          throw new Error(backResult?.reason || 'Back ID verification failed');
        }
      }

      // Verify selfie
      const { data: selfieResult, error: selfieError } = await supabase.functions.invoke('verify-id-image', {
        body: { imageBase64: selfieBase64, imageType: 'selfie' }
      });
      
      if (selfieError || !selfieResult?.isValid) {
        throw new Error(selfieResult?.reason || 'Selfie verification failed');
      }

      setVerificationComplete(true);
      toast({ title: 'Documents verified', description: 'All images have been verified successfully!' });
    } catch (error: any) {
      setVerificationError(error.message);
      toast({ title: 'Verification failed', description: error.message, variant: 'destructive' });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleImageSelect = (file: File | null, type: 'front' | 'back' | 'selfie') => {
    if (!file) return;
    
    setVerificationComplete(false);
    setVerificationError(null);

    const reader = new FileReader();
    reader.onload = () => {
      const preview = reader.result as string;
      if (type === 'front') {
        setFrontImage(file);
        setFrontPreview(preview);
      } else if (type === 'back') {
        setBackImage(file);
        setBackPreview(preview);
      } else {
        setSelfieImage(file);
        setSelfiePreview(preview);
      }
    };
    reader.readAsDataURL(file);
  };

  const clearImage = (type: 'front' | 'back' | 'selfie') => {
    setVerificationComplete(false);
    if (type === 'front') {
      setFrontImage(null);
      setFrontPreview(null);
    } else if (type === 'back') {
      setBackImage(null);
      setBackPreview(null);
    } else {
      setSelfieImage(null);
      setSelfiePreview(null);
    }
  };

  // Compact horizontal upload box component
  const UploadBox = ({ 
    type, 
    label, 
    icon: Icon, 
    image, 
    preview 
  }: { 
    type: 'front' | 'back' | 'selfie'; 
    label: string; 
    icon: any; 
    image: File | null; 
    preview: string | null;
  }) => (
    <div className="relative">
      <input
        type="file"
        accept="image/*"
        onChange={(e) => e.target.files && handleImageSelect(e.target.files[0], type)}
        className="hidden"
        id={`${type}-upload`}
      />
      <label
        htmlFor={`${type}-upload`}
        className={cn(
          'flex items-center gap-3 p-3 rounded-xl cursor-pointer transition-all',
          'border-2 hover:border-primary/50 hover:bg-accent/30',
          image && verificationComplete ? 'border-green-500 bg-green-50 dark:bg-green-950/20' : 
          image && verificationError ? 'border-red-500 bg-red-50 dark:bg-red-950/20' :
          image ? 'border-primary/50 bg-primary/5' : 'border-border bg-muted/30'
        )}
      >
        {/* Thumbnail or Icon */}
        <div className={cn(
          'relative w-14 h-14 rounded-lg overflow-hidden flex-shrink-0 flex items-center justify-center',
          !preview && 'bg-muted'
        )}>
          {preview ? (
            <>
              <img src={preview} alt={label} className="w-full h-full object-cover" />
              {isVerifying && <ShimmerOverlay />}
            </>
          ) : (
            <Icon className="w-6 h-6 text-muted-foreground" />
          )}
        </div>

        {/* Label and Status */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-sm truncate">{label}</span>
            {image && verificationComplete && (
              <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
            )}
          </div>
          <p className="text-xs text-muted-foreground truncate">
            {image ? image.name : 'Tap to upload'}
          </p>
        </div>

        {/* Remove button */}
        {image && !isVerifying && (
          <button
            type="button"
            onClick={(e) => { e.preventDefault(); clearImage(type); }}
            className="p-1.5 rounded-full hover:bg-muted transition-colors"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        )}
      </label>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Header - Google Workspace inspired */}
      <div className="hidden sm:block">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 rounded-lg bg-primary/10">
            <UserCircle className="w-6 h-6 text-primary" />
          </div>
          <h2 className="text-2xl font-semibold">Identity Verification</h2>
        </div>
        <p className="text-muted-foreground text-sm">
          Upload your documents below. AI will verify them automatically.
        </p>
      </div>

      {/* ID Type Selection - Clean pills */}
      <div>
        <Label className="text-sm font-medium mb-3 block">Document Type</Label>
        <div className="flex flex-wrap gap-2">
          {idTypes.map((type) => (
            <button
              key={type.id}
              type="button"
              onClick={() => {
                setIdType(type.id);
                setVerificationComplete(false);
                setBackImage(null);
                setBackPreview(null);
              }}
              className={cn(
                'flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all',
                idType === type.id 
                  ? 'bg-primary text-primary-foreground shadow-md' 
                  : 'bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground'
              )}
            >
              <type.icon className="w-4 h-4" />
              {type.label}
            </button>
          ))}
        </div>
      </div>

      {/* Personal Information - Clean inputs */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div>
          <Label htmlFor="full-name" className="text-sm mb-1.5 block">Full Name</Label>
          <Input
            id="full-name"
            value={fullName}
            onChange={(e) => setFullName(e.target.value)}
            placeholder="As shown on ID"
            className="h-11"
          />
        </div>
        <div>
          <Label htmlFor="id-number" className="text-sm mb-1.5 block">ID Number</Label>
          <Input
            id="id-number"
            value={idNumber}
            onChange={(e) => setIdNumber(e.target.value)}
            placeholder="Enter ID number"
            className="h-11"
          />
        </div>
      </div>

      {/* Document Upload - Horizontal compact boxes */}
      {idType && (
        <div className="space-y-3">
          <Label className="text-sm font-medium block">Upload Documents</Label>
          
          <div className="grid gap-3">
            <UploadBox 
              type="front" 
              label={idType === 'passport' ? 'Passport Photo Page' : 'ID Front'} 
              icon={CreditCard}
              image={frontImage}
              preview={frontPreview}
            />
            
            {needsBackImage && (
              <UploadBox 
                type="back" 
                label="ID Back" 
                icon={CreditCard}
                image={backImage}
                preview={backPreview}
              />
            )}
            
            <UploadBox 
              type="selfie" 
              label="Your Selfie" 
              icon={UserCircle}
              image={selfieImage}
              preview={selfiePreview}
            />
          </div>

          {/* Auto-verify indicator */}
          <AnimatePresence>
            {allImagesSelected && !verificationComplete && !isVerifying && (
              <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="flex items-center justify-center gap-2 py-3"
              >
                <Loader2 className="w-4 h-4 animate-spin text-primary" />
                <span className="text-sm text-muted-foreground">Starting AI verification...</span>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      {/* Verification Error */}
      {verificationError && (
        <div className="flex items-start gap-3 p-4 rounded-xl bg-destructive/10 border border-destructive/20">
          <AlertCircle className="w-5 h-5 text-destructive flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium text-sm text-destructive">Verification Failed</p>
            <p className="text-xs text-destructive/80 mt-1">{verificationError}</p>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={handleBatchVerify}
              className="mt-3"
              disabled={isVerifying}
            >
              {isVerifying ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              Retry Verification
            </Button>
          </div>
        </div>
      )}

      {/* Success State */}
      {verificationComplete && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex items-center gap-3 p-4 rounded-xl bg-green-50 dark:bg-green-950/20 border border-green-200 dark:border-green-800"
        >
          <CheckCircle2 className="w-6 h-6 text-green-600" />
          <div>
            <p className="font-medium text-sm text-green-900 dark:text-green-100">Documents Verified</p>
            <p className="text-xs text-green-700 dark:text-green-300">You can now proceed to the next step.</p>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default NewIdentityVerificationStep;