import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Upload, 
  FileText, 
  CheckCircle2, 
  AlertCircle,
  CreditCard,
  Shield
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface IdentityVerificationStepProps {
  onNext?: () => void;
  onBack?: () => void;
}

const IdentityVerificationStep: React.FC<IdentityVerificationStepProps> = ({ onNext }) => {
  const [idType, setIdType] = useState<'passport' | 'national_id' | 'drivers_license' | null>(null);
  const [frontUploaded, setFrontUploaded] = useState(false);
  const [backUploaded, setBackUploaded] = useState(false);
  const [selfieUploaded, setSelfieUploaded] = useState(false);

  const idTypes = [
    {
      id: 'national_id' as const,
      label: 'National ID',
      icon: CreditCard,
      description: 'Government-issued ID card'
    },
    {
      id: 'passport' as const,
      label: 'Passport',
      icon: FileText,
      description: 'International passport'
    },
    {
      id: 'drivers_license' as const,
      label: "Driver's License",
      icon: Shield,
      description: 'Valid driving license'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="hidden sm:block">
        <h2 className="text-2xl font-bold mb-2">Identity Verification</h2>
        <p className="text-muted-foreground">
          We need to verify your identity to ensure platform security and trust
        </p>
      </div>

      {/* ID Type Selection */}
      <div>
        <Label className="text-base font-semibold mb-3 block">Select Document Type</Label>
        <div className="grid sm:grid-cols-3 gap-3">
          {idTypes.map((type) => (
            <Card
              key={type.id}
              onClick={() => setIdType(type.id)}
              className={cn(
                'p-4 cursor-pointer transition-all hover:shadow-md',
                idType === type.id 
                  ? 'border-2 border-primary bg-primary/5' 
                  : 'border-2 border-transparent hover:border-primary/30'
              )}
            >
              <div className="flex flex-col items-center text-center gap-2">
                <div className={cn(
                  'p-3 rounded-full',
                  idType === type.id ? 'bg-primary text-primary-foreground' : 'bg-muted'
                )}>
                  <type.icon className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-semibold">{type.label}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {type.description}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Document Upload */}
      {idType && (
        <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-300">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-900">
                <p className="font-medium mb-1">Document Requirements:</p>
                <ul className="list-disc list-inside space-y-1 text-xs">
                  <li>Document must be valid and not expired</li>
                  <li>Images must be clear and readable</li>
                  <li>All corners of the document must be visible</li>
                  <li>Maximum file size: 5MB per image</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Front Side */}
          <div>
            <Label className="text-sm font-medium mb-2 block">
              Front Side of {idTypes.find(t => t.id === idType)?.label}
            </Label>
            <div className={cn(
              'border-2 border-dashed rounded-lg p-6 sm:p-8 text-center transition-all',
              frontUploaded 
                ? 'border-green-500 bg-green-50' 
                : 'border-muted-foreground/25 hover:border-primary/50 cursor-pointer'
            )}>
              <input
                type="file"
                id="front-upload"
                className="hidden"
                accept="image/*"
                onChange={(e) => e.target.files?.[0] && setFrontUploaded(true)}
              />
              <label htmlFor="front-upload" className="cursor-pointer">
                {frontUploaded ? (
                  <div className="text-green-600">
                    <CheckCircle2 className="w-12 h-12 mx-auto mb-3" />
                    <p className="font-medium">Front side uploaded</p>
                    <p className="text-sm mt-1">Click to change</p>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-12 h-12 mx-auto mb-3 text-muted-foreground" />
                    <p className="font-medium text-foreground">Upload front side</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Click to browse or drag and drop
                    </p>
                  </div>
                )}
              </label>
            </div>
          </div>

          {/* Back Side */}
          {idType !== 'passport' && (
            <div>
              <Label className="text-sm font-medium mb-2 block">
                Back Side of {idTypes.find(t => t.id === idType)?.label}
              </Label>
              <div className={cn(
                'border-2 border-dashed rounded-lg p-6 sm:p-8 text-center transition-all',
                backUploaded 
                  ? 'border-green-500 bg-green-50' 
                  : 'border-muted-foreground/25 hover:border-primary/50 cursor-pointer'
              )}>
                <input
                  type="file"
                  id="back-upload"
                  className="hidden"
                  accept="image/*"
                  onChange={(e) => e.target.files?.[0] && setBackUploaded(true)}
                />
                <label htmlFor="back-upload" className="cursor-pointer">
                  {backUploaded ? (
                    <div className="text-green-600">
                      <CheckCircle2 className="w-12 h-12 mx-auto mb-3" />
                      <p className="font-medium">Back side uploaded</p>
                      <p className="text-sm mt-1">Click to change</p>
                    </div>
                  ) : (
                    <div>
                      <Upload className="w-12 h-12 mx-auto mb-3 text-muted-foreground" />
                      <p className="font-medium text-foreground">Upload back side</p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Click to browse or drag and drop
                      </p>
                    </div>
                  )}
                </label>
              </div>
            </div>
          )}

          {/* Selfie Verification */}
          <div>
            <Label className="text-sm font-medium mb-2 block">
              Selfie with ID (Optional but Recommended)
            </Label>
            <div className={cn(
              'border-2 border-dashed rounded-lg p-6 sm:p-8 text-center transition-all',
              selfieUploaded 
                ? 'border-green-500 bg-green-50' 
                : 'border-muted-foreground/25 hover:border-primary/50 cursor-pointer'
            )}>
              <input
                type="file"
                id="selfie-upload"
                className="hidden"
                accept="image/*"
                onChange={(e) => e.target.files?.[0] && setSelfieUploaded(true)}
              />
              <label htmlFor="selfie-upload" className="cursor-pointer">
                {selfieUploaded ? (
                  <div className="text-green-600">
                    <CheckCircle2 className="w-12 h-12 mx-auto mb-3" />
                    <p className="font-medium">Selfie uploaded</p>
                    <p className="text-sm mt-1">Click to change</p>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-12 h-12 mx-auto mb-3 text-muted-foreground" />
                    <p className="font-medium text-foreground">Upload selfie holding ID</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      This speeds up verification
                    </p>
                  </div>
                )}
              </label>
            </div>
          </div>

          {/* Personal Information */}
          <div className="grid sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="full-name">Full Name (as on ID)</Label>
              <Input id="full-name" placeholder="John Doe" className="mt-2" />
            </div>
            <div>
              <Label htmlFor="id-number">ID Number</Label>
              <Input id="id-number" placeholder="Enter ID number" className="mt-2" />
            </div>
            <div>
              <Label htmlFor="date-of-birth">Date of Birth</Label>
              <Input id="date-of-birth" type="date" className="mt-2" />
            </div>
            <div>
              <Label htmlFor="nationality">Nationality</Label>
              <Input id="nationality" placeholder="e.g., Ugandan" className="mt-2" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default IdentityVerificationStep;
