import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { TermsModal } from '../TermsModal';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { 
  CheckCircle2, 
  Shield,
  FileText,
  AlertCircle,
  Star,
  Clock,
  ExternalLink,
  Loader2,
  PartyPopper,
  Bell
} from 'lucide-react';
import {
  Dialog,
  DialogContent,
} from '@/components/ui/dialog';
import { motion } from 'framer-motion';

interface ReviewSubmitStepProps {
  onNext?: () => void;
  onBack?: () => void;
  formData?: any;
  onFormDataChange?: (data: any) => void;
  onComplete?: () => void;
}

const ReviewSubmitStep: React.FC<ReviewSubmitStepProps> = ({ formData = {}, onComplete }) => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [agreedToDataUse, setAgreedToDataUse] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);

  const uploadImage = async (file: File, path: string): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${path}-${Date.now()}.${fileExt}`;
      const filePath = `verification/${user?.id}/${fileName}`;

      const { error: uploadError } = await supabase.storage
        .from('verification-documents')
        .upload(filePath, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('verification-documents')
        .getPublicUrl(filePath);

      return data.publicUrl;
    } catch (error) {
      console.error('Upload error:', error);
      return null;
    }
  };

  const handleSubmit = async () => {
    if (!agreedToTerms || !agreedToDataUse) {
      toast({
        title: "Agreement Required",
        description: "Please agree to all terms before submitting.",
        variant: "destructive",
      });
      return;
    }

    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please log in to submit your verification.",
        variant: "destructive",
      });
      return;
    }

    // Verify identity documents are present
    if (!formData.frontImage || !formData.selfieImage) {
      toast({
        title: "Missing Documents",
        description: "Please complete the identity verification step first.",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    
    try {
      // Upload identity documents
      const frontUrl = await uploadImage(formData.frontImage, 'id-front');
      const backUrl = formData.backImage ? await uploadImage(formData.backImage, 'id-back') : null;
      const selfieUrl = await uploadImage(formData.selfieImage, 'selfie');

      if (!frontUrl || !selfieUrl) {
        throw new Error('Failed to upload documents');
      }

      // Check if user already has a verification request
      const { data: existingRequest, error: existingError } = await supabase
        .from('verification_requests')
        .select('id, status')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (existingError) throw existingError;

      // If a request is already pending, don't attempt an update (RLS blocks it)
      if (existingRequest?.status === 'pending') {
        toast({
          title: 'Already submitted',
          description: 'Your verification is already pending review. Please wait for a decision before submitting again.',
        });
        setShowSuccessModal(true);
        return;
      }

      // Prepare the verification data with extracted info
      // Note: gender must be one of 'male', 'female', 'other' per database constraint
      const validGender = ['male', 'female', 'other'].includes(formData.gender) 
        ? formData.gender 
        : 'other';
      
      const verificationData = {
        full_name: formData.fullName || 'Not provided',
        date_of_birth: formData.dateOfBirth || '1990-01-01',
        gender: validGender,
        district: formData.district || 'Not specified',
        phone_number: formData.phoneNumber || 'Not provided',
        national_id_front_url: frontUrl,
        national_id_back_url: backUrl || frontUrl,
        selfie_url: selfieUrl,
        status: 'pending',
        id_type: formData.idType || 'national_id',
        extracted_id_number: formData.idNumber || null,
      };

      if (existingRequest && ['not_verified', 'rejected'].includes(existingRequest.status)) {
        // Update existing request (allowed by RLS only for not_verified/rejected)
        const { error: updateError } = await supabase
          .from('verification_requests')
          .update({
            ...verificationData,
            updated_at: new Date().toISOString(),
          })
          .eq('id', existingRequest.id);

        if (updateError) throw updateError;
      } else if (existingRequest && existingRequest.status === 'approved') {
        toast({
          title: 'Already verified',
          description: 'Your account is already verified. No further action is required.',
        });
        setShowSuccessModal(true);
        return;
      } else {
        // Create new verification request
        const { error: insertError } = await supabase
          .from('verification_requests')
          .insert({
            user_id: user.id,
            ...verificationData,
          });

        if (insertError) throw insertError;
      }

      // Show success modal instead of just toast
      setShowSuccessModal(true);
    } catch (error) {
      console.error('Submission error:', error);
      toast({
        title: "Submission Failed",
        description: error instanceof Error ? error.message : "Failed to submit verification. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const canSubmit = agreedToTerms && agreedToDataUse && !isSubmitting;
  const hasIdentityDocs = formData.frontImage && formData.selfieImage;

  return (
    <div className="space-y-6">
      <div className="hidden sm:block">
        <h2 className="text-2xl font-bold mb-2">Review & Submit</h2>
        <p className="text-muted-foreground">
          Review your application before submitting for verification
        </p>
      </div>

      {/* Application Summary */}
      <Card className={`p-6 ${hasIdentityDocs ? 'bg-gradient-to-br from-green-50 to-emerald-50 border-green-200' : 'bg-gradient-to-br from-amber-50 to-orange-50 border-amber-200'}`}>
        <div className="flex items-start gap-4">
          <div className={`p-3 rounded-full ${hasIdentityDocs ? 'bg-green-500' : 'bg-amber-500'} text-white`}>
            {hasIdentityDocs ? <CheckCircle2 className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
          </div>
          <div className="flex-1">
            <h3 className={`font-bold text-lg mb-2 ${hasIdentityDocs ? 'text-green-900' : 'text-amber-900'}`}>
              {hasIdentityDocs ? 'Application Complete!' : 'Identity Documents Required'}
            </h3>
            <p className={`text-sm mb-4 ${hasIdentityDocs ? 'text-green-800' : 'text-amber-800'}`}>
              {hasIdentityDocs 
                ? "You've completed all required sections. Review your information below before submitting."
                : "Please go back and complete the identity verification step before submitting."}
            </p>
            
            <div className="grid sm:grid-cols-3 gap-4">
              <div className={`${hasIdentityDocs ? 'bg-white/50' : 'bg-white/30'} rounded-lg p-3`}>
                <div className="flex items-center gap-2 mb-1">
                  <Shield className={`w-4 h-4 ${hasIdentityDocs ? 'text-green-600' : 'text-amber-600'}`} />
                  <span className={`text-xs font-medium ${hasIdentityDocs ? 'text-green-900' : 'text-amber-900'}`}>Identity</span>
                </div>
                <p className={`text-xs ${hasIdentityDocs ? 'text-green-700' : 'text-amber-700'}`}>
                  {hasIdentityDocs ? 'Documents uploaded' : 'Documents required'}
                </p>
              </div>
              <div className="bg-white/50 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <FileText className="w-4 h-4 text-green-600" />
                  <span className="text-xs font-medium text-green-900">Business</span>
                </div>
                <p className="text-xs text-green-700">Optional - provided</p>
              </div>
              <div className="bg-white/50 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Star className="w-4 h-4 text-green-600" />
                  <span className="text-xs font-medium text-green-900">Quality</span>
                </div>
                <p className="text-xs text-green-700">Standards reviewed</p>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* What Happens Next */}
      <Card className="p-6">
        <h3 className="font-bold text-lg mb-4 flex items-center gap-2">
          <Clock className="w-5 h-5 text-primary" />
          What Happens Next?
        </h3>
        
        <div className="space-y-4">
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
              1
            </div>
            <div>
              <h4 className="font-semibold mb-1">Application Review</h4>
              <p className="text-sm text-muted-foreground">
                Our team will review your documents and information within 2-3 business days
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
              2
            </div>
            <div>
              <h4 className="font-semibold mb-1">Quality Check</h4>
              <p className="text-sm text-muted-foreground">
                We'll verify your account meets all quality standards and requirements
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold">
              3
            </div>
            <div>
              <h4 className="font-semibold mb-1">Verification Badge</h4>
              <p className="text-sm text-muted-foreground">
                Once approved, you'll receive your verified badge and unlock all premium features
              </p>
            </div>
          </div>
        </div>
      </Card>

      {/* Verification Benefits Reminder */}
      <Card className="p-6 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950/30 dark:to-cyan-950/30 border-blue-200 dark:border-blue-800">
        <h3 className="font-bold text-lg mb-3 text-blue-900 dark:text-blue-100">Your Verification Benefits:</h3>
        <div className="grid sm:grid-cols-2 gap-3">
          {[
            'Verified badge on your profile',
            'Priority in search results',
            'Access to premium features',
            'Enhanced buyer trust',
            'Advanced analytics dashboard',
            'Priority customer support',
            'Featured seller status'
          ].map((benefit, idx) => (
            <div key={idx} className="flex items-start gap-2 text-sm text-blue-900 dark:text-blue-100">
              <CheckCircle2 className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
              <span>{benefit}</span>
            </div>
          ))}
        </div>
      </Card>

      {/* Terms and Agreements */}
      <Card className="p-6">
        <h3 className="font-bold mb-4">Terms & Agreements</h3>
        
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <Checkbox 
              id="terms"
              checked={agreedToTerms}
              onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
              className="mt-1"
            />
            <div className="flex-1">
              <label htmlFor="terms" className="text-sm leading-relaxed cursor-pointer">
                I have read and agree to the{" "}
                <Button
                  variant="link"
                  className="h-auto p-0 text-primary underline"
                  onClick={() => setShowTermsModal(true)}
                >
                  Verification Terms & Conditions
                  <ExternalLink className="w-3 h-3 ml-1 inline" />
                </Button>
                . I confirm that all information provided is accurate and understand that false 
                information may result in account suspension.
              </label>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <Checkbox 
              id="data-use"
              checked={agreedToDataUse}
              onCheckedChange={(checked) => setAgreedToDataUse(checked as boolean)}
              className="mt-1"
            />
            <label 
              htmlFor="data-use"
              className="text-sm cursor-pointer flex-1"
            >
              I authorize EarlyMarket to verify my documents and information with relevant authorities and agree to the processing of my personal data for verification purposes.
            </label>
          </div>
        </div>
      </Card>

      {/* Warning */}
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
        <div className="flex gap-3">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-amber-900">
            <p className="font-medium mb-1">Important:</p>
            <ul className="list-disc list-inside space-y-1 text-xs">
              <li>You'll receive a notification about your verification status</li>
              <li>If additional information is needed, we'll contact you</li>
              <li>Your account remains fully functional during the review process</li>
              <li>Verification typically takes 2-3 business days</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Submit Button */}
      <Button 
        onClick={handleSubmit}
        disabled={!canSubmit || !hasIdentityDocs}
        className="w-full py-6 text-lg"
        size="lg"
      >
        {isSubmitting ? (
          <>
            <Loader2 className="w-5 h-5 mr-2 animate-spin" />
            Submitting Application...
          </>
        ) : (
          'Submit Verification Application'
        )}
      </Button>

      <TermsModal open={showTermsModal} onOpenChange={setShowTermsModal} />
      
      {/* Success Modal */}
      <Dialog open={showSuccessModal} onOpenChange={setShowSuccessModal}>
        <DialogContent className="sm:max-w-md">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="text-center py-6"
          >
            <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
              <PartyPopper className="w-10 h-10 text-white" />
            </div>
            
            <h2 className="text-2xl font-bold mb-2 bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Application Submitted!
            </h2>
            
            <p className="text-muted-foreground mb-6">
              Your verification request has been submitted successfully. Our team will review your documents.
            </p>
            
            <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl p-4 mb-6">
              <div className="flex items-center gap-3 text-left">
                <div className="p-2 bg-blue-500 rounded-lg text-white shrink-0">
                  <Bell className="w-5 h-5" />
                </div>
                <div>
                  <p className="font-semibold text-blue-900 dark:text-blue-100 text-sm">You'll be notified</p>
                  <p className="text-xs text-blue-700 dark:text-blue-300">
                    We'll send you a notification when your verification is reviewed. Check your notifications regularly.
                  </p>
                </div>
              </div>
            </div>
            
            <div className="space-y-3 text-left bg-muted/50 rounded-lg p-4 mb-6">
              <div className="flex items-center gap-2 text-sm">
                <Clock className="w-4 h-4 text-primary" />
                <span>Review takes <strong>2-3 business days</strong></span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <span>Your account remains fully functional</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Shield className="w-4 h-4 text-blue-600" />
                <span>Documents are securely stored</span>
              </div>
            </div>
            
            <Button 
              onClick={() => {
                setShowSuccessModal(false);
                if (onComplete) onComplete();
              }}
              className="w-full"
              size="lg"
            >
              Done
            </Button>
          </motion.div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ReviewSubmitStep;
