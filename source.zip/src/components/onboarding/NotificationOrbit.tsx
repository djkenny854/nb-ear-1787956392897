import React from 'react';
import { Bell, MessageCircle, Heart, ShoppingBag, MapPin, type LucideIcon } from 'lucide-react';

// Circular composition of icons around a central bell, echoing the Play Store
// "verify purchases" illustration.
const NotificationOrbit: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={`relative aspect-square w-full max-w-[280px] mx-auto ${className ?? ''}`}>
      {/* Dashed ring */}
      <svg viewBox="0 0 200 200" className="absolute inset-0 w-full h-full">
        <circle cx="100" cy="100" r="88" fill="none" stroke="hsl(var(--border))" strokeWidth="1" strokeDasharray="2 4" />
        {/* Blue arc top-left */}
        <path d="M 100 12 A 88 88 0 0 0 12 100" fill="none" stroke="#3076F8" strokeWidth="3" strokeLinecap="round" />
        {/* Pink arc bottom-right */}
        <path d="M 100 188 A 88 88 0 0 0 188 100" fill="none" stroke="#DC63CC" strokeWidth="3" strokeLinecap="round" />
      </svg>

      {/* Center bell */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-20 h-20 rounded-full bg-[#3076F8] flex items-center justify-center shadow-lg shadow-[#3076F8]/30">
          <Bell className="w-9 h-9 text-white" strokeWidth={2} />
        </div>
      </div>

      {/* Orbiting mini icons */}
      <OrbitIcon style={{ top: '4%', left: '10%' }} color="#DC63CC" Icon={Heart} />
      <OrbitIcon style={{ top: '10%', right: '4%' }} color="#FC9D3F" Icon={MessageCircle} />
      <OrbitIcon style={{ bottom: '6%', left: '4%' }} color="#3076F8" Icon={ShoppingBag} />
      <OrbitIcon style={{ bottom: '2%', right: '12%' }} color="#22c55e" Icon={MapPin} />

      {/* Decorative dots */}
      <span className="absolute top-[40%] left-[-2%] w-2 h-2 rounded-full bg-[#FC9D3F]" />
      <span className="absolute top-[8%] right-[38%] w-1.5 h-1.5 rounded-full border border-[#3076F8]" />
      <span className="absolute bottom-[36%] right-[-2%] w-2.5 h-2.5 rounded-full bg-[#DC63CC]/70" />
    </div>
  );
};

const OrbitIcon: React.FC<{
  style: React.CSSProperties;
  color: string;
  Icon: LucideIcon;
}> = ({ style, color, Icon }) => (
  <div
    className="absolute w-11 h-11 rounded-full flex items-center justify-center shadow-md"
    style={{ backgroundColor: `${color}22`, ...style }}
  >
    <Icon className="w-5 h-5" strokeWidth={2} />
  </div>
);

export default NotificationOrbit;