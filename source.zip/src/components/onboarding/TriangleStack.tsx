import React from 'react';

// Google Play-inspired: overlapping rounded triangles in different shapes,
// orientations and sizes. Corners are heavily rounded (blob-like) and the
// triangles are not aligned on a baseline.
// Palette per brand direction:
//   Orange   #FC9D3F
//   Rose     #EE668A
//   Blue     #3076F8
//   Lavender #DC63CC
const TriangleStack: React.FC<{ className?: string }> = ({ className }) => {
  return (
    <div className={className}>
      <svg viewBox="0 0 320 240" className="w-full h-full" aria-hidden>
        <g style={{ mixBlendMode: 'multiply' as React.CSSProperties['mixBlendMode'] }}>
          {/* Orange — left, right-angle-ish, tilted */}
          <path
            d="M22 176 Q10 188 26 196 L188 214 Q206 214 196 198 L70 78 Q58 66 50 82 Z"
            fill="#FC9D3F"
            transform="rotate(-6 110 150)"
          />
          {/* Rose — big central, pointing down, rotated */}
          <path
            d="M64 40 Q80 22 100 40 L246 132 Q266 148 244 162 L128 208 Q104 218 96 196 L58 68 Q52 50 64 40 Z"
            fill="#EE668A"
            transform="rotate(8 160 120)"
          />
          {/* Blue — small acute, tucked in the middle */}
          <path
            d="M118 78 Q108 68 120 60 L184 78 Q200 84 190 96 L148 130 Q134 140 130 124 Z"
            fill="#3076F8"
            transform="rotate(-18 150 100)"
          />
          {/* Lavender — right, isosceles pointing left */}
          <path
            d="M300 60 Q316 54 314 74 L306 194 Q304 214 288 202 L196 138 Q180 128 194 116 Z"
            fill="#DC63CC"
            transform="rotate(12 260 130)"
          />
        </g>
      </svg>
    </div>
  );
};

export default TriangleStack;
