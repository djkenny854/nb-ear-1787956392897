import React, { useCallback, useMemo, useState } from 'react';
import { motion, AnimatePresence, PanInfo } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { ONBOARDING_VERSION } from '@/constants/appVersion';
import { isRealNativeRuntime, isCapacitorNative } from '@/hooks/useCapacitor';
import WelcomeScreen from './screens/WelcomeScreen';
import PersonalizeScreen, { CATEGORY_OPTIONS } from './screens/PersonalizeScreen';
import NotificationsScreen from './screens/NotificationsScreen';
import ReadyScreen from './screens/ReadyScreen';

interface Props { onFinish: () => void }

const SWIPE = 60;

const PostAuthOnboarding: React.FC<Props> = ({ onFinish }) => {
  const { user } = useAuth();
  const [index, setIndex] = useState(0);
  const [dir, setDir] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(
    () => new Set(CATEGORY_OPTIONS.map((c) => c.slug))
  );
  const [saving, setSaving] = useState(false);

  const totalSteps = 4;

  const toggle = useCallback((slug: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(slug)) next.delete(slug); else next.add(slug);
      return next;
    });
  }, []);

  const goTo = useCallback((next: number) => {
    if (next < 0 || next >= totalSteps) return;
    setDir(next > index ? 1 : -1);
    setIndex(next);
  }, [index]);

  const persistCategories = useCallback(async () => {
    if (!user) return;
    try {
      await supabase
        .from('profiles')
        .update({ feed_categories: Array.from(selected) })
        .eq('id', user.id);
    } catch (err) {
      console.warn('[Onboarding] failed to save feed categories', err);
    }
  }, [user, selected]);

  const finish = useCallback(async () => {
    if (saving) return;
    setSaving(true);
    try {
      if (user) {
        await supabase
          .from('profiles')
          .update({
            feed_categories: Array.from(selected),
            onboarding_completed_version: ONBOARDING_VERSION,
          })
          .eq('id', user.id);
      }
      localStorage.setItem('earlymarket_onboarding_v2_completed', ONBOARDING_VERSION);
    } catch (err) {
      console.warn('[Onboarding] failed to persist completion', err);
    } finally {
      setSaving(false);
      onFinish();
    }
  }, [user, selected, saving, onFinish]);

  const requestNotifications = useCallback(async () => {
    try {
      if (isRealNativeRuntime()) {
        const mod = await import('@capacitor/push-notifications').catch(() => null);
        if (mod?.PushNotifications) {
          const perm = await mod.PushNotifications.requestPermissions();
          if (perm.receive === 'granted') {
            await mod.PushNotifications.register();
            toast.success('Notifications enabled');
          } else {
            toast('You can enable notifications later in Settings');
          }
        }
      } else if ('Notification' in window) {
        const result = await Notification.requestPermission();
        if (result === 'granted') toast.success('Notifications enabled');
      }
    } catch (err) {
      console.warn('[Onboarding] notif permission failed', err);
    } finally {
      goTo(index + 1);
    }
  }, [index, goTo]);

  const onDragEnd = useCallback((_: unknown, info: PanInfo) => {
    if (Math.abs(info.offset.x) > SWIPE) {
      if (info.offset.x < 0) goTo(index + 1);
      else goTo(index - 1);
    }
  }, [index, goTo]);

  const screens = useMemo(() => [
    <WelcomeScreen key="w" />,
    <PersonalizeScreen key="p" selected={selected} onToggle={toggle} />,
    <NotificationsScreen key="n" />,
    <ReadyScreen key="r" />,
  ], [selected, toggle]);

  const variants = {
    enter: (d: number) => ({ x: d > 0 ? '100%' : '-100%', opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (d: number) => ({ x: d > 0 ? '-100%' : '100%', opacity: 0 }),
  };

  return (
    <div
      className="fixed inset-0 z-[100] bg-background text-foreground flex flex-col"
      style={{ paddingTop: 'env(safe-area-inset-top)' }}
    >
      {/* Slides */}
      <div className="relative flex-1 overflow-hidden">
        <AnimatePresence initial={false} custom={dir} mode="wait">
          <motion.div
            key={index}
            custom={dir}
            variants={variants}
            initial="enter"
            animate="center"
            exit="exit"
            transition={{ type: 'spring', stiffness: 320, damping: 32 }}
            drag="x"
            dragConstraints={{ left: 0, right: 0 }}
            dragElastic={0.18}
            onDragEnd={onDragEnd}
            className="absolute inset-0 touch-pan-y"
          >
            {screens[index]}
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Bottom action bar */}
      <div
        className="border-t border-border/60 bg-background/95 backdrop-blur px-6 pt-4"
        style={{ paddingBottom: 'max(1.25rem, env(safe-area-inset-bottom))' }}
      >
        {/* Dots */}
        <div className="flex justify-center gap-1.5 mb-4">
          {Array.from({ length: totalSteps }).map((_, i) => (
            <span
              key={i}
              className={`h-1.5 rounded-full transition-all ${
                i === index ? 'w-5 bg-foreground' : 'w-1.5 bg-muted-foreground/30'
              }`}
            />
          ))}
        </div>

        {/* Buttons per step */}
        {index === 0 && (
          <PrimaryButton onClick={() => goTo(1)} full>Get started</PrimaryButton>
        )}
        {index === 1 && (
          <div className="flex items-center gap-3">
            <GhostButton onClick={async () => { await persistCategories(); goTo(2); }}>Skip</GhostButton>
            <PrimaryButton onClick={async () => { await persistCategories(); goTo(2); }} full>Continue</PrimaryButton>
          </div>
        )}
        {index === 2 && (
          <div className="flex items-center gap-3">
            <GhostButton onClick={() => goTo(3)}>Not now</GhostButton>
            <PrimaryButton onClick={requestNotifications} full>Enable</PrimaryButton>
          </div>
        )}
        {index === 3 && (
          <PrimaryButton onClick={finish} full disabled={saving}>
            {saving ? 'Getting ready…' : 'Go to Home'}
          </PrimaryButton>
        )}
      </div>
    </div>
  );
};

const PrimaryButton: React.FC<{
  children: React.ReactNode; onClick: () => void; full?: boolean; disabled?: boolean;
}> = ({ children, onClick, full, disabled }) => (
  <button
    onClick={onClick}
    disabled={disabled}
    className={`h-14 rounded-full bg-[#3076F8] text-white font-semibold text-[15px] flex items-center justify-center gap-2 active:scale-[0.98] transition-transform shadow-lg shadow-[#3076F8]/25 disabled:opacity-60 ${full ? 'w-full flex-1' : 'px-8'}`}
  >
    {children}
    <ArrowRight className="w-4 h-4" />
  </button>
);

const GhostButton: React.FC<{ children: React.ReactNode; onClick: () => void }> = ({ children, onClick }) => (
  <button
    onClick={onClick}
    className="h-14 px-8 rounded-full border border-border bg-background text-[#3076F8] font-semibold text-[15px] active:opacity-70"
  >
    {children}
  </button>
);

// Silence unused-import warning if capacitor helper stays referenced in future.
void isCapacitorNative;

export default PostAuthOnboarding;