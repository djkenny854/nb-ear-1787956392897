import React from 'react';
import { Info } from 'lucide-react';
import NotificationOrbit from '../NotificationOrbit';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';

const NotificationsScreen: React.FC = () => {
  return (
    <div className="flex flex-col h-full px-6 overflow-y-auto">
      <div className="flex items-center gap-2 pt-4 mb-4">
        <img src={earlymarketLogo} alt="" className="w-6 h-6 object-contain" />
        <span className="text-sm font-medium text-foreground/80">Earlymarket</span>
      </div>

      <h1 className="text-[40px] leading-[1.05] tracking-tight font-light text-foreground mb-4">
        Never miss an<br />opportunity
      </h1>
      <p className="text-[15px] leading-relaxed text-muted-foreground mb-6">
        Turn on notifications for messages, orders, new followers, and deals near you.
      </p>

      <div className="flex-1 flex items-center justify-center min-h-[240px]">
        <NotificationOrbit />
      </div>

      <div className="space-y-3 pt-6 pb-2">
        <Note>You control what alerts you get — tweak anytime in Settings.</Note>
        <Note>We'll never spam or share your info with third parties.</Note>
      </div>
    </div>
  );
};

const Note: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <div className="flex items-start gap-3 text-[13px] text-muted-foreground leading-relaxed">
    <span className="w-6 h-6 rounded-full bg-muted/60 flex items-center justify-center shrink-0 mt-0.5">
      <Info className="w-3.5 h-3.5" />
    </span>
    <span className="flex-1">{children}</span>
  </div>
);

export default NotificationsScreen;