import React from 'react';
import TriangleStack from '../TriangleStack';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';

const WelcomeScreen: React.FC = () => {
  return (
    <div className="flex flex-col h-full px-6">
      {/* Hero triangles */}
      <div className="flex-1 flex items-center justify-center min-h-0 pt-8">
        <TriangleStack className="w-[90%] max-w-md aspect-[4/3]" />
      </div>

      {/* Text block */}
      <div className="pb-4">
        <div className="flex items-center gap-2 mb-4">
          <img src={earlymarketLogo} alt="" className="w-6 h-6 object-contain" />
          <span className="text-sm font-medium text-foreground/80">Earlymarket</span>
        </div>
        <h1 className="text-[44px] leading-[1.05] tracking-tight font-light text-foreground mb-4">
          Welcome to<br />Earlymarket
        </h1>
        <p className="text-[15px] leading-relaxed text-muted-foreground max-w-md">
          Join the social business marketplace. Buy, sell, hire, and promote — free unlimited listings, verified sellers, real reach.
        </p>
      </div>
    </div>
  );
};

export default WelcomeScreen;
