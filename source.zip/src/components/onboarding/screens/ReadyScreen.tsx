import React from 'react';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';

const ReadyScreen: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center h-full px-6 text-center">
      <div className="relative w-28 h-28 mb-8 flex items-center justify-center">
        <span className="absolute -top-2 -left-4 w-3 h-3 rounded-full bg-[#FC9D3F]" />
        <span className="absolute top-4 -right-6 w-2.5 h-2.5 rounded-full bg-[#3076F8]" />
        <span className="absolute -bottom-2 right-4 w-2 h-2 rounded-full bg-[#DC63CC]" />
        <span className="absolute -bottom-4 -left-2 w-2 h-2 rounded-full bg-[#22c55e]" />
        <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-[#3076F8] to-[#DC63CC] flex items-center justify-center shadow-xl p-4">
          <img src={earlymarketLogo} alt="Earlymarket" className="w-full h-full object-contain drop-shadow" />
        </div>
      </div>

      <div className="flex items-center gap-2 mb-4">
        <img src={earlymarketLogo} alt="" className="w-6 h-6 object-contain" />
        <span className="text-sm font-medium text-foreground/80">Earlymarket</span>
      </div>

      <h1 className="text-[40px] leading-[1.05] tracking-tight font-light text-foreground mb-4">
        Ready to<br />explore?
      </h1>
      <p className="text-[15px] leading-relaxed text-muted-foreground max-w-sm">
        Discover products, services and businesses from across the country — tailored to you.
      </p>
    </div>
  );
};

export default ReadyScreen;
