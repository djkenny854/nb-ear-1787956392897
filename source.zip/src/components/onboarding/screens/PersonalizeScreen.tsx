import React from 'react';
import {
  Smartphone, Shirt, Car, Home, UtensilsCrossed, Briefcase,
  Wrench, PhoneCall, Armchair, Sprout, Check,
} from 'lucide-react';
import earlymarketLogo from '@/assets/earlymarket-logo-new.png';
import heroElectronics from '@/assets/onboarding/hero-electronics.jpg';
import heroFashion from '@/assets/onboarding/hero-fashion.jpg';
import heroFood from '@/assets/onboarding/hero-food.jpg';
import heroRealestate from '@/assets/onboarding/hero-realestate.jpg';

export const CATEGORY_OPTIONS = [
  { slug: 'electronics', label: 'Electronics', Icon: Smartphone },
  { slug: 'fashion', label: 'Fashion', Icon: Shirt },
  { slug: 'vehicles', label: 'Cars & Vehicles', Icon: Car },
  { slug: 'real-estate', label: 'Real Estate', Icon: Home },
  { slug: 'restaurants', label: 'Restaurants & Food', Icon: UtensilsCrossed },
  { slug: 'jobs', label: 'Jobs', Icon: Briefcase },
  { slug: 'services', label: 'Services', Icon: Wrench },
  { slug: 'phones', label: 'Phones', Icon: PhoneCall },
  { slug: 'furniture', label: 'Furniture & Home', Icon: Armchair },
  { slug: 'agriculture', label: 'Agriculture', Icon: Sprout },
] as const;

interface Props {
  selected: Set<string>;
  onToggle: (slug: string) => void;
}

const PersonalizeScreen: React.FC<Props> = ({ selected, onToggle }) => {
  return (
    <div className="flex flex-col h-full px-6 overflow-y-auto">
      {/* Playful, differently-sized hero images — not a grid */}
      <div className="relative h-32 mt-4 mb-20">
        <img
          src={heroElectronics}
          alt=""
          loading="lazy"
          className="absolute left-0 top-2 w-12 h-12 rounded-xl object-cover shadow-sm rotate-[-6deg]"
        />
        <img
          src={heroFashion}
          alt=""
          loading="lazy"
          className="absolute left-[24%] top-0 w-16 h-16 rounded-2xl object-cover shadow-md rotate-[4deg]"
        />
        <img
          src={heroFood}
          alt=""
          loading="lazy"
          className="absolute left-[52%] top-5 w-14 h-14 rounded-xl object-cover shadow-sm rotate-[-3deg]"
        />
        <img
          src={heroRealestate}
          alt=""
          loading="lazy"
          className="absolute right-0 top-1 w-11 h-11 rounded-xl object-cover shadow-sm rotate-[8deg]"
        />
      </div>

      {/* Brand row */}
      <div className="flex items-center gap-2 mb-3">
        <img src={earlymarketLogo} alt="" className="w-6 h-6 object-contain" />
        <span className="text-sm font-medium text-foreground/80">Earlymarket</span>
      </div>

      <h1 className="text-[38px] leading-[1.05] tracking-tight font-light text-foreground mb-3">
        Make your feed<br />yours
      </h1>
      <p className="text-[15px] leading-relaxed text-muted-foreground mb-6">
        Pick what you're into. We'll tailor your marketplace — for buying or selling.
      </p>

      <div className="flex items-center justify-between mb-3">
        <span className="text-[15px] font-semibold text-foreground">
          Categories <span className="text-muted-foreground font-normal">• {selected.size} selected</span>
        </span>
      </div>

      <ul className="space-y-1 pb-4">
        {CATEGORY_OPTIONS.map(({ slug, label, Icon }) => {
          const isOn = selected.has(slug);
          return (
            <li key={slug}>
              <button
                type="button"
                onClick={() => onToggle(slug)}
                className="w-full flex items-center gap-4 py-3 text-left active:opacity-70 transition"
              >
                <span className="w-11 h-11 rounded-xl bg-muted/60 flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-foreground/80" strokeWidth={1.8} />
                </span>
                <span className="flex-1 min-w-0">
                  <span className="block text-[15px] font-medium text-foreground truncate">{label}</span>
                </span>
                <span
                  className={`w-6 h-6 rounded-md flex items-center justify-center transition ${
                    isOn ? 'bg-[#3076F8]' : 'border-2 border-muted-foreground/40'
                  }`}
                >
                  {isOn && <Check className="w-4 h-4 text-white" strokeWidth={3} />}
                </span>
              </button>
            </li>
          );
        })}
      </ul>
    </div>
  );
};

export default PersonalizeScreen;
