import React, { useEffect, useRef } from 'react';
import { useNetworkStatus } from '@/hooks/useNetworkStatus';
import { toast } from 'sonner';

const OfflineOverlay: React.FC = () => {
  const { isOnline } = useNetworkStatus();
  const prevOnline = useRef(isOnline);
  const initialMount = useRef(true);

  useEffect(() => {
    // Skip toast on initial mount
    if (initialMount.current) {
      initialMount.current = false;
      prevOnline.current = isOnline;
      return;
    }

    if (isOnline && !prevOnline.current) {
      toast.success("You're back online");
    } else if (!isOnline && prevOnline.current) {
      toast.error("You're offline", {
        description: 'Check your internet connection',
        duration: 5000,
      });
    }
    prevOnline.current = isOnline;
  }, [isOnline]);

  return null;
};

export default OfflineOverlay;
