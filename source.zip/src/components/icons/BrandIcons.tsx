// Brand icons as simple SVG components for filter display
import React from 'react';

interface BrandIconProps {
  className?: string;
}

export const AppleIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
  </svg>
);

export const SamsungIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M3.18 12.35c.06-.19.31-.31.31-.31s.28.08.28.46c0 .31-.09.47-.28.47-.26 0-.31-.32-.31-.62M6.28 12.23c0-.06.01-.14.03-.2.02-.1.08-.21.24-.21.18 0 .24.14.24.35 0 .24-.09.38-.25.38-.21-.01-.26-.2-.26-.32m-1.04.26c0-.16.01-.3.09-.43.1-.18.27-.26.46-.26.22 0 .35.09.44.24.07.12.09.28.09.45 0 .16-.02.32-.09.45-.09.16-.22.25-.45.25-.22 0-.37-.09-.46-.26-.06-.13-.08-.29-.08-.44m-1.69-.06c0-.12.03-.36.3-.36.22 0 .28.16.28.33 0 .18-.08.36-.28.36-.28 0-.3-.23-.3-.33M2 12c0 .66.54 1.2 1.2 1.2h1.6c.66 0 1.2-.54 1.2-1.2 0-.66-.54-1.2-1.2-1.2H3.2c-.66 0-1.2.54-1.2 1.2m5.55 0c0 .66.54 1.2 1.2 1.2h1.5c.66 0 1.2-.54 1.2-1.2 0-.66-.54-1.2-1.2-1.2h-1.5c-.66 0-1.2.54-1.2 1.2m4.9 0c0 .66.54 1.2 1.2 1.2h1.5c.66 0 1.2-.54 1.2-1.2 0-.66-.54-1.2-1.2-1.2h-1.5c-.66 0-1.2.54-1.2 1.2m4.9 0c0 .66.54 1.2 1.2 1.2h1.5c.66 0 1.2-.54 1.2-1.2 0-.66-.54-1.2-1.2-1.2h-1.5c-.66 0-1.2.54-1.2 1.2"/>
  </svg>
);

export const NikeIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M21 8.719L7.836 14.303C6.74 14.768 5.818 15 5.075 15c-.836 0-1.445-.295-1.819-.884-.485-.76-.273-1.982.559-3.272.494-.754 1.122-1.446 1.734-2.108-.144.234-1.415 2.349-.025 3.345.275.197.618.298 1.02.298.409 0 .891-.097 1.436-.291L21 8.719z"/>
  </svg>
);

export const AdidasIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M1 18L6 8l3 5-8 5zm7.5-5l3 5H1l3-5h4.5zm4.5 0l3 5H8.5l3-5h1.5zm0-5l3 5h-4.5l-3-5h4.5zm4.5 5l3 5h-4.5l-3-5h4.5zm0-10l3 5-3 5-3-5 3-5z"/>
  </svg>
);

export const HPIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <text x="2" y="17" fontSize="14" fontWeight="bold" fontFamily="Arial">hp</text>
  </svg>
);

export const DellIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="2"/>
    <text x="6" y="16" fontSize="10" fontWeight="bold" fontFamily="Arial">DELL</text>
  </svg>
);

export const ToyotaIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <ellipse cx="12" cy="12" rx="10" ry="6" fill="none" stroke="currentColor" strokeWidth="1.5"/>
    <ellipse cx="12" cy="12" rx="6" ry="3" fill="none" stroke="currentColor" strokeWidth="1.5"/>
    <ellipse cx="12" cy="12" rx="3" ry="5" fill="none" stroke="currentColor" strokeWidth="1.5"/>
  </svg>
);

export const HondaIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M2 8h2v8H2V8zm4 0h2v3h3v-3h2v8h-2v-3H8v3H6V8zm8 0h6v2h-4v1h4v2h-4v1h4v2h-6V8z"/>
  </svg>
);

export const LGIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="2"/>
    <text x="5" y="16" fontSize="10" fontWeight="bold" fontFamily="Arial">LG</text>
  </svg>
);

export const SonyIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <text x="1" y="16" fontSize="10" fontWeight="bold" fontFamily="Arial" letterSpacing="1">SONY</text>
  </svg>
);

export const LenovoIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <text x="0" y="15" fontSize="8" fontWeight="bold" fontFamily="Arial">lenovo</text>
  </svg>
);

export const MicrosoftIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <rect x="2" y="2" width="9" height="9" fill="#f25022"/>
    <rect x="13" y="2" width="9" height="9" fill="#7fba00"/>
    <rect x="2" y="13" width="9" height="9" fill="#00a4ef"/>
    <rect x="13" y="13" width="9" height="9" fill="#ffb900"/>
  </svg>
);

export const CanonIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <text x="0" y="15" fontSize="9" fontWeight="bold" fontFamily="Arial" fill="currentColor">Canon</text>
  </svg>
);

export const NikonIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <text x="0" y="15" fontSize="9" fontWeight="bold" fontFamily="Arial" fill="currentColor">Nikon</text>
  </svg>
);

export const AsusIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <text x="1" y="15" fontSize="10" fontWeight="bold" fontFamily="Arial" fill="currentColor">ASUS</text>
  </svg>
);

export const AcerIcon: React.FC<BrandIconProps> = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <text x="1" y="15" fontSize="10" fontWeight="bold" fontFamily="Arial" fill="currentColor">Acer</text>
  </svg>
);

// Map brand names to their icons
export const brandIconMap: Record<string, React.FC<BrandIconProps>> = {
  'Apple': AppleIcon,
  'Samsung': SamsungIcon,
  'Nike': NikeIcon,
  'Adidas': AdidasIcon,
  'HP': HPIcon,
  'Dell': DellIcon,
  'Toyota': ToyotaIcon,
  'Honda': HondaIcon,
  'LG': LGIcon,
  'Sony': SonyIcon,
  'Lenovo': LenovoIcon,
  'Microsoft': MicrosoftIcon,
  'Canon': CanonIcon,
  'Nikon': NikonIcon,
  'Asus': AsusIcon,
  'Acer': AcerIcon,
};

// Get all available brands with icons
export const popularBrands = Object.keys(brandIconMap);
