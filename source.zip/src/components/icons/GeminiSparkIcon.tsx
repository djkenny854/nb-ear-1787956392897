import React from 'react';

interface Props {
  className?: string;
  strokeWidth?: number;
  filled?: boolean;
  fill?: string;
}

/**
 * Gemini-style 4-point spark icon — solid currentColor (white/black depending on theme).
 * Use to replace coloured Gemini logo when a monochrome look is needed.
 */
const GeminiSparkIcon: React.FC<Props> = ({ className = 'h-6 w-6', strokeWidth = 1.8, filled = false, fill }) => {
  const isFilled = filled || fill === 'currentColor';
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 65 65"
      className={className}
      fill={isFilled ? 'currentColor' : 'none'}
      stroke="currentColor"
      strokeWidth={isFilled ? 0 : strokeWidth * 1.2}
      strokeLinejoin="round"
    >
      <path d="M32.447 0c.68 0 1.273.465 1.439 1.125a38.9 38.9 0 0 0 1.999 5.905c2.152 5 5.105 9.376 8.854 13.125 3.751 3.75 8.126 6.703 13.125 8.855a38.98 38.98 0 0 0 5.906 1.999c.66.166 1.124.758 1.124 1.438 0 .68-.464 1.273-1.125 1.439a38.9 38.9 0 0 0-5.905 1.999c-5 2.152-9.375 5.105-13.125 8.854-3.749 3.751-6.702 8.126-8.854 13.125a38.97 38.97 0 0 0-2 5.906 1.485 1.485 0 0 1-1.438 1.124c-.68 0-1.272-.464-1.438-1.125a38.91 38.91 0 0 0-2-5.905c-2.151-5-5.103-9.375-8.854-13.125-3.75-3.749-8.125-6.702-13.125-8.854a38.97 38.97 0 0 0-5.905-2A1.485 1.485 0 0 1 0 32.448c0-.68.465-1.272 1.125-1.438a38.9 38.9 0 0 0 5.905-2c5-2.151 9.376-5.104 13.125-8.854 3.75-3.749 6.703-8.125 8.855-13.125a38.97 38.97 0 0 0 1.999-5.905A1.485 1.485 0 0 1 32.447 0z" />
    </svg>
  );
};

export default GeminiSparkIcon;