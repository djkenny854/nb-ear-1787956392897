import React from 'react';
import type { Icon as PhosphorIcon } from '@phosphor-icons/react';

interface AdapterProps {
  className?: string;
  strokeWidth?: number;
  fill?: string;
  size?: number | string;
  color?: string;
}

/**
 * Wraps a Phosphor icon so it accepts the same props pattern we used for
 * lucide-react icons (className for size, strokeWidth, fill="currentColor"
 * for active state).
 *
 *  - fill === 'currentColor'  -> weight="fill"
 *  - strokeWidth >= 2.5       -> weight="bold"
 *  - default                  -> weight="regular"
 */
export const adaptPhosphor = (Icon: PhosphorIcon) => {
  const Wrapped: React.FC<AdapterProps> = ({ className, strokeWidth, fill, ...rest }) => {
    const weight: 'fill' | 'bold' | 'regular' =
      fill === 'currentColor' ? 'fill' : (strokeWidth && strokeWidth >= 2.4 ? 'bold' : 'regular');
    return <Icon className={className} weight={weight} {...rest} />;
  };
  Wrapped.displayName = `Adapted(${(Icon as any).displayName || 'PhosphorIcon'})`;
  return Wrapped;
};

export default adaptPhosphor;