import React from 'react';
import { Skeleton } from '@/components/ui/skeleton';

const JobListRowSkeleton: React.FC = () => (
  <div className="py-3 md:py-4 border-b border-border/40 last:border-0 px-2 md:px-3">
    <div className="flex items-start gap-3">
      <Skeleton className="w-9 h-9 md:w-10 md:h-10 rounded-full flex-shrink-0" />
      <div className="flex-1 min-w-0 space-y-2">
        <Skeleton className="h-4 w-[85%]" />
        <Skeleton className="h-3 w-[60%]" />
        <div className="flex items-center gap-2 pt-1">
          <Skeleton className="h-7 w-16 rounded-full" />
          <Skeleton className="h-7 w-7 rounded-full" />
          <Skeleton className="h-7 w-7 rounded-full" />
        </div>
      </div>
    </div>
  </div>
);

export default JobListRowSkeleton;
