import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import { toast } from '@/hooks/use-toast';

interface UseDraftSaveOptions {
  wizardType: string;
  formData: Record<string, any>;
  currentStep: number;
  setFormData: (data: any) => void;
  setCurrentStep: (step: number) => void;
}

export function useDraftSave({
  wizardType,
  formData,
  currentStep,
  setFormData,
  setCurrentStep,
}: UseDraftSaveOptions) {
  const { user } = useAuth();
  const [draftLoaded, setDraftLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [pendingDraft, setPendingDraft] = useState<{ formData: Record<string, any>; step: number } | null>(null);
  const formDataRef = useRef(formData);
  const currentStepRef = useRef(currentStep);

  useEffect(() => {
    formDataRef.current = formData;
  }, [formData]);

  useEffect(() => {
    currentStepRef.current = currentStep;
  }, [currentStep]);

  // Load draft on mount - but don't auto-apply
  useEffect(() => {
    const loadDraft = async () => {
      if (!user) { setDraftLoaded(true); return; }
      try {
        const { data, error } = await supabase
          .from('wizard_drafts')
          .select('*')
          .eq('user_id', user.id)
          .eq('wizard_type', wizardType)
          .maybeSingle();

        if (!error && data) {
          const savedFormData = data.form_data as Record<string, any>;
          if (savedFormData && Object.keys(savedFormData).length > 0) {
            setPendingDraft({ formData: savedFormData, step: data.current_step || 0 });
          }
        }
      } catch (err) {
        console.error('Error loading draft:', err);
      } finally {
        setDraftLoaded(true);
      }
    };

    loadDraft();
  }, [user, wizardType]);

  const applyDraft = useCallback(() => {
    if (pendingDraft) {
      setFormData((prev: any) => ({ ...prev, ...pendingDraft.formData }));
      setCurrentStep(pendingDraft.step);
      setPendingDraft(null);
      toast({ title: '📝 Draft restored', description: 'Your previous progress has been loaded.' });
    }
  }, [pendingDraft, setFormData, setCurrentStep]);

  const dismissDraft = useCallback(() => {
    setPendingDraft(null);
  }, []);

  const saveDraft = useCallback(async () => {
    if (!user) return false;
    setSaving(true);
    try {
      const cleanFormData = { ...formDataRef.current };
      if (cleanFormData.images) {
        cleanFormData.images = cleanFormData.images.map((img: any) => ({
          id: img.id,
          url: img.url,
          isHighQuality: img.isHighQuality,
          qualityScore: img.qualityScore,
          edited: img.edited,
          type: img.type,
        }));
      }

      const { error } = await supabase
        .from('wizard_drafts')
        .upsert(
          {
            user_id: user.id,
            wizard_type: wizardType,
            current_step: currentStepRef.current,
            form_data: cleanFormData as any,
            updated_at: new Date().toISOString(),
          },
          { onConflict: 'user_id,wizard_type' }
        );

      if (error) throw error;
      return true;
    } catch (err) {
      console.error('Error saving draft:', err);
      return false;
    } finally {
      setSaving(false);
    }
  }, [user, wizardType]);

  const saveDraftWithToast = useCallback(async () => {
    const success = await saveDraft();
    if (success) {
      toast({ title: '💾 Draft saved', description: 'Your progress has been saved.' });
    } else {
      toast({ title: 'Failed to save draft', variant: 'destructive' });
    }
    return success;
  }, [saveDraft]);

  const deleteDraft = useCallback(async () => {
    if (!user) return;
    try {
      await supabase
        .from('wizard_drafts')
        .delete()
        .eq('user_id', user.id)
        .eq('wizard_type', wizardType);
    } catch (err) {
      console.error('Error deleting draft:', err);
    }
  }, [user, wizardType]);

  return {
    draftLoaded,
    saving,
    saveDraft,
    saveDraftWithToast,
    deleteDraft,
    pendingDraft,
    applyDraft,
    dismissDraft,
  };
}
