import { supabase } from '@/integrations/supabase/client';

/**
 * Shared realtime manager for "interested" engagement counts.
 *
 * Previously every feed card opened its OWN realtime channel that listened to
 * ALL inserts/deletes on `content_engagements` and ran its own count query.
 * With ~20 cards per page that meant ~20 global channels + ~40 queries on load.
 *
 * This module keeps a SINGLE shared channel for the whole app and an in-memory
 * map of counts keyed by `${content_type}:${content_id}`. Cards register a
 * listener and seed their count from batched feed data, so no per-card query or
 * per-card channel is needed.
 */

type CountListener = (count: number) => void;

const counts = new Map<string, number>();
const listeners = new Map<string, Set<CountListener>>();

let channel: ReturnType<typeof supabase.channel> | null = null;
let refCount = 0;
let currentUserId: string | null = null;

const keyOf = (type: string, id: string) => `${type}:${id}`;

export const setEngagementUser = (userId: string | null) => {
  currentUserId = userId;
};

const emit = (key: string) => {
  const c = counts.get(key) ?? 0;
  listeners.get(key)?.forEach((l) => l(c));
};

const handleChange = (record: any, delta: number) => {
  if (!record) return;
  if (record.engagement_type && record.engagement_type !== 'interested') return;
  // Self-initiated changes are applied optimistically by the acting client.
  if (record.user_id && record.user_id === currentUserId) return;
  if (!record.content_type || !record.content_id) return;
  const key = keyOf(record.content_type, record.content_id);
  if (!listeners.has(key)) return; // nobody on screen cares about this item
  counts.set(key, Math.max(0, (counts.get(key) ?? 0) + delta));
  emit(key);
};

const ensureChannel = () => {
  if (channel) return;
  channel = supabase
    .channel('engagement-shared')
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'content_engagements' },
      (payload) => handleChange(payload.new, 1)
    )
    .on(
      'postgres_changes',
      { event: 'DELETE', schema: 'public', table: 'content_engagements' },
      (payload) => handleChange(payload.old, -1)
    )
    .subscribe();
};

/** Register a count listener for a content item. Returns an unsubscribe fn. */
export const subscribeInterestedCount = (
  contentType: string,
  contentId: string,
  initialCount: number | undefined,
  listener: CountListener
): (() => void) => {
  const key = keyOf(contentType, contentId);
  if (initialCount !== undefined && !counts.has(key)) {
    counts.set(key, initialCount);
  }
  if (!listeners.has(key)) listeners.set(key, new Set());
  listeners.get(key)!.add(listener);
  refCount += 1;
  ensureChannel();

  // Emit current value immediately so the card renders the seeded count.
  listener(counts.get(key) ?? initialCount ?? 0);

  return () => {
    const set = listeners.get(key);
    if (set) {
      set.delete(listener);
      if (set.size === 0) listeners.delete(key);
    }
    refCount -= 1;
    if (refCount <= 0 && channel) {
      supabase.removeChannel(channel);
      channel = null;
      refCount = 0;
    }
  };
};

/** Set the authoritative count for an item and notify listeners. */
export const setInterestedCount = (contentType: string, contentId: string, count: number) => {
  const key = keyOf(contentType, contentId);
  counts.set(key, Math.max(0, count));
  emit(key);
};

/** Apply an optimistic local delta (used by the acting client when toggling). */
export const bumpInterestedCount = (contentType: string, contentId: string, delta: number) => {
  const key = keyOf(contentType, contentId);
  counts.set(key, Math.max(0, (counts.get(key) ?? 0) + delta));
  emit(key);
};
