import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';

interface UseActiveAdsOptions {
  limit?: number;
  listingType?: string;
  category?: string;
  location?: string;
  sellerId?: string;
}

/**
 * Hook to fetch active ads, automatically filtering out content from banned/suspended users
 */
export const useActiveAds = (options: UseActiveAdsOptions = {}) => {
  const { limit = 20, listingType, category, location, sellerId } = options;

  return useQuery({
    queryKey: ['active-ads', options],
    queryFn: async () => {
      // Single query with join - no more triple-query pattern
      let query = supabase
        .from('ads')
        .select(`
          *,
          seller_profiles (
            id,
            business_name,
            business_logo_url,
            is_verified,
            user_id
          )
        `)
        .eq('status', 'active')
        .order('created_at', { ascending: false })
        .limit(limit);

      if (listingType) {
        query = query.eq('listing_type', listingType);
      }
      if (category) {
        query = query.eq('category', category);
      }
      if (location) {
        query = query.ilike('location', `%${location}%`);
      }
      if (sellerId) {
        query = query.eq('seller_id', sellerId);
      }

      const { data, error } = await query;

      if (error) throw error;
      return data || [];
    },
    staleTime: 1000 * 60 * 2,
  });
};

/**
 * Hook to check if a specific ad's seller is active before displaying
 */
export const useAdVisibility = (adId: string) => {
  return useQuery({
    queryKey: ['ad-visibility', adId],
    queryFn: async () => {
      const { data: ad } = await supabase
        .from('ads')
        .select(`
          id,
          seller_id,
          seller_profiles (
            user_id
          )
        `)
        .eq('id', adId)
        .single();

      if (!ad) return { isVisible: false, reason: 'not_found' };

      const sellerId = (ad.seller_profiles as any)?.user_id;
      if (!sellerId) return { isVisible: false, reason: 'no_seller' };

      const { data: profile } = await supabase
        .from('profiles')
        .select('account_status')
        .eq('id', sellerId)
        .single();

      const isActive = !profile?.account_status || profile.account_status === 'active';
      return {
        isVisible: isActive,
        reason: isActive ? null : 'seller_restricted',
      };
    },
    enabled: !!adId,
  });
};
