import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

export interface BoostPlan {
  id: string;
  name: string;
  display_name: string;
  description: string | null;
  base_price_per_day: number;
  multiplier: number;
  features: string[];
  visibility_multiplier: number;
  icon: string;
  gradient_from: string;
  gradient_to: string;
  is_popular: boolean;
  is_active: boolean;
  sort_order: number;
}

export interface PlacementType {
  id: string;
  name: string;
  display_name: string;
  description: string | null;
  price_multiplier: number;
  icon: string;
  is_active: boolean;
  sort_order: number;
}

export interface PricingConfig {
  regional_discount: number;
  district_discount: number;
  min_duration_days: number;
  max_duration_days: number;
  currency: string;
  tax_rate: number;
}

export function useBoostPricing() {
  const [plans, setPlans] = useState<BoostPlan[]>([]);
  const [placementTypes, setPlacementTypes] = useState<PlacementType[]>([]);
  const [pricingConfig, setPricingConfig] = useState<PricingConfig>({
    regional_discount: 0.20,
    district_discount: 0.10,
    min_duration_days: 1,
    max_duration_days: 30,
    currency: 'UGX',
    tax_rate: 0.18,
  });
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchPricingData();
  }, []);

  const fetchPricingData = async () => {
    try {
      setIsLoading(true);
      setError(null);

      // Fetch all pricing data in parallel
      const [plansRes, placementRes, configRes] = await Promise.all([
        supabase
          .from('boost_plans')
          .select('*')
          .eq('is_active', true)
          .order('sort_order'),
        supabase
          .from('placement_types')
          .select('*')
          .eq('is_active', true)
          .order('sort_order'),
        supabase
          .from('boost_pricing_config')
          .select('*'),
      ]);

      if (plansRes.error) throw plansRes.error;
      if (placementRes.error) throw placementRes.error;
      if (configRes.error) throw configRes.error;

      // Parse plans with features as string array
      const parsedPlans: BoostPlan[] = (plansRes.data || []).map(plan => ({
        id: plan.id,
        name: plan.name,
        display_name: plan.display_name,
        description: plan.description,
        base_price_per_day: Number(plan.base_price_per_day),
        multiplier: Number(plan.multiplier),
        features: Array.isArray(plan.features) 
          ? (plan.features as unknown[]).map(f => String(f)) 
          : [],
        visibility_multiplier: plan.visibility_multiplier ?? 3,
        icon: plan.icon ?? 'Zap',
        gradient_from: plan.gradient_from ?? 'blue-500',
        gradient_to: plan.gradient_to ?? 'cyan-500',
        is_popular: plan.is_popular ?? false,
        is_active: plan.is_active ?? true,
        sort_order: plan.sort_order ?? 0,
      }));

      // Parse placement types
      const parsedPlacements: PlacementType[] = (placementRes.data || []).map(p => ({
        id: p.id,
        name: p.name,
        display_name: p.display_name,
        description: p.description,
        price_multiplier: Number(p.price_multiplier),
        icon: p.icon ?? 'Zap',
        is_active: p.is_active ?? true,
        sort_order: p.sort_order ?? 0,
      }));

      // Parse config
      const config: PricingConfig = {
        regional_discount: 0.20,
        district_discount: 0.10,
        min_duration_days: 1,
        max_duration_days: 30,
        currency: 'UGX',
        tax_rate: 0.18,
      };

      (configRes.data || []).forEach(item => {
        const value = typeof item.value === 'string' ? JSON.parse(item.value) : item.value;
        switch (item.key) {
          case 'regional_discount':
            config.regional_discount = Number(value);
            break;
          case 'district_discount':
            config.district_discount = Number(value);
            break;
          case 'min_duration_days':
            config.min_duration_days = Number(value);
            break;
          case 'max_duration_days':
            config.max_duration_days = Number(value);
            break;
          case 'currency':
            config.currency = String(value).replace(/"/g, '');
            break;
          case 'tax_rate':
            config.tax_rate = Number(value);
            break;
        }
      });

      setPlans(parsedPlans);
      setPlacementTypes(parsedPlacements);
      setPricingConfig(config);
    } catch (err: any) {
      console.error('Error fetching boost pricing:', err);
      setError(err.message || 'Failed to load pricing');
    } finally {
      setIsLoading(false);
    }
  };

  const calculatePrice = (
    planName: string,
    placementName: string,
    duration: number,
    targetRegion: string,
    targetDistricts: string[]
  ): { price: number; estimatedReach: number } => {
    const plan = plans.find(p => p.name === planName);
    const placement = placementTypes.find(p => p.name === placementName);

    if (!plan || !placement) {
      return { price: 0, estimatedReach: 0 };
    }

    // Base calculation
    let price = plan.base_price_per_day * duration * plan.multiplier * placement.price_multiplier;

    // Regional discount
    if (targetRegion !== 'All Uganda') {
      price *= (1 - pricingConfig.regional_discount);
    }

    // District targeting discount
    if (targetDistricts.length > 0 && targetDistricts.length < 10) {
      price *= (1 - pricingConfig.district_discount);
    }

    // Calculate estimated reach
    let baseReach = 10000;
    if (targetRegion === 'All Uganda') {
      baseReach = 50000;
    } else if (targetRegion === 'Central') {
      baseReach = 30000;
    } else {
      baseReach = 15000;
    }

    baseReach *= plan.visibility_multiplier / 3; // Normalize based on standard 3x
    baseReach *= placement.price_multiplier;
    baseReach *= (duration / 7);

    return {
      price: Math.round(price),
      estimatedReach: Math.round(baseReach),
    };
  };

  return {
    plans,
    placementTypes,
    pricingConfig,
    isLoading,
    error,
    calculatePrice,
    refetch: fetchPricingData,
  };
}
