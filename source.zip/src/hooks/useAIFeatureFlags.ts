import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface AIFeatureFlags {
  enhanceImageEnabled: boolean;
  contentModerationEnabled: boolean;
  aiAssistEnabled: boolean;
  aiChatEnabled: boolean;
  aiSemanticSearchEnabled: boolean;
  loading: boolean;
}

export const useAIFeatureFlags = (): AIFeatureFlags => {
  const [flags, setFlags] = useState<AIFeatureFlags>({
    enhanceImageEnabled: false,
    contentModerationEnabled: false,
    aiAssistEnabled: false,
    aiChatEnabled: false,
    aiSemanticSearchEnabled: false,
    loading: true,
  });

  useEffect(() => {
    const fetchFlags = async () => {
      try {
        const { data, error } = await supabase
          .from('app_settings')
          .select('key, value')
          .in('key', [
            'enhance_image_enabled',
            'content_moderation_enabled',
            'ai_assist_enabled',
            'ai_chat_enabled',
            'ai_semantic_search_enabled',
          ]);

        if (error) throw error;

        let enhance = false;
        let moderation = false;
        let assist = false;
        let chat = false;
        let semanticSearch = false;

        for (const row of data || []) {
          const val = row.value as any;
          if (row.key === 'enhance_image_enabled') enhance = val?.enabled === true;
          if (row.key === 'content_moderation_enabled') moderation = val?.enabled === true;
          if (row.key === 'ai_assist_enabled') assist = val?.enabled === true;
          if (row.key === 'ai_chat_enabled') chat = val?.enabled === true;
          if (row.key === 'ai_semantic_search_enabled') semanticSearch = val?.enabled === true;
        }

        setFlags({
          enhanceImageEnabled: enhance,
          contentModerationEnabled: moderation,
          aiAssistEnabled: assist,
          aiChatEnabled: chat,
          aiSemanticSearchEnabled: semanticSearch,
          loading: false,
        });
      } catch (err) {
        console.error('Failed to fetch AI feature flags:', err);
        setFlags(prev => ({ ...prev, loading: false }));
      }
    };

    fetchFlags();
  }, []);

  return flags;
};
