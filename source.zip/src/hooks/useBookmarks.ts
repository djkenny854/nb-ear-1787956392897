import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/components/auth/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

export interface Bookmark {
  id: string;
  item_id: string;
  item_type: string;
  created_at: string;
}

export const useBookmarks = () => {
  const { user } = useAuth();
  const [bookmarks, setBookmarks] = useState<Bookmark[]>([]);
  const [loading, setLoading] = useState(false);

  // Fetch user's bookmarks
  const fetchBookmarks = useCallback(async () => {
    if (!user?.id) {
      setBookmarks([]);
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('bookmarks')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setBookmarks(data || []);
    } catch (error) {
      console.error('Error fetching bookmarks:', error);
    } finally {
      setLoading(false);
    }
  }, [user?.id]);

  useEffect(() => {
    fetchBookmarks();
  }, [fetchBookmarks]);

  // Check if an item is bookmarked
  const isBookmarked = useCallback((itemId: string, itemType: string = 'product') => {
    return bookmarks.some(b => b.item_id === itemId && b.item_type === itemType);
  }, [bookmarks]);

  // Toggle bookmark
  const toggleBookmark = useCallback(async (itemId: string, itemType: string = 'product') => {
    if (!user?.id) {
      toast.error('Please sign in to save items');
      return false;
    }

    const existing = bookmarks.find(b => b.item_id === itemId && b.item_type === itemType);

    try {
      if (existing) {
        // Remove bookmark
        const { error } = await supabase
          .from('bookmarks')
          .delete()
          .eq('id', existing.id);

        if (error) throw error;
        setBookmarks(prev => prev.filter(b => b.id !== existing.id));
        // Mirror to engagement table for analytics parity
        await supabase
          .from('content_engagements')
          .delete()
          .eq('user_id', user.id)
          .eq('content_id', itemId)
          .eq('engagement_type', 'bookmarked');
        toast.success('Removed from bookmarks');
        return false;
      } else {
        // Add bookmark
        const { data, error } = await supabase
          .from('bookmarks')
          .insert({
            user_id: user.id,
            item_id: itemId,
            item_type: itemType
          })
          .select()
          .single();

        if (error) throw error;
        setBookmarks(prev => [data, ...prev]);
        // Mirror to engagement table so the analytics page picks it up
        // for posts/events/services as well as ads.
        const engagementContentType =
          itemType === 'post' ? 'post' :
          itemType === 'event' ? 'event' :
          itemType === 'service' ? 'service' : 'ad';
        await supabase.from('content_engagements').insert({
          user_id: user.id,
          content_id: itemId,
          content_type: engagementContentType,
          engagement_type: 'bookmarked',
        });
        toast.success('Added to bookmarks');

        // Send notification to the listing owner
        try {
          // Get the ad to find the owner
          const { data: adData } = await supabase
            .from('ads')
            .select('seller_id, title')
            .eq('id', itemId)
            .single();

          if (adData?.seller_id) {
            // Get seller's user_id
            const { data: sellerData } = await supabase
              .from('seller_profiles')
              .select('user_id, business_name')
              .eq('id', adData.seller_id)
              .single();

            if (sellerData?.user_id && sellerData.user_id !== user.id) {
              // Get bookmarker's business name if they have one
              const { data: bookmarkerProfile } = await supabase
                .from('seller_profiles')
                .select('business_name')
                .eq('user_id', user.id)
                .maybeSingle();

              const bookmarkerName = bookmarkerProfile?.business_name || 'Someone';

              await supabase.from('notifications').insert({
                user_id: sellerData.user_id,
                title: 'New Bookmark',
                message: `${bookmarkerName} bookmarked your listing "${adData.title}"`,
                notification_type: 'bookmark_received',
                action_url: `/ad/${itemId}`,
                metadata: { 
                  ad_id: itemId, 
                  bookmarker_id: user.id,
                  item_type: itemType,
                  ad_title: adData.title,
                  content_images: (await supabase.from('ads').select('images').eq('id', itemId).single()).data?.images?.slice(0, 4) || []
                }
              });
            }
          }
        } catch (notifError) {
          console.error('Error sending bookmark notification:', notifError);
          // Don't fail the bookmark operation if notification fails
        }

        return true;
      }
    } catch (error: any) {
      console.error('Error toggling bookmark:', error);
      toast.error('Failed to update bookmark');
      return existing ? true : false;
    }
  }, [user?.id, bookmarks]);

  return {
    bookmarks,
    loading,
    isBookmarked,
    toggleBookmark,
    refetch: fetchBookmarks
  };
};
