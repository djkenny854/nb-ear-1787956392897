import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { isRealNativeRuntime } from '@/hooks/useCapacitor';

// Current app version - update this with each release
export const CURRENT_APP_VERSION = '1.0.0';

interface VersionCheck {
  isOutdated: boolean;
  isForced: boolean;
  latestVersion: string | null;
  requiredVersion: string | null;
  currentVersion: string;
  releaseNotes: string | null;
  playStoreUrl: string | null;
  appStoreUrl: string | null;
  isLoading: boolean;
  daysRemaining: number | null;
}

export const useAppVersion = () => {
  const [versionCheck, setVersionCheck] = useState<VersionCheck>({
    isOutdated: false,
    isForced: false,
    latestVersion: null,
    requiredVersion: null,
    currentVersion: CURRENT_APP_VERSION,
    releaseNotes: null,
    playStoreUrl: null,
    appStoreUrl: null,
    isLoading: true,
    daysRemaining: null,
  });

  const navigate = useNavigate();

  useEffect(() => {
    // Only check version in native mode
    if (!isRealNativeRuntime()) {
      setVersionCheck(prev => ({ ...prev, isLoading: false }));
      return;
    }

    const checkVersion = async () => {
      try {
        const { data, error } = await supabase
          .from('app_update_control')
          .select('*')
          .limit(1)
          .single();

        if (error || !data) {
          console.log('[AppVersion] No update control data found:', error?.message);
          setVersionCheck(prev => ({ ...prev, isLoading: false }));
          return;
        }

        console.log('[AppVersion] Current:', CURRENT_APP_VERSION, 'Min required:', data.min_version, 'Latest:', data.latest_version);

        const isOutdated = compareVersions(CURRENT_APP_VERSION, data.min_version) < 0;
        
        // Calculate days since release for grace period
        const releasedAt = data.released_at ? new Date(data.released_at) : (data.updated_at ? new Date(data.updated_at) : new Date());
        const daysSinceRelease = Math.floor((Date.now() - releasedAt.getTime()) / (1000 * 60 * 60 * 24));
        const gracePeriodDays = 5;
        const daysRemaining = Math.max(gracePeriodDays - daysSinceRelease, 0);
        // Auto-force after 5 days
        const effectiveForced = data.is_forced || (isOutdated && daysSinceRelease >= gracePeriodDays);

        setVersionCheck({
          isOutdated,
          isForced: effectiveForced,
          latestVersion: data.latest_version,
          requiredVersion: data.min_version,
          currentVersion: CURRENT_APP_VERSION,
          releaseNotes: data.release_notes,
          playStoreUrl: data.play_store_url,
          appStoreUrl: data.app_store_url,
          isLoading: false,
          daysRemaining: isOutdated ? daysRemaining : null,
        });

        // Redirect to update page if outdated
        if (isOutdated) {
          console.log('[AppVersion] App is outdated, redirecting to /update-required');
          navigate('/update-required', { replace: true });
        }
      } catch (error) {
        console.error('Error checking app version:', error);
        setVersionCheck(prev => ({ ...prev, isLoading: false }));
      }
    };

    checkVersion();
  }, [navigate]);

  return versionCheck;
};

// Compare semantic versions: returns -1 if v1 < v2, 0 if equal, 1 if v1 > v2
function compareVersions(v1: string, v2: string): number {
  const parts1 = v1.split('.').map(Number);
  const parts2 = v2.split('.').map(Number);

  for (let i = 0; i < Math.max(parts1.length, parts2.length); i++) {
    const p1 = parts1[i] || 0;
    const p2 = parts2[i] || 0;
    if (p1 < p2) return -1;
    if (p1 > p2) return 1;
  }
  return 0;
}
