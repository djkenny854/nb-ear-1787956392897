// =====================================================================
// CAPACITOR NATIVE MODE SWITCH
// =====================================================================
// NATIVE_MODE_ENABLED controls UI gating (AuthGate, native UI).
// isRealNativeRuntime() checks if the Capacitor bridge is actually present.
// isCapacitorNative() returns true for UI gating (AuthGate, layout).
// isRealNativeRuntime() returns true only when plugins can actually run.
// =====================================================================
import { useState, useEffect } from 'react';

// ⬇⬇⬇ CHANGE THIS VALUE TO true OR false TO SWITCH NATIVE MODE ⬇⬇⬇
const NATIVE_MODE_ENABLED = false
// ⬆⬆⬆ CHANGE THIS VALUE TO true OR false TO SWITCH NATIVE MODE ⬆⬆⬆

// ⬇⬇⬇ TURN ON when building a local Android APK with edge-to-edge enabled. ⬇⬇⬇
// When true, every page renders a top spacer the height of the device notch
// (env(safe-area-inset-top)) so content never slides under the status bar.
// Uses --background, so it follows light/dark mode automatically.
const EDGE_TO_EDGE_SPACER_ENABLED = false
// ⬆⬆⬆ TURN ON when building a local Android APK with edge-to-edge enabled. ⬆⬆⬆

/** True when the global top notch spacer should be rendered. */
export const isEdgeToEdgeSpacerEnabled = (): boolean => EDGE_TO_EDGE_SPACER_ENABLED;

/** True when Capacitor bridge is actually present (real device / emulator) */
export const isRealNativeRuntime = (): boolean => {
  try {
    const Capacitor = (window as any).Capacitor;
    return !!(Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
  } catch {
    return false;
  }
};

/** True for UI gating: native mode enabled AND (real runtime OR override flag).
 *  On web with override, this enables AuthGate/layout but plugin calls are guarded
 *  by isRealNativeRuntime(). */
export const isCapacitorNative = (): boolean => {
  if (NATIVE_MODE_ENABLED) return true;
  return isRealNativeRuntime();
};

interface CapacitorInfo {
  isNative: boolean;
  isAndroid: boolean;
  isIOS: boolean;
  isWeb: boolean;
  platform: 'android' | 'ios' | 'web';
}

export const useCapacitor = (): CapacitorInfo => {
  const [info, setInfo] = useState<CapacitorInfo>({
    isNative: isCapacitorNative(),
    isAndroid: false,
    isIOS: false,
    isWeb: !isCapacitorNative(),
    platform: isCapacitorNative() ? 'android' : 'web',
  });

  useEffect(() => {
    if (isRealNativeRuntime()) {
      try {
        const platform = (window as any).Capacitor.getPlatform();
        setInfo({
          isNative: true,
          isAndroid: platform === 'android',
          isIOS: platform === 'ios',
          isWeb: false,
          platform: platform as 'android' | 'ios' | 'web',
        });
      } catch {
        setInfo({ isNative: true, isAndroid: true, isIOS: false, isWeb: false, platform: 'android' });
      }
      return;
    }

    if (NATIVE_MODE_ENABLED) {
      // Override mode on web — treat as native for UI but no real plugins
      setInfo({
        isNative: true,
        isAndroid: true,
        isIOS: false,
        isWeb: false,
        platform: 'android',
      });
      return;
    }
  }, []);

  return info;
};

export const getCapacitorPlatform = (): 'android' | 'ios' | 'web' => {
  if (isRealNativeRuntime()) {
    try {
      return (window as any).Capacitor.getPlatform() as 'android' | 'ios' | 'web';
    } catch {}
  }
  if (NATIVE_MODE_ENABLED) return 'android';
  return 'web';
};
