// Android back button handler for Capacitor
import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { isCapacitorNative } from './useCapacitor';

// Check if real Capacitor runtime is available (not just override)
const hasRealCapacitor = (): boolean => {
  try {
    const Capacitor = (window as any).Capacitor;
    return !!(Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
  } catch { return false; }
};

export const useCapacitorBackButton = () => {
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!isCapacitorNative()) return;
    if (!hasRealCapacitor()) {
      console.log('[Capacitor] Back button — override mode, using browser navigation');
      return;
    }

    let backButtonListener: { remove: () => void } | null = null;

    const setupBackButton = async () => {
      try {
        const AppModule = await import('@capacitor/app').catch(() => null);
        if (!AppModule?.App) return;
        
        const { App } = AppModule;

        backButtonListener = await App.addListener('backButton', ({ canGoBack }: { canGoBack: boolean }) => {
          if (window.history.length > 1 && canGoBack) {
            navigate(-1);
          } else if (location.pathname === '/' || location.pathname === '/discover') {
            App.minimizeApp();
          } else {
            navigate('/');
          }
        });

        console.log('[Capacitor] Back button handler registered');
      } catch {
        console.log('[Capacitor] App plugin not available');
      }
    };

    setupBackButton();

    return () => {
      backButtonListener?.remove();
    };
  }, [navigate, location.pathname]);
};
