import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';

interface AIUsage {
  dailyUsed: number;
  dailyLimit: number;
  monthlyUsed: number;
  monthlyLimit: number;
  loading: boolean;
}

export const useAIUsage = () => {
  const { user } = useAuth();
  const [usage, setUsage] = useState<AIUsage>({
    dailyUsed: 0,
    dailyLimit: 15,
    monthlyUsed: 0,
    monthlyLimit: 300,
    loading: true,
  });

  const fetchUsage = useCallback(async () => {
    if (!user) {
      setUsage(prev => ({ ...prev, loading: false }));
      return;
    }

    try {
      // Get limits from app_settings
      const { data: limitsData } = await supabase
        .from('app_settings')
        .select('value')
        .eq('key', 'ai_usage_limits')
        .single();

      const limits = limitsData?.value as any;
      const dailyLimit = limits?.daily_message_limit || 15;
      const monthlyLimit = limits?.monthly_message_limit || 300;

      // Get current usage
      const periodStart = new Date();
      periodStart.setDate(1);
      const periodKey = periodStart.toISOString().split('T')[0];

      const { data: usageData } = await supabase
        .from('user_ai_usage')
        .select('message_count, daily_message_count, last_message_date')
        .eq('user_id', user.id)
        .eq('period_start', periodKey)
        .maybeSingle();

      const today = new Date().toISOString().split('T')[0];
      const dailyUsed = usageData?.last_message_date === today
        ? (usageData?.daily_message_count || 0)
        : 0;

      setUsage({
        dailyUsed,
        dailyLimit,
        monthlyUsed: usageData?.message_count || 0,
        monthlyLimit,
        loading: false,
      });
    } catch (err) {
      console.error('Failed to fetch AI usage:', err);
      setUsage(prev => ({ ...prev, loading: false }));
    }
  }, [user]);

  useEffect(() => {
    fetchUsage();
  }, [fetchUsage]);

  const dailyRemaining = Math.max(0, usage.dailyLimit - usage.dailyUsed);
  const monthlyRemaining = Math.max(0, usage.monthlyLimit - usage.monthlyUsed);
  const isLimited = dailyRemaining === 0 || monthlyRemaining === 0;

  return {
    ...usage,
    dailyRemaining,
    monthlyRemaining,
    isLimited,
    refresh: fetchUsage,
  };
};
