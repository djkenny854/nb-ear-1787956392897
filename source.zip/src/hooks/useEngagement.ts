import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthContext';
import {
  subscribeInterestedCount,
  setInterestedCount,
  bumpInterestedCount,
  setEngagementUser,
} from './engagementRealtime';

type ContentType = 'ad' | 'post' | 'event' | 'service';
type ClickType = 'item' | 'read_more' | 'video' | 'image' | 'seller' | 'contact' | 'share';
type SourcePage = 'feed' | 'search' | 'details' | 'profile';

// Generate a session ID for anonymous tracking
const getSessionId = () => {
  let sessionId = sessionStorage.getItem('engagement_session_id');
  if (!sessionId) {
    sessionId = crypto.randomUUID();
    sessionStorage.setItem('engagement_session_id', sessionId);
  }
  return sessionId;
};

// Cache of the current user's district/region so we don't refetch on every engagement.
let userLocationCache: { district: string | null; region: string | null; userId: string | null } | null = null;

async function resolveUserLocation(userId: string | null | undefined) {
  if (!userId) return { district: null, region: null };
  if (userLocationCache && userLocationCache.userId === userId) {
    return { district: userLocationCache.district, region: userLocationCache.region };
  }
  try {
    const { data: loc } = await supabase
      .from('user_locations')
      .select('district, region')
      .eq('user_id', userId)
      .order('updated_at', { ascending: false })
      .limit(1)
      .maybeSingle();
    let district = (loc as any)?.district ?? null;
    let region = (loc as any)?.region ?? null;
    if (!district) {
      const { data: prof } = await supabase
        .from('profiles')
        .select('district, region')
        .eq('id', userId)
        .maybeSingle();
      district = (prof as any)?.district ?? district;
      region = (prof as any)?.region ?? region;
    }
    userLocationCache = { userId, district, region };
    return { district, region };
  } catch {
    return { district: null, region: null };
  }
}

export const useEngagement = () => {
  const { user } = useAuth();

  const trackClick = useCallback(async (
    contentId: string,
    contentType: ContentType,
    clickType: ClickType,
    sourcePage: SourcePage = 'feed'
  ) => {
    try {
      await supabase.from('content_clicks').insert({
        user_id: user?.id || null,
        content_id: contentId,
        content_type: contentType,
        click_type: clickType,
        source_page: sourcePage,
      });
    } catch (error) {
      console.error('Error tracking click:', error);
    }
  }, [user?.id]);

  const trackView = useCallback(async (
    contentId: string,
    contentType: ContentType,
    sourcePage: SourcePage = 'feed',
    durationSeconds: number = 5
  ) => {
    try {
      await supabase.from('content_views').insert({
        user_id: user?.id || null,
        content_id: contentId,
        content_type: contentType,
        source_page: sourcePage,
        view_duration_seconds: durationSeconds,
        session_id: getSessionId(),
      });
    } catch (error) {
      console.error('Error tracking view:', error);
    }
  }, [user?.id]);

  return { trackClick, trackView };
};


export const useInterested = (
  contentId: string,
  contentType: ContentType,
  options?: { initialCount?: number; initialInterested?: boolean }
) => {
  const { user } = useAuth();
  const seededCount = options?.initialCount;
  const seededInterested = options?.initialInterested;
  const [isInterested, setIsInterested] = useState(seededInterested ?? false);
  const [isLoading, setIsLoading] = useState(false);
  const [count, setCount] = useState(seededCount ?? 0);

  // Keep the shared realtime manager aware of the current user so it can ignore
  // self-initiated changes (which are applied optimistically).
  useEffect(() => {
    setEngagementUser(user?.id ?? null);
  }, [user?.id]);

  // Sync seeded interested state when it arrives/changes from batched feed data.
  useEffect(() => {
    if (seededInterested !== undefined) setIsInterested(seededInterested);
  }, [seededInterested]);

  useEffect(() => {
    if (!contentId) return;
    let active = true;

    // Single shared channel keeps this card's count in sync.
    const unsubscribe = subscribeInterestedCount(
      contentType,
      contentId,
      seededCount,
      (c) => {
        if (active) setCount(c);
      }
    );

    // Only hit the DB when the count was NOT seeded by the parent (e.g. detail
    // views / standalone buttons). Feed cards seed from batched data => no query.
    if (seededCount === undefined) {
      supabase
        .from('content_engagements')
        .select('*', { count: 'exact', head: true })
        .eq('content_id', contentId)
        .eq('content_type', contentType)
        .eq('engagement_type', 'interested')
        .then(({ count: engagementCount }) => {
          if (active) setInterestedCount(contentType, contentId, engagementCount || 0);
        });
    }

    // Only check the user's own interest when it was not seeded.
    if (user?.id && seededInterested === undefined) {
      supabase
        .from('content_engagements')
        .select('id')
        .eq('user_id', user.id)
        .eq('content_id', contentId)
        .eq('content_type', contentType)
        .eq('engagement_type', 'interested')
        .maybeSingle()
        .then(({ data }) => {
          if (active) setIsInterested(!!data);
        });
    }

    return () => {
      active = false;
      unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [contentId, contentType, user?.id]);

  const toggleInterested = useCallback(async () => {
    if (!user?.id) {
      return false; // Return false to indicate auth required
    }

    setIsLoading(true);

    try {
      if (isInterested) {
        const { error } = await supabase
          .from('content_engagements')
          .delete()
          .eq('user_id', user.id)
          .eq('content_id', contentId)
          .eq('content_type', contentType)
          .eq('engagement_type', 'interested');
        if (error) throw error;

        setIsInterested(false);
        bumpInterestedCount(contentType, contentId, -1);
      } else {
        const { district, region } = await resolveUserLocation(user.id);
        const { error } = await supabase
          .from('content_engagements')
          .insert({
            user_id: user.id,
            content_id: contentId,
            content_type: contentType,
            engagement_type: 'interested',
            district,
            region,
            session_id: getSessionId(),
          } as any);
        if (error) throw error;

        setIsInterested(true);
        bumpInterestedCount(contentType, contentId, 1);
      }
      return true;
    } catch (error) {
      console.error('Error toggling interested:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  }, [user?.id, contentId, contentType, isInterested]);


  return { isInterested, isLoading, count, toggleInterested };
};
