// Deep link handler hook for Capacitor
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { isCapacitorNative } from './useCapacitor';

// Check if real Capacitor runtime is available (not just override)
const hasRealCapacitor = (): boolean => {
  try {
    const Capacitor = (window as any).Capacitor;
    return !!(Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
  } catch { return false; }
};

export const useDeepLinks = () => {
  const navigate = useNavigate();

  useEffect(() => {
    console.log('[DeepLinks] Hook initialized, isCapacitorNative:', isCapacitorNative(), 'hasRealCapacitor:', hasRealCapacitor());
    
    if (!isCapacitorNative()) return;
    if (!hasRealCapacitor()) {
      console.log('[DeepLinks] Override mode — using web URL handling');
      return;
    }

    let listener: { remove: () => void } | null = null;

    const routeFromUrl = (rawUrl: string) => {
      try {
        console.log('[DeepLinks] Routing URL:', rawUrl);

        // SKIP auth callback URLs — those are handled by useNativeAuth
        if (rawUrl.includes('login-callback') ||
            rawUrl.includes('access_token') ||
            rawUrl.includes('code=')) {
          console.log('[DeepLinks] Auth callback URL, skipping (handled by useNativeAuth)');
          return;
        }

        // Support https hosts and the custom earlymarket:// scheme.
        let path = '';
        let search = '';
        try {
          const url = new URL(rawUrl);
          path = url.pathname || '';
          search = url.search || '';
          // earlymarket://product/123 → host is "product", pathname "/123"
          if (url.protocol === 'earlymarket:' && url.host) {
            path = `/${url.host}${url.pathname}`;
          }
        } catch {
          return;
        }

        const known = [
          '/product/', '/seller/', '/business/', '/job/', '/service/',
          '/promotion/', '/event/', '/digital-product/', '/profile/',
        ];
        if (known.some((p) => path.includes(p))) {
          navigate(path + search);
        } else if (path.includes('/marketplace')) navigate('/marketplace' + search);
        else if (path.includes('/messages')) navigate('/messages');
        else if (path.includes('/social')) navigate('/social');
        else if (path.includes('/discover')) navigate('/discover');
        else if (path.includes('/changelog')) navigate('/changelog');
        else if (path && path !== '/') navigate(path + search);
        else navigate('/');
      } catch {
        navigate('/');
      }
    };

    const setup = async () => {
      try {
        const AppModule = await import('@capacitor/app').catch(() => null);
        if (!AppModule?.App) return;

        // Cold start: app launched from a link while it was closed.
        try {
          const launch = await AppModule.App.getLaunchUrl();
          if (launch?.url) {
            console.log('[DeepLinks] Cold-start launch URL:', launch.url);
            routeFromUrl(launch.url);
          }
        } catch (e) {
          console.log('[DeepLinks] getLaunchUrl not available', e);
        }

        // Warm: link opened while app is already running.
        listener = await AppModule.App.addListener('appUrlOpen', (event: { url: string }) => {
          routeFromUrl(event.url);
        });
      } catch (err) {
        console.error('[DeepLinks] Setup failed:', err);
      }
    };

    setup();
    return () => { listener?.remove(); };
  }, [navigate]);
};
