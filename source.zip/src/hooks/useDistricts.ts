import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { ugandaDistricts as fallback, District } from '@/data/ugandaDistricts';

// In-memory cache so we hit the DB once per session.
let cache: District[] | null = null;
let inflight: Promise<District[]> | null = null;

async function loadDistricts(): Promise<District[]> {
  if (cache) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    try {
      const { data: dRows, error } = await supabase
        .from('districts' as any)
        .select('id, slug, name, region')
        .order('name');
      if (error || !dRows?.length) throw error || new Error('no districts');
      const ids = (dRows as any[]).map((r) => r.id);
      const { data: scRows } = await supabase
        .from('sub_counties' as any)
        .select('district_id, name')
        .in('district_id', ids);
      const byDistrict = new Map<string, string[]>();
      (scRows as any[] || []).forEach((s) => {
        const arr = byDistrict.get(s.district_id) || [];
        arr.push(s.name);
        byDistrict.set(s.district_id, arr);
      });
      cache = (dRows as any[]).map((d) => ({
        id: d.slug,
        name: d.name,
        region: d.region,
        subCounties: (byDistrict.get(d.id) || []).sort(),
      }));
      return cache;
    } catch (e) {
      console.warn('[useDistricts] falling back to static data:', e);
      cache = fallback;
      return cache;
    } finally {
      inflight = null;
    }
  })();
  return inflight;
}

export function useDistricts() {
  const [districts, setDistricts] = useState<District[]>(cache || []);
  const [loading, setLoading] = useState(!cache);

  useEffect(() => {
    let cancelled = false;
    if (cache) { setDistricts(cache); setLoading(false); return; }
    loadDistricts().then((d) => {
      if (!cancelled) { setDistricts(d); setLoading(false); }
    });
    return () => { cancelled = true; };
  }, []);

  return { districts, loading };
}

export function getSubCountiesFor(districts: District[], districtName: string): string[] {
  return districts.find((d) => d.name === districtName)?.subCounties || [];
}
