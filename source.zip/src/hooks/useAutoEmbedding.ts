import { supabase } from '@/integrations/supabase/client';

interface EmbeddingInput {
  adId: string;
  title: string;
  description?: string | null;
  category?: string;
  brand?: string | null;
  model?: string | null;
}

/**
 * Generate embedding for an ad after publishing
 * This is fire-and-forget - doesn't block the publish flow
 */
export const generateAdEmbedding = async (input: EmbeddingInput): Promise<void> => {
  try {
    const { adId, title, description, category, brand, model } = input;
    
    // Call the generate-embedding edge function
    const { error } = await supabase.functions.invoke('generate-embedding', {
      body: {
        adId,
        title,
        description,
        category,
        brand,
        model,
      },
    });

    if (error) {
      console.warn('Failed to generate embedding:', error);
      // Don't throw - embedding generation is non-critical
    } else {
      console.log('Embedding generated for ad:', adId);
    }
  } catch (err) {
    console.warn('Error generating embedding:', err);
    // Silently fail - embedding is a nice-to-have
  }
};

/**
 * Hook to use auto-embedding in publish flows
 */
export const useAutoEmbedding = () => {
  return { generateAdEmbedding };
};
