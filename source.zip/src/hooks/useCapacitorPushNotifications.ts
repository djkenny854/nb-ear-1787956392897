// Native Push Notifications hook for Capacitor
import { useEffect, useCallback } from 'react';
import { useAuth } from '@/components/auth/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { useLocation, useNavigate } from 'react-router-dom';
import { isCapacitorNative } from './useCapacitor';
import { toast } from '@/components/ui/use-toast';

// Check if real Capacitor runtime is available
const hasRealCapacitor = (): boolean => {
  try {
    const Capacitor = (window as any).Capacitor;
    return !!(Capacitor && Capacitor.isNativePlatform && Capacitor.isNativePlatform());
  } catch { return false; }
};

interface NotificationData {
  type: 'message' | 'follower' | 'job_application' | 'general';
  title: string;
  body: string;
  data?: Record<string, unknown>;
}

export const useCapacitorPushNotifications = () => {
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const isOnMessagesPage = location.pathname === '/messages';

  // Register for native push notifications and store device token
  useEffect(() => {
    if (!user?.id || !isCapacitorNative() || !hasRealCapacitor()) return;

    let registrationListener: { remove: () => void } | null = null;
    let receivedListener: { remove: () => void } | null = null;
    let actionListener: { remove: () => void } | null = null;

    const setupNativePush = async () => {
      try {
        const PushModule = await import('@capacitor/push-notifications').catch(() => null);
        if (!PushModule?.PushNotifications) return;

        const { PushNotifications } = PushModule;

        // Request permission
        const permResult = await PushNotifications.requestPermissions();
        if (permResult.receive !== 'granted') {
          console.log('[Push] Permission not granted');
          return;
        }

        // Register for push
        await PushNotifications.register();

        // Listen for registration token (FCM/APNs)
        registrationListener = await PushNotifications.addListener('registration', async (token: { value: string }) => {
          console.log('[Push] Device token:', token.value);
          try {
            const platform = (window as any).Capacitor?.getPlatform?.() || 'unknown';
            const appVersion = (window as any).Capacitor?.getAppInfo?.().version || null;
            const { error } = await supabase.from('device_tokens' as any).upsert({
              user_id: user.id,
              token: token.value,
              platform,
              app_version: appVersion,
              last_seen_at: new Date().toISOString(),
            }, { onConflict: 'user_id,token' });
            if (error) console.log('[Push] Token storage error:', error.message);
          } catch (e) {
            console.log('[Push] Could not store device token:', e);
          }
        });

        // Foreground notification — show toast (FCM message already delivered by OS)
        receivedListener = await PushNotifications.addListener('pushNotificationReceived', (notification: any) => {
          toast({
            title: notification.title || '🔔 Notification',
            description: notification.body || '',
            duration: 5000,
          });
        });

        // Notification tapped — route by data.path, honoring quick actions
        actionListener = await PushNotifications.addListener('pushNotificationActionPerformed', (action: any) => {
          const data = action.notification?.data || {};
          const actionId = action.actionId; // 'tap', 'reply', 'mark_read', ...
          const path = data.path || '/notifications';
          if (actionId === 'mark_read' && data.notification_id) {
            supabase.from('notifications').update({ is_read: true }).eq('id', data.notification_id);
            return;
          }
          navigate(path);
        });

        console.log('[Push] Native push notifications registered');
      } catch (err) {
        console.error('[Push] Native push setup failed:', err);
      }
    };

    setupNativePush();

    return () => {
      registrationListener?.remove();
      receivedListener?.remove();
      actionListener?.remove();
    };
  }, [user?.id, navigate]);

  const showLocalNotification = useCallback(async (notification: NotificationData) => {
    // Try native local notification first (works even without FCM)
    if (isCapacitorNative() && hasRealCapacitor()) {
      try {
        const LocalModule = await import('@capacitor/local-notifications').catch(() => null);
        if (LocalModule?.LocalNotifications) {
          // Ensure permission is granted before scheduling
          const permStatus = await LocalModule.LocalNotifications.requestPermissions();
          if (permStatus.display !== 'granted') {
            console.log('[Push] Local notification permission not granted');
            // Fall through to toast fallback
          } else {
          await LocalModule.LocalNotifications.schedule({
            notifications: [{
              id: Math.floor(Math.random() * 100000),
              title: notification.title,
              body: notification.body,
              schedule: { at: new Date(Date.now() + 100) },
              sound: 'notification.wav',
              extra: notification.data,
            }],
          });
          return;
          }
        }
      } catch { /* fall through to toast */ }
    }

    // Fallback: in-app toast
    toast({
      title: notification.title,
      description: notification.body,
      duration: 5000,
    });
  }, []);

  // Realtime message notifications (in-app fallback)
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('capacitor-push-messages')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `recipient_id=eq.${user.id}`,
      }, async (payload) => {
        const newMessage = payload.new as Record<string, unknown>;
        if (newMessage.sender_id === user.id || isOnMessagesPage) return;

        const { data: senderProfile } = await supabase
          .from('seller_profiles')
          .select('business_name')
          .eq('user_id', newMessage.sender_id as string)
          .single();

        const senderName = senderProfile?.business_name || 'Someone';
        const content = newMessage.content as string || '';
        const messagePreview = newMessage.is_voice_message
          ? '🎤 Voice message'
          : content.substring(0, 50) + (content.length > 50 ? '...' : '');

        await showLocalNotification({
          type: 'message',
          title: `💬 ${senderName}`,
          body: messagePreview,
          data: { type: 'message' },
        });
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user?.id, isOnMessagesPage, showLocalNotification]);

  // Realtime general notifications (in-app fallback)
  useEffect(() => {
    if (!user?.id) return;

    const channel = supabase
      .channel('capacitor-push-general')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${user.id}`,
      }, async (payload) => {
        const notification = payload.new as Record<string, unknown>;
        await showLocalNotification({
          type: 'general',
          title: `🔔 ${notification.title as string}`,
          body: notification.message as string,
          data: { type: 'general' },
        });
      })
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [user?.id, showLocalNotification]);

  return { showLocalNotification };
};
