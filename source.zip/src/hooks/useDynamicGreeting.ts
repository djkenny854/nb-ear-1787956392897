import { useMemo } from 'react';

const GENERIC = [
  'What can I help you find?',
  'Looking for a service provider?',
  'Need a verified seller today?',
  'Hunting for the best deals?',
  'Compare prices, pick smart.',
  'Ask me anything about the market.',
  'Discover trending products.',
  'Need someone to fix it fast?',
  'What are you sourcing today?',
  'Find a pro near you.',
  'Curious about a seller?',
  'Let’s find what you really need.',
  'Ready to explore EarlyMarket?',
];

const MORNING = [
  'Good morning{name}. What’s the plan?',
  'Bright and early{name} — what shall we find?',
  'Morning{name}, let’s get to work.',
];

const AFTERNOON = [
  'Good afternoon{name}. What’s on your mind?',
  'Afternoon{name} — need a hand finding something?',
];

const EVENING = [
  'Good evening{name}. What are we looking for?',
  'Evening{name}, ready to explore?',
];

const LATE_NIGHT = [
  'Night owl{name} — what brings you here?',
  'Burning the midnight oil{name}?',
  'Late night browsing{name}?',
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function useDynamicGreeting(userName?: string, seed?: number): string {
  return useMemo(() => {
    const name = userName ? `, ${userName.split(' ')[0]}` : '';
    const hour = new Date().getHours();

    // 60% chance a time-aware greeting, otherwise pull a generic prompt-style one
    const useTime = Math.random() < 0.6;
    if (useTime) {
      let pool = AFTERNOON;
      if (hour < 5 || hour >= 23) pool = LATE_NIGHT;
      else if (hour < 12) pool = MORNING;
      else if (hour < 17) pool = AFTERNOON;
      else pool = EVENING;
      return pick(pool).replace('{name}', name);
    }
    return pick(GENERIC);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userName, seed]);
}
