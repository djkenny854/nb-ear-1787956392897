
export interface District {
  id: string;
  name: string;
  region: string;
  subCounties: string[];
}

export const ugandaDistricts: District[] = [
  // Central Region
  {
    id: "kampala",
    name: "Kampala",
    region: "Central",
    subCounties: ["Central Division", "Kawempe Division", "Makindye Division", "Nakawa Division", "Rubaga Division"]
  },
  {
    id: "wakiso",
    name: "Wakiso",
    region: "Central",
    subCounties: ["Busukuma", "Katabi", "Kira", "Makindye-Ssabagabo", "Nangabo", "Nsangi", "Wakiso"]
  },
  {
    id: "mukono",
    name: "Mukono",
    region: "Central",
    subCounties: ["Goma", "Kasawo", "Mukono", "Ntenjeru", "Seeta-Namuganga"]
  },
  {
    id: "masaka",
    name: "Masaka",
    region: "Central",
    subCounties: ["Katwe", "Kimanya", "Masaka", "Mukungwe", "Nyendo"]
  },
  {
    id: "mpigi",
    name: "Mpigi",
    region: "Central",
    subCounties: ["Mpigi", "Muduma", "Kituntu", "Buwama", "Nkozi"]
  },
  {
    id: "rakai",
    name: "Rakai",
    region: "Central",
    subCounties: ["Rakai", "Kakuuto", "Kyotera", "Dwaniro", "Lwamaggwa"]
  },
  {
    id: "kalangala",
    name: "Kalangala",
    region: "Central",
    subCounties: ["Kalangala", "Bugala", "Bukasa", "Bufumira", "Buggala"]
  },
  {
    id: "butambala",
    name: "Butambala",
    region: "Central",
    subCounties: ["Butambala", "Gombe", "Kibibi", "Tabuka", "Kalamba"]
  },
  {
    id: "gomba",
    name: "Gomba",
    region: "Central",
    subCounties: ["Gomba", "Kanoni", "Kabulasoke", "Maddu", "Mpenja"]
  },
  {
    id: "kalungu",
    name: "Kalungu",
    region: "Central",
    subCounties: ["Kalungu", "Bukulula", "Lwabenge", "Kyanamukaaka", "Kabaganda"]
  },
  {
    id: "kyotera",
    name: "Kyotera",
    region: "Central",
    subCounties: ["Kyotera", "Kalisizo", "Kakuuto", "Lwankoni", "Mutukula"]
  },
  {
    id: "lwengo",
    name: "Lwengo",
    region: "Central",
    subCounties: ["Lwengo", "Kyazanga", "Ndagwe", "Malongo", "Kayunga"]
  },
  {
    id: "lyantonde",
    name: "Lyantonde",
    region: "Central",
    subCounties: ["Lyantonde", "Kabira", "Kaliiro", "Kinuuka", "Bigasa"]
  },
  {
    id: "bukomansimbi",
    name: "Bukomansimbi",
    region: "Central",
    subCounties: ["Bukomansimbi", "Kibanda", "Bigasa", "Bukulula", "Kisekka"]
  },
  {
    id: "kassanda",
    name: "Kassanda",
    region: "Central",
    subCounties: ["Kassanda", "Mubende", "Kiganda", "Bukuya", "Mitala"]
  },
  {
    id: "mubende",
    name: "Mubende",
    region: "Central",
    subCounties: ["Mubende", "Kasanda", "Kiganda", "Bukuya", "Mitala"]
  },
  {
    id: "mityana",
    name: "Mityana",
    region: "Central",
    subCounties: ["Mityana", "Busujju", "Zigoti", "Malangala", "Sekanyonyi"]
  },
  {
    id: "kiboga",
    name: "Kiboga",
    region: "Central",
    subCounties: ["Kiboga", "Bukomero", "Dwaniro", "Kagadi", "Lwamata"]
  },
  {
    id: "nakaseke",
    name: "Nakaseke",
    region: "Central",
    subCounties: ["Nakaseke", "Semuto", "Kapeeka", "Kasangombe", "Kikamulo"]
  },
  {
    id: "luwero",
    name: "Luwero",
    region: "Central",
    subCounties: ["Luwero", "Bombo", "Wobulenzi", "Zirobwe", "Makulubita"]
  },
  {
    id: "nakasongola",
    name: "Nakasongola",
    region: "Central",
    subCounties: ["Nakasongola", "Lwampanga", "Wabinyonyi", "Kalongo", "Nabiswera"]
  },
  {
    id: "kayunga",
    name: "Kayunga",
    region: "Central",
    subCounties: ["Kayunga", "Bbale", "Busaana", "Kangulumira", "Nazigo"]
  },
  {
    id: "buvuma",
    name: "Buvuma",
    region: "Central",
    subCounties: ["Buvuma", "Bunyama", "Bwondha", "Kiyindi", "Mpunge"]
  },

  // Eastern Region
  {
    id: "jinja",
    name: "Jinja",
    region: "Eastern",
    subCounties: ["Budondo", "Bugembe", "Jinja", "Kakira", "Kimaka"]
  },
  {
    id: "mbale",
    name: "Mbale",
    region: "Eastern",
    subCounties: ["Bufumbo", "Bungokho", "Mbale", "Wanale", "Malukhu"]
  },
  {
    id: "soroti",
    name: "Soroti",
    region: "Eastern",
    subCounties: ["Arapai", "Gweri", "Kamuda", "Opiyai", "Soroti", "Tubur"]
  },
  {
    id: "tororo",
    name: "Tororo",
    region: "Eastern",
    subCounties: ["Tororo", "Nagongera", "Mulanda", "Kirewa", "Kisoko"]
  },
  {
    id: "busia",
    name: "Busia",
    region: "Eastern",
    subCounties: ["Busia", "Masafu", "Lumino", "Dabani", "Sikuda"]
  },
  {
    id: "iganga",
    name: "Iganga",
    region: "Eastern",
    subCounties: ["Iganga", "Namalemba", "Namungalwe", "Kigandalo", "Namayingo"]
  },
  {
    id: "kamuli",
    name: "Kamuli",
    region: "Eastern",
    subCounties: ["Kamuli", "Butebo", "Namasagali", "Balawoli", "Gadumire"]
  },
  {
    id: "pallisa",
    name: "Pallisa",
    region: "Eastern",
    subCounties: ["Pallisa", "Agule", "Butebo", "Kakoro", "Kasodo"]
  },
  {
    id: "kumi",
    name: "Kumi",
    region: "Eastern",
    subCounties: ["Kumi", "Mukongoro", "Tisai", "Atutur", "Ongino"]
  },
  {
    id: "kapchorwa",
    name: "Kapchorwa",
    region: "Eastern",
    subCounties: ["Kapchorwa", "Kaptanya", "Tegeres", "Cheminy", "Kaproron"]
  },
  {
    id: "katakwi",
    name: "Katakwi",
    region: "Eastern",
    subCounties: ["Katakwi", "Usuk", "Magoro", "Ngariam", "Obalanga"]
  },
  {
    id: "amuria",
    name: "Amuria",
    region: "Eastern",
    subCounties: ["Amuria", "Orungo", "Kapelebyong", "Asamuk", "Ogera"]
  },
  {
    id: "budaka",
    name: "Budaka",
    region: "Eastern",
    subCounties: ["Budaka", "Kaderuna", "Naboa", "Tirinyi", "Kagoma"]
  },
  {
    id: "bududa",
    name: "Bududa",
    region: "Eastern",
    subCounties: ["Bududa", "Bubiita", "Bushika", "Bulucheke", "Bukalasi"]
  },
  {
    id: "bukwa",
    name: "Bukwa",
    region: "Eastern",
    subCounties: ["Bukwa", "Riwo", "Suam", "Chesower", "Kachumbala"]
  },
  {
    id: "bulambuli",
    name: "Bulambuli",
    region: "Eastern",
    subCounties: ["Bulambuli", "Bulegeni", "Buluganya", "Budadiri", "Buwalasi"]
  },
  {
    id: "butaleja",
    name: "Butaleja",
    region: "Eastern",
    subCounties: ["Butaleja", "Kadama", "Busolwe", "Mazimasa", "Kachonga"]
  },
  {
    id: "butebo",
    name: "Butebo",
    region: "Eastern",
    subCounties: ["Butebo", "Mazimasa", "Himutu", "Kachonga", "Malaba"]
  },
  {
    id: "buyende",
    name: "Buyende",
    region: "Eastern",
    subCounties: ["Buyende", "Kidera", "Kagulu", "Nankandulo", "Buseta"]
  },
  {
    id: "kaliro",
    name: "Kaliro",
    region: "Eastern",
    subCounties: ["Kaliro", "Nankulabye", "Gadumire", "Nawaikoke", "Bumanya"]
  },
  {
    id: "kibuku",
    name: "Kibuku",
    region: "Eastern",
    subCounties: ["Kibuku", "Lwakhakha", "Kamonkoli", "Kidongole", "Sironko"]
  },
  {
    id: "kween",
    name: "Kween",
    region: "Eastern",
    subCounties: ["Kween", "Kaproron", "Kwoti", "Ngenge", "Binyiny"]
  },
  {
    id: "luuka",
    name: "Luuka",
    region: "Eastern",
    subCounties: ["Luuka", "Kiyunga", "Irongo", "Busembatya", "Wairasa"]
  },
  {
    id: "manafwa",
    name: "Manafwa",
    region: "Eastern",
    subCounties: ["Manafwa", "Namakwekwe", "Buwenge", "Mayuge", "Wairasa"]
  },
  {
    id: "mayuge",
    name: "Mayuge",
    region: "Eastern",
    subCounties: ["Mayuge", "Baitambogwe", "Kityerera", "Malongo", "Imanyiro"]
  },
  {
    id: "namayingo",
    name: "Namayingo",
    region: "Eastern",
    subCounties: ["Namayingo", "Sigulu", "Banda", "Buwunga", "Namayingo"]
  },
  {
    id: "namutumba",
    name: "Namutumba",
    region: "Eastern",
    subCounties: ["Namutumba", "Magada", "Nabiganda", "Busede", "Budumba"]
  },
  {
    id: "ngora",
    name: "Ngora",
    region: "Eastern",
    subCounties: ["Ngora", "Mukura", "Ngora", "Kuju", "Dakabela"]
  },
  {
    id: "serere",
    name: "Serere",
    region: "Eastern",
    subCounties: ["Serere", "Pingire", "Olio", "Kadungulu", "Kasilo"]
  },
  {
    id: "sironko",
    name: "Sironko",
    region: "Eastern",
    subCounties: ["Sironko", "Budadiri", "Buwalasi", "Zesui", "Bubiita"]
  },

  // Northern Region
  {
    id: "gulu",
    name: "Gulu",
    region: "Northern",
    subCounties: ["Aswa", "Bardege", "Bungatira", "Gulu", "Laroo", "Layibi", "Pece"]
  },
  {
    id: "lira",
    name: "Lira",
    region: "Northern",
    subCounties: ["Adekokwok", "Agweng", "Aromo", "Barr", "Lira"]
  },
  {
    id: "arua",
    name: "Arua",
    region: "Northern",
    subCounties: ["Arua", "Dadamu", "Oluko", "Pajulu", "Rhino Camp", "Vurra"]
  },
  {
    id: "koboko",
    name: "Koboko",
    region: "Northern",
    subCounties: ["Koboko", "Kuluba", "Ludara", "Midia"]
  },
  {
    id: "kitgum",
    name: "Kitgum",
    region: "Northern",
    subCounties: ["Kitgum", "Mucwini", "Namokora", "Akwang", "Lagoro"]
  },
  {
    id: "pader",
    name: "Pader",
    region: "Northern",
    subCounties: ["Pader", "Aromo", "Atanga", "Purongo", "Pajule"]
  },
  {
    id: "yumbe",
    name: "Yumbe",
    region: "Northern",
    subCounties: ["Yumbe", "Kei", "Kululu", "Midigo", "Apo"]
  },
  {
    id: "nebbi",
    name: "Nebbi",
    region: "Northern",
    subCounties: ["Nebbi", "Wadelai", "Panyimur", "Kucwiny", "Erussi"]
  },
  {
    id: "adjumani",
    name: "Adjumani",
    region: "Northern",
    subCounties: ["Adjumani", "Dzaipi", "Ofua", "Pakele", "Rigbo"]
  },
  {
    id: "moyo",
    name: "Moyo",
    region: "Northern",
    subCounties: ["Moyo", "Dufile", "Gimara", "Itula", "Lefori"]
  },
  {
    id: "amuru",
    name: "Amuru",
    region: "Northern",
    subCounties: ["Amuru", "Atiak", "Lamogi", "Pabbo", "Kalongo"]
  },
  {
    id: "nwoya",
    name: "Nwoya",
    region: "Northern",
    subCounties: ["Nwoya", "Anaka", "Purongo", "Koch", "Alero"]
  },
  {
    id: "lamwo",
    name: "Lamwo",
    region: "Northern",
    subCounties: ["Lamwo", "Palabek", "Agago", "Padibe", "Lokung"]
  },
  {
    id: "agago",
    name: "Agago",
    region: "Northern",
    subCounties: ["Agago", "Patongo", "Wol", "Kalongo", "Lira-Palwo"]
  },
  {
    id: "zombo",
    name: "Zombo",
    region: "Northern",
    subCounties: ["Zombo", "Paidha", "Warr", "Kango", "Atyak"]
  },
  {
    id: "pakwach",
    name: "Pakwach",
    region: "Northern",
    subCounties: ["Pakwach", "Panyimur", "Wadelai", "Jonam", "Panyango"]
  },
  {
    id: "maracha",
    name: "Maracha",
    region: "Northern",
    subCounties: ["Maracha", "Nyadri", "Ovujo", "Kijomoro", "Dryad"]
  },
  {
    id: "terego",
    name: "Terego",
    region: "Northern",
    subCounties: ["Terego", "Uriama", "Ofua", "Rigbo", "Ayivu"]
  },
  {
    id: "madi-okollo",
    name: "Madi-Okollo",
    region: "Northern",
    subCounties: ["Madi-Okollo", "Rigbo", "Dzaipi", "Ofua", "Zoka"]
  },
  {
    id: "obongi",
    name: "Obongi",
    region: "Northern",
    subCounties: ["Obongi", "Palorinya", "Gimara", "Itula", "Moyo"]
  },

  // Western Region
  {
    id: "mbarara",
    name: "Mbarara",
    region: "Western",
    subCounties: ["Biharwe", "Gwakara", "Kakiika", "Kamukuzi", "Kashare", "Mbarara", "Nyakayojo"]
  },
  {
    id: "kasese",
    name: "Kasese",
    region: "Western",
    subCounties: ["Bugoye", "Hima", "Kasese", "Kitswamba", "Mahango", "Munkunyu"]
  },
  {
    id: "hoima",
    name: "Hoima",
    region: "Western",
    subCounties: ["Bujumbura", "Hoima", "Kabukye", "Kigorobya", "Kyabigambire"]
  },
  {
    id: "fort-portal",
    name: "Fort Portal",
    region: "Western",
    subCounties: ["Fort Portal", "Hakibale", "Karambi", "North Division", "South Division"]
  },
  {
    id: "kabale",
    name: "Kabale",
    region: "Western",
    subCounties: ["Kabale", "Bubaare", "Kamuganguzi", "Kitumba", "Maziba"]
  },
  {
    id: "bundibugyo",
    name: "Bundibugyo",
    region: "Western",
    subCounties: ["Bundibugyo", "Bubukwanga", "Bughendera", "Busaru", "Harugongo"]
  },
  {
    id: "bushenyi",
    name: "Bushenyi",
    region: "Western",
    subCounties: ["Bushenyi", "Bumbaire", "Kyeizooba", "Kizinda", "Ishaka"]
  },
  {
    id: "ntungamo",
    name: "Ntungamo",
    region: "Western",
    subCounties: ["Ntungamo", "Bitereko", "Kajara", "Rubaare", "Rwashamaire"]
  },
  {
    id: "kanungu",
    name: "Kanungu",
    region: "Western",
    subCounties: ["Kanungu", "Kambuga", "Kihihi", "Nyamirama", "Rugyeyo"]
  },
  {
    id: "kisoro",
    name: "Kisoro",
    region: "Western",
    subCounties: ["Kisoro", "Bufumbira", "Chahi", "Murora", "Nyakabande"]
  },
  {
    id: "rukungiri",
    name: "Rukungiri",
    region: "Western",
    subCounties: ["Rukungiri", "Bitereko", "Buyanja", "Kebisoni", "Nyakishenyi"]
  },
  {
    id: "kabarole",
    name: "Kabarole",
    region: "Western",
    subCounties: ["Kabarole", "Bunyangabu", "Harugongo", "Kyenjojo", "Rwimi"]
  },
  {
    id: "kamwenge",
    name: "Kamwenge",
    region: "Western",
    subCounties: ["Kamwenge", "Bigodi", "Mahyoro", "Mpara", "Rukoki"]
  },
  {
    id: "kyenjojo",
    name: "Kyenjojo",
    region: "Western",
    subCounties: ["Kyenjojo", "Hakibaale", "Mahyoro", "Mpara", "Tecumsech"]
  },
  {
    id: "masindi",
    name: "Masindi",
    region: "Western",
    subCounties: ["Masindi", "Bujenje", "Kigumba", "Miirya", "Pakanyi"]
  },
  {
    id: "kibaale",
    name: "Kibaale",
    region: "Western",
    subCounties: ["Kibaale", "Kagadi", "Mabaale", "Muchwa", "Nyantonzi"]
  },
  {
    id: "ibanda",
    name: "Ibanda",
    region: "Western",
    subCounties: ["Ibanda", "Bisheshe", "Bufunda", "Kagongo", "Nyabbani"]
  },
  {
    id: "isingiro",
    name: "Isingiro",
    region: "Western",
    subCounties: ["Isingiro", "Bukanga", "Endinzi", "Kabuyanda", "Kikagate"]
  },
  {
    id: "kiruhura",
    name: "Kiruhura",
    region: "Western",
    subCounties: ["Kiruhura", "Engari", "Kenshunga", "Kikagate", "Nshaara"]
  },
  {
    id: "mitooma",
    name: "Mitooma",
    region: "Western",
    subCounties: ["Mitooma", "Bitereko", "Bushenyi", "Kambuga", "Ruhinda"]
  },
  {
    id: "rubirizi",
    name: "Rubirizi",
    region: "Western",
    subCounties: ["Rubirizi", "Bunyaruguru", "Kichwamba", "Rubirizi", "Ryeru"]
  },
  {
    id: "sheema",
    name: "Sheema",
    region: "Western",
    subCounties: ["Sheema", "Kabwohe", "Kitagata", "Masheruka", "Shuuku"]
  },
  {
    id: "buhweju",
    name: "Buhweju",
    region: "Western",
    subCounties: ["Buhweju", "Bitooma", "Engari", "Nsiika", "Rwamwanja"]
  },
  {
    id: "buliisa",
    name: "Buliisa",
    region: "Western",
    subCounties: ["Buliisa", "Biiso", "Butiaba", "Kigwera", "Ngwedo"]
  },
  {
    id: "kyegegwa",
    name: "Kyegegwa",
    region: "Western",
    subCounties: ["Kyegegwa", "Mpara", "Kyaka", "Rwebikoona", "Rwamwanja"]
  },
  {
    id: "kakumiro",
    name: "Kakumiro",
    region: "Western",
    subCounties: ["Kakumiro", "Kakumiro", "Kibaale", "Mpeefu", "Nyantonzi"]
  },
  {
    id: "kagadi",
    name: "Kagadi",
    region: "Western",
    subCounties: ["Kagadi", "Kibaale", "Mabaale", "Muchwa", "Nyantonzi"]
  },
  {
    id: "kikuube",
    name: "Kikuube",
    region: "Western",
    subCounties: ["Kikuube", "Bugambe", "Buhuka", "Kyangwali", "Kyangwali"]
  },
  {
    id: "rubanda",
    name: "Rubanda",
    region: "Western",
    subCounties: ["Rubanda", "Bubaare", "Hamurwa", "Ikumba", "Muko"]
  },
  {
    id: "rukiga",
    name: "Rukiga",
    region: "Western",
    subCounties: ["Rukiga", "Kamwezi", "Muhanga", "Nyakambu", "Rwamucucu"]
  },
  {
    id: "rwampara",
    name: "Rwampara",
    region: "Western",
    subCounties: ["Rwampara", "Mwizi", "Nyakashashara", "Rwemikoma", "Rwanyamahembe"]
  },
  {
    id: "bunyangabu",
    name: "Bunyangabu",
    region: "Western",
    subCounties: ["Bunyangabu", "Harugongo", "Karangura", "Ntoroko", "Rwimi"]
  },
  {
    id: "ntoroko",
    name: "Ntoroko",
    region: "Western",
    subCounties: ["Ntoroko", "Bweramule", "Karugutu", "Kikorongo", "Rwebisengo"]
  }
];

export const getDistricts = (): District[] => {
  return ugandaDistricts;
};

export const getSubCounties = (districtName: string): string[] => {
  const district = ugandaDistricts.find(d => d.name.toLowerCase() === districtName.toLowerCase());
  return district ? district.subCounties : [];
};
