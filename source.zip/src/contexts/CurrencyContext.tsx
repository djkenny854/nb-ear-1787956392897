import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { useGlobalSettings } from '@/contexts/AppSettingsContext';

// Fallback exchange rates (used when API fails - base is UGX)
const FALLBACK_RATES: { [key: string]: number } = {
  UGX: 1,
  USD: 0.00027, // 1 UGX = 0.00027 USD (1 USD ≈ 3,700 UGX)
  KES: 0.035,   // 1 UGX = 0.035 KES (1 KES ≈ 28.5 UGX)
  EUR: 0.00025, // 1 UGX = 0.00025 EUR
  GBP: 0.00021, // 1 UGX = 0.00021 GBP
  TZS: 0.68,    // 1 UGX = 0.68 TZS
  RWF: 0.33,    // 1 UGX = 0.33 RWF
};

// Cache key for storing exchange rates
const RATES_CACHE_KEY = 'exchange_rates_cache';
const RATES_CACHE_EXPIRY_KEY = 'exchange_rates_cache_expiry';
const CACHE_DURATION_MS = 6 * 60 * 60 * 1000; // 6 hours

const CURRENCY_SYMBOLS: { [key: string]: string } = {
  UGX: 'UGX',
  USD: '$',
  KES: 'KES',
  EUR: '€',
  GBP: '£',
  TZS: 'TZS',
  RWF: 'RWF',
};

const CURRENCY_NAMES: { [key: string]: string } = {
  UGX: 'Ugandan Shilling',
  USD: 'US Dollar',
  KES: 'Kenyan Shilling',
  EUR: 'Euro',
  GBP: 'British Pound',
  TZS: 'Tanzanian Shilling',
  RWF: 'Rwandan Franc',
};

interface CurrencyContextType {
  currency: string;
  setCurrency: (currency: string) => void;
  convertPrice: (priceInUGX: number) => number;
  formatPrice: (priceInUGX: number, showSymbol?: boolean) => string;
  formatPriceCompact: (priceInUGX: number) => string;
  getCurrencySymbol: () => string;
  getCurrencyName: () => string;
  availableCurrencies: string[];
  exchangeRates: { [key: string]: number };
  isLoading: boolean;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { settings, saveSettings } = useGlobalSettings();
  const [currency, setCurrencyState] = useState<string>(() => {
    // Initialize from localStorage for immediate effect
    const stored = localStorage.getItem('app_currency');
    return stored || settings.currency || 'UGX';
  });
  const [exchangeRates, setExchangeRates] = useState<{ [key: string]: number }>(FALLBACK_RATES);
  const [isLoading, setIsLoading] = useState(false);
  const hasFetchedRates = useRef(false);

  // Fetch live exchange rates from API
  const fetchExchangeRates = useCallback(async () => {
    // Check cache first
    const cachedRates = localStorage.getItem(RATES_CACHE_KEY);
    const cacheExpiry = localStorage.getItem(RATES_CACHE_EXPIRY_KEY);
    
    if (cachedRates && cacheExpiry && Date.now() < parseInt(cacheExpiry)) {
      try {
        const parsed = JSON.parse(cachedRates);
        setExchangeRates(parsed);
        console.log('Using cached exchange rates');
        return;
      } catch (e) {
        console.error('Failed to parse cached rates:', e);
      }
    }

    setIsLoading(true);
    try {
      // Using exchangerate-api.com free tier (no API key needed for basic usage)
      // Base currency is UGX, we fetch rates relative to USD then convert
      const response = await fetch('https://api.exchangerate-api.com/v4/latest/USD');
      
      if (!response.ok) {
        throw new Error('Failed to fetch exchange rates');
      }
      
      const data = await response.json();
      
      // Convert rates to be relative to UGX (our base currency)
      // data.rates gives us how much of each currency = 1 USD
      const usdToUgx = data.rates.UGX || 3700; // fallback
      
      const newRates: { [key: string]: number } = {
        UGX: 1,
        USD: 1 / usdToUgx,
        KES: (data.rates.KES || 130) / usdToUgx,
        EUR: (data.rates.EUR || 0.92) / usdToUgx,
        GBP: (data.rates.GBP || 0.79) / usdToUgx,
        TZS: (data.rates.TZS || 2500) / usdToUgx,
        RWF: (data.rates.RWF || 1200) / usdToUgx,
      };
      
      setExchangeRates(newRates);
      
      // Cache the rates
      localStorage.setItem(RATES_CACHE_KEY, JSON.stringify(newRates));
      localStorage.setItem(RATES_CACHE_EXPIRY_KEY, (Date.now() + CACHE_DURATION_MS).toString());
      
      console.log('Fetched live exchange rates:', newRates);
    } catch (error) {
      console.error('Failed to fetch exchange rates, using fallback:', error);
      setExchangeRates(FALLBACK_RATES);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Fetch rates on mount
  useEffect(() => {
    if (!hasFetchedRates.current) {
      hasFetchedRates.current = true;
      fetchExchangeRates();
    }
  }, [fetchExchangeRates]);

  // Sync with global settings - this is the key fix
  useEffect(() => {
    if (settings.currency && settings.currency !== currency) {
      setCurrencyState(settings.currency);
      localStorage.setItem('app_currency', settings.currency);
    }
  }, [settings.currency, currency]);

  const setCurrency = useCallback((newCurrency: string) => {
    setCurrencyState(newCurrency);
    saveSettings({ currency: newCurrency });
    localStorage.setItem('app_currency', newCurrency);
  }, [saveSettings]);

  // Convert price from UGX to selected currency
  const convertPrice = useCallback((priceInUGX: number): number => {
    if (!priceInUGX || isNaN(priceInUGX)) return 0;
    const rate = exchangeRates[currency] || 1;
    return priceInUGX * rate;
  }, [currency, exchangeRates]);

  // Format price with currency symbol
  const formatPrice = useCallback((priceInUGX: number, showSymbol: boolean = true): string => {
    const converted = convertPrice(priceInUGX);
    const symbol = showSymbol ? CURRENCY_SYMBOLS[currency] || currency : '';
    
    // Different formatting based on currency
    if (currency === 'USD' || currency === 'EUR' || currency === 'GBP') {
      // Format with decimals for major currencies
      return `${symbol}${converted.toLocaleString('en-US', { 
        minimumFractionDigits: 2, 
        maximumFractionDigits: 2 
      })}`;
    }
    
    // Format without decimals for African currencies
    return `${symbol} ${Math.round(converted).toLocaleString()}`;
  }, [currency, convertPrice]);

  // Format price in compact form (e.g., 1.5M, 500K)
  const formatPriceCompact = useCallback((priceInUGX: number): string => {
    const converted = convertPrice(priceInUGX);
    const symbol = CURRENCY_SYMBOLS[currency] || currency;
    
    if (currency === 'USD' || currency === 'EUR' || currency === 'GBP') {
      // Major currencies - show actual value since conversion makes it smaller
      if (converted >= 1000000) {
        return `${symbol}${(converted / 1000000).toFixed(1)}M`;
      }
      if (converted >= 1000) {
        return `${symbol}${(converted / 1000).toFixed(1)}K`;
      }
      return `${symbol}${converted.toFixed(2)}`;
    }
    
    // African currencies - larger numbers
    if (converted >= 1000000) {
      return `${symbol} ${(converted / 1000000).toFixed(1)}M`;
    }
    if (converted >= 1000) {
      return `${symbol} ${(converted / 1000).toFixed(0)}K`;
    }
    return `${symbol} ${Math.round(converted).toLocaleString()}`;
  }, [currency, convertPrice]);

  const getCurrencySymbol = useCallback(() => {
    return CURRENCY_SYMBOLS[currency] || currency;
  }, [currency]);

  const getCurrencyName = useCallback(() => {
    return CURRENCY_NAMES[currency] || currency;
  }, [currency]);

  const availableCurrencies = Object.keys(FALLBACK_RATES);

  return (
    <CurrencyContext.Provider value={{
      currency,
      setCurrency,
      convertPrice,
      formatPrice,
      formatPriceCompact,
      getCurrencySymbol,
      getCurrencyName,
      availableCurrencies,
      exchangeRates,
      isLoading,
    }}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (!context) {
    // Return a fallback for when context is not available
    return {
      currency: 'UGX',
      setCurrency: () => {},
      convertPrice: (price: number) => price,
      formatPrice: (price: number) => `UGX ${price.toLocaleString()}`,
      formatPriceCompact: (price: number) => {
        if (price >= 1000000) return `UGX ${(price / 1000000).toFixed(1)}M`;
        if (price >= 1000) return `UGX ${(price / 1000).toFixed(0)}K`;
        return `UGX ${price.toLocaleString()}`;
      },
      getCurrencySymbol: () => 'UGX',
      getCurrencyName: () => 'Ugandan Shilling',
      availableCurrencies: ['UGX', 'USD', 'KES'],
      exchangeRates: FALLBACK_RATES,
      isLoading: false,
    };
  }
  return context;
};

export type { CurrencyContextType };
