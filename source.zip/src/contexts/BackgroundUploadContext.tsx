import React, { createContext, useCallback, useContext, useRef, useState } from 'react';
import { toast } from '@/hooks/use-toast';
import BackgroundUploadDock from '@/components/upload/BackgroundUploadDock';
import PublishSuccessDialog from '@/components/publish/PublishSuccessDialog';

export interface UploadSuccess {
  listingId: string;
  listingType: string;
  title: string;
  description?: string;
  imageUrl?: string;
}

export interface UploadJob {
  id: string;
  label: string;
  progress: number;
  status: 'running' | 'success' | 'error';
  error?: string;
  result?: UploadSuccess;
}

type Runner = (report: (progress: number, label?: string) => void) => Promise<UploadSuccess>;

interface BackgroundUploadContextValue {
  startJob: (label: string, runner: Runner) => string;
}

const BackgroundUploadContext = createContext<BackgroundUploadContextValue | null>(null);

export function useBackgroundUpload() {
  const ctx = useContext(BackgroundUploadContext);
  if (!ctx) throw new Error('useBackgroundUpload must be used inside BackgroundUploadProvider');
  return ctx;
}

export const BackgroundUploadProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [jobs, setJobs] = useState<UploadJob[]>([]);
  const [success, setSuccess] = useState<UploadSuccess | null>(null);
  const runnersRef = useRef<Map<string, { label: string; runner: Runner }>>(new Map());

  const updateJob = useCallback((id: string, patch: Partial<UploadJob>) => {
    setJobs(prev => prev.map(j => (j.id === id ? { ...j, ...patch } : j)));
  }, []);

  const removeJob = useCallback((id: string) => {
    setJobs(prev => prev.filter(j => j.id !== id));
    runnersRef.current.delete(id);
  }, []);

  const execute = useCallback(async (id: string, label: string, runner: Runner) => {
    try {
      const result = await runner((progress, newLabel) => {
        updateJob(id, { progress: Math.max(0, Math.min(100, progress)), ...(newLabel ? { label: newLabel } : {}) });
      });
      updateJob(id, { status: 'success', progress: 100, result });
      setSuccess(result);
      toast({ title: '✅ Published', description: result.title });
      // Auto-remove pill after a moment
      setTimeout(() => removeJob(id), 1500);
    } catch (err: any) {
      console.error('Background upload failed:', err);
      updateJob(id, { status: 'error', error: err?.message || 'Upload failed' });
      toast({ title: 'Upload failed', description: err?.message || 'Something went wrong', variant: 'destructive' });
    }
  }, [updateJob, removeJob]);

  const startJob = useCallback((label: string, runner: Runner) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    runnersRef.current.set(id, { label, runner });
    setJobs(prev => [...prev, { id, label, progress: 0, status: 'running' }]);
    void execute(id, label, runner);
    return id;
  }, [execute]);

  const retryJob = useCallback((id: string) => {
    const entry = runnersRef.current.get(id);
    if (!entry) return;
    updateJob(id, { status: 'running', progress: 0, error: undefined });
    void execute(id, entry.label, entry.runner);
  }, [execute, updateJob]);

  return (
    <BackgroundUploadContext.Provider value={{ startJob }}>
      {children}
      <BackgroundUploadDock jobs={jobs} onRetry={retryJob} onDismiss={removeJob} />
      <PublishSuccessDialog
        open={!!success}
        onOpenChange={(open) => { if (!open) setSuccess(null); }}
        title={success?.title || ''}
        description={success?.description}
        imageUrl={success?.imageUrl}
        listingId={success?.listingId}
        listingType={success?.listingType || 'post'}
      />
    </BackgroundUploadContext.Provider>
  );
};