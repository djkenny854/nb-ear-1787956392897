/**
 * EarlyMarket video streaming worker.
 *
 * Sits in front of the public Backblaze B2 bucket and:
 *   - forwards HTTP Range requests verbatim (enables progressive playback)
 *   - returns 206 / Content-Range for partial responses
 *   - sets long-lived immutable cache + Accept-Ranges so Cloudflare's edge
 *     keeps the bytes hot for every user in the region
 *   - answers CORS preflight (OPTIONS) and HEAD requests correctly
 *
 * Accepted URL shapes (all map onto the same B2 object):
 *   https://videos.earlymarketug.com/file/<bucket>/<key>
 *   https://videos.earlymarketug.com/<key>                  (bucket from env)
 *   https://videos.earlymarketug.com/?key=<key>             (legacy fallback)
 */

export interface Env {
  B2_ORIGIN: string;
  B2_BUCKET: string;
}

const BASE_CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
  "Access-Control-Allow-Headers": "Range, Content-Type",
  "Access-Control-Expose-Headers":
    "Content-Range, Accept-Ranges, Content-Length, Content-Type",
};

function buildUpstreamUrl(req: Request, env: Env): string | null {
  const url = new URL(req.url);
  const origin = env.B2_ORIGIN.replace(/\/$/, "");

  // /file/<bucket>/<key> -> forward as-is
  if (url.pathname.startsWith("/file/")) {
    return `${origin}${url.pathname}${url.search}`;
  }

  // ?key=<b2-key>
  const keyParam = url.searchParams.get("key");
  if (keyParam) {
    return `${origin}/file/${env.B2_BUCKET}/${keyParam.replace(/^\/+/, "")}`;
  }

  // /<key>
  if (url.pathname && url.pathname !== "/") {
    return `${origin}/file/${env.B2_BUCKET}${url.pathname}`;
  }

  return null;
}

function withCors(headers: Headers): Headers {
  const out = new Headers(headers);
  for (const [k, v] of Object.entries(BASE_CORS)) out.set(k, v);
  // Always advertise range support, even when upstream forgets to.
  if (!out.has("Accept-Ranges")) out.set("Accept-Ranges", "bytes");
  // Long-lived immutable cache: videos are content-addressed in B2.
  out.set("Cache-Control", "public, max-age=31536000, immutable");
  return out;
}

export default {
  async fetch(req: Request, env: Env): Promise<Response> {
    if (req.method === "OPTIONS") {
      return new Response(null, { status: 200, headers: withCors(new Headers()) });
    }
    if (req.method !== "GET" && req.method !== "HEAD") {
      return new Response("Method not allowed", {
        status: 405,
        headers: withCors(new Headers()),
      });
    }

    const upstream = buildUpstreamUrl(req, env);
    if (!upstream) {
      return new Response("Not found", { status: 404, headers: withCors(new Headers()) });
    }

    // Forward Range header verbatim. Strip hop-by-hop headers.
    const fwdHeaders = new Headers();
    const range = req.headers.get("Range");
    if (range) fwdHeaders.set("Range", range);
    const ifRange = req.headers.get("If-Range");
    if (ifRange) fwdHeaders.set("If-Range", ifRange);

    const upstreamReq = new Request(upstream, {
      method: req.method,
      headers: fwdHeaders,
      // Edge cache: include Range in the cache key implicitly via Cloudflare's
      // built-in range-aware caching. cacheEverything respects status 206.
      // @ts-expect-error - cf is a Cloudflare-specific RequestInit field
      cf: { cacheEverything: true, cacheTtl: 31536000 },
    });

    const upstreamResp = await fetch(upstreamReq);

    const headers = withCors(upstreamResp.headers);
    // Force video/mp4 when upstream returns generic octet-stream for .mp4 files.
    const ct = headers.get("Content-Type") || "";
    if (!ct || ct === "application/octet-stream") {
      const lower = upstream.toLowerCase();
      if (lower.endsWith(".mp4") || lower.endsWith(".m4v")) {
        headers.set("Content-Type", "video/mp4");
      } else if (lower.endsWith(".webm")) {
        headers.set("Content-Type", "video/webm");
      } else if (lower.endsWith(".mov")) {
        headers.set("Content-Type", "video/quicktime");
      }
    }

    // HEAD: drop the body but keep headers.
    if (req.method === "HEAD") {
      return new Response(null, { status: upstreamResp.status, headers });
    }

    return new Response(upstreamResp.body, {
      status: upstreamResp.status,
      headers,
    });
  },
};