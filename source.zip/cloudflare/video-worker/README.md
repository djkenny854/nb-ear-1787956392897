# EarlyMarket video worker

Cloudflare Worker that proxies the public Backblaze B2 video bucket and adds
HTTP range support + long-lived edge caching. This is what makes videos in the
app start playing in ~1s instead of waiting for the entire file to download.

See also `docs/CLOUDFLARE_VIDEO_WORKER.md` for the architectural overview.

## Deploy

```bash
cd cloudflare/video-worker
npm i -g wrangler   # if not installed
wrangler login
wrangler deploy
```

## DNS

In Cloudflare DNS for `earlymarketug.com`, add:

| Type  | Name   | Target | Proxy |
| ----- | ------ | ------ | ----- |
| AAAA  | videos | 100::  | ✅    |

The route in `wrangler.toml` (`videos.earlymarketug.com/*`) attaches the worker
to that hostname.

## App env var

After deploy, set in `.env` (Lovable already injects Supabase keys; add this
one manually):

```
VITE_VIDEO_CDN_BASE_URL=https://videos.earlymarketug.com
```

`src/utils/cdnUrl.ts > videoCdnUrl()` rewrites any stored B2 or legacy
`cdn.earlymarketug.com` video URL to the worker. No DB migration needed —
existing rows continue working transparently.

## URL shapes the worker accepts

- `https://videos.earlymarketug.com/file/<bucket>/<key>` (recommended)
- `https://videos.earlymarketug.com/<key>` (bucket defaults from env)
- `https://videos.earlymarketug.com/?key=<key>` (legacy fallback)

## What it sets on every response

- `Accept-Ranges: bytes`
- `Cache-Control: public, max-age=31536000, immutable`
- Full CORS (`*`, `GET, HEAD, OPTIONS`, exposes `Content-Range`, etc.)
- Correct `Content-Type` for `.mp4` / `.webm` / `.mov` when B2 returns
  `application/octet-stream`.

Range requests are forwarded verbatim; partial responses come back as `206`
with the correct `Content-Range`.